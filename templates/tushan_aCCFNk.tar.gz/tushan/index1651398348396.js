/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/axios/index.js":
/*!*************************************!*\
  !*** ./node_modules/axios/index.js ***!
  \*************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(/*! ./lib/axios */ "./node_modules/axios/lib/axios.js");

/***/ }),

/***/ "./node_modules/axios/lib/adapters/xhr.js":
/*!************************************************!*\
  !*** ./node_modules/axios/lib/adapters/xhr.js ***!
  \************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");
var settle = __webpack_require__(/*! ./../core/settle */ "./node_modules/axios/lib/core/settle.js");
var cookies = __webpack_require__(/*! ./../helpers/cookies */ "./node_modules/axios/lib/helpers/cookies.js");
var buildURL = __webpack_require__(/*! ./../helpers/buildURL */ "./node_modules/axios/lib/helpers/buildURL.js");
var buildFullPath = __webpack_require__(/*! ../core/buildFullPath */ "./node_modules/axios/lib/core/buildFullPath.js");
var parseHeaders = __webpack_require__(/*! ./../helpers/parseHeaders */ "./node_modules/axios/lib/helpers/parseHeaders.js");
var isURLSameOrigin = __webpack_require__(/*! ./../helpers/isURLSameOrigin */ "./node_modules/axios/lib/helpers/isURLSameOrigin.js");
var createError = __webpack_require__(/*! ../core/createError */ "./node_modules/axios/lib/core/createError.js");
var transitionalDefaults = __webpack_require__(/*! ../defaults/transitional */ "./node_modules/axios/lib/defaults/transitional.js");
var Cancel = __webpack_require__(/*! ../cancel/Cancel */ "./node_modules/axios/lib/cancel/Cancel.js");

module.exports = function xhrAdapter(config) {
  return new Promise(function dispatchXhrRequest(resolve, reject) {
    var requestData = config.data;
    var requestHeaders = config.headers;
    var responseType = config.responseType;
    var onCanceled;
    function done() {
      if (config.cancelToken) {
        config.cancelToken.unsubscribe(onCanceled);
      }

      if (config.signal) {
        config.signal.removeEventListener('abort', onCanceled);
      }
    }

    if (utils.isFormData(requestData)) {
      delete requestHeaders['Content-Type']; // Let the browser set it
    }

    var request = new XMLHttpRequest();

    // HTTP basic authentication
    if (config.auth) {
      var username = config.auth.username || '';
      var password = config.auth.password ? unescape(encodeURIComponent(config.auth.password)) : '';
      requestHeaders.Authorization = 'Basic ' + btoa(username + ':' + password);
    }

    var fullPath = buildFullPath(config.baseURL, config.url);
    request.open(config.method.toUpperCase(), buildURL(fullPath, config.params, config.paramsSerializer), true);

    // Set the request timeout in MS
    request.timeout = config.timeout;

    function onloadend() {
      if (!request) {
        return;
      }
      // Prepare the response
      var responseHeaders = 'getAllResponseHeaders' in request ? parseHeaders(request.getAllResponseHeaders()) : null;
      var responseData = !responseType || responseType === 'text' ||  responseType === 'json' ?
        request.responseText : request.response;
      var response = {
        data: responseData,
        status: request.status,
        statusText: request.statusText,
        headers: responseHeaders,
        config: config,
        request: request
      };

      settle(function _resolve(value) {
        resolve(value);
        done();
      }, function _reject(err) {
        reject(err);
        done();
      }, response);

      // Clean up request
      request = null;
    }

    if ('onloadend' in request) {
      // Use onloadend if available
      request.onloadend = onloadend;
    } else {
      // Listen for ready state to emulate onloadend
      request.onreadystatechange = function handleLoad() {
        if (!request || request.readyState !== 4) {
          return;
        }

        // The request errored out and we didn't get a response, this will be
        // handled by onerror instead
        // With one exception: request that using file: protocol, most browsers
        // will return status as 0 even though it's a successful request
        if (request.status === 0 && !(request.responseURL && request.responseURL.indexOf('file:') === 0)) {
          return;
        }
        // readystate handler is calling before onerror or ontimeout handlers,
        // so we should call onloadend on the next 'tick'
        setTimeout(onloadend);
      };
    }

    // Handle browser request cancellation (as opposed to a manual cancellation)
    request.onabort = function handleAbort() {
      if (!request) {
        return;
      }

      reject(createError('Request aborted', config, 'ECONNABORTED', request));

      // Clean up request
      request = null;
    };

    // Handle low level network errors
    request.onerror = function handleError() {
      // Real errors are hidden from us by the browser
      // onerror should only fire if it's a network error
      reject(createError('Network Error', config, null, request));

      // Clean up request
      request = null;
    };

    // Handle timeout
    request.ontimeout = function handleTimeout() {
      var timeoutErrorMessage = config.timeout ? 'timeout of ' + config.timeout + 'ms exceeded' : 'timeout exceeded';
      var transitional = config.transitional || transitionalDefaults;
      if (config.timeoutErrorMessage) {
        timeoutErrorMessage = config.timeoutErrorMessage;
      }
      reject(createError(
        timeoutErrorMessage,
        config,
        transitional.clarifyTimeoutError ? 'ETIMEDOUT' : 'ECONNABORTED',
        request));

      // Clean up request
      request = null;
    };

    // Add xsrf header
    // This is only done if running in a standard browser environment.
    // Specifically not if we're in a web worker, or react-native.
    if (utils.isStandardBrowserEnv()) {
      // Add xsrf header
      var xsrfValue = (config.withCredentials || isURLSameOrigin(fullPath)) && config.xsrfCookieName ?
        cookies.read(config.xsrfCookieName) :
        undefined;

      if (xsrfValue) {
        requestHeaders[config.xsrfHeaderName] = xsrfValue;
      }
    }

    // Add headers to the request
    if ('setRequestHeader' in request) {
      utils.forEach(requestHeaders, function setRequestHeader(val, key) {
        if (typeof requestData === 'undefined' && key.toLowerCase() === 'content-type') {
          // Remove Content-Type if data is undefined
          delete requestHeaders[key];
        } else {
          // Otherwise add header to the request
          request.setRequestHeader(key, val);
        }
      });
    }

    // Add withCredentials to request if needed
    if (!utils.isUndefined(config.withCredentials)) {
      request.withCredentials = !!config.withCredentials;
    }

    // Add responseType to request if needed
    if (responseType && responseType !== 'json') {
      request.responseType = config.responseType;
    }

    // Handle progress if needed
    if (typeof config.onDownloadProgress === 'function') {
      request.addEventListener('progress', config.onDownloadProgress);
    }

    // Not all browsers support upload events
    if (typeof config.onUploadProgress === 'function' && request.upload) {
      request.upload.addEventListener('progress', config.onUploadProgress);
    }

    if (config.cancelToken || config.signal) {
      // Handle cancellation
      // eslint-disable-next-line func-names
      onCanceled = function(cancel) {
        if (!request) {
          return;
        }
        reject(!cancel || (cancel && cancel.type) ? new Cancel('canceled') : cancel);
        request.abort();
        request = null;
      };

      config.cancelToken && config.cancelToken.subscribe(onCanceled);
      if (config.signal) {
        config.signal.aborted ? onCanceled() : config.signal.addEventListener('abort', onCanceled);
      }
    }

    if (!requestData) {
      requestData = null;
    }

    // Send the request
    request.send(requestData);
  });
};


/***/ }),

/***/ "./node_modules/axios/lib/axios.js":
/*!*****************************************!*\
  !*** ./node_modules/axios/lib/axios.js ***!
  \*****************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var utils = __webpack_require__(/*! ./utils */ "./node_modules/axios/lib/utils.js");
var bind = __webpack_require__(/*! ./helpers/bind */ "./node_modules/axios/lib/helpers/bind.js");
var Axios = __webpack_require__(/*! ./core/Axios */ "./node_modules/axios/lib/core/Axios.js");
var mergeConfig = __webpack_require__(/*! ./core/mergeConfig */ "./node_modules/axios/lib/core/mergeConfig.js");
var defaults = __webpack_require__(/*! ./defaults */ "./node_modules/axios/lib/defaults/index.js");

/**
 * Create an instance of Axios
 *
 * @param {Object} defaultConfig The default config for the instance
 * @return {Axios} A new instance of Axios
 */
function createInstance(defaultConfig) {
  var context = new Axios(defaultConfig);
  var instance = bind(Axios.prototype.request, context);

  // Copy axios.prototype to instance
  utils.extend(instance, Axios.prototype, context);

  // Copy context to instance
  utils.extend(instance, context);

  // Factory for creating new instances
  instance.create = function create(instanceConfig) {
    return createInstance(mergeConfig(defaultConfig, instanceConfig));
  };

  return instance;
}

// Create the default instance to be exported
var axios = createInstance(defaults);

// Expose Axios class to allow class inheritance
axios.Axios = Axios;

// Expose Cancel & CancelToken
axios.Cancel = __webpack_require__(/*! ./cancel/Cancel */ "./node_modules/axios/lib/cancel/Cancel.js");
axios.CancelToken = __webpack_require__(/*! ./cancel/CancelToken */ "./node_modules/axios/lib/cancel/CancelToken.js");
axios.isCancel = __webpack_require__(/*! ./cancel/isCancel */ "./node_modules/axios/lib/cancel/isCancel.js");
axios.VERSION = (__webpack_require__(/*! ./env/data */ "./node_modules/axios/lib/env/data.js").version);

// Expose all/spread
axios.all = function all(promises) {
  return Promise.all(promises);
};
axios.spread = __webpack_require__(/*! ./helpers/spread */ "./node_modules/axios/lib/helpers/spread.js");

// Expose isAxiosError
axios.isAxiosError = __webpack_require__(/*! ./helpers/isAxiosError */ "./node_modules/axios/lib/helpers/isAxiosError.js");

module.exports = axios;

// Allow use of default import syntax in TypeScript
module.exports["default"] = axios;


/***/ }),

/***/ "./node_modules/axios/lib/cancel/Cancel.js":
/*!*************************************************!*\
  !*** ./node_modules/axios/lib/cancel/Cancel.js ***!
  \*************************************************/
/***/ ((module) => {

"use strict";


/**
 * A `Cancel` is an object that is thrown when an operation is canceled.
 *
 * @class
 * @param {string=} message The message.
 */
function Cancel(message) {
  this.message = message;
}

Cancel.prototype.toString = function toString() {
  return 'Cancel' + (this.message ? ': ' + this.message : '');
};

Cancel.prototype.__CANCEL__ = true;

module.exports = Cancel;


/***/ }),

/***/ "./node_modules/axios/lib/cancel/CancelToken.js":
/*!******************************************************!*\
  !*** ./node_modules/axios/lib/cancel/CancelToken.js ***!
  \******************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var Cancel = __webpack_require__(/*! ./Cancel */ "./node_modules/axios/lib/cancel/Cancel.js");

/**
 * A `CancelToken` is an object that can be used to request cancellation of an operation.
 *
 * @class
 * @param {Function} executor The executor function.
 */
function CancelToken(executor) {
  if (typeof executor !== 'function') {
    throw new TypeError('executor must be a function.');
  }

  var resolvePromise;

  this.promise = new Promise(function promiseExecutor(resolve) {
    resolvePromise = resolve;
  });

  var token = this;

  // eslint-disable-next-line func-names
  this.promise.then(function(cancel) {
    if (!token._listeners) return;

    var i;
    var l = token._listeners.length;

    for (i = 0; i < l; i++) {
      token._listeners[i](cancel);
    }
    token._listeners = null;
  });

  // eslint-disable-next-line func-names
  this.promise.then = function(onfulfilled) {
    var _resolve;
    // eslint-disable-next-line func-names
    var promise = new Promise(function(resolve) {
      token.subscribe(resolve);
      _resolve = resolve;
    }).then(onfulfilled);

    promise.cancel = function reject() {
      token.unsubscribe(_resolve);
    };

    return promise;
  };

  executor(function cancel(message) {
    if (token.reason) {
      // Cancellation has already been requested
      return;
    }

    token.reason = new Cancel(message);
    resolvePromise(token.reason);
  });
}

/**
 * Throws a `Cancel` if cancellation has been requested.
 */
CancelToken.prototype.throwIfRequested = function throwIfRequested() {
  if (this.reason) {
    throw this.reason;
  }
};

/**
 * Subscribe to the cancel signal
 */

CancelToken.prototype.subscribe = function subscribe(listener) {
  if (this.reason) {
    listener(this.reason);
    return;
  }

  if (this._listeners) {
    this._listeners.push(listener);
  } else {
    this._listeners = [listener];
  }
};

/**
 * Unsubscribe from the cancel signal
 */

CancelToken.prototype.unsubscribe = function unsubscribe(listener) {
  if (!this._listeners) {
    return;
  }
  var index = this._listeners.indexOf(listener);
  if (index !== -1) {
    this._listeners.splice(index, 1);
  }
};

/**
 * Returns an object that contains a new `CancelToken` and a function that, when called,
 * cancels the `CancelToken`.
 */
CancelToken.source = function source() {
  var cancel;
  var token = new CancelToken(function executor(c) {
    cancel = c;
  });
  return {
    token: token,
    cancel: cancel
  };
};

module.exports = CancelToken;


/***/ }),

/***/ "./node_modules/axios/lib/cancel/isCancel.js":
/*!***************************************************!*\
  !*** ./node_modules/axios/lib/cancel/isCancel.js ***!
  \***************************************************/
/***/ ((module) => {

"use strict";


module.exports = function isCancel(value) {
  return !!(value && value.__CANCEL__);
};


/***/ }),

/***/ "./node_modules/axios/lib/core/Axios.js":
/*!**********************************************!*\
  !*** ./node_modules/axios/lib/core/Axios.js ***!
  \**********************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");
var buildURL = __webpack_require__(/*! ../helpers/buildURL */ "./node_modules/axios/lib/helpers/buildURL.js");
var InterceptorManager = __webpack_require__(/*! ./InterceptorManager */ "./node_modules/axios/lib/core/InterceptorManager.js");
var dispatchRequest = __webpack_require__(/*! ./dispatchRequest */ "./node_modules/axios/lib/core/dispatchRequest.js");
var mergeConfig = __webpack_require__(/*! ./mergeConfig */ "./node_modules/axios/lib/core/mergeConfig.js");
var validator = __webpack_require__(/*! ../helpers/validator */ "./node_modules/axios/lib/helpers/validator.js");

var validators = validator.validators;
/**
 * Create a new instance of Axios
 *
 * @param {Object} instanceConfig The default config for the instance
 */
function Axios(instanceConfig) {
  this.defaults = instanceConfig;
  this.interceptors = {
    request: new InterceptorManager(),
    response: new InterceptorManager()
  };
}

/**
 * Dispatch a request
 *
 * @param {Object} config The config specific for this request (merged with this.defaults)
 */
Axios.prototype.request = function request(configOrUrl, config) {
  /*eslint no-param-reassign:0*/
  // Allow for axios('example/url'[, config]) a la fetch API
  if (typeof configOrUrl === 'string') {
    config = config || {};
    config.url = configOrUrl;
  } else {
    config = configOrUrl || {};
  }

  config = mergeConfig(this.defaults, config);

  // Set config.method
  if (config.method) {
    config.method = config.method.toLowerCase();
  } else if (this.defaults.method) {
    config.method = this.defaults.method.toLowerCase();
  } else {
    config.method = 'get';
  }

  var transitional = config.transitional;

  if (transitional !== undefined) {
    validator.assertOptions(transitional, {
      silentJSONParsing: validators.transitional(validators.boolean),
      forcedJSONParsing: validators.transitional(validators.boolean),
      clarifyTimeoutError: validators.transitional(validators.boolean)
    }, false);
  }

  // filter out skipped interceptors
  var requestInterceptorChain = [];
  var synchronousRequestInterceptors = true;
  this.interceptors.request.forEach(function unshiftRequestInterceptors(interceptor) {
    if (typeof interceptor.runWhen === 'function' && interceptor.runWhen(config) === false) {
      return;
    }

    synchronousRequestInterceptors = synchronousRequestInterceptors && interceptor.synchronous;

    requestInterceptorChain.unshift(interceptor.fulfilled, interceptor.rejected);
  });

  var responseInterceptorChain = [];
  this.interceptors.response.forEach(function pushResponseInterceptors(interceptor) {
    responseInterceptorChain.push(interceptor.fulfilled, interceptor.rejected);
  });

  var promise;

  if (!synchronousRequestInterceptors) {
    var chain = [dispatchRequest, undefined];

    Array.prototype.unshift.apply(chain, requestInterceptorChain);
    chain = chain.concat(responseInterceptorChain);

    promise = Promise.resolve(config);
    while (chain.length) {
      promise = promise.then(chain.shift(), chain.shift());
    }

    return promise;
  }


  var newConfig = config;
  while (requestInterceptorChain.length) {
    var onFulfilled = requestInterceptorChain.shift();
    var onRejected = requestInterceptorChain.shift();
    try {
      newConfig = onFulfilled(newConfig);
    } catch (error) {
      onRejected(error);
      break;
    }
  }

  try {
    promise = dispatchRequest(newConfig);
  } catch (error) {
    return Promise.reject(error);
  }

  while (responseInterceptorChain.length) {
    promise = promise.then(responseInterceptorChain.shift(), responseInterceptorChain.shift());
  }

  return promise;
};

Axios.prototype.getUri = function getUri(config) {
  config = mergeConfig(this.defaults, config);
  return buildURL(config.url, config.params, config.paramsSerializer).replace(/^\?/, '');
};

// Provide aliases for supported request methods
utils.forEach(['delete', 'get', 'head', 'options'], function forEachMethodNoData(method) {
  /*eslint func-names:0*/
  Axios.prototype[method] = function(url, config) {
    return this.request(mergeConfig(config || {}, {
      method: method,
      url: url,
      data: (config || {}).data
    }));
  };
});

utils.forEach(['post', 'put', 'patch'], function forEachMethodWithData(method) {
  /*eslint func-names:0*/
  Axios.prototype[method] = function(url, data, config) {
    return this.request(mergeConfig(config || {}, {
      method: method,
      url: url,
      data: data
    }));
  };
});

module.exports = Axios;


/***/ }),

/***/ "./node_modules/axios/lib/core/InterceptorManager.js":
/*!***********************************************************!*\
  !*** ./node_modules/axios/lib/core/InterceptorManager.js ***!
  \***********************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");

function InterceptorManager() {
  this.handlers = [];
}

/**
 * Add a new interceptor to the stack
 *
 * @param {Function} fulfilled The function to handle `then` for a `Promise`
 * @param {Function} rejected The function to handle `reject` for a `Promise`
 *
 * @return {Number} An ID used to remove interceptor later
 */
InterceptorManager.prototype.use = function use(fulfilled, rejected, options) {
  this.handlers.push({
    fulfilled: fulfilled,
    rejected: rejected,
    synchronous: options ? options.synchronous : false,
    runWhen: options ? options.runWhen : null
  });
  return this.handlers.length - 1;
};

/**
 * Remove an interceptor from the stack
 *
 * @param {Number} id The ID that was returned by `use`
 */
InterceptorManager.prototype.eject = function eject(id) {
  if (this.handlers[id]) {
    this.handlers[id] = null;
  }
};

/**
 * Iterate over all the registered interceptors
 *
 * This method is particularly useful for skipping over any
 * interceptors that may have become `null` calling `eject`.
 *
 * @param {Function} fn The function to call for each interceptor
 */
InterceptorManager.prototype.forEach = function forEach(fn) {
  utils.forEach(this.handlers, function forEachHandler(h) {
    if (h !== null) {
      fn(h);
    }
  });
};

module.exports = InterceptorManager;


/***/ }),

/***/ "./node_modules/axios/lib/core/buildFullPath.js":
/*!******************************************************!*\
  !*** ./node_modules/axios/lib/core/buildFullPath.js ***!
  \******************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var isAbsoluteURL = __webpack_require__(/*! ../helpers/isAbsoluteURL */ "./node_modules/axios/lib/helpers/isAbsoluteURL.js");
var combineURLs = __webpack_require__(/*! ../helpers/combineURLs */ "./node_modules/axios/lib/helpers/combineURLs.js");

/**
 * Creates a new URL by combining the baseURL with the requestedURL,
 * only when the requestedURL is not already an absolute URL.
 * If the requestURL is absolute, this function returns the requestedURL untouched.
 *
 * @param {string} baseURL The base URL
 * @param {string} requestedURL Absolute or relative URL to combine
 * @returns {string} The combined full path
 */
module.exports = function buildFullPath(baseURL, requestedURL) {
  if (baseURL && !isAbsoluteURL(requestedURL)) {
    return combineURLs(baseURL, requestedURL);
  }
  return requestedURL;
};


/***/ }),

/***/ "./node_modules/axios/lib/core/createError.js":
/*!****************************************************!*\
  !*** ./node_modules/axios/lib/core/createError.js ***!
  \****************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var enhanceError = __webpack_require__(/*! ./enhanceError */ "./node_modules/axios/lib/core/enhanceError.js");

/**
 * Create an Error with the specified message, config, error code, request and response.
 *
 * @param {string} message The error message.
 * @param {Object} config The config.
 * @param {string} [code] The error code (for example, 'ECONNABORTED').
 * @param {Object} [request] The request.
 * @param {Object} [response] The response.
 * @returns {Error} The created error.
 */
module.exports = function createError(message, config, code, request, response) {
  var error = new Error(message);
  return enhanceError(error, config, code, request, response);
};


/***/ }),

/***/ "./node_modules/axios/lib/core/dispatchRequest.js":
/*!********************************************************!*\
  !*** ./node_modules/axios/lib/core/dispatchRequest.js ***!
  \********************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");
var transformData = __webpack_require__(/*! ./transformData */ "./node_modules/axios/lib/core/transformData.js");
var isCancel = __webpack_require__(/*! ../cancel/isCancel */ "./node_modules/axios/lib/cancel/isCancel.js");
var defaults = __webpack_require__(/*! ../defaults */ "./node_modules/axios/lib/defaults/index.js");
var Cancel = __webpack_require__(/*! ../cancel/Cancel */ "./node_modules/axios/lib/cancel/Cancel.js");

/**
 * Throws a `Cancel` if cancellation has been requested.
 */
function throwIfCancellationRequested(config) {
  if (config.cancelToken) {
    config.cancelToken.throwIfRequested();
  }

  if (config.signal && config.signal.aborted) {
    throw new Cancel('canceled');
  }
}

/**
 * Dispatch a request to the server using the configured adapter.
 *
 * @param {object} config The config that is to be used for the request
 * @returns {Promise} The Promise to be fulfilled
 */
module.exports = function dispatchRequest(config) {
  throwIfCancellationRequested(config);

  // Ensure headers exist
  config.headers = config.headers || {};

  // Transform request data
  config.data = transformData.call(
    config,
    config.data,
    config.headers,
    config.transformRequest
  );

  // Flatten headers
  config.headers = utils.merge(
    config.headers.common || {},
    config.headers[config.method] || {},
    config.headers
  );

  utils.forEach(
    ['delete', 'get', 'head', 'post', 'put', 'patch', 'common'],
    function cleanHeaderConfig(method) {
      delete config.headers[method];
    }
  );

  var adapter = config.adapter || defaults.adapter;

  return adapter(config).then(function onAdapterResolution(response) {
    throwIfCancellationRequested(config);

    // Transform response data
    response.data = transformData.call(
      config,
      response.data,
      response.headers,
      config.transformResponse
    );

    return response;
  }, function onAdapterRejection(reason) {
    if (!isCancel(reason)) {
      throwIfCancellationRequested(config);

      // Transform response data
      if (reason && reason.response) {
        reason.response.data = transformData.call(
          config,
          reason.response.data,
          reason.response.headers,
          config.transformResponse
        );
      }
    }

    return Promise.reject(reason);
  });
};


/***/ }),

/***/ "./node_modules/axios/lib/core/enhanceError.js":
/*!*****************************************************!*\
  !*** ./node_modules/axios/lib/core/enhanceError.js ***!
  \*****************************************************/
/***/ ((module) => {

"use strict";


/**
 * Update an Error with the specified config, error code, and response.
 *
 * @param {Error} error The error to update.
 * @param {Object} config The config.
 * @param {string} [code] The error code (for example, 'ECONNABORTED').
 * @param {Object} [request] The request.
 * @param {Object} [response] The response.
 * @returns {Error} The error.
 */
module.exports = function enhanceError(error, config, code, request, response) {
  error.config = config;
  if (code) {
    error.code = code;
  }

  error.request = request;
  error.response = response;
  error.isAxiosError = true;

  error.toJSON = function toJSON() {
    return {
      // Standard
      message: this.message,
      name: this.name,
      // Microsoft
      description: this.description,
      number: this.number,
      // Mozilla
      fileName: this.fileName,
      lineNumber: this.lineNumber,
      columnNumber: this.columnNumber,
      stack: this.stack,
      // Axios
      config: this.config,
      code: this.code,
      status: this.response && this.response.status ? this.response.status : null
    };
  };
  return error;
};


/***/ }),

/***/ "./node_modules/axios/lib/core/mergeConfig.js":
/*!****************************************************!*\
  !*** ./node_modules/axios/lib/core/mergeConfig.js ***!
  \****************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var utils = __webpack_require__(/*! ../utils */ "./node_modules/axios/lib/utils.js");

/**
 * Config-specific merge-function which creates a new config-object
 * by merging two configuration objects together.
 *
 * @param {Object} config1
 * @param {Object} config2
 * @returns {Object} New object resulting from merging config2 to config1
 */
module.exports = function mergeConfig(config1, config2) {
  // eslint-disable-next-line no-param-reassign
  config2 = config2 || {};
  var config = {};

  function getMergedValue(target, source) {
    if (utils.isPlainObject(target) && utils.isPlainObject(source)) {
      return utils.merge(target, source);
    } else if (utils.isPlainObject(source)) {
      return utils.merge({}, source);
    } else if (utils.isArray(source)) {
      return source.slice();
    }
    return source;
  }

  // eslint-disable-next-line consistent-return
  function mergeDeepProperties(prop) {
    if (!utils.isUndefined(config2[prop])) {
      return getMergedValue(config1[prop], config2[prop]);
    } else if (!utils.isUndefined(config1[prop])) {
      return getMergedValue(undefined, config1[prop]);
    }
  }

  // eslint-disable-next-line consistent-return
  function valueFromConfig2(prop) {
    if (!utils.isUndefined(config2[prop])) {
      return getMergedValue(undefined, config2[prop]);
    }
  }

  // eslint-disable-next-line consistent-return
  function defaultToConfig2(prop) {
    if (!utils.isUndefined(config2[prop])) {
      return getMergedValue(undefined, config2[prop]);
    } else if (!utils.isUndefined(config1[prop])) {
      return getMergedValue(undefined, config1[prop]);
    }
  }

  // eslint-disable-next-line consistent-return
  function mergeDirectKeys(prop) {
    if (prop in config2) {
      return getMergedValue(config1[prop], config2[prop]);
    } else if (prop in config1) {
      return getMergedValue(undefined, config1[prop]);
    }
  }

  var mergeMap = {
    'url': valueFromConfig2,
    'method': valueFromConfig2,
    'data': valueFromConfig2,
    'baseURL': defaultToConfig2,
    'transformRequest': defaultToConfig2,
    'transformResponse': defaultToConfig2,
    'paramsSerializer': defaultToConfig2,
    'timeout': defaultToConfig2,
    'timeoutMessage': defaultToConfig2,
    'withCredentials': defaultToConfig2,
    'adapter': defaultToConfig2,
    'responseType': defaultToConfig2,
    'xsrfCookieName': defaultToConfig2,
    'xsrfHeaderName': defaultToConfig2,
    'onUploadProgress': defaultToConfig2,
    'onDownloadProgress': defaultToConfig2,
    'decompress': defaultToConfig2,
    'maxContentLength': defaultToConfig2,
    'maxBodyLength': defaultToConfig2,
    'transport': defaultToConfig2,
    'httpAgent': defaultToConfig2,
    'httpsAgent': defaultToConfig2,
    'cancelToken': defaultToConfig2,
    'socketPath': defaultToConfig2,
    'responseEncoding': defaultToConfig2,
    'validateStatus': mergeDirectKeys
  };

  utils.forEach(Object.keys(config1).concat(Object.keys(config2)), function computeConfigValue(prop) {
    var merge = mergeMap[prop] || mergeDeepProperties;
    var configValue = merge(prop);
    (utils.isUndefined(configValue) && merge !== mergeDirectKeys) || (config[prop] = configValue);
  });

  return config;
};


/***/ }),

/***/ "./node_modules/axios/lib/core/settle.js":
/*!***********************************************!*\
  !*** ./node_modules/axios/lib/core/settle.js ***!
  \***********************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var createError = __webpack_require__(/*! ./createError */ "./node_modules/axios/lib/core/createError.js");

/**
 * Resolve or reject a Promise based on response status.
 *
 * @param {Function} resolve A function that resolves the promise.
 * @param {Function} reject A function that rejects the promise.
 * @param {object} response The response.
 */
module.exports = function settle(resolve, reject, response) {
  var validateStatus = response.config.validateStatus;
  if (!response.status || !validateStatus || validateStatus(response.status)) {
    resolve(response);
  } else {
    reject(createError(
      'Request failed with status code ' + response.status,
      response.config,
      null,
      response.request,
      response
    ));
  }
};


/***/ }),

/***/ "./node_modules/axios/lib/core/transformData.js":
/*!******************************************************!*\
  !*** ./node_modules/axios/lib/core/transformData.js ***!
  \******************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");
var defaults = __webpack_require__(/*! ../defaults */ "./node_modules/axios/lib/defaults/index.js");

/**
 * Transform the data for a request or a response
 *
 * @param {Object|String} data The data to be transformed
 * @param {Array} headers The headers for the request or response
 * @param {Array|Function} fns A single function or Array of functions
 * @returns {*} The resulting transformed data
 */
module.exports = function transformData(data, headers, fns) {
  var context = this || defaults;
  /*eslint no-param-reassign:0*/
  utils.forEach(fns, function transform(fn) {
    data = fn.call(context, data, headers);
  });

  return data;
};


/***/ }),

/***/ "./node_modules/axios/lib/defaults/index.js":
/*!**************************************************!*\
  !*** ./node_modules/axios/lib/defaults/index.js ***!
  \**************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var utils = __webpack_require__(/*! ../utils */ "./node_modules/axios/lib/utils.js");
var normalizeHeaderName = __webpack_require__(/*! ../helpers/normalizeHeaderName */ "./node_modules/axios/lib/helpers/normalizeHeaderName.js");
var enhanceError = __webpack_require__(/*! ../core/enhanceError */ "./node_modules/axios/lib/core/enhanceError.js");
var transitionalDefaults = __webpack_require__(/*! ./transitional */ "./node_modules/axios/lib/defaults/transitional.js");

var DEFAULT_CONTENT_TYPE = {
  'Content-Type': 'application/x-www-form-urlencoded'
};

function setContentTypeIfUnset(headers, value) {
  if (!utils.isUndefined(headers) && utils.isUndefined(headers['Content-Type'])) {
    headers['Content-Type'] = value;
  }
}

function getDefaultAdapter() {
  var adapter;
  if (typeof XMLHttpRequest !== 'undefined') {
    // For browsers use XHR adapter
    adapter = __webpack_require__(/*! ../adapters/xhr */ "./node_modules/axios/lib/adapters/xhr.js");
  } else if (typeof process !== 'undefined' && Object.prototype.toString.call(process) === '[object process]') {
    // For node use HTTP adapter
    adapter = __webpack_require__(/*! ../adapters/http */ "./node_modules/axios/lib/adapters/xhr.js");
  }
  return adapter;
}

function stringifySafely(rawValue, parser, encoder) {
  if (utils.isString(rawValue)) {
    try {
      (parser || JSON.parse)(rawValue);
      return utils.trim(rawValue);
    } catch (e) {
      if (e.name !== 'SyntaxError') {
        throw e;
      }
    }
  }

  return (encoder || JSON.stringify)(rawValue);
}

var defaults = {

  transitional: transitionalDefaults,

  adapter: getDefaultAdapter(),

  transformRequest: [function transformRequest(data, headers) {
    normalizeHeaderName(headers, 'Accept');
    normalizeHeaderName(headers, 'Content-Type');

    if (utils.isFormData(data) ||
      utils.isArrayBuffer(data) ||
      utils.isBuffer(data) ||
      utils.isStream(data) ||
      utils.isFile(data) ||
      utils.isBlob(data)
    ) {
      return data;
    }
    if (utils.isArrayBufferView(data)) {
      return data.buffer;
    }
    if (utils.isURLSearchParams(data)) {
      setContentTypeIfUnset(headers, 'application/x-www-form-urlencoded;charset=utf-8');
      return data.toString();
    }
    if (utils.isObject(data) || (headers && headers['Content-Type'] === 'application/json')) {
      setContentTypeIfUnset(headers, 'application/json');
      return stringifySafely(data);
    }
    return data;
  }],

  transformResponse: [function transformResponse(data) {
    var transitional = this.transitional || defaults.transitional;
    var silentJSONParsing = transitional && transitional.silentJSONParsing;
    var forcedJSONParsing = transitional && transitional.forcedJSONParsing;
    var strictJSONParsing = !silentJSONParsing && this.responseType === 'json';

    if (strictJSONParsing || (forcedJSONParsing && utils.isString(data) && data.length)) {
      try {
        return JSON.parse(data);
      } catch (e) {
        if (strictJSONParsing) {
          if (e.name === 'SyntaxError') {
            throw enhanceError(e, this, 'E_JSON_PARSE');
          }
          throw e;
        }
      }
    }

    return data;
  }],

  /**
   * A timeout in milliseconds to abort a request. If set to 0 (default) a
   * timeout is not created.
   */
  timeout: 0,

  xsrfCookieName: 'XSRF-TOKEN',
  xsrfHeaderName: 'X-XSRF-TOKEN',

  maxContentLength: -1,
  maxBodyLength: -1,

  validateStatus: function validateStatus(status) {
    return status >= 200 && status < 300;
  },

  headers: {
    common: {
      'Accept': 'application/json, text/plain, */*'
    }
  }
};

utils.forEach(['delete', 'get', 'head'], function forEachMethodNoData(method) {
  defaults.headers[method] = {};
});

utils.forEach(['post', 'put', 'patch'], function forEachMethodWithData(method) {
  defaults.headers[method] = utils.merge(DEFAULT_CONTENT_TYPE);
});

module.exports = defaults;


/***/ }),

/***/ "./node_modules/axios/lib/defaults/transitional.js":
/*!*********************************************************!*\
  !*** ./node_modules/axios/lib/defaults/transitional.js ***!
  \*********************************************************/
/***/ ((module) => {

"use strict";


module.exports = {
  silentJSONParsing: true,
  forcedJSONParsing: true,
  clarifyTimeoutError: false
};


/***/ }),

/***/ "./node_modules/axios/lib/env/data.js":
/*!********************************************!*\
  !*** ./node_modules/axios/lib/env/data.js ***!
  \********************************************/
/***/ ((module) => {

module.exports = {
  "version": "0.26.1"
};

/***/ }),

/***/ "./node_modules/axios/lib/helpers/bind.js":
/*!************************************************!*\
  !*** ./node_modules/axios/lib/helpers/bind.js ***!
  \************************************************/
/***/ ((module) => {

"use strict";


module.exports = function bind(fn, thisArg) {
  return function wrap() {
    var args = new Array(arguments.length);
    for (var i = 0; i < args.length; i++) {
      args[i] = arguments[i];
    }
    return fn.apply(thisArg, args);
  };
};


/***/ }),

/***/ "./node_modules/axios/lib/helpers/buildURL.js":
/*!****************************************************!*\
  !*** ./node_modules/axios/lib/helpers/buildURL.js ***!
  \****************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");

function encode(val) {
  return encodeURIComponent(val).
    replace(/%3A/gi, ':').
    replace(/%24/g, '$').
    replace(/%2C/gi, ',').
    replace(/%20/g, '+').
    replace(/%5B/gi, '[').
    replace(/%5D/gi, ']');
}

/**
 * Build a URL by appending params to the end
 *
 * @param {string} url The base of the url (e.g., http://www.google.com)
 * @param {object} [params] The params to be appended
 * @returns {string} The formatted url
 */
module.exports = function buildURL(url, params, paramsSerializer) {
  /*eslint no-param-reassign:0*/
  if (!params) {
    return url;
  }

  var serializedParams;
  if (paramsSerializer) {
    serializedParams = paramsSerializer(params);
  } else if (utils.isURLSearchParams(params)) {
    serializedParams = params.toString();
  } else {
    var parts = [];

    utils.forEach(params, function serialize(val, key) {
      if (val === null || typeof val === 'undefined') {
        return;
      }

      if (utils.isArray(val)) {
        key = key + '[]';
      } else {
        val = [val];
      }

      utils.forEach(val, function parseValue(v) {
        if (utils.isDate(v)) {
          v = v.toISOString();
        } else if (utils.isObject(v)) {
          v = JSON.stringify(v);
        }
        parts.push(encode(key) + '=' + encode(v));
      });
    });

    serializedParams = parts.join('&');
  }

  if (serializedParams) {
    var hashmarkIndex = url.indexOf('#');
    if (hashmarkIndex !== -1) {
      url = url.slice(0, hashmarkIndex);
    }

    url += (url.indexOf('?') === -1 ? '?' : '&') + serializedParams;
  }

  return url;
};


/***/ }),

/***/ "./node_modules/axios/lib/helpers/combineURLs.js":
/*!*******************************************************!*\
  !*** ./node_modules/axios/lib/helpers/combineURLs.js ***!
  \*******************************************************/
/***/ ((module) => {

"use strict";


/**
 * Creates a new URL by combining the specified URLs
 *
 * @param {string} baseURL The base URL
 * @param {string} relativeURL The relative URL
 * @returns {string} The combined URL
 */
module.exports = function combineURLs(baseURL, relativeURL) {
  return relativeURL
    ? baseURL.replace(/\/+$/, '') + '/' + relativeURL.replace(/^\/+/, '')
    : baseURL;
};


/***/ }),

/***/ "./node_modules/axios/lib/helpers/cookies.js":
/*!***************************************************!*\
  !*** ./node_modules/axios/lib/helpers/cookies.js ***!
  \***************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");

module.exports = (
  utils.isStandardBrowserEnv() ?

  // Standard browser envs support document.cookie
    (function standardBrowserEnv() {
      return {
        write: function write(name, value, expires, path, domain, secure) {
          var cookie = [];
          cookie.push(name + '=' + encodeURIComponent(value));

          if (utils.isNumber(expires)) {
            cookie.push('expires=' + new Date(expires).toGMTString());
          }

          if (utils.isString(path)) {
            cookie.push('path=' + path);
          }

          if (utils.isString(domain)) {
            cookie.push('domain=' + domain);
          }

          if (secure === true) {
            cookie.push('secure');
          }

          document.cookie = cookie.join('; ');
        },

        read: function read(name) {
          var match = document.cookie.match(new RegExp('(^|;\\s*)(' + name + ')=([^;]*)'));
          return (match ? decodeURIComponent(match[3]) : null);
        },

        remove: function remove(name) {
          this.write(name, '', Date.now() - 86400000);
        }
      };
    })() :

  // Non standard browser env (web workers, react-native) lack needed support.
    (function nonStandardBrowserEnv() {
      return {
        write: function write() {},
        read: function read() { return null; },
        remove: function remove() {}
      };
    })()
);


/***/ }),

/***/ "./node_modules/axios/lib/helpers/isAbsoluteURL.js":
/*!*********************************************************!*\
  !*** ./node_modules/axios/lib/helpers/isAbsoluteURL.js ***!
  \*********************************************************/
/***/ ((module) => {

"use strict";


/**
 * Determines whether the specified URL is absolute
 *
 * @param {string} url The URL to test
 * @returns {boolean} True if the specified URL is absolute, otherwise false
 */
module.exports = function isAbsoluteURL(url) {
  // A URL is considered absolute if it begins with "<scheme>://" or "//" (protocol-relative URL).
  // RFC 3986 defines scheme name as a sequence of characters beginning with a letter and followed
  // by any combination of letters, digits, plus, period, or hyphen.
  return /^([a-z][a-z\d+\-.]*:)?\/\//i.test(url);
};


/***/ }),

/***/ "./node_modules/axios/lib/helpers/isAxiosError.js":
/*!********************************************************!*\
  !*** ./node_modules/axios/lib/helpers/isAxiosError.js ***!
  \********************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");

/**
 * Determines whether the payload is an error thrown by Axios
 *
 * @param {*} payload The value to test
 * @returns {boolean} True if the payload is an error thrown by Axios, otherwise false
 */
module.exports = function isAxiosError(payload) {
  return utils.isObject(payload) && (payload.isAxiosError === true);
};


/***/ }),

/***/ "./node_modules/axios/lib/helpers/isURLSameOrigin.js":
/*!***********************************************************!*\
  !*** ./node_modules/axios/lib/helpers/isURLSameOrigin.js ***!
  \***********************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");

module.exports = (
  utils.isStandardBrowserEnv() ?

  // Standard browser envs have full support of the APIs needed to test
  // whether the request URL is of the same origin as current location.
    (function standardBrowserEnv() {
      var msie = /(msie|trident)/i.test(navigator.userAgent);
      var urlParsingNode = document.createElement('a');
      var originURL;

      /**
    * Parse a URL to discover it's components
    *
    * @param {String} url The URL to be parsed
    * @returns {Object}
    */
      function resolveURL(url) {
        var href = url;

        if (msie) {
        // IE needs attribute set twice to normalize properties
          urlParsingNode.setAttribute('href', href);
          href = urlParsingNode.href;
        }

        urlParsingNode.setAttribute('href', href);

        // urlParsingNode provides the UrlUtils interface - http://url.spec.whatwg.org/#urlutils
        return {
          href: urlParsingNode.href,
          protocol: urlParsingNode.protocol ? urlParsingNode.protocol.replace(/:$/, '') : '',
          host: urlParsingNode.host,
          search: urlParsingNode.search ? urlParsingNode.search.replace(/^\?/, '') : '',
          hash: urlParsingNode.hash ? urlParsingNode.hash.replace(/^#/, '') : '',
          hostname: urlParsingNode.hostname,
          port: urlParsingNode.port,
          pathname: (urlParsingNode.pathname.charAt(0) === '/') ?
            urlParsingNode.pathname :
            '/' + urlParsingNode.pathname
        };
      }

      originURL = resolveURL(window.location.href);

      /**
    * Determine if a URL shares the same origin as the current location
    *
    * @param {String} requestURL The URL to test
    * @returns {boolean} True if URL shares the same origin, otherwise false
    */
      return function isURLSameOrigin(requestURL) {
        var parsed = (utils.isString(requestURL)) ? resolveURL(requestURL) : requestURL;
        return (parsed.protocol === originURL.protocol &&
            parsed.host === originURL.host);
      };
    })() :

  // Non standard browser envs (web workers, react-native) lack needed support.
    (function nonStandardBrowserEnv() {
      return function isURLSameOrigin() {
        return true;
      };
    })()
);


/***/ }),

/***/ "./node_modules/axios/lib/helpers/normalizeHeaderName.js":
/*!***************************************************************!*\
  !*** ./node_modules/axios/lib/helpers/normalizeHeaderName.js ***!
  \***************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var utils = __webpack_require__(/*! ../utils */ "./node_modules/axios/lib/utils.js");

module.exports = function normalizeHeaderName(headers, normalizedName) {
  utils.forEach(headers, function processHeader(value, name) {
    if (name !== normalizedName && name.toUpperCase() === normalizedName.toUpperCase()) {
      headers[normalizedName] = value;
      delete headers[name];
    }
  });
};


/***/ }),

/***/ "./node_modules/axios/lib/helpers/parseHeaders.js":
/*!********************************************************!*\
  !*** ./node_modules/axios/lib/helpers/parseHeaders.js ***!
  \********************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");

// Headers whose duplicates are ignored by node
// c.f. https://nodejs.org/api/http.html#http_message_headers
var ignoreDuplicateOf = [
  'age', 'authorization', 'content-length', 'content-type', 'etag',
  'expires', 'from', 'host', 'if-modified-since', 'if-unmodified-since',
  'last-modified', 'location', 'max-forwards', 'proxy-authorization',
  'referer', 'retry-after', 'user-agent'
];

/**
 * Parse headers into an object
 *
 * ```
 * Date: Wed, 27 Aug 2014 08:58:49 GMT
 * Content-Type: application/json
 * Connection: keep-alive
 * Transfer-Encoding: chunked
 * ```
 *
 * @param {String} headers Headers needing to be parsed
 * @returns {Object} Headers parsed into an object
 */
module.exports = function parseHeaders(headers) {
  var parsed = {};
  var key;
  var val;
  var i;

  if (!headers) { return parsed; }

  utils.forEach(headers.split('\n'), function parser(line) {
    i = line.indexOf(':');
    key = utils.trim(line.substr(0, i)).toLowerCase();
    val = utils.trim(line.substr(i + 1));

    if (key) {
      if (parsed[key] && ignoreDuplicateOf.indexOf(key) >= 0) {
        return;
      }
      if (key === 'set-cookie') {
        parsed[key] = (parsed[key] ? parsed[key] : []).concat([val]);
      } else {
        parsed[key] = parsed[key] ? parsed[key] + ', ' + val : val;
      }
    }
  });

  return parsed;
};


/***/ }),

/***/ "./node_modules/axios/lib/helpers/spread.js":
/*!**************************************************!*\
  !*** ./node_modules/axios/lib/helpers/spread.js ***!
  \**************************************************/
/***/ ((module) => {

"use strict";


/**
 * Syntactic sugar for invoking a function and expanding an array for arguments.
 *
 * Common use case would be to use `Function.prototype.apply`.
 *
 *  ```js
 *  function f(x, y, z) {}
 *  var args = [1, 2, 3];
 *  f.apply(null, args);
 *  ```
 *
 * With `spread` this example can be re-written.
 *
 *  ```js
 *  spread(function(x, y, z) {})([1, 2, 3]);
 *  ```
 *
 * @param {Function} callback
 * @returns {Function}
 */
module.exports = function spread(callback) {
  return function wrap(arr) {
    return callback.apply(null, arr);
  };
};


/***/ }),

/***/ "./node_modules/axios/lib/helpers/validator.js":
/*!*****************************************************!*\
  !*** ./node_modules/axios/lib/helpers/validator.js ***!
  \*****************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var VERSION = (__webpack_require__(/*! ../env/data */ "./node_modules/axios/lib/env/data.js").version);

var validators = {};

// eslint-disable-next-line func-names
['object', 'boolean', 'number', 'function', 'string', 'symbol'].forEach(function(type, i) {
  validators[type] = function validator(thing) {
    return typeof thing === type || 'a' + (i < 1 ? 'n ' : ' ') + type;
  };
});

var deprecatedWarnings = {};

/**
 * Transitional option validator
 * @param {function|boolean?} validator - set to false if the transitional option has been removed
 * @param {string?} version - deprecated version / removed since version
 * @param {string?} message - some message with additional info
 * @returns {function}
 */
validators.transitional = function transitional(validator, version, message) {
  function formatMessage(opt, desc) {
    return '[Axios v' + VERSION + '] Transitional option \'' + opt + '\'' + desc + (message ? '. ' + message : '');
  }

  // eslint-disable-next-line func-names
  return function(value, opt, opts) {
    if (validator === false) {
      throw new Error(formatMessage(opt, ' has been removed' + (version ? ' in ' + version : '')));
    }

    if (version && !deprecatedWarnings[opt]) {
      deprecatedWarnings[opt] = true;
      // eslint-disable-next-line no-console
      console.warn(
        formatMessage(
          opt,
          ' has been deprecated since v' + version + ' and will be removed in the near future'
        )
      );
    }

    return validator ? validator(value, opt, opts) : true;
  };
};

/**
 * Assert object's properties type
 * @param {object} options
 * @param {object} schema
 * @param {boolean?} allowUnknown
 */

function assertOptions(options, schema, allowUnknown) {
  if (typeof options !== 'object') {
    throw new TypeError('options must be an object');
  }
  var keys = Object.keys(options);
  var i = keys.length;
  while (i-- > 0) {
    var opt = keys[i];
    var validator = schema[opt];
    if (validator) {
      var value = options[opt];
      var result = value === undefined || validator(value, opt, options);
      if (result !== true) {
        throw new TypeError('option ' + opt + ' must be ' + result);
      }
      continue;
    }
    if (allowUnknown !== true) {
      throw Error('Unknown option ' + opt);
    }
  }
}

module.exports = {
  assertOptions: assertOptions,
  validators: validators
};


/***/ }),

/***/ "./node_modules/axios/lib/utils.js":
/*!*****************************************!*\
  !*** ./node_modules/axios/lib/utils.js ***!
  \*****************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var bind = __webpack_require__(/*! ./helpers/bind */ "./node_modules/axios/lib/helpers/bind.js");

// utils is a library of generic helper functions non-specific to axios

var toString = Object.prototype.toString;

/**
 * Determine if a value is an Array
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is an Array, otherwise false
 */
function isArray(val) {
  return Array.isArray(val);
}

/**
 * Determine if a value is undefined
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if the value is undefined, otherwise false
 */
function isUndefined(val) {
  return typeof val === 'undefined';
}

/**
 * Determine if a value is a Buffer
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a Buffer, otherwise false
 */
function isBuffer(val) {
  return val !== null && !isUndefined(val) && val.constructor !== null && !isUndefined(val.constructor)
    && typeof val.constructor.isBuffer === 'function' && val.constructor.isBuffer(val);
}

/**
 * Determine if a value is an ArrayBuffer
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is an ArrayBuffer, otherwise false
 */
function isArrayBuffer(val) {
  return toString.call(val) === '[object ArrayBuffer]';
}

/**
 * Determine if a value is a FormData
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is an FormData, otherwise false
 */
function isFormData(val) {
  return toString.call(val) === '[object FormData]';
}

/**
 * Determine if a value is a view on an ArrayBuffer
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a view on an ArrayBuffer, otherwise false
 */
function isArrayBufferView(val) {
  var result;
  if ((typeof ArrayBuffer !== 'undefined') && (ArrayBuffer.isView)) {
    result = ArrayBuffer.isView(val);
  } else {
    result = (val) && (val.buffer) && (isArrayBuffer(val.buffer));
  }
  return result;
}

/**
 * Determine if a value is a String
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a String, otherwise false
 */
function isString(val) {
  return typeof val === 'string';
}

/**
 * Determine if a value is a Number
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a Number, otherwise false
 */
function isNumber(val) {
  return typeof val === 'number';
}

/**
 * Determine if a value is an Object
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is an Object, otherwise false
 */
function isObject(val) {
  return val !== null && typeof val === 'object';
}

/**
 * Determine if a value is a plain Object
 *
 * @param {Object} val The value to test
 * @return {boolean} True if value is a plain Object, otherwise false
 */
function isPlainObject(val) {
  if (toString.call(val) !== '[object Object]') {
    return false;
  }

  var prototype = Object.getPrototypeOf(val);
  return prototype === null || prototype === Object.prototype;
}

/**
 * Determine if a value is a Date
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a Date, otherwise false
 */
function isDate(val) {
  return toString.call(val) === '[object Date]';
}

/**
 * Determine if a value is a File
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a File, otherwise false
 */
function isFile(val) {
  return toString.call(val) === '[object File]';
}

/**
 * Determine if a value is a Blob
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a Blob, otherwise false
 */
function isBlob(val) {
  return toString.call(val) === '[object Blob]';
}

/**
 * Determine if a value is a Function
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a Function, otherwise false
 */
function isFunction(val) {
  return toString.call(val) === '[object Function]';
}

/**
 * Determine if a value is a Stream
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a Stream, otherwise false
 */
function isStream(val) {
  return isObject(val) && isFunction(val.pipe);
}

/**
 * Determine if a value is a URLSearchParams object
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a URLSearchParams object, otherwise false
 */
function isURLSearchParams(val) {
  return toString.call(val) === '[object URLSearchParams]';
}

/**
 * Trim excess whitespace off the beginning and end of a string
 *
 * @param {String} str The String to trim
 * @returns {String} The String freed of excess whitespace
 */
function trim(str) {
  return str.trim ? str.trim() : str.replace(/^\s+|\s+$/g, '');
}

/**
 * Determine if we're running in a standard browser environment
 *
 * This allows axios to run in a web worker, and react-native.
 * Both environments support XMLHttpRequest, but not fully standard globals.
 *
 * web workers:
 *  typeof window -> undefined
 *  typeof document -> undefined
 *
 * react-native:
 *  navigator.product -> 'ReactNative'
 * nativescript
 *  navigator.product -> 'NativeScript' or 'NS'
 */
function isStandardBrowserEnv() {
  if (typeof navigator !== 'undefined' && (navigator.product === 'ReactNative' ||
                                           navigator.product === 'NativeScript' ||
                                           navigator.product === 'NS')) {
    return false;
  }
  return (
    typeof window !== 'undefined' &&
    typeof document !== 'undefined'
  );
}

/**
 * Iterate over an Array or an Object invoking a function for each item.
 *
 * If `obj` is an Array callback will be called passing
 * the value, index, and complete array for each item.
 *
 * If 'obj' is an Object callback will be called passing
 * the value, key, and complete object for each property.
 *
 * @param {Object|Array} obj The object to iterate
 * @param {Function} fn The callback to invoke for each item
 */
function forEach(obj, fn) {
  // Don't bother if no value provided
  if (obj === null || typeof obj === 'undefined') {
    return;
  }

  // Force an array if not already something iterable
  if (typeof obj !== 'object') {
    /*eslint no-param-reassign:0*/
    obj = [obj];
  }

  if (isArray(obj)) {
    // Iterate over array values
    for (var i = 0, l = obj.length; i < l; i++) {
      fn.call(null, obj[i], i, obj);
    }
  } else {
    // Iterate over object keys
    for (var key in obj) {
      if (Object.prototype.hasOwnProperty.call(obj, key)) {
        fn.call(null, obj[key], key, obj);
      }
    }
  }
}

/**
 * Accepts varargs expecting each argument to be an object, then
 * immutably merges the properties of each object and returns result.
 *
 * When multiple objects contain the same key the later object in
 * the arguments list will take precedence.
 *
 * Example:
 *
 * ```js
 * var result = merge({foo: 123}, {foo: 456});
 * console.log(result.foo); // outputs 456
 * ```
 *
 * @param {Object} obj1 Object to merge
 * @returns {Object} Result of all merge properties
 */
function merge(/* obj1, obj2, obj3, ... */) {
  var result = {};
  function assignValue(val, key) {
    if (isPlainObject(result[key]) && isPlainObject(val)) {
      result[key] = merge(result[key], val);
    } else if (isPlainObject(val)) {
      result[key] = merge({}, val);
    } else if (isArray(val)) {
      result[key] = val.slice();
    } else {
      result[key] = val;
    }
  }

  for (var i = 0, l = arguments.length; i < l; i++) {
    forEach(arguments[i], assignValue);
  }
  return result;
}

/**
 * Extends object a by mutably adding to it the properties of object b.
 *
 * @param {Object} a The object to be extended
 * @param {Object} b The object to copy properties from
 * @param {Object} thisArg The object to bind function to
 * @return {Object} The resulting value of object a
 */
function extend(a, b, thisArg) {
  forEach(b, function assignValue(val, key) {
    if (thisArg && typeof val === 'function') {
      a[key] = bind(val, thisArg);
    } else {
      a[key] = val;
    }
  });
  return a;
}

/**
 * Remove byte order marker. This catches EF BB BF (the UTF-8 BOM)
 *
 * @param {string} content with BOM
 * @return {string} content value without BOM
 */
function stripBOM(content) {
  if (content.charCodeAt(0) === 0xFEFF) {
    content = content.slice(1);
  }
  return content;
}

module.exports = {
  isArray: isArray,
  isArrayBuffer: isArrayBuffer,
  isBuffer: isBuffer,
  isFormData: isFormData,
  isArrayBufferView: isArrayBufferView,
  isString: isString,
  isNumber: isNumber,
  isObject: isObject,
  isPlainObject: isPlainObject,
  isUndefined: isUndefined,
  isDate: isDate,
  isFile: isFile,
  isBlob: isBlob,
  isFunction: isFunction,
  isStream: isStream,
  isURLSearchParams: isURLSearchParams,
  isStandardBrowserEnv: isStandardBrowserEnv,
  forEach: forEach,
  merge: merge,
  extend: extend,
  trim: trim,
  stripBOM: stripBOM
};


/***/ }),

/***/ "./src/js/menu.jsx":
/*!*************************!*\
  !*** ./src/js/menu.jsx ***!
  \*************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

const bus = __webpack_require__(/*! ./bus */ "./src/js/bus.js");

const axios = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");

const {
  memory
} = __webpack_require__(/*! jsb-util */ "./node_modules/jsb-util/src/index.js");

exports.install = function install(Vue) {
  Vue.component('add_link', {
    template: `
                 <el-dialog :close-on-click-modal="false" append-to-body :visible.sync="dialogVisible" :title="!isedit?'添加链接':'修改链接'" :width="sumwidth(dialogVisible)">
                     <div class="menu_add">
                         <el-input placeholder="请输入完整的网址链接" v-model="addInfo.url"></el-input>
                         <el-input placeholder="请输入备用链接，没有请留空" v-model="addInfo.url_standby"></el-input>
                         <el-input placeholder="请输入标题" v-model="addInfo.title"></el-input>
                         <el-input placeholder="请输入站点描述（完整）" show-word-limit maxlength="300" type="textarea" v-model="addInfo.description"></el-input>
                         <div class="other">
                         <el-select v-model="addInfo.fid" placeholder="请选择目录">
                            <el-option :value="it.id" :label="it.name" v-for="(it,index) in option" :key="index"></el-option>
                         </el-select>
                         <el-input placeholder="权重（0-99）" type="number" v-model="addInfo.weight"></el-input>
                         <el-switch
                        v-model="addInfo.property"
                        active-color="#13ce66"
                        inactive-text="是否公开"
                        inactive-color="#ff4949">
                        </el-switch>
                         </div>
                    </div>
                     <span slot="footer" class="dialog-footer">
                       <el-button @click="dialogVisible = false">取 消</el-button>
                       <el-button type="primary"  @click="submit">确 定</el-button>
                      </span>
                 </el-dialog>
                `,
    methods: {
      submit(type) {
        if (this.addInfo.url === "") return this.$message.error("缺少url地址");
        if (this.addInfo.title === "") return this.$message.error("缺少标题");
        const data = { ...this.addInfo
        };
        let url = "";

        if (this.isedit) {
          url = "./index.php?c=api&method=edit_link" + "&u=" + u;
        } else {
          url = "./index.php?c=api&method=add_link" + "&u=" + u;
        }

        data.property = this.addInfo.property ? 0 : 1;
        axios.post(url, data).then(e => {
          const {
            code
          } = e.data;

          if (code === 0) {
            this.$message.success("添加成功");
            setTimeout(_ => location.reload(), 1000);
            this.dialogVisible = false;
          } else {
            this.$message.error("添加失败");
          }
        });
      },

      sumwidth() {
        if (outerWidth > 500) {
          return '500px';
        }

        return "375px";
      }

    },

    data() {
      return {
        dialogVisible: false,
        option: [],
        addInfo: {},
        tmp: {
          //这个是为了在下次打开的时候清空内容的数据结构
          url: '',
          weight: '',
          title: '',
          property: true,
          fid: "",
          url_standby: '',
          description: ''
        },
        isedit: false
      };
    },

    watch: {
      dialogVisible(e) {
        if (e === false) {
          window.scrolllock = false;
        } else if (e === true) {
          this.addInfo = JSON.parse(JSON.stringify(this.tmp));
          window.scrolllock = true;
        }
      }

    },

    mounted() {
      bus.$on("show", () => {
        this.option = memory.get("list") || [];
        this.dialogVisible = true;
      });
      bus.$on("showandupdate", e => {
        this.dialogVisible = true;
        this.isedit = true;
        this.$nextTick(_ => {
          this.option = memory.get("list") || [];
          this.addInfo = e;
          this.addInfo.property = e.property == 0 ? true : false;
        });
      });
    }

  });
  Vue.component("tabar", {
    template: `<div v-show="show" class="tabar" :style="{left:mouseRight.x,top:mouseRight.y}">
                        <div @click="addmenu">新增目录</div>
                        <div v-if="canshow(1)" @click="updatemenu">修改目录</div>
                        <div v-if="canshow(2)" @click="delmenu" >删除目录</div>
                        <div class="addlink"   @click="addlink">新增链接</div>
                        <div v-if="canshow(3)" @click="dellink">删除链接</div>
                        <div v-if="canshow(4)" @click="updatelink">修改链接</div>
                        <div v-if="canshow(5)" @click="delhistory">删除记录</div>
                        <div v-if="canshow(6)" @click="swiptBg">换个背景</div>
                        <div v-if="canshow(6)" @click="downbg" >下载壁纸</div>
<!--                        <div @click="setting">个性设置</div>-->
                    </div>`,

    data() {
      return {
        mouseRight: {
          x: 0,
          y: 0
        },
        show: false,
        info: {},
        ctype: [],
        element: null
      };
    },

    props: ["xy", "type"],
    methods: {
      addmenu() {
        bus.$emit("menushow", true);
      },

      downbg() {
        const data = base64ToBlob(memory.get("bg"));
        let a = document.createElement("a");
        a.href = URL.createObjectURL(data);
        a.download = "壁纸.jpg";
        a.click();
      },

      updatemenu() {
        const list = memory.get("list") || [];
        const index = list.findIndex(e => e.id == this.info);
        if (index === -1) return false;
        const info = list[index];
        bus.$emit("menushow", info);
        this.show = false;
      },

      addlink() {
        bus.$emit("show", true);
      },

      delhistory() {
        bus.$emit("delhistory", this.info);
        this.show = false;
      },

      swiptBg() {
        let data = new FileReader();

        data.onload = er => {
          const base = data.result;

          if (base.length < 100) {
            this.$notify.error({
              title: '出现异常',
              message: '没有切换成功'
            });
          }

          memory.set("bg", base);
        };

        this.$notify.info({
          title: '切换中',
          message: '请稍等片刻，我处理一下'
        });
        fetch(axios.defaults.baseURL + "/background.php").then(ell => {
          ell.blob().then(cc => {
            data.readAsDataURL(cc);
            const ac = URL.createObjectURL(cc);
            document.querySelector("#root").style.background = `url(${ac}) no-repeat center/cover`;
          });
        });
        this.show = false;
      },

      async delmenu() {
        try {
          await this.$confirm("是否删除？");
        } catch (e) {
          return false;
        }

        axios.post("./index.php?c=api&method=del_category" + "&u=" + u, {
          id: this.info
        }).then(el => {
          const {
            code
          } = el.data;

          if (code === 0) {
            this.element.parentNode.remove();
            this.$message.success("删除成功");
          } else {
            this.$message.error("删除失败");
          }
        });
        this.show = false;
      },

      async dellink() {
        try {
          await this.$confirm("是否删除？");
        } catch (e) {
          return false;
        }

        const lists = memory.get("lists") || [];
        const index = lists.findIndex(e => e.id == this.info);
        if (index === -1) return false;
        const info = lists[index];
        axios.post("./index.php?c=api&method=del_link" + "&u=" + u, {
          id: info.id
        }).then(el => {
          const {
            code
          } = el.data;

          if (code === 0) {
            this.element.remove();
            this.$message.success("删除成功");
          } else {
            this.$message.error("删除失败");
          }
        });
        this.show = false;
      },

      setting() {
        this.show = false;
      },

      updatelink() {
        const lists = memory.get("lists") || [];
        const index = lists.findIndex(e => e.id == this.info);
        if (index === -1) return false;
        const info = lists[index];
        bus.$emit("showandupdate", info);
        this.show = false;
      },

      canshow(index) {
        return Boolean(this.ctype.indexOf(index) > -1);
      }

    },

    mounted() {
      document.querySelector(".tabar").addEventListener("click", function (event) {
        event.stopPropagation();
        event.preventDefault();
      });
      document.addEventListener("click", event => {
        this.show = false;
      });
      const touch = {
        isdown: false,
        time: null
      };
      window.addEventListener("touchstart", e => {
        touch.isdown = true;
        touch.time = new Date().getTime();
        touch.time = setTimeout(_ => {
          this.mouseRight = {
            x: e.changedTouches[0].clientX + 'px',
            y: e.changedTouches[0].clientY + 'px'
          };

          try {
            let t = JSON.parse(e.target.attributes.ctype.value);

            if (t.length > 0) {
              this.ctype = t;
            }
          } catch (e) {
            this.ctype = [];
          }

          try {
            let info = e.target.attributes.cdata.value;
            this.info = info;
            this.element = e.target;
          } catch (e) {}

          this.show = true;
        }, 500);
      });
      window.addEventListener("touchend", function () {
        touch.isdown = false;
        clearTimeout(touch.time);
        touch.time = null;
      });
      window.addEventListener("mouseup", e => {
        if (e.button === 2) {
          this.mouseRight = {
            x: e.clientX + 'px',
            y: e.clientY + 'px'
          };

          try {
            let t = JSON.parse(e.toElement.attributes.ctype.value);

            if (t.length > 0) {
              this.ctype = t;
            }
          } catch (e) {
            this.ctype = [];
          }

          try {
            let info = e.toElement.attributes.cdata.value;
            this.info = info;
            this.element = e.target;
          } catch (e) {}

          this.show = true;
          e.preventDefault();
          e.stopPropagation();
        }
      });
    }

  });
  Vue.component('add_menus', {
    template: `
                 <el-dialog :close-on-click-modal="false" append-to-body :visible.sync="dialogVisible" title="添加目录" :width="sumwidth(dialogVisible)">
                     <div class="menu_add">
                         <el-input placeholder="请输入分类名称" v-model="addInfo.name"></el-input>
                         <el-input placeholder="请输入图标类名 不要删除fa (fa 图标名称)" v-model="addInfo.font_icon" ></el-input>
                         <el-input placeholder="请输入站点描述（完整）" show-word-limit maxlength="300" type="textarea" v-model="addInfo.description"></el-input>
                         <div class="other">
                          <el-select v-model="addInfo.fid" placeholder="父级菜单，非必选">
                            <el-option :value="it.id" :label="it.name" v-for="(it,index) in option" :key="index"></el-option>
                         </el-select>
                         <el-input placeholder="权重（0-99）" type="number" v-model="addInfo.weight"></el-input>
                         <el-switch
                             v-model="addInfo.property"
                             active-color="#13ce66"
                             inactive-text="是否公开"
                             inactive-color="#ff4949">
                        </el-switch>
                         </div>
                         <div style="margin:15px 0px;">图标查看地址 <a href="https://fontawesome.dashgame.com" target="_blank">https://fontawesome.dashgame.com</a></div>
                    </div>
                     <span slot="footer" class="dialog-footer">
                       <el-button @click="dialogVisible = false">取 消</el-button>
                       <el-button type="primary"  @click="submit">确 定</el-button>
                      </span>
                 </el-dialog>
                `,
    methods: {
      submit() {
        if (this.addInfo.name === "") return this.$message.error("缺少目录名称");
        const data = { ...this.addInfo
        };
        data.property = this.addInfo.property ? 0 : 1;
        let url = "./index.php?c=api&method=add_category" + "&u=" + u;
        if (this.isedit) url = "./index.php?c=api&method=edit_category" + "&u=" + u;
        axios.post(url, data).then(e => {
          const {
            code
          } = e.data;

          if (code === 0) {
            this.$message.success("添加成功");
            setTimeout(_ => location.reload(), 1000);
            this.dialogVisible = false;
          } else {
            this.$message.error("添加失败");
          }
        });
      },

      sumwidth() {
        if (outerWidth > 500) {
          return '500px';
        }

        return "375px";
      }

    },

    data() {
      return {
        dialogVisible: false,
        option: [],
        addInfo: {
          name: '',
          weight: '',
          property: true,
          description: '',
          font_icon: 'fa ',
          fid: ""
        },
        tmp: {
          name: '',
          weight: '',
          property: true,
          description: '',
          font_icon: 'fa ',
          fid: ""
        },
        isedit: false
      };
    },

    watch: {
      dialogVisible(e) {
        if (e === false) {
          window.scrolllock = false;
        } else if (e === true) {
          this.addInfo = JSON.parse(JSON.stringify(this.tmp));
          window.scrolllock = true;
        }
      }

    },

    mounted() {
      bus.$on("menushow", info => {
        this.dialogVisible = true;
        this.$nextTick(_ => {
          let arr = [];
          memory.get("list").forEach(el => {
            if (el.fid == '0') {
              arr.push(el);
            }
          });
          this.option = arr;

          if (info !== true) {
            for (const item in this.addInfo) {
              this.addInfo[item] = info[item];
            }

            this.addInfo.property = Boolean(info["property"] !== 1);
            this.addInfo.id = info.id;
            this.addInfo.fid = info.fid;
            this.isedit = true;
          }
        });
      });
    }

  });
};

/***/ }),

/***/ "./node_modules/cssfilter/lib/css.js":
/*!*******************************************!*\
  !*** ./node_modules/cssfilter/lib/css.js ***!
  \*******************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/**
 * cssfilter
 *
 * @author 老雷<leizongmin@gmail.com>
 */

var DEFAULT = __webpack_require__(/*! ./default */ "./node_modules/cssfilter/lib/default.js");
var parseStyle = __webpack_require__(/*! ./parser */ "./node_modules/cssfilter/lib/parser.js");
var _ = __webpack_require__(/*! ./util */ "./node_modules/cssfilter/lib/util.js");


/**
 * 返回值是否为空
 *
 * @param {Object} obj
 * @return {Boolean}
 */
function isNull (obj) {
  return (obj === undefined || obj === null);
}

/**
 * 浅拷贝对象
 *
 * @param {Object} obj
 * @return {Object}
 */
function shallowCopyObject (obj) {
  var ret = {};
  for (var i in obj) {
    ret[i] = obj[i];
  }
  return ret;
}

/**
 * 创建CSS过滤器
 *
 * @param {Object} options
 *   - {Object} whiteList
 *   - {Function} onAttr
 *   - {Function} onIgnoreAttr
 *   - {Function} safeAttrValue
 */
function FilterCSS (options) {
  options = shallowCopyObject(options || {});
  options.whiteList = options.whiteList || DEFAULT.whiteList;
  options.onAttr = options.onAttr || DEFAULT.onAttr;
  options.onIgnoreAttr = options.onIgnoreAttr || DEFAULT.onIgnoreAttr;
  options.safeAttrValue = options.safeAttrValue || DEFAULT.safeAttrValue;
  this.options = options;
}

FilterCSS.prototype.process = function (css) {
  // 兼容各种奇葩输入
  css = css || '';
  css = css.toString();
  if (!css) return '';

  var me = this;
  var options = me.options;
  var whiteList = options.whiteList;
  var onAttr = options.onAttr;
  var onIgnoreAttr = options.onIgnoreAttr;
  var safeAttrValue = options.safeAttrValue;

  var retCSS = parseStyle(css, function (sourcePosition, position, name, value, source) {

    var check = whiteList[name];
    var isWhite = false;
    if (check === true) isWhite = check;
    else if (typeof check === 'function') isWhite = check(value);
    else if (check instanceof RegExp) isWhite = check.test(value);
    if (isWhite !== true) isWhite = false;

    // 如果过滤后 value 为空则直接忽略
    value = safeAttrValue(name, value);
    if (!value) return;

    var opts = {
      position: position,
      sourcePosition: sourcePosition,
      source: source,
      isWhite: isWhite
    };

    if (isWhite) {

      var ret = onAttr(name, value, opts);
      if (isNull(ret)) {
        return name + ':' + value;
      } else {
        return ret;
      }

    } else {

      var ret = onIgnoreAttr(name, value, opts);
      if (!isNull(ret)) {
        return ret;
      }

    }
  });

  return retCSS;
};


module.exports = FilterCSS;


/***/ }),

/***/ "./node_modules/cssfilter/lib/default.js":
/*!***********************************************!*\
  !*** ./node_modules/cssfilter/lib/default.js ***!
  \***********************************************/
/***/ ((__unused_webpack_module, exports) => {

/**
 * cssfilter
 *
 * @author 老雷<leizongmin@gmail.com>
 */

function getDefaultWhiteList () {
  // 白名单值说明：
  // true: 允许该属性
  // Function: function (val) { } 返回true表示允许该属性，其他值均表示不允许
  // RegExp: regexp.test(val) 返回true表示允许该属性，其他值均表示不允许
  // 除上面列出的值外均表示不允许
  var whiteList = {};

  whiteList['align-content'] = false; // default: auto
  whiteList['align-items'] = false; // default: auto
  whiteList['align-self'] = false; // default: auto
  whiteList['alignment-adjust'] = false; // default: auto
  whiteList['alignment-baseline'] = false; // default: baseline
  whiteList['all'] = false; // default: depending on individual properties
  whiteList['anchor-point'] = false; // default: none
  whiteList['animation'] = false; // default: depending on individual properties
  whiteList['animation-delay'] = false; // default: 0
  whiteList['animation-direction'] = false; // default: normal
  whiteList['animation-duration'] = false; // default: 0
  whiteList['animation-fill-mode'] = false; // default: none
  whiteList['animation-iteration-count'] = false; // default: 1
  whiteList['animation-name'] = false; // default: none
  whiteList['animation-play-state'] = false; // default: running
  whiteList['animation-timing-function'] = false; // default: ease
  whiteList['azimuth'] = false; // default: center
  whiteList['backface-visibility'] = false; // default: visible
  whiteList['background'] = true; // default: depending on individual properties
  whiteList['background-attachment'] = true; // default: scroll
  whiteList['background-clip'] = true; // default: border-box
  whiteList['background-color'] = true; // default: transparent
  whiteList['background-image'] = true; // default: none
  whiteList['background-origin'] = true; // default: padding-box
  whiteList['background-position'] = true; // default: 0% 0%
  whiteList['background-repeat'] = true; // default: repeat
  whiteList['background-size'] = true; // default: auto
  whiteList['baseline-shift'] = false; // default: baseline
  whiteList['binding'] = false; // default: none
  whiteList['bleed'] = false; // default: 6pt
  whiteList['bookmark-label'] = false; // default: content()
  whiteList['bookmark-level'] = false; // default: none
  whiteList['bookmark-state'] = false; // default: open
  whiteList['border'] = true; // default: depending on individual properties
  whiteList['border-bottom'] = true; // default: depending on individual properties
  whiteList['border-bottom-color'] = true; // default: current color
  whiteList['border-bottom-left-radius'] = true; // default: 0
  whiteList['border-bottom-right-radius'] = true; // default: 0
  whiteList['border-bottom-style'] = true; // default: none
  whiteList['border-bottom-width'] = true; // default: medium
  whiteList['border-collapse'] = true; // default: separate
  whiteList['border-color'] = true; // default: depending on individual properties
  whiteList['border-image'] = true; // default: none
  whiteList['border-image-outset'] = true; // default: 0
  whiteList['border-image-repeat'] = true; // default: stretch
  whiteList['border-image-slice'] = true; // default: 100%
  whiteList['border-image-source'] = true; // default: none
  whiteList['border-image-width'] = true; // default: 1
  whiteList['border-left'] = true; // default: depending on individual properties
  whiteList['border-left-color'] = true; // default: current color
  whiteList['border-left-style'] = true; // default: none
  whiteList['border-left-width'] = true; // default: medium
  whiteList['border-radius'] = true; // default: 0
  whiteList['border-right'] = true; // default: depending on individual properties
  whiteList['border-right-color'] = true; // default: current color
  whiteList['border-right-style'] = true; // default: none
  whiteList['border-right-width'] = true; // default: medium
  whiteList['border-spacing'] = true; // default: 0
  whiteList['border-style'] = true; // default: depending on individual properties
  whiteList['border-top'] = true; // default: depending on individual properties
  whiteList['border-top-color'] = true; // default: current color
  whiteList['border-top-left-radius'] = true; // default: 0
  whiteList['border-top-right-radius'] = true; // default: 0
  whiteList['border-top-style'] = true; // default: none
  whiteList['border-top-width'] = true; // default: medium
  whiteList['border-width'] = true; // default: depending on individual properties
  whiteList['bottom'] = false; // default: auto
  whiteList['box-decoration-break'] = true; // default: slice
  whiteList['box-shadow'] = true; // default: none
  whiteList['box-sizing'] = true; // default: content-box
  whiteList['box-snap'] = true; // default: none
  whiteList['box-suppress'] = true; // default: show
  whiteList['break-after'] = true; // default: auto
  whiteList['break-before'] = true; // default: auto
  whiteList['break-inside'] = true; // default: auto
  whiteList['caption-side'] = false; // default: top
  whiteList['chains'] = false; // default: none
  whiteList['clear'] = true; // default: none
  whiteList['clip'] = false; // default: auto
  whiteList['clip-path'] = false; // default: none
  whiteList['clip-rule'] = false; // default: nonzero
  whiteList['color'] = true; // default: implementation dependent
  whiteList['color-interpolation-filters'] = true; // default: auto
  whiteList['column-count'] = false; // default: auto
  whiteList['column-fill'] = false; // default: balance
  whiteList['column-gap'] = false; // default: normal
  whiteList['column-rule'] = false; // default: depending on individual properties
  whiteList['column-rule-color'] = false; // default: current color
  whiteList['column-rule-style'] = false; // default: medium
  whiteList['column-rule-width'] = false; // default: medium
  whiteList['column-span'] = false; // default: none
  whiteList['column-width'] = false; // default: auto
  whiteList['columns'] = false; // default: depending on individual properties
  whiteList['contain'] = false; // default: none
  whiteList['content'] = false; // default: normal
  whiteList['counter-increment'] = false; // default: none
  whiteList['counter-reset'] = false; // default: none
  whiteList['counter-set'] = false; // default: none
  whiteList['crop'] = false; // default: auto
  whiteList['cue'] = false; // default: depending on individual properties
  whiteList['cue-after'] = false; // default: none
  whiteList['cue-before'] = false; // default: none
  whiteList['cursor'] = false; // default: auto
  whiteList['direction'] = false; // default: ltr
  whiteList['display'] = true; // default: depending on individual properties
  whiteList['display-inside'] = true; // default: auto
  whiteList['display-list'] = true; // default: none
  whiteList['display-outside'] = true; // default: inline-level
  whiteList['dominant-baseline'] = false; // default: auto
  whiteList['elevation'] = false; // default: level
  whiteList['empty-cells'] = false; // default: show
  whiteList['filter'] = false; // default: none
  whiteList['flex'] = false; // default: depending on individual properties
  whiteList['flex-basis'] = false; // default: auto
  whiteList['flex-direction'] = false; // default: row
  whiteList['flex-flow'] = false; // default: depending on individual properties
  whiteList['flex-grow'] = false; // default: 0
  whiteList['flex-shrink'] = false; // default: 1
  whiteList['flex-wrap'] = false; // default: nowrap
  whiteList['float'] = false; // default: none
  whiteList['float-offset'] = false; // default: 0 0
  whiteList['flood-color'] = false; // default: black
  whiteList['flood-opacity'] = false; // default: 1
  whiteList['flow-from'] = false; // default: none
  whiteList['flow-into'] = false; // default: none
  whiteList['font'] = true; // default: depending on individual properties
  whiteList['font-family'] = true; // default: implementation dependent
  whiteList['font-feature-settings'] = true; // default: normal
  whiteList['font-kerning'] = true; // default: auto
  whiteList['font-language-override'] = true; // default: normal
  whiteList['font-size'] = true; // default: medium
  whiteList['font-size-adjust'] = true; // default: none
  whiteList['font-stretch'] = true; // default: normal
  whiteList['font-style'] = true; // default: normal
  whiteList['font-synthesis'] = true; // default: weight style
  whiteList['font-variant'] = true; // default: normal
  whiteList['font-variant-alternates'] = true; // default: normal
  whiteList['font-variant-caps'] = true; // default: normal
  whiteList['font-variant-east-asian'] = true; // default: normal
  whiteList['font-variant-ligatures'] = true; // default: normal
  whiteList['font-variant-numeric'] = true; // default: normal
  whiteList['font-variant-position'] = true; // default: normal
  whiteList['font-weight'] = true; // default: normal
  whiteList['grid'] = false; // default: depending on individual properties
  whiteList['grid-area'] = false; // default: depending on individual properties
  whiteList['grid-auto-columns'] = false; // default: auto
  whiteList['grid-auto-flow'] = false; // default: none
  whiteList['grid-auto-rows'] = false; // default: auto
  whiteList['grid-column'] = false; // default: depending on individual properties
  whiteList['grid-column-end'] = false; // default: auto
  whiteList['grid-column-start'] = false; // default: auto
  whiteList['grid-row'] = false; // default: depending on individual properties
  whiteList['grid-row-end'] = false; // default: auto
  whiteList['grid-row-start'] = false; // default: auto
  whiteList['grid-template'] = false; // default: depending on individual properties
  whiteList['grid-template-areas'] = false; // default: none
  whiteList['grid-template-columns'] = false; // default: none
  whiteList['grid-template-rows'] = false; // default: none
  whiteList['hanging-punctuation'] = false; // default: none
  whiteList['height'] = true; // default: auto
  whiteList['hyphens'] = false; // default: manual
  whiteList['icon'] = false; // default: auto
  whiteList['image-orientation'] = false; // default: auto
  whiteList['image-resolution'] = false; // default: normal
  whiteList['ime-mode'] = false; // default: auto
  whiteList['initial-letters'] = false; // default: normal
  whiteList['inline-box-align'] = false; // default: last
  whiteList['justify-content'] = false; // default: auto
  whiteList['justify-items'] = false; // default: auto
  whiteList['justify-self'] = false; // default: auto
  whiteList['left'] = false; // default: auto
  whiteList['letter-spacing'] = true; // default: normal
  whiteList['lighting-color'] = true; // default: white
  whiteList['line-box-contain'] = false; // default: block inline replaced
  whiteList['line-break'] = false; // default: auto
  whiteList['line-grid'] = false; // default: match-parent
  whiteList['line-height'] = false; // default: normal
  whiteList['line-snap'] = false; // default: none
  whiteList['line-stacking'] = false; // default: depending on individual properties
  whiteList['line-stacking-ruby'] = false; // default: exclude-ruby
  whiteList['line-stacking-shift'] = false; // default: consider-shifts
  whiteList['line-stacking-strategy'] = false; // default: inline-line-height
  whiteList['list-style'] = true; // default: depending on individual properties
  whiteList['list-style-image'] = true; // default: none
  whiteList['list-style-position'] = true; // default: outside
  whiteList['list-style-type'] = true; // default: disc
  whiteList['margin'] = true; // default: depending on individual properties
  whiteList['margin-bottom'] = true; // default: 0
  whiteList['margin-left'] = true; // default: 0
  whiteList['margin-right'] = true; // default: 0
  whiteList['margin-top'] = true; // default: 0
  whiteList['marker-offset'] = false; // default: auto
  whiteList['marker-side'] = false; // default: list-item
  whiteList['marks'] = false; // default: none
  whiteList['mask'] = false; // default: border-box
  whiteList['mask-box'] = false; // default: see individual properties
  whiteList['mask-box-outset'] = false; // default: 0
  whiteList['mask-box-repeat'] = false; // default: stretch
  whiteList['mask-box-slice'] = false; // default: 0 fill
  whiteList['mask-box-source'] = false; // default: none
  whiteList['mask-box-width'] = false; // default: auto
  whiteList['mask-clip'] = false; // default: border-box
  whiteList['mask-image'] = false; // default: none
  whiteList['mask-origin'] = false; // default: border-box
  whiteList['mask-position'] = false; // default: center
  whiteList['mask-repeat'] = false; // default: no-repeat
  whiteList['mask-size'] = false; // default: border-box
  whiteList['mask-source-type'] = false; // default: auto
  whiteList['mask-type'] = false; // default: luminance
  whiteList['max-height'] = true; // default: none
  whiteList['max-lines'] = false; // default: none
  whiteList['max-width'] = true; // default: none
  whiteList['min-height'] = true; // default: 0
  whiteList['min-width'] = true; // default: 0
  whiteList['move-to'] = false; // default: normal
  whiteList['nav-down'] = false; // default: auto
  whiteList['nav-index'] = false; // default: auto
  whiteList['nav-left'] = false; // default: auto
  whiteList['nav-right'] = false; // default: auto
  whiteList['nav-up'] = false; // default: auto
  whiteList['object-fit'] = false; // default: fill
  whiteList['object-position'] = false; // default: 50% 50%
  whiteList['opacity'] = false; // default: 1
  whiteList['order'] = false; // default: 0
  whiteList['orphans'] = false; // default: 2
  whiteList['outline'] = false; // default: depending on individual properties
  whiteList['outline-color'] = false; // default: invert
  whiteList['outline-offset'] = false; // default: 0
  whiteList['outline-style'] = false; // default: none
  whiteList['outline-width'] = false; // default: medium
  whiteList['overflow'] = false; // default: depending on individual properties
  whiteList['overflow-wrap'] = false; // default: normal
  whiteList['overflow-x'] = false; // default: visible
  whiteList['overflow-y'] = false; // default: visible
  whiteList['padding'] = true; // default: depending on individual properties
  whiteList['padding-bottom'] = true; // default: 0
  whiteList['padding-left'] = true; // default: 0
  whiteList['padding-right'] = true; // default: 0
  whiteList['padding-top'] = true; // default: 0
  whiteList['page'] = false; // default: auto
  whiteList['page-break-after'] = false; // default: auto
  whiteList['page-break-before'] = false; // default: auto
  whiteList['page-break-inside'] = false; // default: auto
  whiteList['page-policy'] = false; // default: start
  whiteList['pause'] = false; // default: implementation dependent
  whiteList['pause-after'] = false; // default: implementation dependent
  whiteList['pause-before'] = false; // default: implementation dependent
  whiteList['perspective'] = false; // default: none
  whiteList['perspective-origin'] = false; // default: 50% 50%
  whiteList['pitch'] = false; // default: medium
  whiteList['pitch-range'] = false; // default: 50
  whiteList['play-during'] = false; // default: auto
  whiteList['position'] = false; // default: static
  whiteList['presentation-level'] = false; // default: 0
  whiteList['quotes'] = false; // default: text
  whiteList['region-fragment'] = false; // default: auto
  whiteList['resize'] = false; // default: none
  whiteList['rest'] = false; // default: depending on individual properties
  whiteList['rest-after'] = false; // default: none
  whiteList['rest-before'] = false; // default: none
  whiteList['richness'] = false; // default: 50
  whiteList['right'] = false; // default: auto
  whiteList['rotation'] = false; // default: 0
  whiteList['rotation-point'] = false; // default: 50% 50%
  whiteList['ruby-align'] = false; // default: auto
  whiteList['ruby-merge'] = false; // default: separate
  whiteList['ruby-position'] = false; // default: before
  whiteList['shape-image-threshold'] = false; // default: 0.0
  whiteList['shape-outside'] = false; // default: none
  whiteList['shape-margin'] = false; // default: 0
  whiteList['size'] = false; // default: auto
  whiteList['speak'] = false; // default: auto
  whiteList['speak-as'] = false; // default: normal
  whiteList['speak-header'] = false; // default: once
  whiteList['speak-numeral'] = false; // default: continuous
  whiteList['speak-punctuation'] = false; // default: none
  whiteList['speech-rate'] = false; // default: medium
  whiteList['stress'] = false; // default: 50
  whiteList['string-set'] = false; // default: none
  whiteList['tab-size'] = false; // default: 8
  whiteList['table-layout'] = false; // default: auto
  whiteList['text-align'] = true; // default: start
  whiteList['text-align-last'] = true; // default: auto
  whiteList['text-combine-upright'] = true; // default: none
  whiteList['text-decoration'] = true; // default: none
  whiteList['text-decoration-color'] = true; // default: currentColor
  whiteList['text-decoration-line'] = true; // default: none
  whiteList['text-decoration-skip'] = true; // default: objects
  whiteList['text-decoration-style'] = true; // default: solid
  whiteList['text-emphasis'] = true; // default: depending on individual properties
  whiteList['text-emphasis-color'] = true; // default: currentColor
  whiteList['text-emphasis-position'] = true; // default: over right
  whiteList['text-emphasis-style'] = true; // default: none
  whiteList['text-height'] = true; // default: auto
  whiteList['text-indent'] = true; // default: 0
  whiteList['text-justify'] = true; // default: auto
  whiteList['text-orientation'] = true; // default: mixed
  whiteList['text-overflow'] = true; // default: clip
  whiteList['text-shadow'] = true; // default: none
  whiteList['text-space-collapse'] = true; // default: collapse
  whiteList['text-transform'] = true; // default: none
  whiteList['text-underline-position'] = true; // default: auto
  whiteList['text-wrap'] = true; // default: normal
  whiteList['top'] = false; // default: auto
  whiteList['transform'] = false; // default: none
  whiteList['transform-origin'] = false; // default: 50% 50% 0
  whiteList['transform-style'] = false; // default: flat
  whiteList['transition'] = false; // default: depending on individual properties
  whiteList['transition-delay'] = false; // default: 0s
  whiteList['transition-duration'] = false; // default: 0s
  whiteList['transition-property'] = false; // default: all
  whiteList['transition-timing-function'] = false; // default: ease
  whiteList['unicode-bidi'] = false; // default: normal
  whiteList['vertical-align'] = false; // default: baseline
  whiteList['visibility'] = false; // default: visible
  whiteList['voice-balance'] = false; // default: center
  whiteList['voice-duration'] = false; // default: auto
  whiteList['voice-family'] = false; // default: implementation dependent
  whiteList['voice-pitch'] = false; // default: medium
  whiteList['voice-range'] = false; // default: medium
  whiteList['voice-rate'] = false; // default: normal
  whiteList['voice-stress'] = false; // default: normal
  whiteList['voice-volume'] = false; // default: medium
  whiteList['volume'] = false; // default: medium
  whiteList['white-space'] = false; // default: normal
  whiteList['widows'] = false; // default: 2
  whiteList['width'] = true; // default: auto
  whiteList['will-change'] = false; // default: auto
  whiteList['word-break'] = true; // default: normal
  whiteList['word-spacing'] = true; // default: normal
  whiteList['word-wrap'] = true; // default: normal
  whiteList['wrap-flow'] = false; // default: auto
  whiteList['wrap-through'] = false; // default: wrap
  whiteList['writing-mode'] = false; // default: horizontal-tb
  whiteList['z-index'] = false; // default: auto

  return whiteList;
}


/**
 * 匹配到白名单上的一个属性时
 *
 * @param {String} name
 * @param {String} value
 * @param {Object} options
 * @return {String}
 */
function onAttr (name, value, options) {
  // do nothing
}

/**
 * 匹配到不在白名单上的一个属性时
 *
 * @param {String} name
 * @param {String} value
 * @param {Object} options
 * @return {String}
 */
function onIgnoreAttr (name, value, options) {
  // do nothing
}

var REGEXP_URL_JAVASCRIPT = /javascript\s*\:/img;

/**
 * 过滤属性值
 *
 * @param {String} name
 * @param {String} value
 * @return {String}
 */
function safeAttrValue(name, value) {
  if (REGEXP_URL_JAVASCRIPT.test(value)) return '';
  return value;
}


exports.whiteList = getDefaultWhiteList();
exports.getDefaultWhiteList = getDefaultWhiteList;
exports.onAttr = onAttr;
exports.onIgnoreAttr = onIgnoreAttr;
exports.safeAttrValue = safeAttrValue;


/***/ }),

/***/ "./node_modules/cssfilter/lib/index.js":
/*!*********************************************!*\
  !*** ./node_modules/cssfilter/lib/index.js ***!
  \*********************************************/
/***/ ((module, exports, __webpack_require__) => {

/**
 * cssfilter
 *
 * @author 老雷<leizongmin@gmail.com>
 */

var DEFAULT = __webpack_require__(/*! ./default */ "./node_modules/cssfilter/lib/default.js");
var FilterCSS = __webpack_require__(/*! ./css */ "./node_modules/cssfilter/lib/css.js");


/**
 * XSS过滤
 *
 * @param {String} css 要过滤的CSS代码
 * @param {Object} options 选项：whiteList, onAttr, onIgnoreAttr
 * @return {String}
 */
function filterCSS (html, options) {
  var xss = new FilterCSS(options);
  return xss.process(html);
}


// 输出
exports = module.exports = filterCSS;
exports.FilterCSS = FilterCSS;
for (var i in DEFAULT) exports[i] = DEFAULT[i];

// 在浏览器端使用
if (typeof window !== 'undefined') {
  window.filterCSS = module.exports;
}


/***/ }),

/***/ "./node_modules/cssfilter/lib/parser.js":
/*!**********************************************!*\
  !*** ./node_modules/cssfilter/lib/parser.js ***!
  \**********************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/**
 * cssfilter
 *
 * @author 老雷<leizongmin@gmail.com>
 */

var _ = __webpack_require__(/*! ./util */ "./node_modules/cssfilter/lib/util.js");


/**
 * 解析style
 *
 * @param {String} css
 * @param {Function} onAttr 处理属性的函数
 *   参数格式： function (sourcePosition, position, name, value, source)
 * @return {String}
 */
function parseStyle (css, onAttr) {
  css = _.trimRight(css);
  if (css[css.length - 1] !== ';') css += ';';
  var cssLength = css.length;
  var isParenthesisOpen = false;
  var lastPos = 0;
  var i = 0;
  var retCSS = '';

  function addNewAttr () {
    // 如果没有正常的闭合圆括号，则直接忽略当前属性
    if (!isParenthesisOpen) {
      var source = _.trim(css.slice(lastPos, i));
      var j = source.indexOf(':');
      if (j !== -1) {
        var name = _.trim(source.slice(0, j));
        var value = _.trim(source.slice(j + 1));
        // 必须有属性名称
        if (name) {
          var ret = onAttr(lastPos, retCSS.length, name, value, source);
          if (ret) retCSS += ret + '; ';
        }
      }
    }
    lastPos = i + 1;
  }

  for (; i < cssLength; i++) {
    var c = css[i];
    if (c === '/' && css[i + 1] === '*') {
      // 备注开始
      var j = css.indexOf('*/', i + 2);
      // 如果没有正常的备注结束，则后面的部分全部跳过
      if (j === -1) break;
      // 直接将当前位置调到备注结尾，并且初始化状态
      i = j + 1;
      lastPos = i + 1;
      isParenthesisOpen = false;
    } else if (c === '(') {
      isParenthesisOpen = true;
    } else if (c === ')') {
      isParenthesisOpen = false;
    } else if (c === ';') {
      if (isParenthesisOpen) {
        // 在圆括号里面，忽略
      } else {
        addNewAttr();
      }
    } else if (c === '\n') {
      addNewAttr();
    }
  }

  return _.trim(retCSS);
}

module.exports = parseStyle;


/***/ }),

/***/ "./node_modules/cssfilter/lib/util.js":
/*!********************************************!*\
  !*** ./node_modules/cssfilter/lib/util.js ***!
  \********************************************/
/***/ ((module) => {

module.exports = {
  indexOf: function (arr, item) {
    var i, j;
    if (Array.prototype.indexOf) {
      return arr.indexOf(item);
    }
    for (i = 0, j = arr.length; i < j; i++) {
      if (arr[i] === item) {
        return i;
      }
    }
    return -1;
  },
  forEach: function (arr, fn, scope) {
    var i, j;
    if (Array.prototype.forEach) {
      return arr.forEach(fn, scope);
    }
    for (i = 0, j = arr.length; i < j; i++) {
      fn.call(scope, arr[i], i, arr);
    }
  },
  trim: function (str) {
    if (String.prototype.trim) {
      return str.trim();
    }
    return str.replace(/(^\s*)|(\s*$)/g, '');
  },
  trimRight: function (str) {
    if (String.prototype.trimRight) {
      return str.trimRight();
    }
    return str.replace(/(\s*$)/g, '');
  }
};


/***/ }),

/***/ "./node_modules/jsb-util/src/index.js":
/*!********************************************!*\
  !*** ./node_modules/jsb-util/src/index.js ***!
  \********************************************/
/***/ ((module, exports, __webpack_require__) => {

const memory = __webpack_require__(/*! ./lib/memory */ "./node_modules/jsb-util/src/lib/memory.js")
const formatXss = __webpack_require__(/*! ./lib/formatXss */ "./node_modules/jsb-util/src/lib/formatXss.js")
const cookie = __webpack_require__(/*! ./lib/cookie */ "./node_modules/jsb-util/src/lib/cookie.js")
const util = __webpack_require__(/*! ./lib/util */ "./node_modules/jsb-util/src/lib/util.js")

exports.isMobileOrMail = util.isMobileOrMail;
exports.isMobile = util.isMobile;
exports.isMail = util.isMail;
exports.memory = memory;
exports.formatXss = formatXss;
exports.cookie = cookie;
exports.debounce = util.debounce;
exports.throttle = util.throttle
//将整个模块导出
module.exports.jsbUtil = {
    ...util, formatXss, memory, cookie
}


/***/ }),

/***/ "./node_modules/jsb-util/src/lib/cookie.js":
/*!*************************************************!*\
  !*** ./node_modules/jsb-util/src/lib/cookie.js ***!
  \*************************************************/
/***/ ((module) => {

/**
 * @description:cookie基本管理
 */
function Cookie() {

}

/**
 * @description:获取对应的key
 * @param {string} key key
 * @param {anys} value 没有找到时返回的预设值，默认false
 * @return {string|Boolean} string / false
 */
Cookie.prototype.get = function (key, def = false) {
    let arr = document.cookie.split(";");
    for (let item of arr) {
        const el = item.split("=");
        if (el[0].trim() === key) {
            return el[1];
        }
    }
    return def;
}
/**
 * @description:设置对应的key value
 * @param {string} key key
 * @param {string} value value
 * @param {Date} expires 过期时间 Date对象
 * @return {Boolean} Boolean
 */
Cookie.prototype.set = function (key, value, expires = "") {
    if (key.trim() == "") return false;
    document.cookie = `${key}=${value};expires=${expires}`;
}
/**
 * @description:删除对应的key
 * @param {string} key key
 * @return {void} void
 */
Cookie.prototype.del = function (key) {
    document.cookie = `${key}=0; path=/; expires=${new Date(0).toUTCString()}`
}
/**
 * @description:清除本地所有cookie
 * @return {void} void
 */
Cookie.prototype.clear = function () {
    let list = document.cookie.match(/[^ =;]+(?=\=)/g);
    for (let i = 0; i < list.length; i++) {
        this.del(list[i]);
    }
    document.cookie = `=0; path=/; expires=${new Date(0).toUTCString()}`
}

module.exports = new Cookie()


/***/ }),

/***/ "./node_modules/jsb-util/src/lib/formatXss.js":
/*!****************************************************!*\
  !*** ./node_modules/jsb-util/src/lib/formatXss.js ***!
  \****************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

const xss = __webpack_require__(/*! xss */ "./node_modules/xss/lib/index.js");
/**
 * @description:xss过滤
 * @param {string} Html 富文本内容
 * @param {array} format 允许放行的html标签
 * @param {array} attr 允许放行的标签属性标签
 * @return {string} htmlString
 */
function formatXss(Html, format = [], attr = []){
    //允许通过的标签
    const tag = [
        "p",
        "a",
        "img",
        "font",
        "span",
        "b",
        "blockquote",
        "code",
        "h1",
        "h2",
        "h3",
        "h4",
        "h5",
        "h6",
        "hr",
        "br",
        "s",
        "i",
        "u",
        "strike",
        "div",
        "strong",
        "pre"
    ];
    if (format.length > 0) {
        format.forEach(el => {
            tag.push(el);
        })
    }
    //允许使用的属性
    const can = ["color", "size", "style", "href", "src"];
    if (attr.length > 0) {
        attr.map(e => {
            can.push(e)
        })
    }
    let tmp = {};
    for (let index = 0; index < tag.length; index++) {
        const element = tag[index];
        tmp[element] = can;
    }
    let text = xss(Html, {
        whiteList: tmp,
    });
    return text;
}

module.exports = formatXss


/***/ }),

/***/ "./node_modules/jsb-util/src/lib/memory.js":
/*!*************************************************!*\
  !*** ./node_modules/jsb-util/src/lib/memory.js ***!
  \*************************************************/
/***/ ((module) => {

/**
 * @description:localStorage储存管理
 * @returns {Memory}
 */
class Memory {
    Local = null;

    constructor() {
        this.Local = localStorage || window.localStorage;
    }

    /**
     * @description: 设置本地localStorage储存
     * @param {*} key 键
     * @param {Object|String} value 值
     * @return {Memory} Memory 可实现链式连续调用
     */
    set(key, value) {
        if (typeof value == "object") {
            value = JSON.stringify(value);
        }
        this.Local.setItem(key, value);
        return this;
    }

    /**
     * @description: 获取键
     * @param {*} key
     * @return {Object|String} value 返回值
     */
    get(key) {
        let info = this.Local.getItem(key);
        if (info === "" || !info) {
            return "";
        }
        return this.isObj(info);
    }

    /**
     * @description: 判断字符串是不是json对象
     * @param {*} str
     * @return {*}
     */
    isObj(str) {
        if (typeof str == "string") {
            try {
                let obj = JSON.parse(str);
                if (typeof obj == "object" && obj) {
                    return obj;
                } else {
                    return str;
                }
            } catch (e) {
                return str;
            }
        }
    }

    /**
     * @description: 删除本地localStorage储存key
     * @param {*} key
     * @return {Memory} boolean
     */
    del(key) {
        this.Local.removeItem(key);
        return this; //返回自身，可以实现链式调用Memory().del(key).del(key).set(key,value);
    }

    /**
     * @description: 清除全部本地localStorage储存
     * @return {Memory} boolean
     */
    clear() {
        this.Local.clear();
        return this;
    }
}

var memory = new Memory()
module.exports = memory;


/***/ }),

/***/ "./node_modules/jsb-util/src/lib/util.js":
/*!***********************************************!*\
  !*** ./node_modules/jsb-util/src/lib/util.js ***!
  \***********************************************/
/***/ ((module) => {

/**
 * @description:验证是否为手机账号
 * @param {string} Mobile 手机账号
 * @return {Boolean} Boolean
 */
const isMobile = (Mobile = "") => {
    return /^1[3456789]\d{9}$/.test(Mobile);
}

/**
 * @description:验证是否为邮箱
 * @param {string} Mail 邮箱账号
 * @return {Boolean} Boolean
 */
const isMail = (Mail = "") => {
    return /^[A-Za-z0-9\u4e00-\u9fa5]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/.test(Mail)
}

/**
 * @description:验证一段字符串是邮箱还是手机号码
 * @param {string} account 字符串
 * @return {String|Boolean} mail / mobile / false
 */
const isMobileOrMail = (account) => {
    if (isMail(account)) {
        return "mail"
    }
    if (isMobile(account)) {
        return "mobile"
    }
    return false;
}
/**
 * @description:防抖
 * @param fn 方法名|回调函数
 * @param wait 前后间隔时间间距
 * @returns {(function(): void)|*} 闭包方法
 */
const debounce = (fn, wait) => {
    let timer = null;
    return function () {
        if (timer !== null) {
            clearTimeout(timer);
        }
        timer = setTimeout(fn, wait);
    }
}
/**
 * @description:截流
 * @param fn 方法名｜回调函数
 * @param wait 每次调用间隔
 * @return {(function(): void)|*}
 */
const throttle = (fn, wait) => {
    let timer = true;
    return function () {
        if (!timer) return;
        timer = false;
        setTimeout(function () {
            fn.apply(this, arguments)
            timer = true;
        }, wait)
    }
}

module.exports = {
    debounce, isMobileOrMail, isMail, isMobile, throttle
}


/***/ }),

/***/ "./src/css/index.scss":
/*!****************************!*\
  !*** ./src/css/index.scss ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./src/assets/360.svg":
/*!****************************!*\
  !*** ./src/assets/360.svg ***!
  \****************************/
/***/ ((module) => {

module.exports = "data:image/svg+xml;base64,PHN2ZyB0PSIxNjUwNDIwNTE1OTA0IiBjbGFzcz0iaWNvbiIgdmlld0JveD0iMCAwIDEwMjQgMTAyNCIgdmVyc2lvbj0iMS4xIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHAtaWQ9IjY3ODEiIHdpZHRoPSIyMDAiIGhlaWdodD0iMjAwIj48cGF0aCBkPSJNNDU3Ljg4MTYgOTU0LjI2NTZDMjE0LjAxNiA5NTQuMjY1NiAxNS42MTYgNzU1Ljg2NTYgMTUuNjE2IDUxMlMyMTQuMDE2IDY5LjczNDQgNDU3Ljg4MTYgNjkuNzM0NHM0NDIuMjY1NiAxOTguNCA0NDIuMjY1NiA0NDIuMjY1Ni0xOTguNDEwMjQgNDQyLjI2NTYtNDQyLjI2NTYgNDQyLjI2NTZ6IG0wLTc0Mi4yNTY2NGMtMTY1LjQxNjk2IDAtMjk5Ljk5MTA0IDEzNC41NzQwOC0yOTkuOTkxMDQgMjk5Ljk5MTA0UzI5Mi40NTQ0IDgxMS45OTEwNCA0NTcuODgxNiA4MTEuOTkxMDQgNzU3Ljg3MjY0IDY3Ny40MTY5NiA3NTcuODcyNjQgNTEyIDYyMy4yOTg1NiAyMTIuMDA4OTYgNDU3Ljg4MTYgMjEyLjAwODk2eiIgZmlsbD0iIzJDQUM1NyIgcC1pZD0iNjc4MiI+PC9wYXRoPjxwYXRoIGQ9Ik05MzcuMjQ2NzIgODQ5LjExMTA0bS03MS4xMzcyOCAwYTcxLjEzNzI4IDcxLjEzNzI4IDAgMSAwIDE0Mi4yNzQ1NiAwIDcxLjEzNzI4IDcxLjEzNzI4IDAgMSAwLTE0Mi4yNzQ1NiAwWiIgZmlsbD0iI0Y0QjEyMiIgcC1pZD0iNjc4MyI+PC9wYXRoPjxwYXRoIGQ9Ik00NTcuODgxNiA5NTQuMjY1NmMtMTc1LjMzOTUyIDAtMzM0LjI4NDgtMTAzLjcxMDcyLTQwNC45NDA4LTI2NC4yMTI0OGwtMS45NTU4NC00LjUwNTZjLTE1LjQxMTItMzYuMTM2OTYgMS4zOTI2NC03Ny45MjY0IDM3LjUxOTM2LTkzLjMzNzYgMzYuMTI2NzItMTUuNDExMiA3Ny45MjY0IDEuMzgyNCA5My4zMzc2IDM3LjUxOTM2bDEuMjkwMjQgMi45Njk2YzQ3Ljk1MzkyIDEwOC45MzMxMiAxNTUuNzkxMzYgMTc5LjI5MjE2IDI3NC43MzkyIDE3OS4yOTIxNiAxMTcuNTU1MiAwIDIyNC44ODA2NC02OS4yMTIxNiAyNzMuNDE4MjQtMTc2LjMyMjU2IDAuNjU1MzYtMS40NDM4NCAxLjMxMDcyLTIuOTE4NCAxLjk0NTYtNC4zOTI5NiAxNS42MDU3Ni0zNi4wNTUwNCA1Ny40NzcxMi01Mi42MzM2IDkzLjUzMjE2LTM3LjAyNzg0IDM2LjA1NTA0IDE1LjYwNTc2IDUyLjYzMzYgNTcuNDc3MTIgMzcuMDI3ODQgOTMuNTMyMTYtMC45NTIzMiAyLjIxMTg0LTEuOTM1MzYgNC40MDMyLTIuOTI4NjQgNi41OTQ1Ni03MS41MzY2NCAxNTcuODgwMzItMjI5LjcyNDE2IDI1OS44OTEyLTQwMi45ODQ5NiAyNTkuODkxMnoiIGZpbGw9IiNGNEIxMjIiIHAtaWQ9IjY3ODQiPjwvcGF0aD48L3N2Zz4K"

/***/ }),

/***/ "./src/assets/baidu.svg":
/*!******************************!*\
  !*** ./src/assets/baidu.svg ***!
  \******************************/
/***/ ((module) => {

module.exports = "data:image/svg+xml;base64,PHN2ZyB0PSIxNjUwNDIwMDY3OTMwIiBjbGFzcz0iaWNvbiIgdmlld0JveD0iMCAwIDEwMjQgMTAyNCIgdmVyc2lvbj0iMS4xIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHAtaWQ9IjMzNjgiIHdpZHRoPSIyMDAiIGhlaWdodD0iMjAwIj48cGF0aCBkPSJNMTg0LjY4MiA1MzguNzU5YzExMS4xNzctMjMuODc0IDk2LjAzLTE1Ni43MzcgOTIuNzAyLTE4NS43NzYtNS40NDUtNDQuNzY4LTU4LjEwMi0xMjMuMDItMTI5LjYwNi0xMTYuODMxLTg5Ljk4IDguMDc0LTEwMy4xMjYgMTM4LjA1Mi0xMDMuMTI2IDEzOC4wNTItMTIuMTcgNjAuMDggMjkuMTMyIDE4OC40NTIgMTQwLjAzIDE2NC41NTV6TTMwMi43NDYgNzY5Ljg2Yy0zLjI1NyA5LjMzMS0xMC41MTcgMzMuMjI4LTQuMjM0IDU0LjAzIDEyLjQwMiA0Ni42NzcgNTIuOTEyIDQ4Ljc3IDUyLjkxMiA0OC43N2g1OC4yMTh2LTE0Mi4zMWgtNjIuMzM2Yy0yOC4wMTYgOC4zNTQtNDEuNTM1IDMwLjE1Ny00NC41NiAzOS41MXogbTg4LjI4MS00NTMuODk4YzYxLjQwNiAwIDExMS4wMzctNzAuNjY3IDExMS4wMzctMTU4LjA0QzUwMi4wNjQgNzAuNjQzIDQ1Mi40MzMgMCAzOTEuMDI3IDBjLTYxLjMxMiAwLTExMS4wNiA3MC42NDMtMTExLjA2IDE1Ny45MjMgMCA4Ny4zNzMgNDkuNzcgMTU4LjA0IDExMS4wNiAxNTguMDR6IG0yNjQuNDcgMTAuNDQ3YzgyLjA2OCAxMC42NTcgMTM0Ljg0LTc2LjkyNSAxNDUuMzM1LTE0My4zMSAxMC43MDMtNjYuMjkyLTQyLjI1Ni0xNDMuMjg4LTEwMC4zNTctMTU2LjUyNy01OC4yMTgtMTMuMzU2LTEzMC45MDkgNzkuOTA0LTEzNy41NCAxNDAuNzA0LTcuOTEyIDc0LjMyIDEwLjYzMyAxNDguNTkzIDkyLjU2MiAxNTkuMTMzeiBtMjAxLjA4NiAzOTAuMjEzcy0xMjYuOTc2LTk4LjI0LTIwMS4xMS0yMDQuNDE0QzU1NSAzNTUuNjYgNDEyLjI3MiA0MTkuMzcgMzY0LjUyNSA0OTguOTkzIDMxNi45ODcgNTc4LjU5NCAyNDIuOSA2MjguOTQ3IDIzMi4zODIgNjQyLjI4Yy0xMC42OCAxMy4xMjQtMTUzLjM4NSA5MC4xNjYtMTIxLjY5NCAyMzAuODcgMzEuNjY5IDE0MC42MTIgMTQyLjkzOSAxMzcuOTM2IDE0Mi45MzkgMTM3LjkzNnM4MS45OTggOC4wNzQgMTc3LjEyLTEzLjIxN2M5NS4xNjgtMjEuMTA0IDE3Ny4wOTYgNS4yNiAxNzcuMDk2IDUuMjZzMjIyLjI4NCA3NC40MzUgMjgzLjEwOC02OC44NTJjNjAuNzU0LTE0My4zMzQtMzQuMzY4LTIxNy42NTQtMzQuMzY4LTIxNy42NTR6TTQ3Ni4yNiA5MjkuODhIMzMxLjczOWMtNjIuNDA2LTEyLjQ0OS04Ny4yNTctNTUuMDMtOTAuMzk4LTYyLjI5LTMuMDcyLTcuMzc2LTIwLjgwMi00MS42MDQtMTEuNDI1LTk5Ljg0NSAyNi45NjgtODcuMjU3IDEwMy44Ny05My41MTYgMTAzLjg3LTkzLjUxNmg3Ni45MjZ2LTk0LjU2M2w2NS41MjQgMVY5MjkuODh6IG0yNjkuMTQ2LTFoLTE2Ni4zYy02NC40NTMtMTYuNjE0LTY3LjQ1NS02Mi40MDctNjcuNDU1LTYyLjQwN3YtMTgzLjg5bDY3LjQ1NS0xLjA5NHYxNjUuMjc2YzQuMTE5IDE3LjYzNyAyNi4wMTUgMjAuODI1IDI2LjAxNSAyMC44MjVoNjguNTI1VjY4Mi41ODFoNzEuNzZ2MjQ2LjI5N3ogbTIzNS40MDgtNDkwLjk5YzAtMzEuNzYtMjYuMzg3LTEyNy4zOTQtMTI0LjIzLTEyNy4zOTQtOTguMDA4IDAtMTExLjEwOCA5MC4yNTgtMTExLjEwOCAxNTQuMDYgMCA2MC44OTQgNS4xNDIgMTQ1Ljg5NCAxMjYuODgzIDE0My4xOTUgMTIxLjc4OC0yLjcgMTA4LjQ1NS0xMzcuOTM2IDEwOC40NTUtMTY5Ljg2eiBtMCAwIiBmaWxsPSIjMzI0NURGIiBwLWlkPSIzMzY5Ij48L3BhdGg+PC9zdmc+Cg=="

/***/ }),

/***/ "./src/assets/bing.svg":
/*!*****************************!*\
  !*** ./src/assets/bing.svg ***!
  \*****************************/
/***/ ((module) => {

module.exports = "data:image/svg+xml;base64,PHN2ZyB0PSIxNjUwNDIwNTQzMTkzIiBjbGFzcz0iaWNvbiIgdmlld0JveD0iMCAwIDEwMjQgMTAyNCIgdmVyc2lvbj0iMS4xIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHAtaWQ9IjgzNDMiIHdpZHRoPSIyMDAiIGhlaWdodD0iMjAwIj48cGF0aCBkPSJNMzQwLjU4MjQgNzAuMTA5ODY3TDEwMi41MzY1MzMgMC42ODI2Njd2ODUxLjIxNzA2NkwzNDAuNjUwNjY3IDY0My4zNDUwNjdWNzAuMTA5ODY3ek0xMDIuNTM2NTMzIDg1MS43NjMybDIzOC4wNDU4NjcgMTcxLjYyMjQgNTgwLjg4MTA2Ny0zNDAuOTIzNzMzVjQxMS43ODQ1MzNMMTAyLjUzNjUzMyA4NTEuODMxNDY3eiIgZmlsbD0iIzQwOUVGRiIgcC1pZD0iODM0NCI+PC9wYXRoPjxwYXRoIGQ9Ik00MDkuNDYzNDY3IDI1NS4zODU2bDExMy43MzIyNjYgMjM4LjkzMzMzMyAxMzguODU0NCA1Ni44NjYxMzQgMjU5LjQxMzMzNC0xMzkuNDAwNTM0LTUwNi4wNjA4LTE1Ni4zMzA2NjZ6IiBmaWxsPSIjNDA5RUZGIiBwLWlkPSI4MzQ1Ij48L3BhdGg+PC9zdmc+Cg=="

/***/ }),

/***/ "./src/assets/google.svg":
/*!*******************************!*\
  !*** ./src/assets/google.svg ***!
  \*******************************/
/***/ ((module) => {

module.exports = "data:image/svg+xml;base64,PHN2ZyB0PSIxNjUwNDE5OTg3NjgwIiBjbGFzcz0iaWNvbiIgdmlld0JveD0iMCAwIDEwMjQgMTAyNCIgdmVyc2lvbj0iMS4xIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHAtaWQ9IjI1NjIiIHdpZHRoPSIyMDAiIGhlaWdodD0iMjAwIj48cGF0aCBkPSJNMjE0LjEwMTMzMyA1MTJjMC0zMi41MTIgNS41NDY2NjctNjMuNzAxMzMzIDE1LjM2LTkyLjkyOEw1Ny4xNzMzMzMgMjkwLjIxODY2N0E0OTEuODYxMzMzIDQ5MS44NjEzMzMgMCAwIDAgNC42OTMzMzMgNTEyYzAgNzkuNzAxMzMzIDE4Ljg1ODY2NyAxNTQuODggNTIuMzk0NjY3IDIyMS42MTA2NjdsMTcyLjIwMjY2Ny0xMjkuMDY2NjY3QTI5MC41NiAyOTAuNTYgMCAwIDEgMjE0LjEwMTMzMyA1MTIiIGZpbGw9IiNGQkJDMDUiIHAtaWQ9IjI1NjMiPjwvcGF0aD48cGF0aCBkPSJNNTE2LjY5MzMzMyAyMTYuMTkyYzcyLjEwNjY2NyAwIDEzNy4yNTg2NjcgMjUuMDAyNjY3IDE4OC40NTg2NjcgNjUuOTYyNjY3TDg1NC4xMDEzMzMgMTM2LjUzMzMzM0M3NjMuMzQ5MzMzIDU5LjE3ODY2NyA2NDYuOTk3MzMzIDExLjM5MiA1MTYuNjkzMzMzIDExLjM5MmMtMjAyLjMyNTMzMyAwLTM3Ni4yMzQ2NjcgMTEzLjI4LTQ1OS41MiAyNzguODI2NjY3bDE3Mi4zNzMzMzQgMTI4Ljg1MzMzM2MzOS42OC0xMTguMDE2IDE1Mi44MzItMjAyLjg4IDI4Ny4xNDY2NjYtMjAyLjg4IiBmaWxsPSIjRUE0MzM1IiBwLWlkPSIyNTY0Ij48L3BhdGg+PHBhdGggZD0iTTUxNi42OTMzMzMgODA3LjgwOGMtMTM0LjM1NzMzMyAwLTI0Ny41MDkzMzMtODQuODY0LTI4Ny4yMzItMjAyLjg4bC0xNzIuMjg4IDEyOC44NTMzMzNjODMuMjQyNjY3IDE2NS41NDY2NjcgMjU3LjE1MiAyNzguODI2NjY3IDQ1OS41MiAyNzguODI2NjY3IDEyNC44NDI2NjcgMCAyNDQuMDUzMzMzLTQzLjM5MiAzMzMuNTY4LTEyNC43NTczMzNsLTE2My41ODQtMTIzLjgxODY2N2MtNDYuMTIyNjY3IDI4LjQ1ODY2Ny0xMDQuMjM0NjY3IDQzLjc3Ni0xNzAuMDI2NjY2IDQzLjc3NiIgZmlsbD0iIzM0QTg1MyIgcC1pZD0iMjU2NSI+PC9wYXRoPjxwYXRoIGQ9Ik0xMDA1LjM5NzMzMyA1MTJjMC0yOS41NjgtNC42OTMzMzMtNjEuNDQtMTEuNjQ4LTkxLjAwOEg1MTYuNjUwNjY3VjYxNC40aDI3NC42MDI2NjZjLTEzLjY5NiA2NS45NjI2NjctNTEuMDcyIDExNi42NTA2NjctMTA0LjUzMzMzMyAxNDkuNjMybDE2My41NDEzMzMgMTIzLjgxODY2N2M5My45OTQ2NjctODUuNDE4NjY3IDE1NS4xMzYtMjEyLjY1MDY2NyAxNTUuMTM2LTM3NS44NTA2NjciIGZpbGw9IiM0Mjg1RjQiIHAtaWQ9IjI1NjYiPjwvcGF0aD48L3N2Zz4K"

/***/ }),

/***/ "./src/assets/sougou.svg":
/*!*******************************!*\
  !*** ./src/assets/sougou.svg ***!
  \*******************************/
/***/ ((module) => {

module.exports = "data:image/svg+xml;base64,PHN2ZyB0PSIxNjUwNDIwNDEzNzY2IiBjbGFzcz0iaWNvbiIgdmlld0JveD0iMCAwIDEwMjQgMTAyNCIgdmVyc2lvbj0iMS4xIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHAtaWQ9IjUwOTAiIHdpZHRoPSIyMDAiIGhlaWdodD0iMjAwIj48cGF0aCBkPSJNNTEwLjA1MDMwMiAxMDA5LjExMzMwOGE1MDQuNTQ4NzggNTA0LjU0ODc4IDAgMSAxIDUwNC40NzA3OTMtNTA0LjU0ODc4IDUwNS4wOTQ2OTYgNTA1LjA5NDY5NiAwIDAgMS01MDQuNDcxNzkzIDUwNC40NzE3OTJ6IG0wLTk4MC4wMDEwNzFhNDc1LjQ1MjI5MSA0NzUuNDUyMjkxIDAgMSAwIDQ3NS4zNzQzMDMgNDc1LjQ1MjI5MUE0NzUuOTk4MjA2IDQ3NS45OTgyMDYgMCAwIDAgNTEwLjA1MDMwMiAyOS4xMTIyMzd6IiBmaWxsPSIjM0VBMUZDIiBwLWlkPSI1MDkxIj48L3BhdGg+PHBhdGggZD0iTTY5NC4zMDE3MzggOTEzLjE2NTE4M2MxODQuNjQzMzc1LTg4LjUzODI3NCAyNzMuODA0NTUyLTIzNy4xNDEyMzYgMjY3LjQwODU0NC00NDUuOTY1ODYzLTIyLjIzMjU1My0zNDQuNTU2NTg0LTQzOC45NDQ5NTEtNDgyLjg2MzE0Mi01MzIuOTQzMzc4LTI2OC42NTYzNS00NC4zMDgxMzEgMTk2LjE4NzU4NSAyMjMuNTY3MzQxIDE3NC40MjM5NTkgMzI5LjE4ODk2NiAzMjAuNDUzMzIgOTQuMzg4MzY3IDEzMy4wNzkzNjkgNzMuMTcwNjU2IDI2NC40NDMwMDQtNjMuNjUzMTMyIDM5NC4xNjg4OTN6IiBmaWxsPSIjM0VBMUZDIiBwLWlkPSI1MDkyIj48L3BhdGg+PHBhdGggZD0iTTMyMS42NjM1MDggOTYuNTg4Nzc2QzEzNy4wMjAxMzMgMTg1LjEyNjA1IDQ3Ljg1ODk1NSAzMzMuODA3IDU0LjI1NDk2NCA1NDIuNTUzNjM4IDc2LjQ4NzUxNyA4ODcuMTExMjIyIDQ5My4xOTk5MTUgMTAyNS40MTY3OCA1ODcuMTk4MzQyIDgxMS4yMDk5ODljNDQuMzg2MTE5LTE5Ni4xODc1ODUtMjIzLjQ4OTM1My0xNzQuNDIyOTU5LTMyOS4wMzI5OS0zMjAuMzc0MzMzLTk0LjM4ODM2Ny0xMzMuMzE0MzMyLTczLjMyNjYzMi0yNjQuNzU1OTU1IDYzLjQ5ODE1Ni0zOTQuMjQ2ODh6IiBmaWxsPSIjM0VBMUZDIiBwLWlkPSI1MDkzIj48L3BhdGg+PC9zdmc+Cg=="

/***/ }),

/***/ "./node_modules/xss/lib/default.js":
/*!*****************************************!*\
  !*** ./node_modules/xss/lib/default.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

/**
 * default settings
 *
 * @author Zongmin Lei<leizongmin@gmail.com>
 */

var FilterCSS = (__webpack_require__(/*! cssfilter */ "./node_modules/cssfilter/lib/index.js").FilterCSS);
var getDefaultCSSWhiteList = (__webpack_require__(/*! cssfilter */ "./node_modules/cssfilter/lib/index.js").getDefaultWhiteList);
var _ = __webpack_require__(/*! ./util */ "./node_modules/xss/lib/util.js");

function getDefaultWhiteList() {
  return {
    a: ["target", "href", "title"],
    abbr: ["title"],
    address: [],
    area: ["shape", "coords", "href", "alt"],
    article: [],
    aside: [],
    audio: [
      "autoplay",
      "controls",
      "crossorigin",
      "loop",
      "muted",
      "preload",
      "src",
    ],
    b: [],
    bdi: ["dir"],
    bdo: ["dir"],
    big: [],
    blockquote: ["cite"],
    br: [],
    caption: [],
    center: [],
    cite: [],
    code: [],
    col: ["align", "valign", "span", "width"],
    colgroup: ["align", "valign", "span", "width"],
    dd: [],
    del: ["datetime"],
    details: ["open"],
    div: [],
    dl: [],
    dt: [],
    em: [],
    figcaption: [],
    figure: [],
    font: ["color", "size", "face"],
    footer: [],
    h1: [],
    h2: [],
    h3: [],
    h4: [],
    h5: [],
    h6: [],
    header: [],
    hr: [],
    i: [],
    img: ["src", "alt", "title", "width", "height"],
    ins: ["datetime"],
    li: [],
    mark: [],
    nav: [],
    ol: [],
    p: [],
    pre: [],
    s: [],
    section: [],
    small: [],
    span: [],
    sub: [],
    summary: [],
    sup: [],
    strong: [],
    strike: [],
    table: ["width", "border", "align", "valign"],
    tbody: ["align", "valign"],
    td: ["width", "rowspan", "colspan", "align", "valign"],
    tfoot: ["align", "valign"],
    th: ["width", "rowspan", "colspan", "align", "valign"],
    thead: ["align", "valign"],
    tr: ["rowspan", "align", "valign"],
    tt: [],
    u: [],
    ul: [],
    video: [
      "autoplay",
      "controls",
      "crossorigin",
      "loop",
      "muted",
      "playsinline",
      "poster",
      "preload",
      "src",
      "height",
      "width",
    ],
  };
}

var defaultCSSFilter = new FilterCSS();

/**
 * default onTag function
 *
 * @param {String} tag
 * @param {String} html
 * @param {Object} options
 * @return {String}
 */
function onTag(tag, html, options) {
  // do nothing
}

/**
 * default onIgnoreTag function
 *
 * @param {String} tag
 * @param {String} html
 * @param {Object} options
 * @return {String}
 */
function onIgnoreTag(tag, html, options) {
  // do nothing
}

/**
 * default onTagAttr function
 *
 * @param {String} tag
 * @param {String} name
 * @param {String} value
 * @return {String}
 */
function onTagAttr(tag, name, value) {
  // do nothing
}

/**
 * default onIgnoreTagAttr function
 *
 * @param {String} tag
 * @param {String} name
 * @param {String} value
 * @return {String}
 */
function onIgnoreTagAttr(tag, name, value) {
  // do nothing
}

/**
 * default escapeHtml function
 *
 * @param {String} html
 */
function escapeHtml(html) {
  return html.replace(REGEXP_LT, "&lt;").replace(REGEXP_GT, "&gt;");
}

/**
 * default safeAttrValue function
 *
 * @param {String} tag
 * @param {String} name
 * @param {String} value
 * @param {Object} cssFilter
 * @return {String}
 */
function safeAttrValue(tag, name, value, cssFilter) {
  // unescape attribute value firstly
  value = friendlyAttrValue(value);

  if (name === "href" || name === "src") {
    // filter `href` and `src` attribute
    // only allow the value that starts with `http://` | `https://` | `mailto:` | `/` | `#`
    value = _.trim(value);
    if (value === "#") return "#";
    if (
      !(
        value.substr(0, 7) === "http://" ||
        value.substr(0, 8) === "https://" ||
        value.substr(0, 7) === "mailto:" ||
        value.substr(0, 4) === "tel:" ||
        value.substr(0, 11) === "data:image/" ||
        value.substr(0, 6) === "ftp://" ||
        value.substr(0, 2) === "./" ||
        value.substr(0, 3) === "../" ||
        value[0] === "#" ||
        value[0] === "/"
      )
    ) {
      return "";
    }
  } else if (name === "background") {
    // filter `background` attribute (maybe no use)
    // `javascript:`
    REGEXP_DEFAULT_ON_TAG_ATTR_4.lastIndex = 0;
    if (REGEXP_DEFAULT_ON_TAG_ATTR_4.test(value)) {
      return "";
    }
  } else if (name === "style") {
    // `expression()`
    REGEXP_DEFAULT_ON_TAG_ATTR_7.lastIndex = 0;
    if (REGEXP_DEFAULT_ON_TAG_ATTR_7.test(value)) {
      return "";
    }
    // `url()`
    REGEXP_DEFAULT_ON_TAG_ATTR_8.lastIndex = 0;
    if (REGEXP_DEFAULT_ON_TAG_ATTR_8.test(value)) {
      REGEXP_DEFAULT_ON_TAG_ATTR_4.lastIndex = 0;
      if (REGEXP_DEFAULT_ON_TAG_ATTR_4.test(value)) {
        return "";
      }
    }
    if (cssFilter !== false) {
      cssFilter = cssFilter || defaultCSSFilter;
      value = cssFilter.process(value);
    }
  }

  // escape `<>"` before returns
  value = escapeAttrValue(value);
  return value;
}

// RegExp list
var REGEXP_LT = /</g;
var REGEXP_GT = />/g;
var REGEXP_QUOTE = /"/g;
var REGEXP_QUOTE_2 = /&quot;/g;
var REGEXP_ATTR_VALUE_1 = /&#([a-zA-Z0-9]*);?/gim;
var REGEXP_ATTR_VALUE_COLON = /&colon;?/gim;
var REGEXP_ATTR_VALUE_NEWLINE = /&newline;?/gim;
var REGEXP_DEFAULT_ON_TAG_ATTR_3 = /\/\*|\*\//gm;
var REGEXP_DEFAULT_ON_TAG_ATTR_4 =
  /((j\s*a\s*v\s*a|v\s*b|l\s*i\s*v\s*e)\s*s\s*c\s*r\s*i\s*p\s*t\s*|m\s*o\s*c\s*h\s*a)\:/gi;
var REGEXP_DEFAULT_ON_TAG_ATTR_5 = /^[\s"'`]*(d\s*a\s*t\s*a\s*)\:/gi;
var REGEXP_DEFAULT_ON_TAG_ATTR_6 = /^[\s"'`]*(d\s*a\s*t\s*a\s*)\:\s*image\//gi;
var REGEXP_DEFAULT_ON_TAG_ATTR_7 =
  /e\s*x\s*p\s*r\s*e\s*s\s*s\s*i\s*o\s*n\s*\(.*/gi;
var REGEXP_DEFAULT_ON_TAG_ATTR_8 = /u\s*r\s*l\s*\(.*/gi;

/**
 * escape double quote
 *
 * @param {String} str
 * @return {String} str
 */
function escapeQuote(str) {
  return str.replace(REGEXP_QUOTE, "&quot;");
}

/**
 * unescape double quote
 *
 * @param {String} str
 * @return {String} str
 */
function unescapeQuote(str) {
  return str.replace(REGEXP_QUOTE_2, '"');
}

/**
 * escape html entities
 *
 * @param {String} str
 * @return {String}
 */
function escapeHtmlEntities(str) {
  return str.replace(REGEXP_ATTR_VALUE_1, function replaceUnicode(str, code) {
    return code[0] === "x" || code[0] === "X"
      ? String.fromCharCode(parseInt(code.substr(1), 16))
      : String.fromCharCode(parseInt(code, 10));
  });
}

/**
 * escape html5 new danger entities
 *
 * @param {String} str
 * @return {String}
 */
function escapeDangerHtml5Entities(str) {
  return str
    .replace(REGEXP_ATTR_VALUE_COLON, ":")
    .replace(REGEXP_ATTR_VALUE_NEWLINE, " ");
}

/**
 * clear nonprintable characters
 *
 * @param {String} str
 * @return {String}
 */
function clearNonPrintableCharacter(str) {
  var str2 = "";
  for (var i = 0, len = str.length; i < len; i++) {
    str2 += str.charCodeAt(i) < 32 ? " " : str.charAt(i);
  }
  return _.trim(str2);
}

/**
 * get friendly attribute value
 *
 * @param {String} str
 * @return {String}
 */
function friendlyAttrValue(str) {
  str = unescapeQuote(str);
  str = escapeHtmlEntities(str);
  str = escapeDangerHtml5Entities(str);
  str = clearNonPrintableCharacter(str);
  return str;
}

/**
 * unescape attribute value
 *
 * @param {String} str
 * @return {String}
 */
function escapeAttrValue(str) {
  str = escapeQuote(str);
  str = escapeHtml(str);
  return str;
}

/**
 * `onIgnoreTag` function for removing all the tags that are not in whitelist
 */
function onIgnoreTagStripAll() {
  return "";
}

/**
 * remove tag body
 * specify a `tags` list, if the tag is not in the `tags` list then process by the specify function (optional)
 *
 * @param {array} tags
 * @param {function} next
 */
function StripTagBody(tags, next) {
  if (typeof next !== "function") {
    next = function () {};
  }

  var isRemoveAllTag = !Array.isArray(tags);
  function isRemoveTag(tag) {
    if (isRemoveAllTag) return true;
    return _.indexOf(tags, tag) !== -1;
  }

  var removeList = [];
  var posStart = false;

  return {
    onIgnoreTag: function (tag, html, options) {
      if (isRemoveTag(tag)) {
        if (options.isClosing) {
          var ret = "[/removed]";
          var end = options.position + ret.length;
          removeList.push([
            posStart !== false ? posStart : options.position,
            end,
          ]);
          posStart = false;
          return ret;
        } else {
          if (!posStart) {
            posStart = options.position;
          }
          return "[removed]";
        }
      } else {
        return next(tag, html, options);
      }
    },
    remove: function (html) {
      var rethtml = "";
      var lastPos = 0;
      _.forEach(removeList, function (pos) {
        rethtml += html.slice(lastPos, pos[0]);
        lastPos = pos[1];
      });
      rethtml += html.slice(lastPos);
      return rethtml;
    },
  };
}

/**
 * remove html comments
 *
 * @param {String} html
 * @return {String}
 */
function stripCommentTag(html) {
  var retHtml = "";
  var lastPos = 0;
  while (lastPos < html.length) {
    var i = html.indexOf("<!--", lastPos);
    if (i === -1) {
      retHtml += html.slice(lastPos);
      break;
    }
    retHtml += html.slice(lastPos, i);
    var j = html.indexOf("-->", i);
    if (j === -1) {
      break;
    }
    lastPos = j + 3;
  }
  return retHtml;
}

/**
 * remove invisible characters
 *
 * @param {String} html
 * @return {String}
 */
function stripBlankChar(html) {
  var chars = html.split("");
  chars = chars.filter(function (char) {
    var c = char.charCodeAt(0);
    if (c === 127) return false;
    if (c <= 31) {
      if (c === 10 || c === 13) return true;
      return false;
    }
    return true;
  });
  return chars.join("");
}

exports.whiteList = getDefaultWhiteList();
exports.getDefaultWhiteList = getDefaultWhiteList;
exports.onTag = onTag;
exports.onIgnoreTag = onIgnoreTag;
exports.onTagAttr = onTagAttr;
exports.onIgnoreTagAttr = onIgnoreTagAttr;
exports.safeAttrValue = safeAttrValue;
exports.escapeHtml = escapeHtml;
exports.escapeQuote = escapeQuote;
exports.unescapeQuote = unescapeQuote;
exports.escapeHtmlEntities = escapeHtmlEntities;
exports.escapeDangerHtml5Entities = escapeDangerHtml5Entities;
exports.clearNonPrintableCharacter = clearNonPrintableCharacter;
exports.friendlyAttrValue = friendlyAttrValue;
exports.escapeAttrValue = escapeAttrValue;
exports.onIgnoreTagStripAll = onIgnoreTagStripAll;
exports.StripTagBody = StripTagBody;
exports.stripCommentTag = stripCommentTag;
exports.stripBlankChar = stripBlankChar;
exports.cssFilter = defaultCSSFilter;
exports.getDefaultCSSWhiteList = getDefaultCSSWhiteList;


/***/ }),

/***/ "./node_modules/xss/lib/index.js":
/*!***************************************!*\
  !*** ./node_modules/xss/lib/index.js ***!
  \***************************************/
/***/ ((module, exports, __webpack_require__) => {

/**
 * xss
 *
 * @author Zongmin Lei<leizongmin@gmail.com>
 */

var DEFAULT = __webpack_require__(/*! ./default */ "./node_modules/xss/lib/default.js");
var parser = __webpack_require__(/*! ./parser */ "./node_modules/xss/lib/parser.js");
var FilterXSS = __webpack_require__(/*! ./xss */ "./node_modules/xss/lib/xss.js");

/**
 * filter xss function
 *
 * @param {String} html
 * @param {Object} options { whiteList, onTag, onTagAttr, onIgnoreTag, onIgnoreTagAttr, safeAttrValue, escapeHtml }
 * @return {String}
 */
function filterXSS(html, options) {
  var xss = new FilterXSS(options);
  return xss.process(html);
}

exports = module.exports = filterXSS;
exports.filterXSS = filterXSS;
exports.FilterXSS = FilterXSS;
for (var i in DEFAULT) exports[i] = DEFAULT[i];
for (var i in parser) exports[i] = parser[i];

// using `xss` on the browser, output `filterXSS` to the globals
if (typeof window !== "undefined") {
  window.filterXSS = module.exports;
}

// using `xss` on the WebWorker, output `filterXSS` to the globals
function isWorkerEnv() {
  return (
    typeof self !== "undefined" &&
    typeof DedicatedWorkerGlobalScope !== "undefined" &&
    self instanceof DedicatedWorkerGlobalScope
  );
}
if (isWorkerEnv()) {
  self.filterXSS = module.exports;
}


/***/ }),

/***/ "./node_modules/xss/lib/parser.js":
/*!****************************************!*\
  !*** ./node_modules/xss/lib/parser.js ***!
  \****************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

/**
 * Simple HTML Parser
 *
 * @author Zongmin Lei<leizongmin@gmail.com>
 */

var _ = __webpack_require__(/*! ./util */ "./node_modules/xss/lib/util.js");

/**
 * get tag name
 *
 * @param {String} html e.g. '<a hef="#">'
 * @return {String}
 */
function getTagName(html) {
  var i = _.spaceIndex(html);
  if (i === -1) {
    var tagName = html.slice(1, -1);
  } else {
    var tagName = html.slice(1, i + 1);
  }
  tagName = _.trim(tagName).toLowerCase();
  if (tagName.slice(0, 1) === "/") tagName = tagName.slice(1);
  if (tagName.slice(-1) === "/") tagName = tagName.slice(0, -1);
  return tagName;
}

/**
 * is close tag?
 *
 * @param {String} html 如：'<a hef="#">'
 * @return {Boolean}
 */
function isClosing(html) {
  return html.slice(0, 2) === "</";
}

/**
 * parse input html and returns processed html
 *
 * @param {String} html
 * @param {Function} onTag e.g. function (sourcePosition, position, tag, html, isClosing)
 * @param {Function} escapeHtml
 * @return {String}
 */
function parseTag(html, onTag, escapeHtml) {
  "use strict";

  var rethtml = "";
  var lastPos = 0;
  var tagStart = false;
  var quoteStart = false;
  var currentPos = 0;
  var len = html.length;
  var currentTagName = "";
  var currentHtml = "";

  chariterator: for (currentPos = 0; currentPos < len; currentPos++) {
    var c = html.charAt(currentPos);
    if (tagStart === false) {
      if (c === "<") {
        tagStart = currentPos;
        continue;
      }
    } else {
      if (quoteStart === false) {
        if (c === "<") {
          rethtml += escapeHtml(html.slice(lastPos, currentPos));
          tagStart = currentPos;
          lastPos = currentPos;
          continue;
        }
        if (c === ">") {
          rethtml += escapeHtml(html.slice(lastPos, tagStart));
          currentHtml = html.slice(tagStart, currentPos + 1);
          currentTagName = getTagName(currentHtml);
          rethtml += onTag(
            tagStart,
            rethtml.length,
            currentTagName,
            currentHtml,
            isClosing(currentHtml)
          );
          lastPos = currentPos + 1;
          tagStart = false;
          continue;
        }
        if (c === '"' || c === "'") {
          var i = 1;
          var ic = html.charAt(currentPos - i);

          while (ic.trim() === "" || ic === "=") {
            if (ic === "=") {
              quoteStart = c;
              continue chariterator;
            }
            ic = html.charAt(currentPos - ++i);
          }
        }
      } else {
        if (c === quoteStart) {
          quoteStart = false;
          continue;
        }
      }
    }
  }
  if (lastPos < html.length) {
    rethtml += escapeHtml(html.substr(lastPos));
  }

  return rethtml;
}

var REGEXP_ILLEGAL_ATTR_NAME = /[^a-zA-Z0-9_:\.\-]/gim;

/**
 * parse input attributes and returns processed attributes
 *
 * @param {String} html e.g. `href="#" target="_blank"`
 * @param {Function} onAttr e.g. `function (name, value)`
 * @return {String}
 */
function parseAttr(html, onAttr) {
  "use strict";

  var lastPos = 0;
  var retAttrs = [];
  var tmpName = false;
  var len = html.length;

  function addAttr(name, value) {
    name = _.trim(name);
    name = name.replace(REGEXP_ILLEGAL_ATTR_NAME, "").toLowerCase();
    if (name.length < 1) return;
    var ret = onAttr(name, value || "");
    if (ret) retAttrs.push(ret);
  }

  // 逐个分析字符
  for (var i = 0; i < len; i++) {
    var c = html.charAt(i);
    var v, j;
    if (tmpName === false && c === "=") {
      tmpName = html.slice(lastPos, i);
      lastPos = i + 1;
      continue;
    }
    if (tmpName !== false) {
      if (
        i === lastPos &&
        (c === '"' || c === "'") &&
        html.charAt(i - 1) === "="
      ) {
        j = html.indexOf(c, i + 1);
        if (j === -1) {
          break;
        } else {
          v = _.trim(html.slice(lastPos + 1, j));
          addAttr(tmpName, v);
          tmpName = false;
          i = j;
          lastPos = i + 1;
          continue;
        }
      }
    }
    if (/\s|\n|\t/.test(c)) {
      html = html.replace(/\s|\n|\t/g, " ");
      if (tmpName === false) {
        j = findNextEqual(html, i);
        if (j === -1) {
          v = _.trim(html.slice(lastPos, i));
          addAttr(v);
          tmpName = false;
          lastPos = i + 1;
          continue;
        } else {
          i = j - 1;
          continue;
        }
      } else {
        j = findBeforeEqual(html, i - 1);
        if (j === -1) {
          v = _.trim(html.slice(lastPos, i));
          v = stripQuoteWrap(v);
          addAttr(tmpName, v);
          tmpName = false;
          lastPos = i + 1;
          continue;
        } else {
          continue;
        }
      }
    }
  }

  if (lastPos < html.length) {
    if (tmpName === false) {
      addAttr(html.slice(lastPos));
    } else {
      addAttr(tmpName, stripQuoteWrap(_.trim(html.slice(lastPos))));
    }
  }

  return _.trim(retAttrs.join(" "));
}

function findNextEqual(str, i) {
  for (; i < str.length; i++) {
    var c = str[i];
    if (c === " ") continue;
    if (c === "=") return i;
    return -1;
  }
}

function findBeforeEqual(str, i) {
  for (; i > 0; i--) {
    var c = str[i];
    if (c === " ") continue;
    if (c === "=") return i;
    return -1;
  }
}

function isQuoteWrapString(text) {
  if (
    (text[0] === '"' && text[text.length - 1] === '"') ||
    (text[0] === "'" && text[text.length - 1] === "'")
  ) {
    return true;
  } else {
    return false;
  }
}

function stripQuoteWrap(text) {
  if (isQuoteWrapString(text)) {
    return text.substr(1, text.length - 2);
  } else {
    return text;
  }
}

exports.parseTag = parseTag;
exports.parseAttr = parseAttr;


/***/ }),

/***/ "./node_modules/xss/lib/util.js":
/*!**************************************!*\
  !*** ./node_modules/xss/lib/util.js ***!
  \**************************************/
/***/ ((module) => {

module.exports = {
  indexOf: function (arr, item) {
    var i, j;
    if (Array.prototype.indexOf) {
      return arr.indexOf(item);
    }
    for (i = 0, j = arr.length; i < j; i++) {
      if (arr[i] === item) {
        return i;
      }
    }
    return -1;
  },
  forEach: function (arr, fn, scope) {
    var i, j;
    if (Array.prototype.forEach) {
      return arr.forEach(fn, scope);
    }
    for (i = 0, j = arr.length; i < j; i++) {
      fn.call(scope, arr[i], i, arr);
    }
  },
  trim: function (str) {
    if (String.prototype.trim) {
      return str.trim();
    }
    return str.replace(/(^\s*)|(\s*$)/g, "");
  },
  spaceIndex: function (str) {
    var reg = /\s|\n|\t/;
    var match = reg.exec(str);
    return match ? match.index : -1;
  },
};


/***/ }),

/***/ "./node_modules/xss/lib/xss.js":
/*!*************************************!*\
  !*** ./node_modules/xss/lib/xss.js ***!
  \*************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/**
 * filter xss
 *
 * @author Zongmin Lei<leizongmin@gmail.com>
 */

var FilterCSS = (__webpack_require__(/*! cssfilter */ "./node_modules/cssfilter/lib/index.js").FilterCSS);
var DEFAULT = __webpack_require__(/*! ./default */ "./node_modules/xss/lib/default.js");
var parser = __webpack_require__(/*! ./parser */ "./node_modules/xss/lib/parser.js");
var parseTag = parser.parseTag;
var parseAttr = parser.parseAttr;
var _ = __webpack_require__(/*! ./util */ "./node_modules/xss/lib/util.js");

/**
 * returns `true` if the input value is `undefined` or `null`
 *
 * @param {Object} obj
 * @return {Boolean}
 */
function isNull(obj) {
  return obj === undefined || obj === null;
}

/**
 * get attributes for a tag
 *
 * @param {String} html
 * @return {Object}
 *   - {String} html
 *   - {Boolean} closing
 */
function getAttrs(html) {
  var i = _.spaceIndex(html);
  if (i === -1) {
    return {
      html: "",
      closing: html[html.length - 2] === "/",
    };
  }
  html = _.trim(html.slice(i + 1, -1));
  var isClosing = html[html.length - 1] === "/";
  if (isClosing) html = _.trim(html.slice(0, -1));
  return {
    html: html,
    closing: isClosing,
  };
}

/**
 * shallow copy
 *
 * @param {Object} obj
 * @return {Object}
 */
function shallowCopyObject(obj) {
  var ret = {};
  for (var i in obj) {
    ret[i] = obj[i];
  }
  return ret;
}

/**
 * FilterXSS class
 *
 * @param {Object} options
 *        whiteList, onTag, onTagAttr, onIgnoreTag,
 *        onIgnoreTagAttr, safeAttrValue, escapeHtml
 *        stripIgnoreTagBody, allowCommentTag, stripBlankChar
 *        css{whiteList, onAttr, onIgnoreAttr} `css=false` means don't use `cssfilter`
 */
function FilterXSS(options) {
  options = shallowCopyObject(options || {});

  if (options.stripIgnoreTag) {
    if (options.onIgnoreTag) {
      console.error(
        'Notes: cannot use these two options "stripIgnoreTag" and "onIgnoreTag" at the same time'
      );
    }
    options.onIgnoreTag = DEFAULT.onIgnoreTagStripAll;
  }

  options.whiteList = options.whiteList || DEFAULT.whiteList;
  options.onTag = options.onTag || DEFAULT.onTag;
  options.onTagAttr = options.onTagAttr || DEFAULT.onTagAttr;
  options.onIgnoreTag = options.onIgnoreTag || DEFAULT.onIgnoreTag;
  options.onIgnoreTagAttr = options.onIgnoreTagAttr || DEFAULT.onIgnoreTagAttr;
  options.safeAttrValue = options.safeAttrValue || DEFAULT.safeAttrValue;
  options.escapeHtml = options.escapeHtml || DEFAULT.escapeHtml;
  this.options = options;

  if (options.css === false) {
    this.cssFilter = false;
  } else {
    options.css = options.css || {};
    this.cssFilter = new FilterCSS(options.css);
  }
}

/**
 * start process and returns result
 *
 * @param {String} html
 * @return {String}
 */
FilterXSS.prototype.process = function (html) {
  // compatible with the input
  html = html || "";
  html = html.toString();
  if (!html) return "";

  var me = this;
  var options = me.options;
  var whiteList = options.whiteList;
  var onTag = options.onTag;
  var onIgnoreTag = options.onIgnoreTag;
  var onTagAttr = options.onTagAttr;
  var onIgnoreTagAttr = options.onIgnoreTagAttr;
  var safeAttrValue = options.safeAttrValue;
  var escapeHtml = options.escapeHtml;
  var cssFilter = me.cssFilter;

  // remove invisible characters
  if (options.stripBlankChar) {
    html = DEFAULT.stripBlankChar(html);
  }

  // remove html comments
  if (!options.allowCommentTag) {
    html = DEFAULT.stripCommentTag(html);
  }

  // if enable stripIgnoreTagBody
  var stripIgnoreTagBody = false;
  if (options.stripIgnoreTagBody) {
    var stripIgnoreTagBody = DEFAULT.StripTagBody(
      options.stripIgnoreTagBody,
      onIgnoreTag
    );
    onIgnoreTag = stripIgnoreTagBody.onIgnoreTag;
  }

  var retHtml = parseTag(
    html,
    function (sourcePosition, position, tag, html, isClosing) {
      var info = {
        sourcePosition: sourcePosition,
        position: position,
        isClosing: isClosing,
        isWhite: whiteList.hasOwnProperty(tag),
      };

      // call `onTag()`
      var ret = onTag(tag, html, info);
      if (!isNull(ret)) return ret;

      if (info.isWhite) {
        if (info.isClosing) {
          return "</" + tag + ">";
        }

        var attrs = getAttrs(html);
        var whiteAttrList = whiteList[tag];
        var attrsHtml = parseAttr(attrs.html, function (name, value) {
          // call `onTagAttr()`
          var isWhiteAttr = _.indexOf(whiteAttrList, name) !== -1;
          var ret = onTagAttr(tag, name, value, isWhiteAttr);
          if (!isNull(ret)) return ret;

          if (isWhiteAttr) {
            // call `safeAttrValue()`
            value = safeAttrValue(tag, name, value, cssFilter);
            if (value) {
              return name + '="' + value + '"';
            } else {
              return name;
            }
          } else {
            // call `onIgnoreTagAttr()`
            var ret = onIgnoreTagAttr(tag, name, value, isWhiteAttr);
            if (!isNull(ret)) return ret;
            return;
          }
        });

        // build new tag html
        var html = "<" + tag;
        if (attrsHtml) html += " " + attrsHtml;
        if (attrs.closing) html += " /";
        html += ">";
        return html;
      } else {
        // call `onIgnoreTag()`
        var ret = onIgnoreTag(tag, html, info);
        if (!isNull(ret)) return ret;
        return escapeHtml(html);
      }
    },
    escapeHtml
  );

  // if enable stripIgnoreTagBody
  if (stripIgnoreTagBody) {
    retHtml = stripIgnoreTagBody.remove(retHtml);
  }

  return retHtml;
};

module.exports = FilterXSS;


/***/ }),

/***/ "./src/js/bus.js":
/*!***********************!*\
  !*** ./src/js/bus.js ***!
  \***********************/
/***/ ((module) => {

const bus = new Vue()
window.bus = bus;
module.exports = bus;


/***/ }),

/***/ "./src/js/sousuo.js":
/*!**************************!*\
  !*** ./src/js/sousuo.js ***!
  \**************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

const {memory} = __webpack_require__(/*! jsb-util */ "./node_modules/jsb-util/src/index.js");

const baidu = __webpack_require__(/*! ../../../../src/assets/baidu.svg */ "./src/assets/baidu.svg");
const google = __webpack_require__(/*! ../../../../src/assets/google.svg */ "./src/assets/google.svg");
const sougou = __webpack_require__(/*! ../../../../src/assets/sougou.svg */ "./src/assets/sougou.svg");
const s360 = __webpack_require__(/*! ../../../../src/assets/360.svg */ "./src/assets/360.svg")
const bing = __webpack_require__(/*! ../../../../src/assets/bing.svg */ "./src/assets/bing.svg")

const sou = [
    {
        name: '百度',
        href: "https://www.baidu.com/s?&ie=utf-8&word=$key",
        icon: baidu
    },
    {
        name: '谷歌',
        href: 'https://www.google.com/search?q=$key',
        icon: google
    },
    {
        name: '搜狗',
        href: "https://www.sogou.com/web?query=$key",
        icon: sougou
    },
    {
        name: '360',
        href: 'https://www.so.com/s?ie=utf-8&q=$key',
        icon: s360
    },
    {
        name: '必应',
        href: 'https://cn.bing.com/search?q=$key',
        icon: bing
    }
]
let default_sou = memory.get("sou") || sou[0];
set_sou(default_sou)

function sousearch(text) {
    location.href = default_sou.href.replace(/\$key/, text)
}

/**
 * 设置搜索引擎
 * @param item
 */
function set_sou(item) {
    default_sou = item;
    memory.set("sou", item)
}

exports.sousearch = sousearch;
exports.set_sou = set_sou
exports.default_sou = default_sou;
exports.sou = sou;


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
(() => {
"use strict";
/*!**********************!*\
  !*** ./src/index.js ***!
  \**********************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _css_index_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./css/index.scss */ "./src/css/index.scss");
/* harmony import */ var _js_sousuo__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./js/sousuo */ "./src/js/sousuo.js");
/* harmony import */ var jsb_util__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! jsb-util */ "./node_modules/jsb-util/src/index.js");
/* harmony import */ var _js_menu_jsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./js/menu.jsx */ "./src/js/menu.jsx");
/* harmony import */ var _src_js_bus__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../src/js/bus */ "./src/js/bus.js");
/* harmony import */ var _src_js_bus__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_src_js_bus__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_5__);







let token = false;
(axios__WEBPACK_IMPORTED_MODULE_5___default().defaults.baseURL) = "";
if (location.hostname === "localhost") {
    (axios__WEBPACK_IMPORTED_MODULE_5___default().defaults.baseURL) = "https://web.png.ink"
    token = "a63d21e1946cf0746056c75550a787c6" //开发环境的token
}
window.scrolllock = false;
axios__WEBPACK_IMPORTED_MODULE_5___default().interceptors.request.use((config) => {
    config.headers['Content-Type'] = "application/x-www-form-urlencoded; charset=UTF-8";
    if (config.method === "post")
        if (token)
            if (typeof config.data == "object")
                config.data['token'] = token
            else
                config.data = {token: token}
    config.transformRequest = [
        function (data) {
            let ret = '';
            for (let it in data) {
                // 中文编码
                if (data[it] != '' || data[it] == 0) {
                    //值为空的全部剔除
                    ret += encodeURIComponent(it) + '=' + encodeURIComponent(data[it]) + '&';
                }
            }
            return ret;
        },
    ];
    return config
})
;(0,_js_menu_jsx__WEBPACK_IMPORTED_MODULE_3__.install)(Vue);
const vm = new Vue({
    el: '#root',
    data() {
        return {
            searchPreview: false,
            searchList: [],
            history: jsb_util__WEBPACK_IMPORTED_MODULE_2__.memory.get("history") || [],
            search: '',
            drawer: false,
            souStatus: false,
            sou: _js_sousuo__WEBPACK_IMPORTED_MODULE_1__.sou,
            default_sou: _js_sousuo__WEBPACK_IMPORTED_MODULE_1__.default_sou,
            touch: {
                y: 0,
                time: 0
            },
            list: jsb_util__WEBPACK_IMPORTED_MODULE_2__.memory.get("list") || [],
            lists: [],
            mouseRight: {
                x: 0,
                y: 0,
            },
            tabbar: []
        }
    },
    methods: {
        search_go() {
            if (this.CHECK_URL(this.search)) {
                if (/^http/.test(this.search)) {
                    location.href = this.search;
                } else {
                    location.href = "//" + this.search;
                }
                return;
            }
            (0,_js_sousuo__WEBPACK_IMPORTED_MODULE_1__.sousearch)(this.search)
        },
        /**
         * 正则表达式判定Url
         * @param url
         * @returns {Boolean}
         */
        CHECK_URL(url) {
            //url= 协议://(ftp的登录信息)[IP|域名](:端口号)(/或?请求参数)
            var strRegex = '^((https|http|ftp)://)?'//(https或http或ftp):// 可有可无
                + '(([\\w_!~*\'()\\.&=+$%-]+: )?[\\w_!~*\'()\\.&=+$%-]+@)?' //ftp的user@  可有可无
                + '(([0-9]{1,3}\\.){3}[0-9]{1,3}' // IP形式的URL- 3位数字.3位数字.3位数字.3位数字
                + '|' // 允许IP和DOMAIN（域名）
                + '(localhost)|'	//匹配localhost
                + '([\\w_!~*\'()-]+\\.)*' // 域名- 至少一个[英文或数字_!~*\'()-]加上.
                + '\\w+\\.' // 一级域名 -英文或数字  加上.
                + '[a-zA-Z]{1,6})' // 顶级域名- 1-6位英文
                + '(:[0-9]{1,5})?' // 端口- :80 ,1-5位数字
                + '((/?)|' // url无参数结尾 - 斜杆或这没有
                + '(/[\\w_!~*\'()\\.;?:@&=+$,%#-]+)+/?)$';//请求参数结尾- 英文或数字和[]内的各种字符

            var strRegex1 = '^(?=^.{3,255}$)((http|https|ftp)?:\/\/)?(www\.)?[a-zA-Z0-9][-a-zA-Z0-9]{0,62}(\.[a-zA-Z0-9][-a-zA-Z0-9]{0,62})+(:\d+)*(\/)?(?:\/(.+)\/?$)?(\/\w+\.\w+)*([\?&]\w+=\w*|[\u4e00-\u9fa5]+)*$';
            var re = new RegExp(strRegex, 'i');//i不区分大小写
            console.log(re);
            //将url做uri转码后再匹配，解除请求参数中的中文和空字符影响
            if (re.test(encodeURI(url))) {
                return (true);
            } else {
                return (false);
            }
        },
        to({url}) {
            const index = this.lists.findIndex(el => el.url === url)//查找本地的信息
            const info = this.lists[index];
            const index1 = this.history.findIndex(it => it.url === url);
            if (index1 > -1) {//如果历史记录存在，则删除
                this.history.splice(index1, 1)
            }
            if (index > -1) {
                if (this.history.length === 8) {
                    this.history.pop();
                }
                this.history.unshift({
                    url: url,
                    title: info.title,
                    description: info.description
                })//删除后向数组最开始插入数据

                jsb_util__WEBPACK_IMPORTED_MODULE_2__.memory.set("history", this.history.slice(0, 8));
            }
            const tempwindow = window.open();
            tempwindow.location = url;
        }
        ,
        getIcon(item) {
            if (item.url) {
                let str = ""
                try {
                    str = "https://favicon.rss.ink/v1/" + btoa(encodeURI(item.url));
                } catch (e) {
                    console.log(e);
                    console.log(item)
                    console.log(item.url)
                }
                return str
            }
        }
        ,
        login() {
            location.href = './index.php?c=login'
        },
        mouseMenu(event) {
            const {clientX, clientY} = event;
            event.preventDefault()
        }
        ,
        setsou(item) {
            (0,_js_sousuo__WEBPACK_IMPORTED_MODULE_1__.set_sou)(item);
            this.default_sou = item;
            this.souStatus = false
        }
        ,
        async fetchData() {
            let data = (await axios__WEBPACK_IMPORTED_MODULE_5___default().get("./index.php?c=api&method=category_list&limit=999999" + "&u=" + u )).data
            let list = (await axios__WEBPACK_IMPORTED_MODULE_5___default().post('./index.php?c=api&method=link_list&limit=999999' + "&u=" + u)).data
            vm.lists = list.data
            jsb_util__WEBPACK_IMPORTED_MODULE_2__.memory.set("lists", list.data)
            //下面是将目录和列表合并。将列表加入目录children里
            let menu = data.data;
            list.data.forEach((item) => {
                const {category_name: name} = item;
                const index = menu.findIndex(el => el.name === name);
                if (!menu[index].children) {
                    menu[index].children = [];
                }
                menu[index].children.push(item)
            })
            vm.list = menu
            jsb_util__WEBPACK_IMPORTED_MODULE_2__.memory.set("list", menu)
            await this.$nextTick(_ => {
                sumicon()
            })
        }
        ,
        searchPreviewRender() {
            const val = this.search
            // this.searchPreview = val.split("").length > 0;
            const list = jsb_util__WEBPACK_IMPORTED_MODULE_2__.memory.get("lists") || []
            let tmp = [];
            list.forEach(el => {
                if (el.title.toLowerCase().indexOf(this.search.toLowerCase()) !== -1) {
                    tmp.push({
                        title: el.title.replace(RegExp(this.search, "ig"), `<b>${this.search}</b>`),
                        url: el.url,
                        description: el.description
                    })
                }
            })
            this.searchPreview = Boolean(tmp.length > 0)
            // if (!this.searchPreview) {
            //     $.ajax({
            //         url: 'https://www.baidu.com/sugrec?pre=1&p=3&ie=utf-8&json=1&prod=pc',
            //         dataType: 'jsonp',
            //         jsonp: 'cb',
            //         data: {wd: this.search},
            //         success: function (msg) {
            //             console.log(msg.g)
            //         }
            //     })
            // }
            this.searchList = tmp.slice(0, 10)
            if (this.drawer)
                this.drawer = false;
        }
        ,
        closePreview() {
            setTimeout(_ => {
                this.searchPreview = false
            }, 100)
        }
    },
    async mounted() {
        await this.fetchData()
        _src_js_bus__WEBPACK_IMPORTED_MODULE_4___default().$on("delhistory", (e) => {
            const index = this.history.findIndex(it => it.url === e);
            this.history.splice(index, 1)
            jsb_util__WEBPACK_IMPORTED_MODULE_2__.memory.set("history", this.history)
        })
    }
    ,
    watch: {
        search(val) {
            this.searchPreviewRender()
        }
        ,
        drawer(val) {
            if (val)
                vm.searchPreview = false
        }
    }
})
//监听鼠标滚动
window.addEventListener("wheel", (event) => {
    if (window.scrolllock) return;
    let fangxiang = Boolean(event.deltaY > 0);
    const drawer = document.querySelector(".drawer-main");
    if (fangxiang) {
        if (!vm.drawer)
            setTimeout(_ => {
                drawer.style.overflowY = "scroll"
            }, 200)
        vm.drawer = true;
    } else {
        if (drawer.scrollTop !== 0) return;
        vm.drawer = false;
        drawer.style.overflowY = "hidden"
    }
})
document.querySelector(".drawer-main").addEventListener('touchmove', function (event) {
    event.stopPropagation();
}, {passive: false})

//监听面触摸滑动事件
document.querySelector("#root").addEventListener("touchstart", function (event) {
    if (scrolllock) return
    let y = event.touches[0].clientY;
    vm.touch = {
        y: y,
        time: new Date().getTime()
    }
})
//页面滑动结束事件
document.querySelector("#root").addEventListener("touchend", function (event) {
    if (scrolllock) return
    let y = event.changedTouches[0].clientY;
    let t = new Date().getTime();
    if (y === vm.touch.y) {
        return false;
    }
    if (t - 300 < vm.touch.time) {
        if (y + 100 < vm.touch.y) {
            vm.drawer = true;
        } else if (y - 100 > vm.touch.y) {
            if (document.querySelector(".drawer-main").scrollTop !== 0) return;
            vm.drawer = false;
        }
    }
})
//阻止冒泡
document.querySelector("#root").addEventListener("touchmove", function (e) {
    e.stopPropagation();
    e.preventDefault()
}, {passive: false})

function sumicon() {
    let w = outerWidth - 60;
    let auto = Math.floor(w / 100);
    let l = w / auto
    if (outerWidth > 501) {
        document.querySelectorAll(".dreaer-list").forEach(el => {
            el.style.width = l + 'px';
        })
    } else {
        document.querySelectorAll(".dreaer-list").forEach(el => {
            el.style.width = "";
        })
    }
}

sumicon();
window.addEventListener("resize", (0,jsb_util__WEBPACK_IMPORTED_MODULE_2__.throttle)(sumicon, 200))

_src_js_bus__WEBPACK_IMPORTED_MODULE_4___default().$on("cc", function () {
    //打开抽屉
    vm.drawer = true
})

window.base64ToBlob = (urlData, type) => {
    let arr = urlData.split(',');
    let mime = arr[0].match(/:(.*?);/)[1] || type;
    let bytes = window.atob(arr[1]);
    let ab = new ArrayBuffer(bytes.length);
    let ia = new Uint8Array(ab);
    for (let i = 0; i < bytes.length; i++) {
        ia[i] = bytes.charCodeAt(i);
    }
    return new Blob([ab], {
        type: mime
    });
}
let base = jsb_util__WEBPACK_IMPORTED_MODULE_2__.memory.get("bg");
if (base) {
    if (base.length < 100) {
        jsb_util__WEBPACK_IMPORTED_MODULE_2__.memory.del('bg')
    } else {
        base64ToBlob(base)
        const bz = URL.createObjectURL(base64ToBlob(base))
        document.querySelector("#root").style.background = `url(${bz}) no-repeat center/cover`
    }
}

})();

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXgxNjUxMzk4MzQ4Mzk2LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFBLDRGQUF1Qzs7Ozs7Ozs7Ozs7QUNBMUI7O0FBRWIsWUFBWSxtQkFBTyxDQUFDLHFEQUFZO0FBQ2hDLGFBQWEsbUJBQU8sQ0FBQyxpRUFBa0I7QUFDdkMsY0FBYyxtQkFBTyxDQUFDLHlFQUFzQjtBQUM1QyxlQUFlLG1CQUFPLENBQUMsMkVBQXVCO0FBQzlDLG9CQUFvQixtQkFBTyxDQUFDLDZFQUF1QjtBQUNuRCxtQkFBbUIsbUJBQU8sQ0FBQyxtRkFBMkI7QUFDdEQsc0JBQXNCLG1CQUFPLENBQUMseUZBQThCO0FBQzVELGtCQUFrQixtQkFBTyxDQUFDLHlFQUFxQjtBQUMvQywyQkFBMkIsbUJBQU8sQ0FBQyxtRkFBMEI7QUFDN0QsYUFBYSxtQkFBTyxDQUFDLG1FQUFrQjs7QUFFdkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSw2Q0FBNkM7QUFDN0M7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBLE9BQU87O0FBRVA7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsVUFBVTtBQUNWO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7Ozs7Ozs7Ozs7OztBQ25OYTs7QUFFYixZQUFZLG1CQUFPLENBQUMsa0RBQVM7QUFDN0IsV0FBVyxtQkFBTyxDQUFDLGdFQUFnQjtBQUNuQyxZQUFZLG1CQUFPLENBQUMsNERBQWM7QUFDbEMsa0JBQWtCLG1CQUFPLENBQUMsd0VBQW9CO0FBQzlDLGVBQWUsbUJBQU8sQ0FBQyw4REFBWTs7QUFFbkM7QUFDQTtBQUNBO0FBQ0EsV0FBVyxRQUFRO0FBQ25CLFlBQVksT0FBTztBQUNuQjtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQSxlQUFlLG1CQUFPLENBQUMsa0VBQWlCO0FBQ3hDLG9CQUFvQixtQkFBTyxDQUFDLDRFQUFzQjtBQUNsRCxpQkFBaUIsbUJBQU8sQ0FBQyxzRUFBbUI7QUFDNUMsZ0JBQWdCLHVGQUE2Qjs7QUFFN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQSxlQUFlLG1CQUFPLENBQUMsb0VBQWtCOztBQUV6QztBQUNBLHFCQUFxQixtQkFBTyxDQUFDLGdGQUF3Qjs7QUFFckQ7O0FBRUE7QUFDQSx5QkFBc0I7Ozs7Ozs7Ozs7OztBQ3hEVDs7QUFFYjtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsU0FBUztBQUNwQjtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7Ozs7Ozs7Ozs7OztBQ2xCYTs7QUFFYixhQUFhLG1CQUFPLENBQUMsMkRBQVU7O0FBRS9CO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVyxVQUFVO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBLEdBQUc7O0FBRUg7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUEsZ0JBQWdCLE9BQU87QUFDdkI7QUFDQTtBQUNBO0FBQ0EsR0FBRzs7QUFFSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7O0FBRUw7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsR0FBRztBQUNIOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7Ozs7Ozs7Ozs7OztBQ3RIYTs7QUFFYjtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQ0phOztBQUViLFlBQVksbUJBQU8sQ0FBQyxxREFBWTtBQUNoQyxlQUFlLG1CQUFPLENBQUMseUVBQXFCO0FBQzVDLHlCQUF5QixtQkFBTyxDQUFDLGlGQUFzQjtBQUN2RCxzQkFBc0IsbUJBQU8sQ0FBQywyRUFBbUI7QUFDakQsa0JBQWtCLG1CQUFPLENBQUMsbUVBQWU7QUFDekMsZ0JBQWdCLG1CQUFPLENBQUMsMkVBQXNCOztBQUU5QztBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsUUFBUTtBQUNuQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsUUFBUTtBQUNuQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBLElBQUk7QUFDSjtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQSxHQUFHOztBQUVIO0FBQ0E7QUFDQTtBQUNBLEdBQUc7O0FBRUg7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7OztBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnREFBZ0Q7QUFDaEQ7QUFDQTtBQUNBLHlCQUF5QjtBQUN6QixLQUFLO0FBQ0w7QUFDQSxDQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNBLGdEQUFnRDtBQUNoRDtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQSxDQUFDOztBQUVEOzs7Ozs7Ozs7Ozs7QUNuSmE7O0FBRWIsWUFBWSxtQkFBTyxDQUFDLHFEQUFZOztBQUVoQztBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsV0FBVyxVQUFVO0FBQ3JCLFdBQVcsVUFBVTtBQUNyQjtBQUNBLFlBQVksUUFBUTtBQUNwQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsUUFBUTtBQUNuQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVyxVQUFVO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDs7QUFFQTs7Ozs7Ozs7Ozs7O0FDckRhOztBQUViLG9CQUFvQixtQkFBTyxDQUFDLG1GQUEwQjtBQUN0RCxrQkFBa0IsbUJBQU8sQ0FBQywrRUFBd0I7O0FBRWxEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLFFBQVE7QUFDbkIsV0FBVyxRQUFRO0FBQ25CLGFBQWEsUUFBUTtBQUNyQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDbkJhOztBQUViLG1CQUFtQixtQkFBTyxDQUFDLHFFQUFnQjs7QUFFM0M7QUFDQTtBQUNBO0FBQ0EsV0FBVyxRQUFRO0FBQ25CLFdBQVcsUUFBUTtBQUNuQixXQUFXLFFBQVE7QUFDbkIsV0FBVyxRQUFRO0FBQ25CLFdBQVcsUUFBUTtBQUNuQixhQUFhLE9BQU87QUFDcEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDakJhOztBQUViLFlBQVksbUJBQU8sQ0FBQyxxREFBWTtBQUNoQyxvQkFBb0IsbUJBQU8sQ0FBQyx1RUFBaUI7QUFDN0MsZUFBZSxtQkFBTyxDQUFDLHVFQUFvQjtBQUMzQyxlQUFlLG1CQUFPLENBQUMsK0RBQWE7QUFDcEMsYUFBYSxtQkFBTyxDQUFDLG1FQUFrQjs7QUFFdkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsV0FBVyxRQUFRO0FBQ25CLGFBQWEsU0FBUztBQUN0QjtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsK0JBQStCO0FBQy9CLHVDQUF1QztBQUN2QztBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxHQUFHO0FBQ0g7Ozs7Ozs7Ozs7OztBQ3RGYTs7QUFFYjtBQUNBO0FBQ0E7QUFDQSxXQUFXLE9BQU87QUFDbEIsV0FBVyxRQUFRO0FBQ25CLFdBQVcsUUFBUTtBQUNuQixXQUFXLFFBQVE7QUFDbkIsV0FBVyxRQUFRO0FBQ25CLGFBQWEsT0FBTztBQUNwQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDMUNhOztBQUViLFlBQVksbUJBQU8sQ0FBQyxtREFBVTs7QUFFOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLFFBQVE7QUFDbkIsV0FBVyxRQUFRO0FBQ25CLGFBQWEsUUFBUTtBQUNyQjtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLE1BQU07QUFDTiwyQkFBMkI7QUFDM0IsTUFBTTtBQUNOO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7O0FBRUg7QUFDQTs7Ozs7Ozs7Ozs7O0FDbEdhOztBQUViLGtCQUFrQixtQkFBTyxDQUFDLG1FQUFlOztBQUV6QztBQUNBO0FBQ0E7QUFDQSxXQUFXLFVBQVU7QUFDckIsV0FBVyxVQUFVO0FBQ3JCLFdBQVcsUUFBUTtBQUNuQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDeEJhOztBQUViLFlBQVksbUJBQU8sQ0FBQyxxREFBWTtBQUNoQyxlQUFlLG1CQUFPLENBQUMsK0RBQWE7O0FBRXBDO0FBQ0E7QUFDQTtBQUNBLFdBQVcsZUFBZTtBQUMxQixXQUFXLE9BQU87QUFDbEIsV0FBVyxnQkFBZ0I7QUFDM0IsYUFBYSxHQUFHO0FBQ2hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7O0FBRUg7QUFDQTs7Ozs7Ozs7Ozs7O0FDckJhOztBQUViLFlBQVksbUJBQU8sQ0FBQyxtREFBVTtBQUM5QiwwQkFBMEIsbUJBQU8sQ0FBQywrRkFBZ0M7QUFDbEUsbUJBQW1CLG1CQUFPLENBQUMsMkVBQXNCO0FBQ2pELDJCQUEyQixtQkFBTyxDQUFDLHlFQUFnQjs7QUFFbkQ7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxjQUFjLG1CQUFPLENBQUMsaUVBQWlCO0FBQ3ZDLElBQUk7QUFDSjtBQUNBLGNBQWMsbUJBQU8sQ0FBQyxrRUFBa0I7QUFDeEM7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBOztBQUVBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdFQUF3RTtBQUN4RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7O0FBRUg7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLEdBQUc7O0FBRUg7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLEdBQUc7O0FBRUg7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxDQUFDOztBQUVEO0FBQ0E7QUFDQSxDQUFDOztBQUVEOzs7Ozs7Ozs7Ozs7QUNsSWE7O0FBRWI7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7QUNOQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7O0FDRmE7O0FBRWI7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CLGlCQUFpQjtBQUNyQztBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNWYTs7QUFFYixZQUFZLG1CQUFPLENBQUMscURBQVk7O0FBRWhDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLFFBQVE7QUFDbkIsV0FBVyxRQUFRO0FBQ25CLGFBQWEsUUFBUTtBQUNyQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0EsSUFBSTtBQUNKOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxVQUFVO0FBQ1Y7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQLEtBQUs7O0FBRUw7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7Ozs7Ozs7Ozs7O0FDckVhOztBQUViO0FBQ0E7QUFDQTtBQUNBLFdBQVcsUUFBUTtBQUNuQixXQUFXLFFBQVE7QUFDbkIsYUFBYSxRQUFRO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDYmE7O0FBRWIsWUFBWSxtQkFBTyxDQUFDLHFEQUFZOztBQUVoQztBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUEsMkNBQTJDO0FBQzNDLFNBQVM7O0FBRVQ7QUFDQSw0REFBNEQsd0JBQXdCO0FBQ3BGO0FBQ0EsU0FBUzs7QUFFVDtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7O0FBRUw7QUFDQTtBQUNBO0FBQ0Esa0NBQWtDO0FBQ2xDLGdDQUFnQyxjQUFjO0FBQzlDO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7Ozs7Ozs7Ozs7OztBQ3BEYTs7QUFFYjtBQUNBO0FBQ0E7QUFDQSxXQUFXLFFBQVE7QUFDbkIsYUFBYSxTQUFTO0FBQ3RCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNiYTs7QUFFYixZQUFZLG1CQUFPLENBQUMscURBQVk7O0FBRWhDO0FBQ0E7QUFDQTtBQUNBLFdBQVcsR0FBRztBQUNkLGFBQWEsU0FBUztBQUN0QjtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDWmE7O0FBRWIsWUFBWSxtQkFBTyxDQUFDLHFEQUFZOztBQUVoQztBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxjQUFjLFFBQVE7QUFDdEIsZ0JBQWdCO0FBQ2hCO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsY0FBYyxRQUFRO0FBQ3RCLGdCQUFnQixTQUFTO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7O0FBRUw7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDs7Ozs7Ozs7Ozs7O0FDbkVhOztBQUViLFlBQVksbUJBQU8sQ0FBQyxtREFBVTs7QUFFOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIOzs7Ozs7Ozs7Ozs7QUNYYTs7QUFFYixZQUFZLG1CQUFPLENBQUMscURBQVk7O0FBRWhDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLFFBQVE7QUFDbkIsYUFBYSxRQUFRO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxrQkFBa0I7O0FBRWxCO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQVE7QUFDUjtBQUNBO0FBQ0E7QUFDQSxHQUFHOztBQUVIO0FBQ0E7Ozs7Ozs7Ozs7OztBQ3BEYTs7QUFFYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCO0FBQy9CO0FBQ0E7QUFDQSxXQUFXLFVBQVU7QUFDckIsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDMUJhOztBQUViLGNBQWMsd0ZBQThCOztBQUU1Qzs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7QUFFRDs7QUFFQTtBQUNBO0FBQ0EsV0FBVyxtQkFBbUI7QUFDOUIsV0FBVyxTQUFTO0FBQ3BCLFdBQVcsU0FBUztBQUNwQixhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsV0FBVyxRQUFRO0FBQ25CLFdBQVcsUUFBUTtBQUNuQixXQUFXLFVBQVU7QUFDckI7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQ2pGYTs7QUFFYixXQUFXLG1CQUFPLENBQUMsZ0VBQWdCOztBQUVuQzs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLFFBQVE7QUFDbkIsYUFBYSxTQUFTO0FBQ3RCO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsUUFBUTtBQUNuQixhQUFhLFNBQVM7QUFDdEI7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsV0FBVyxRQUFRO0FBQ25CLGFBQWEsU0FBUztBQUN0QjtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsUUFBUTtBQUNuQixhQUFhLFNBQVM7QUFDdEI7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsV0FBVyxRQUFRO0FBQ25CLGFBQWEsU0FBUztBQUN0QjtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLFFBQVE7QUFDbkIsYUFBYSxTQUFTO0FBQ3RCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsV0FBVyxRQUFRO0FBQ25CLGFBQWEsU0FBUztBQUN0QjtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLFFBQVE7QUFDbkIsYUFBYSxTQUFTO0FBQ3RCO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsUUFBUTtBQUNuQixhQUFhLFNBQVM7QUFDdEI7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsV0FBVyxRQUFRO0FBQ25CLFlBQVksU0FBUztBQUNyQjtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLFFBQVE7QUFDbkIsYUFBYSxTQUFTO0FBQ3RCO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsUUFBUTtBQUNuQixhQUFhLFNBQVM7QUFDdEI7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsV0FBVyxRQUFRO0FBQ25CLGFBQWEsU0FBUztBQUN0QjtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLFFBQVE7QUFDbkIsYUFBYSxTQUFTO0FBQ3RCO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsUUFBUTtBQUNuQixhQUFhLFNBQVM7QUFDdEI7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsV0FBVyxRQUFRO0FBQ25CLGFBQWEsU0FBUztBQUN0QjtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLFFBQVE7QUFDbkIsYUFBYSxRQUFRO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVyxjQUFjO0FBQ3pCLFdBQVcsVUFBVTtBQUNyQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0Esb0NBQW9DLE9BQU87QUFDM0M7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUJBQXVCLFNBQVMsR0FBRyxTQUFTO0FBQzVDLDRCQUE0QjtBQUM1QjtBQUNBO0FBQ0EsV0FBVyxRQUFRO0FBQ25CLGFBQWEsUUFBUTtBQUNyQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ04sNEJBQTRCO0FBQzVCLE1BQU07QUFDTjtBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0E7O0FBRUEsd0NBQXdDLE9BQU87QUFDL0M7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsV0FBVyxRQUFRO0FBQ25CLFdBQVcsUUFBUTtBQUNuQixXQUFXLFFBQVE7QUFDbkIsWUFBWSxRQUFRO0FBQ3BCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsUUFBUTtBQUNuQixZQUFZLFFBQVE7QUFDcEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7OztBQzVWQSxNQUFNQSxHQUFHLEdBQUdDLG1CQUFPLENBQUMsOEJBQUQsQ0FBbkI7O0FBQ0EsTUFBTUMsS0FBSyxHQUFHRCxtQkFBTyxDQUFDLDRDQUFELENBQXJCOztBQUNBLE1BQU07QUFBQ0UsRUFBQUE7QUFBRCxJQUFXRixtQkFBTyxDQUFDLHNEQUFELENBQXhCOztBQUNBRyxlQUFBLEdBQWtCLFNBQVNDLE9BQVQsQ0FBaUJDLEdBQWpCLEVBQXNCO0FBQ3BDQSxFQUFBQSxHQUFHLENBQUNDLFNBQUosQ0FBYyxVQUFkLEVBQ0k7QUFDSUMsSUFBQUEsUUFBUSxFQUFJO0FBQ3hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQTFCUTtBQTJCSUMsSUFBQUEsT0FBTyxFQUFFO0FBQ0xDLE1BQUFBLE1BQU0sQ0FBQ0MsSUFBRCxFQUFPO0FBQ1QsWUFBSSxLQUFLQyxPQUFMLENBQWFDLEdBQWIsS0FBcUIsRUFBekIsRUFBNkIsT0FBTyxLQUFLQyxRQUFMLENBQWNDLEtBQWQsQ0FBb0IsU0FBcEIsQ0FBUDtBQUM3QixZQUFJLEtBQUtILE9BQUwsQ0FBYUksS0FBYixLQUF1QixFQUEzQixFQUErQixPQUFPLEtBQUtGLFFBQUwsQ0FBY0MsS0FBZCxDQUFvQixNQUFwQixDQUFQO0FBQy9CLGNBQU1FLElBQUksR0FBRyxFQUFDLEdBQUcsS0FBS0w7QUFBVCxTQUFiO0FBQ0EsWUFBSUMsR0FBRyxHQUFHLEVBQVY7O0FBQ0EsWUFBSSxLQUFLSyxNQUFULEVBQWlCO0FBQ2JMLFVBQUFBLEdBQUcsR0FBRyxtQ0FBTjtBQUNILFNBRkQsTUFFTztBQUNIQSxVQUFBQSxHQUFHLEdBQUcsa0NBQU47QUFDSDs7QUFDREksUUFBQUEsSUFBSSxDQUFDRSxRQUFMLEdBQWdCLEtBQUtQLE9BQUwsQ0FBYU8sUUFBYixHQUF3QixDQUF4QixHQUE0QixDQUE1QztBQUNBakIsUUFBQUEsS0FBSyxDQUFDa0IsSUFBTixDQUFXUCxHQUFYLEVBQWdCSSxJQUFoQixFQUFzQkksSUFBdEIsQ0FBMkJDLENBQUMsSUFBSTtBQUM1QixnQkFBTTtBQUFDQyxZQUFBQTtBQUFELGNBQVNELENBQUMsQ0FBQ0wsSUFBakI7O0FBQ0EsY0FBSU0sSUFBSSxLQUFLLENBQWIsRUFBZ0I7QUFDWixpQkFBS1QsUUFBTCxDQUFjVSxPQUFkLENBQXNCLE1BQXRCO0FBQ0FDLFlBQUFBLFVBQVUsQ0FBQ0MsQ0FBQyxJQUFJQyxRQUFRLENBQUNDLE1BQVQsRUFBTixFQUF5QixJQUF6QixDQUFWO0FBQ0EsaUJBQUtDLGFBQUwsR0FBcUIsS0FBckI7QUFDSCxXQUpELE1BSU87QUFDSCxpQkFBS2YsUUFBTCxDQUFjQyxLQUFkLENBQW9CLE1BQXBCO0FBQ0g7QUFDSixTQVREO0FBV0gsT0F2Qkk7O0FBd0JMZSxNQUFBQSxRQUFRLEdBQUc7QUFDUCxZQUFJQyxVQUFVLEdBQUcsR0FBakIsRUFBc0I7QUFDbEIsaUJBQU8sT0FBUDtBQUNIOztBQUNELGVBQU8sT0FBUDtBQUNIOztBQTdCSSxLQTNCYjs7QUEwRElkLElBQUFBLElBQUksR0FBRztBQUNILGFBQU87QUFDSFksUUFBQUEsYUFBYSxFQUFFLEtBRFo7QUFFSEcsUUFBQUEsTUFBTSxFQUFFLEVBRkw7QUFHSHBCLFFBQUFBLE9BQU8sRUFBRSxFQUhOO0FBSUhxQixRQUFBQSxHQUFHLEVBQUU7QUFBQztBQUNGcEIsVUFBQUEsR0FBRyxFQUFFLEVBREo7QUFFRHFCLFVBQUFBLE1BQU0sRUFBRSxFQUZQO0FBR0RsQixVQUFBQSxLQUFLLEVBQUUsRUFITjtBQUlERyxVQUFBQSxRQUFRLEVBQUUsSUFKVDtBQUtEZ0IsVUFBQUEsR0FBRyxFQUFFLEVBTEo7QUFNREMsVUFBQUEsV0FBVyxFQUFFLEVBTlo7QUFPREMsVUFBQUEsV0FBVyxFQUFFO0FBUFosU0FKRjtBQWFIbkIsUUFBQUEsTUFBTSxFQUFFO0FBYkwsT0FBUDtBQWVILEtBMUVMOztBQTJFSW9CLElBQUFBLEtBQUssRUFBRTtBQUNIVCxNQUFBQSxhQUFhLENBQUNQLENBQUQsRUFBSTtBQUNiLFlBQUlBLENBQUMsS0FBSyxLQUFWLEVBQWlCO0FBQ2JpQixVQUFBQSxNQUFNLENBQUNDLFVBQVAsR0FBb0IsS0FBcEI7QUFDSCxTQUZELE1BRU8sSUFBSWxCLENBQUMsS0FBSyxJQUFWLEVBQWdCO0FBQ25CLGVBQUtWLE9BQUwsR0FBZTZCLElBQUksQ0FBQ0MsS0FBTCxDQUFXRCxJQUFJLENBQUNFLFNBQUwsQ0FBZSxLQUFLVixHQUFwQixDQUFYLENBQWY7QUFDQU0sVUFBQUEsTUFBTSxDQUFDQyxVQUFQLEdBQW9CLElBQXBCO0FBQ0g7QUFDSjs7QUFSRSxLQTNFWDs7QUFxRklJLElBQUFBLE9BQU8sR0FBRztBQUNONUMsTUFBQUEsR0FBRyxDQUFDNkMsR0FBSixDQUFRLE1BQVIsRUFBZ0IsTUFBTTtBQUNsQixhQUFLYixNQUFMLEdBQWM3QixNQUFNLENBQUMyQyxHQUFQLENBQVcsTUFBWCxLQUFzQixFQUFwQztBQUNBLGFBQUtqQixhQUFMLEdBQXFCLElBQXJCO0FBQ0gsT0FIRDtBQUlBN0IsTUFBQUEsR0FBRyxDQUFDNkMsR0FBSixDQUFRLGVBQVIsRUFBMEJ2QixDQUFELElBQU87QUFDNUIsYUFBS08sYUFBTCxHQUFxQixJQUFyQjtBQUNBLGFBQUtYLE1BQUwsR0FBYyxJQUFkO0FBQ0EsYUFBSzZCLFNBQUwsQ0FBZXJCLENBQUMsSUFBSTtBQUNoQixlQUFLTSxNQUFMLEdBQWM3QixNQUFNLENBQUMyQyxHQUFQLENBQVcsTUFBWCxLQUFzQixFQUFwQztBQUNBLGVBQUtsQyxPQUFMLEdBQWVVLENBQWY7QUFDQSxlQUFLVixPQUFMLENBQWFPLFFBQWIsR0FBd0JHLENBQUMsQ0FBQ0gsUUFBRixJQUFjLENBQWQsR0FBa0IsSUFBbEIsR0FBeUIsS0FBakQ7QUFDSCxTQUpEO0FBS0gsT0FSRDtBQVNIOztBQW5HTCxHQURKO0FBd0dBYixFQUFBQSxHQUFHLENBQUNDLFNBQUosQ0FBYyxPQUFkLEVBQXVCO0FBQ25CQyxJQUFBQSxRQUFRLEVBQUk7QUFDcEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwyQkFaMkI7O0FBYW5CUyxJQUFBQSxJQUFJLEdBQUc7QUFDSCxhQUFPO0FBQ0grQixRQUFBQSxVQUFVLEVBQUU7QUFDUkMsVUFBQUEsQ0FBQyxFQUFFLENBREs7QUFFUkMsVUFBQUEsQ0FBQyxFQUFFO0FBRkssU0FEVDtBQUtIQyxRQUFBQSxJQUFJLEVBQUUsS0FMSDtBQU1IQyxRQUFBQSxJQUFJLEVBQUUsRUFOSDtBQU9IQyxRQUFBQSxLQUFLLEVBQUUsRUFQSjtBQVFIQyxRQUFBQSxPQUFPLEVBQUU7QUFSTixPQUFQO0FBVUgsS0F4QmtCOztBQXlCbkJDLElBQUFBLEtBQUssRUFBRSxDQUFDLElBQUQsRUFBTyxNQUFQLENBekJZO0FBMEJuQjlDLElBQUFBLE9BQU8sRUFBRTtBQUNMK0MsTUFBQUEsT0FBTyxHQUFHO0FBQ054RCxRQUFBQSxHQUFHLENBQUN5RCxLQUFKLENBQVUsVUFBVixFQUFzQixJQUF0QjtBQUNILE9BSEk7O0FBSUxDLE1BQUFBLE1BQU0sR0FBRztBQUNMLGNBQU16QyxJQUFJLEdBQUcwQyxZQUFZLENBQUN4RCxNQUFNLENBQUMyQyxHQUFQLENBQVcsSUFBWCxDQUFELENBQXpCO0FBQ0EsWUFBSWMsQ0FBQyxHQUFHQyxRQUFRLENBQUNDLGFBQVQsQ0FBdUIsR0FBdkIsQ0FBUjtBQUNBRixRQUFBQSxDQUFDLENBQUNHLElBQUYsR0FBU0MsR0FBRyxDQUFDQyxlQUFKLENBQW9CaEQsSUFBcEIsQ0FBVDtBQUNBMkMsUUFBQUEsQ0FBQyxDQUFDTSxRQUFGLEdBQWEsUUFBYjtBQUNBTixRQUFBQSxDQUFDLENBQUNPLEtBQUY7QUFDSCxPQVZJOztBQVdMQyxNQUFBQSxVQUFVLEdBQUc7QUFDVCxjQUFNQyxJQUFJLEdBQUdsRSxNQUFNLENBQUMyQyxHQUFQLENBQVcsTUFBWCxLQUFzQixFQUFuQztBQUNBLGNBQU13QixLQUFLLEdBQUdELElBQUksQ0FBQ0UsU0FBTCxDQUFlakQsQ0FBQyxJQUFJQSxDQUFDLENBQUNrRCxFQUFGLElBQVEsS0FBS3BCLElBQWpDLENBQWQ7QUFDQSxZQUFJa0IsS0FBSyxLQUFLLENBQUMsQ0FBZixFQUFrQixPQUFPLEtBQVA7QUFDbEIsY0FBTWxCLElBQUksR0FBR2lCLElBQUksQ0FBQ0MsS0FBRCxDQUFqQjtBQUNBdEUsUUFBQUEsR0FBRyxDQUFDeUQsS0FBSixDQUFVLFVBQVYsRUFBc0JMLElBQXRCO0FBQ0EsYUFBS0QsSUFBTCxHQUFZLEtBQVo7QUFDSCxPQWxCSTs7QUFtQkxzQixNQUFBQSxPQUFPLEdBQUc7QUFDTnpFLFFBQUFBLEdBQUcsQ0FBQ3lELEtBQUosQ0FBVSxNQUFWLEVBQWtCLElBQWxCO0FBQ0gsT0FyQkk7O0FBc0JMaUIsTUFBQUEsVUFBVSxHQUFHO0FBQ1QxRSxRQUFBQSxHQUFHLENBQUN5RCxLQUFKLENBQVUsWUFBVixFQUF3QixLQUFLTCxJQUE3QjtBQUNBLGFBQUtELElBQUwsR0FBWSxLQUFaO0FBQ0gsT0F6Qkk7O0FBMEJMd0IsTUFBQUEsT0FBTyxHQUFHO0FBQ04sWUFBSTFELElBQUksR0FBRyxJQUFJMkQsVUFBSixFQUFYOztBQUNBM0QsUUFBQUEsSUFBSSxDQUFDNEQsTUFBTCxHQUFlQyxFQUFELElBQVE7QUFDbEIsZ0JBQU1DLElBQUksR0FBRzlELElBQUksQ0FBQytELE1BQWxCOztBQUNBLGNBQUlELElBQUksQ0FBQ0UsTUFBTCxHQUFjLEdBQWxCLEVBQXVCO0FBQ25CLGlCQUFLQyxPQUFMLENBQWFuRSxLQUFiLENBQW1CO0FBQ2ZDLGNBQUFBLEtBQUssRUFBRSxNQURRO0FBRWZtRSxjQUFBQSxPQUFPLEVBQUU7QUFGTSxhQUFuQjtBQUlIOztBQUNEaEYsVUFBQUEsTUFBTSxDQUFDaUYsR0FBUCxDQUFXLElBQVgsRUFBaUJMLElBQWpCO0FBQ0gsU0FURDs7QUFVQSxhQUFLRyxPQUFMLENBQWE5QixJQUFiLENBQWtCO0FBQ2RwQyxVQUFBQSxLQUFLLEVBQUUsS0FETztBQUVkbUUsVUFBQUEsT0FBTyxFQUFFO0FBRkssU0FBbEI7QUFJQUUsUUFBQUEsS0FBSyxDQUFDbkYsS0FBSyxDQUFDb0YsUUFBTixDQUFlQyxPQUFmLEdBQXlCLGlCQUExQixDQUFMLENBQWtEbEUsSUFBbEQsQ0FBdURtRSxHQUFHLElBQUk7QUFDMURBLFVBQUFBLEdBQUcsQ0FBQ0MsSUFBSixHQUFXcEUsSUFBWCxDQUFnQnFFLEVBQUUsSUFBSTtBQUNsQnpFLFlBQUFBLElBQUksQ0FBQzBFLGFBQUwsQ0FBbUJELEVBQW5CO0FBQ0Esa0JBQU1FLEVBQUUsR0FBRzVCLEdBQUcsQ0FBQ0MsZUFBSixDQUFvQnlCLEVBQXBCLENBQVg7QUFDQTdCLFlBQUFBLFFBQVEsQ0FBQ2dDLGFBQVQsQ0FBdUIsT0FBdkIsRUFBZ0NDLEtBQWhDLENBQXNDQyxVQUF0QyxHQUFvRCxPQUFNSCxFQUFHLDBCQUE3RDtBQUNILFdBSkQ7QUFLSCxTQU5EO0FBT0EsYUFBS3pDLElBQUwsR0FBWSxLQUFaO0FBQ0gsT0FsREk7O0FBbURMLFlBQU02QyxPQUFOLEdBQWdCO0FBQ1osWUFBSTtBQUNBLGdCQUFNLEtBQUtDLFFBQUwsQ0FBYyxPQUFkLENBQU47QUFDSCxTQUZELENBRUUsT0FBTzNFLENBQVAsRUFBVTtBQUNSLGlCQUFPLEtBQVA7QUFDSDs7QUFDRHBCLFFBQUFBLEtBQUssQ0FBQ2tCLElBQU4sQ0FBVyxzQ0FBWCxFQUFtRDtBQUMvQ29ELFVBQUFBLEVBQUUsRUFBRSxLQUFLcEI7QUFEc0MsU0FBbkQsRUFFRy9CLElBRkgsQ0FFUTZFLEVBQUUsSUFBSTtBQUNWLGdCQUFNO0FBQUMzRSxZQUFBQTtBQUFELGNBQVMyRSxFQUFFLENBQUNqRixJQUFsQjs7QUFDQSxjQUFJTSxJQUFJLEtBQUssQ0FBYixFQUFnQjtBQUNaLGlCQUFLK0IsT0FBTCxDQUFhNkMsVUFBYixDQUF3QkMsTUFBeEI7QUFDQSxpQkFBS3RGLFFBQUwsQ0FBY1UsT0FBZCxDQUFzQixNQUF0QjtBQUNILFdBSEQsTUFHTztBQUNILGlCQUFLVixRQUFMLENBQWNDLEtBQWQsQ0FBb0IsTUFBcEI7QUFDSDtBQUNKLFNBVkQ7QUFXQSxhQUFLb0MsSUFBTCxHQUFZLEtBQVo7QUFDSCxPQXJFSTs7QUFzRUwsWUFBTWtELE9BQU4sR0FBZ0I7QUFDWixZQUFJO0FBQ0EsZ0JBQU0sS0FBS0osUUFBTCxDQUFjLE9BQWQsQ0FBTjtBQUNILFNBRkQsQ0FFRSxPQUFPM0UsQ0FBUCxFQUFVO0FBQ1IsaUJBQU8sS0FBUDtBQUNIOztBQUNELGNBQU1nRixLQUFLLEdBQUduRyxNQUFNLENBQUMyQyxHQUFQLENBQVcsT0FBWCxLQUF1QixFQUFyQztBQUNBLGNBQU13QixLQUFLLEdBQUdnQyxLQUFLLENBQUMvQixTQUFOLENBQWdCakQsQ0FBQyxJQUFJQSxDQUFDLENBQUNrRCxFQUFGLElBQVEsS0FBS3BCLElBQWxDLENBQWQ7QUFDQSxZQUFJa0IsS0FBSyxLQUFLLENBQUMsQ0FBZixFQUFrQixPQUFPLEtBQVA7QUFDbEIsY0FBTWxCLElBQUksR0FBR2tELEtBQUssQ0FBQ2hDLEtBQUQsQ0FBbEI7QUFDQXBFLFFBQUFBLEtBQUssQ0FBQ2tCLElBQU4sQ0FBVyxrQ0FBWCxFQUErQztBQUMzQ29ELFVBQUFBLEVBQUUsRUFBRXBCLElBQUksQ0FBQ29CO0FBRGtDLFNBQS9DLEVBRUduRCxJQUZILENBRVE2RSxFQUFFLElBQUk7QUFDVixnQkFBTTtBQUFDM0UsWUFBQUE7QUFBRCxjQUFTMkUsRUFBRSxDQUFDakYsSUFBbEI7O0FBQ0EsY0FBSU0sSUFBSSxLQUFLLENBQWIsRUFBZ0I7QUFDWixpQkFBSytCLE9BQUwsQ0FBYThDLE1BQWI7QUFDQSxpQkFBS3RGLFFBQUwsQ0FBY1UsT0FBZCxDQUFzQixNQUF0QjtBQUNILFdBSEQsTUFHTztBQUNILGlCQUFLVixRQUFMLENBQWNDLEtBQWQsQ0FBb0IsTUFBcEI7QUFDSDtBQUNKLFNBVkQ7QUFXQSxhQUFLb0MsSUFBTCxHQUFZLEtBQVo7QUFDSCxPQTVGSTs7QUE2RkxvRCxNQUFBQSxPQUFPLEdBQUc7QUFFTixhQUFLcEQsSUFBTCxHQUFZLEtBQVo7QUFDSCxPQWhHSTs7QUFpR0xxRCxNQUFBQSxVQUFVLEdBQUc7QUFDVCxjQUFNRixLQUFLLEdBQUduRyxNQUFNLENBQUMyQyxHQUFQLENBQVcsT0FBWCxLQUF1QixFQUFyQztBQUNBLGNBQU13QixLQUFLLEdBQUdnQyxLQUFLLENBQUMvQixTQUFOLENBQWdCakQsQ0FBQyxJQUFJQSxDQUFDLENBQUNrRCxFQUFGLElBQVEsS0FBS3BCLElBQWxDLENBQWQ7QUFDQSxZQUFJa0IsS0FBSyxLQUFLLENBQUMsQ0FBZixFQUFrQixPQUFPLEtBQVA7QUFDbEIsY0FBTWxCLElBQUksR0FBR2tELEtBQUssQ0FBQ2hDLEtBQUQsQ0FBbEI7QUFDQXRFLFFBQUFBLEdBQUcsQ0FBQ3lELEtBQUosQ0FBVSxlQUFWLEVBQTJCTCxJQUEzQjtBQUNBLGFBQUtELElBQUwsR0FBWSxLQUFaO0FBQ0gsT0F4R0k7O0FBeUdMc0QsTUFBQUEsT0FBTyxDQUFDbkMsS0FBRCxFQUFRO0FBQ1gsZUFBT29DLE9BQU8sQ0FBQyxLQUFLckQsS0FBTCxDQUFXc0QsT0FBWCxDQUFtQnJDLEtBQW5CLElBQTRCLENBQUMsQ0FBOUIsQ0FBZDtBQUNIOztBQTNHSSxLQTFCVTs7QUF1SW5CMUIsSUFBQUEsT0FBTyxHQUFHO0FBQ05pQixNQUFBQSxRQUFRLENBQUNnQyxhQUFULENBQXVCLFFBQXZCLEVBQWlDZSxnQkFBakMsQ0FBa0QsT0FBbEQsRUFBMkQsVUFBVUMsS0FBVixFQUFpQjtBQUN4RUEsUUFBQUEsS0FBSyxDQUFDQyxlQUFOO0FBQ0FELFFBQUFBLEtBQUssQ0FBQ0UsY0FBTjtBQUNILE9BSEQ7QUFJQWxELE1BQUFBLFFBQVEsQ0FBQytDLGdCQUFULENBQTBCLE9BQTFCLEVBQW9DQyxLQUFELElBQVc7QUFDMUMsYUFBSzFELElBQUwsR0FBWSxLQUFaO0FBQ0gsT0FGRDtBQUdBLFlBQU02RCxLQUFLLEdBQUc7QUFDVkMsUUFBQUEsTUFBTSxFQUFFLEtBREU7QUFFVkMsUUFBQUEsSUFBSSxFQUFFO0FBRkksT0FBZDtBQUlBM0UsTUFBQUEsTUFBTSxDQUFDcUUsZ0JBQVAsQ0FBd0IsWUFBeEIsRUFBdUN0RixDQUFELElBQU87QUFDekMwRixRQUFBQSxLQUFLLENBQUNDLE1BQU4sR0FBZSxJQUFmO0FBQ0FELFFBQUFBLEtBQUssQ0FBQ0UsSUFBTixHQUFhLElBQUlDLElBQUosR0FBV0MsT0FBWCxFQUFiO0FBQ0FKLFFBQUFBLEtBQUssQ0FBQ0UsSUFBTixHQUFhekYsVUFBVSxDQUFDQyxDQUFDLElBQUk7QUFDekIsZUFBS3NCLFVBQUwsR0FBa0I7QUFDZEMsWUFBQUEsQ0FBQyxFQUFFM0IsQ0FBQyxDQUFDK0YsY0FBRixDQUFpQixDQUFqQixFQUFvQkMsT0FBcEIsR0FBOEIsSUFEbkI7QUFFZHBFLFlBQUFBLENBQUMsRUFBRTVCLENBQUMsQ0FBQytGLGNBQUYsQ0FBaUIsQ0FBakIsRUFBb0JFLE9BQXBCLEdBQThCO0FBRm5CLFdBQWxCOztBQUlBLGNBQUk7QUFDQSxnQkFBSUMsQ0FBQyxHQUFHL0UsSUFBSSxDQUFDQyxLQUFMLENBQVdwQixDQUFDLENBQUNtRyxNQUFGLENBQVNDLFVBQVQsQ0FBb0JyRSxLQUFwQixDQUEwQnNFLEtBQXJDLENBQVI7O0FBQ0EsZ0JBQUlILENBQUMsQ0FBQ3ZDLE1BQUYsR0FBVyxDQUFmLEVBQWtCO0FBQ2QsbUJBQUs1QixLQUFMLEdBQWFtRSxDQUFiO0FBQ0g7QUFDSixXQUxELENBS0UsT0FBT2xHLENBQVAsRUFBVTtBQUNSLGlCQUFLK0IsS0FBTCxHQUFhLEVBQWI7QUFDSDs7QUFDRCxjQUFJO0FBQ0EsZ0JBQUlELElBQUksR0FBRzlCLENBQUMsQ0FBQ21HLE1BQUYsQ0FBU0MsVUFBVCxDQUFvQkUsS0FBcEIsQ0FBMEJELEtBQXJDO0FBQ0EsaUJBQUt2RSxJQUFMLEdBQVlBLElBQVo7QUFDQSxpQkFBS0UsT0FBTCxHQUFlaEMsQ0FBQyxDQUFDbUcsTUFBakI7QUFDSCxXQUpELENBSUUsT0FBT25HLENBQVAsRUFBVSxDQUNYOztBQUNELGVBQUs2QixJQUFMLEdBQVksSUFBWjtBQUNILFNBcEJzQixFQW9CcEIsR0FwQm9CLENBQXZCO0FBcUJILE9BeEJEO0FBeUJBWixNQUFBQSxNQUFNLENBQUNxRSxnQkFBUCxDQUF3QixVQUF4QixFQUFvQyxZQUFZO0FBQzVDSSxRQUFBQSxLQUFLLENBQUNDLE1BQU4sR0FBZSxLQUFmO0FBQ0FZLFFBQUFBLFlBQVksQ0FBQ2IsS0FBSyxDQUFDRSxJQUFQLENBQVo7QUFDQUYsUUFBQUEsS0FBSyxDQUFDRSxJQUFOLEdBQWEsSUFBYjtBQUVILE9BTEQ7QUFRQTNFLE1BQUFBLE1BQU0sQ0FBQ3FFLGdCQUFQLENBQXdCLFNBQXhCLEVBQW9DdEYsQ0FBRCxJQUFPO0FBQ3RDLFlBQUlBLENBQUMsQ0FBQ3dHLE1BQUYsS0FBYSxDQUFqQixFQUFvQjtBQUNoQixlQUFLOUUsVUFBTCxHQUFrQjtBQUNkQyxZQUFBQSxDQUFDLEVBQUUzQixDQUFDLENBQUNnRyxPQUFGLEdBQVksSUFERDtBQUVkcEUsWUFBQUEsQ0FBQyxFQUFFNUIsQ0FBQyxDQUFDaUcsT0FBRixHQUFZO0FBRkQsV0FBbEI7O0FBSUEsY0FBSTtBQUNBLGdCQUFJQyxDQUFDLEdBQUcvRSxJQUFJLENBQUNDLEtBQUwsQ0FBV3BCLENBQUMsQ0FBQ3lHLFNBQUYsQ0FBWUwsVUFBWixDQUF1QnJFLEtBQXZCLENBQTZCc0UsS0FBeEMsQ0FBUjs7QUFDQSxnQkFBSUgsQ0FBQyxDQUFDdkMsTUFBRixHQUFXLENBQWYsRUFBa0I7QUFDZCxtQkFBSzVCLEtBQUwsR0FBYW1FLENBQWI7QUFDSDtBQUNKLFdBTEQsQ0FLRSxPQUFPbEcsQ0FBUCxFQUFVO0FBQ1IsaUJBQUsrQixLQUFMLEdBQWEsRUFBYjtBQUNIOztBQUNELGNBQUk7QUFDQSxnQkFBSUQsSUFBSSxHQUFHOUIsQ0FBQyxDQUFDeUcsU0FBRixDQUFZTCxVQUFaLENBQXVCRSxLQUF2QixDQUE2QkQsS0FBeEM7QUFDQSxpQkFBS3ZFLElBQUwsR0FBWUEsSUFBWjtBQUNBLGlCQUFLRSxPQUFMLEdBQWVoQyxDQUFDLENBQUNtRyxNQUFqQjtBQUNILFdBSkQsQ0FJRSxPQUFPbkcsQ0FBUCxFQUFVLENBRVg7O0FBQ0QsZUFBSzZCLElBQUwsR0FBWSxJQUFaO0FBQ0E3QixVQUFBQSxDQUFDLENBQUN5RixjQUFGO0FBQ0F6RixVQUFBQSxDQUFDLENBQUN3RixlQUFGO0FBQ0g7QUFDSixPQXpCRDtBQTBCSDs7QUE5TWtCLEdBQXZCO0FBa05BeEcsRUFBQUEsR0FBRyxDQUFDQyxTQUFKLENBQWMsV0FBZCxFQUNJO0FBQ0lDLElBQUFBLFFBQVEsRUFBSTtBQUN4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkExQlE7QUEyQklDLElBQUFBLE9BQU8sRUFBRTtBQUNMQyxNQUFBQSxNQUFNLEdBQUc7QUFDTCxZQUFJLEtBQUtFLE9BQUwsQ0FBYW9ILElBQWIsS0FBc0IsRUFBMUIsRUFBOEIsT0FBTyxLQUFLbEgsUUFBTCxDQUFjQyxLQUFkLENBQW9CLFFBQXBCLENBQVA7QUFDOUIsY0FBTUUsSUFBSSxHQUFHLEVBQUMsR0FBRyxLQUFLTDtBQUFULFNBQWI7QUFDQUssUUFBQUEsSUFBSSxDQUFDRSxRQUFMLEdBQWdCLEtBQUtQLE9BQUwsQ0FBYU8sUUFBYixHQUF3QixDQUF4QixHQUE0QixDQUE1QztBQUNBLFlBQUlOLEdBQUcsR0FBRyxzQ0FBVjtBQUNBLFlBQUksS0FBS0ssTUFBVCxFQUNJTCxHQUFHLEdBQUcsdUNBQU47QUFDSlgsUUFBQUEsS0FBSyxDQUFDa0IsSUFBTixDQUFXUCxHQUFYLEVBQWdCSSxJQUFoQixFQUFzQkksSUFBdEIsQ0FBMkJDLENBQUMsSUFBSTtBQUM1QixnQkFBTTtBQUFDQyxZQUFBQTtBQUFELGNBQVNELENBQUMsQ0FBQ0wsSUFBakI7O0FBQ0EsY0FBSU0sSUFBSSxLQUFLLENBQWIsRUFBZ0I7QUFDWixpQkFBS1QsUUFBTCxDQUFjVSxPQUFkLENBQXNCLE1BQXRCO0FBQ0FDLFlBQUFBLFVBQVUsQ0FBQ0MsQ0FBQyxJQUFJQyxRQUFRLENBQUNDLE1BQVQsRUFBTixFQUF5QixJQUF6QixDQUFWO0FBQ0EsaUJBQUtDLGFBQUwsR0FBcUIsS0FBckI7QUFDSCxXQUpELE1BSU87QUFDSCxpQkFBS2YsUUFBTCxDQUFjQyxLQUFkLENBQW9CLE1BQXBCO0FBQ0g7QUFDSixTQVREO0FBV0gsT0FuQkk7O0FBb0JMZSxNQUFBQSxRQUFRLEdBQUc7QUFDUCxZQUFJQyxVQUFVLEdBQUcsR0FBakIsRUFBc0I7QUFDbEIsaUJBQU8sT0FBUDtBQUNIOztBQUNELGVBQU8sT0FBUDtBQUNIOztBQXpCSSxLQTNCYjs7QUFzRElkLElBQUFBLElBQUksR0FBRztBQUNILGFBQU87QUFDSFksUUFBQUEsYUFBYSxFQUFFLEtBRFo7QUFFSEcsUUFBQUEsTUFBTSxFQUFFLEVBRkw7QUFHSHBCLFFBQUFBLE9BQU8sRUFBRTtBQUNMb0gsVUFBQUEsSUFBSSxFQUFFLEVBREQ7QUFFTDlGLFVBQUFBLE1BQU0sRUFBRSxFQUZIO0FBR0xmLFVBQUFBLFFBQVEsRUFBRSxJQUhMO0FBSUxrQixVQUFBQSxXQUFXLEVBQUUsRUFKUjtBQUtMNEYsVUFBQUEsU0FBUyxFQUFFLEtBTE47QUFNTDlGLFVBQUFBLEdBQUcsRUFBRTtBQU5BLFNBSE47QUFXSEYsUUFBQUEsR0FBRyxFQUFFO0FBQ0QrRixVQUFBQSxJQUFJLEVBQUUsRUFETDtBQUVEOUYsVUFBQUEsTUFBTSxFQUFFLEVBRlA7QUFHRGYsVUFBQUEsUUFBUSxFQUFFLElBSFQ7QUFJRGtCLFVBQUFBLFdBQVcsRUFBRSxFQUpaO0FBS0Q0RixVQUFBQSxTQUFTLEVBQUUsS0FMVjtBQU1EOUYsVUFBQUEsR0FBRyxFQUFFO0FBTkosU0FYRjtBQW1CSGpCLFFBQUFBLE1BQU0sRUFBRTtBQW5CTCxPQUFQO0FBcUJILEtBNUVMOztBQTZFSW9CLElBQUFBLEtBQUssRUFBRTtBQUNIVCxNQUFBQSxhQUFhLENBQUNQLENBQUQsRUFBSTtBQUNiLFlBQUlBLENBQUMsS0FBSyxLQUFWLEVBQWlCO0FBQ2JpQixVQUFBQSxNQUFNLENBQUNDLFVBQVAsR0FBb0IsS0FBcEI7QUFDSCxTQUZELE1BRU8sSUFBSWxCLENBQUMsS0FBSyxJQUFWLEVBQWdCO0FBQ25CLGVBQUtWLE9BQUwsR0FBZTZCLElBQUksQ0FBQ0MsS0FBTCxDQUFXRCxJQUFJLENBQUNFLFNBQUwsQ0FBZSxLQUFLVixHQUFwQixDQUFYLENBQWY7QUFDQU0sVUFBQUEsTUFBTSxDQUFDQyxVQUFQLEdBQW9CLElBQXBCO0FBQ0g7QUFDSjs7QUFSRSxLQTdFWDs7QUF1RklJLElBQUFBLE9BQU8sR0FBRztBQUNONUMsTUFBQUEsR0FBRyxDQUFDNkMsR0FBSixDQUFRLFVBQVIsRUFBcUJPLElBQUQsSUFBVTtBQUMxQixhQUFLdkIsYUFBTCxHQUFxQixJQUFyQjtBQUNBLGFBQUtrQixTQUFMLENBQWVyQixDQUFDLElBQUk7QUFDaEIsY0FBSXdHLEdBQUcsR0FBRyxFQUFWO0FBQ0EvSCxVQUFBQSxNQUFNLENBQUMyQyxHQUFQLENBQVcsTUFBWCxFQUFtQnFGLE9BQW5CLENBQTJCakMsRUFBRSxJQUFJO0FBQzdCLGdCQUFJQSxFQUFFLENBQUMvRCxHQUFILElBQVUsR0FBZCxFQUFtQjtBQUNmK0YsY0FBQUEsR0FBRyxDQUFDRSxJQUFKLENBQVNsQyxFQUFUO0FBQ0g7QUFDSixXQUpEO0FBS0EsZUFBS2xFLE1BQUwsR0FBY2tHLEdBQWQ7O0FBQ0EsY0FBSTlFLElBQUksS0FBSyxJQUFiLEVBQW1CO0FBQ2YsaUJBQUssTUFBTWlGLElBQVgsSUFBbUIsS0FBS3pILE9BQXhCLEVBQWlDO0FBQzdCLG1CQUFLQSxPQUFMLENBQWF5SCxJQUFiLElBQXFCakYsSUFBSSxDQUFDaUYsSUFBRCxDQUF6QjtBQUNIOztBQUNELGlCQUFLekgsT0FBTCxDQUFhTyxRQUFiLEdBQXdCdUYsT0FBTyxDQUFDdEQsSUFBSSxDQUFDLFVBQUQsQ0FBSixLQUFxQixDQUF0QixDQUEvQjtBQUNBLGlCQUFLeEMsT0FBTCxDQUFhNEQsRUFBYixHQUFrQnBCLElBQUksQ0FBQ29CLEVBQXZCO0FBQ0EsaUJBQUs1RCxPQUFMLENBQWF1QixHQUFiLEdBQW1CaUIsSUFBSSxDQUFDakIsR0FBeEI7QUFDQSxpQkFBS2pCLE1BQUwsR0FBYyxJQUFkO0FBQ0g7QUFDSixTQWpCRDtBQW1CSCxPQXJCRDtBQXNCSDs7QUE5R0wsR0FESjtBQWtISCxDQTdhRDs7Ozs7Ozs7OztBQ0hBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsY0FBYyxtQkFBTyxDQUFDLDBEQUFXO0FBQ2pDLGlCQUFpQixtQkFBTyxDQUFDLHdEQUFVO0FBQ25DLFFBQVEsbUJBQU8sQ0FBQyxvREFBUTs7O0FBR3hCO0FBQ0E7QUFDQTtBQUNBLFdBQVcsUUFBUTtBQUNuQixZQUFZO0FBQ1o7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsV0FBVyxRQUFRO0FBQ25CLFlBQVk7QUFDWjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsUUFBUTtBQUNuQixRQUFRLFFBQVE7QUFDaEIsUUFBUSxVQUFVO0FBQ2xCLFFBQVEsVUFBVTtBQUNsQixRQUFRLFVBQVU7QUFDbEI7QUFDQTtBQUNBLDJDQUEyQztBQUMzQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsUUFBUTtBQUNSO0FBQ0E7O0FBRUEsTUFBTTs7QUFFTjtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLEdBQUc7O0FBRUg7QUFDQTs7O0FBR0E7Ozs7Ozs7Ozs7O0FDN0dBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0Esa0NBQWtDO0FBQ2xDO0FBQ0E7QUFDQTs7QUFFQSxzQ0FBc0M7QUFDdEMsb0NBQW9DO0FBQ3BDLG1DQUFtQztBQUNuQyx5Q0FBeUM7QUFDekMsMkNBQTJDO0FBQzNDLDRCQUE0QjtBQUM1QixxQ0FBcUM7QUFDckMsa0NBQWtDO0FBQ2xDLHdDQUF3QztBQUN4Qyw0Q0FBNEM7QUFDNUMsMkNBQTJDO0FBQzNDLDRDQUE0QztBQUM1QyxrREFBa0Q7QUFDbEQsdUNBQXVDO0FBQ3ZDLDZDQUE2QztBQUM3QyxrREFBa0Q7QUFDbEQsZ0NBQWdDO0FBQ2hDLDRDQUE0QztBQUM1QyxrQ0FBa0M7QUFDbEMsNkNBQTZDO0FBQzdDLHVDQUF1QztBQUN2Qyx3Q0FBd0M7QUFDeEMsd0NBQXdDO0FBQ3hDLHlDQUF5QztBQUN6QywyQ0FBMkM7QUFDM0MseUNBQXlDO0FBQ3pDLHVDQUF1QztBQUN2Qyx1Q0FBdUM7QUFDdkMsZ0NBQWdDO0FBQ2hDLDhCQUE4QjtBQUM5Qix1Q0FBdUM7QUFDdkMsdUNBQXVDO0FBQ3ZDLHVDQUF1QztBQUN2Qyw4QkFBOEI7QUFDOUIscUNBQXFDO0FBQ3JDLDJDQUEyQztBQUMzQyxpREFBaUQ7QUFDakQsa0RBQWtEO0FBQ2xELDJDQUEyQztBQUMzQywyQ0FBMkM7QUFDM0MsdUNBQXVDO0FBQ3ZDLG9DQUFvQztBQUNwQyxvQ0FBb0M7QUFDcEMsMkNBQTJDO0FBQzNDLDJDQUEyQztBQUMzQywwQ0FBMEM7QUFDMUMsMkNBQTJDO0FBQzNDLDBDQUEwQztBQUMxQyxtQ0FBbUM7QUFDbkMseUNBQXlDO0FBQ3pDLHlDQUF5QztBQUN6Qyx5Q0FBeUM7QUFDekMscUNBQXFDO0FBQ3JDLG9DQUFvQztBQUNwQywwQ0FBMEM7QUFDMUMsMENBQTBDO0FBQzFDLDBDQUEwQztBQUMxQyxzQ0FBc0M7QUFDdEMsb0NBQW9DO0FBQ3BDLGtDQUFrQztBQUNsQyx3Q0FBd0M7QUFDeEMsOENBQThDO0FBQzlDLCtDQUErQztBQUMvQyx3Q0FBd0M7QUFDeEMsd0NBQXdDO0FBQ3hDLG9DQUFvQztBQUNwQywrQkFBK0I7QUFDL0IsNENBQTRDO0FBQzVDLGtDQUFrQztBQUNsQyxrQ0FBa0M7QUFDbEMsZ0NBQWdDO0FBQ2hDLG9DQUFvQztBQUNwQyxtQ0FBbUM7QUFDbkMsb0NBQW9DO0FBQ3BDLG9DQUFvQztBQUNwQyxxQ0FBcUM7QUFDckMsK0JBQStCO0FBQy9CLDZCQUE2QjtBQUM3Qiw2QkFBNkI7QUFDN0Isa0NBQWtDO0FBQ2xDLGtDQUFrQztBQUNsQyw2QkFBNkI7QUFDN0IsbURBQW1EO0FBQ25ELHFDQUFxQztBQUNyQyxvQ0FBb0M7QUFDcEMsbUNBQW1DO0FBQ25DLG9DQUFvQztBQUNwQywwQ0FBMEM7QUFDMUMsMENBQTBDO0FBQzFDLDBDQUEwQztBQUMxQyxvQ0FBb0M7QUFDcEMscUNBQXFDO0FBQ3JDLGdDQUFnQztBQUNoQyxnQ0FBZ0M7QUFDaEMsZ0NBQWdDO0FBQ2hDLDBDQUEwQztBQUMxQyxzQ0FBc0M7QUFDdEMsb0NBQW9DO0FBQ3BDLDZCQUE2QjtBQUM3Qiw0QkFBNEI7QUFDNUIsa0NBQWtDO0FBQ2xDLG1DQUFtQztBQUNuQywrQkFBK0I7QUFDL0Isa0NBQWtDO0FBQ2xDLCtCQUErQjtBQUMvQixzQ0FBc0M7QUFDdEMsb0NBQW9DO0FBQ3BDLHVDQUF1QztBQUN2QywwQ0FBMEM7QUFDMUMsa0NBQWtDO0FBQ2xDLG9DQUFvQztBQUNwQywrQkFBK0I7QUFDL0IsNkJBQTZCO0FBQzdCLG1DQUFtQztBQUNuQyx1Q0FBdUM7QUFDdkMsa0NBQWtDO0FBQ2xDLGtDQUFrQztBQUNsQyxvQ0FBb0M7QUFDcEMsa0NBQWtDO0FBQ2xDLDhCQUE4QjtBQUM5QixxQ0FBcUM7QUFDckMsb0NBQW9DO0FBQ3BDLHNDQUFzQztBQUN0QyxrQ0FBa0M7QUFDbEMsa0NBQWtDO0FBQ2xDLDRCQUE0QjtBQUM1QixtQ0FBbUM7QUFDbkMsNkNBQTZDO0FBQzdDLG9DQUFvQztBQUNwQyw4Q0FBOEM7QUFDOUMsaUNBQWlDO0FBQ2pDLHdDQUF3QztBQUN4QyxvQ0FBb0M7QUFDcEMsa0NBQWtDO0FBQ2xDLHNDQUFzQztBQUN0QyxvQ0FBb0M7QUFDcEMsK0NBQStDO0FBQy9DLHlDQUF5QztBQUN6QywrQ0FBK0M7QUFDL0MsOENBQThDO0FBQzlDLDRDQUE0QztBQUM1Qyw2Q0FBNkM7QUFDN0MsbUNBQW1DO0FBQ25DLDZCQUE2QjtBQUM3QixrQ0FBa0M7QUFDbEMsMENBQTBDO0FBQzFDLHVDQUF1QztBQUN2Qyx1Q0FBdUM7QUFDdkMsb0NBQW9DO0FBQ3BDLHdDQUF3QztBQUN4QywwQ0FBMEM7QUFDMUMsaUNBQWlDO0FBQ2pDLHFDQUFxQztBQUNyQyx1Q0FBdUM7QUFDdkMsc0NBQXNDO0FBQ3RDLDRDQUE0QztBQUM1Qyw4Q0FBOEM7QUFDOUMsMkNBQTJDO0FBQzNDLDRDQUE0QztBQUM1Qyw4QkFBOEI7QUFDOUIsZ0NBQWdDO0FBQ2hDLDZCQUE2QjtBQUM3QiwwQ0FBMEM7QUFDMUMseUNBQXlDO0FBQ3pDLGlDQUFpQztBQUNqQyx3Q0FBd0M7QUFDeEMseUNBQXlDO0FBQ3pDLHdDQUF3QztBQUN4QyxzQ0FBc0M7QUFDdEMscUNBQXFDO0FBQ3JDLDZCQUE2QjtBQUM3QixzQ0FBc0M7QUFDdEMsc0NBQXNDO0FBQ3RDLHlDQUF5QztBQUN6QyxtQ0FBbUM7QUFDbkMsa0NBQWtDO0FBQ2xDLG9DQUFvQztBQUNwQyxrQ0FBa0M7QUFDbEMsc0NBQXNDO0FBQ3RDLDJDQUEyQztBQUMzQyw0Q0FBNEM7QUFDNUMsK0NBQStDO0FBQy9DLGtDQUFrQztBQUNsQyx3Q0FBd0M7QUFDeEMsMkNBQTJDO0FBQzNDLHVDQUF1QztBQUN2Qyw4QkFBOEI7QUFDOUIscUNBQXFDO0FBQ3JDLG1DQUFtQztBQUNuQyxvQ0FBb0M7QUFDcEMsa0NBQWtDO0FBQ2xDLHNDQUFzQztBQUN0QyxvQ0FBb0M7QUFDcEMsOEJBQThCO0FBQzlCLDZCQUE2QjtBQUM3QixpQ0FBaUM7QUFDakMsd0NBQXdDO0FBQ3hDLHdDQUF3QztBQUN4Qyx1Q0FBdUM7QUFDdkMsd0NBQXdDO0FBQ3hDLHVDQUF1QztBQUN2QyxrQ0FBa0M7QUFDbEMsbUNBQW1DO0FBQ25DLG9DQUFvQztBQUNwQyxzQ0FBc0M7QUFDdEMsb0NBQW9DO0FBQ3BDLGtDQUFrQztBQUNsQyx5Q0FBeUM7QUFDekMsa0NBQWtDO0FBQ2xDLGtDQUFrQztBQUNsQyxrQ0FBa0M7QUFDbEMsaUNBQWlDO0FBQ2pDLGtDQUFrQztBQUNsQyxpQ0FBaUM7QUFDakMsZ0NBQWdDO0FBQ2hDLGlDQUFpQztBQUNqQyxrQ0FBa0M7QUFDbEMsaUNBQWlDO0FBQ2pDLGtDQUFrQztBQUNsQywrQkFBK0I7QUFDL0IsbUNBQW1DO0FBQ25DLHdDQUF3QztBQUN4QyxnQ0FBZ0M7QUFDaEMsOEJBQThCO0FBQzlCLGdDQUFnQztBQUNoQyxnQ0FBZ0M7QUFDaEMsc0NBQXNDO0FBQ3RDLHVDQUF1QztBQUN2QyxzQ0FBc0M7QUFDdEMsc0NBQXNDO0FBQ3RDLGlDQUFpQztBQUNqQyxzQ0FBc0M7QUFDdEMsbUNBQW1DO0FBQ25DLG1DQUFtQztBQUNuQywrQkFBK0I7QUFDL0Isc0NBQXNDO0FBQ3RDLG9DQUFvQztBQUNwQyxxQ0FBcUM7QUFDckMsbUNBQW1DO0FBQ25DLDZCQUE2QjtBQUM3Qix5Q0FBeUM7QUFDekMsMENBQTBDO0FBQzFDLDBDQUEwQztBQUMxQyxvQ0FBb0M7QUFDcEMsOEJBQThCO0FBQzlCLG9DQUFvQztBQUNwQyxxQ0FBcUM7QUFDckMsb0NBQW9DO0FBQ3BDLDJDQUEyQztBQUMzQyw4QkFBOEI7QUFDOUIsb0NBQW9DO0FBQ3BDLG9DQUFvQztBQUNwQyxpQ0FBaUM7QUFDakMsMkNBQTJDO0FBQzNDLCtCQUErQjtBQUMvQix3Q0FBd0M7QUFDeEMsK0JBQStCO0FBQy9CLDZCQUE2QjtBQUM3QixtQ0FBbUM7QUFDbkMsb0NBQW9DO0FBQ3BDLGlDQUFpQztBQUNqQyw4QkFBOEI7QUFDOUIsaUNBQWlDO0FBQ2pDLHVDQUF1QztBQUN2QyxtQ0FBbUM7QUFDbkMsbUNBQW1DO0FBQ25DLHNDQUFzQztBQUN0Qyw4Q0FBOEM7QUFDOUMsc0NBQXNDO0FBQ3RDLHFDQUFxQztBQUNyQyw2QkFBNkI7QUFDN0IsOEJBQThCO0FBQzlCLGlDQUFpQztBQUNqQyxxQ0FBcUM7QUFDckMsc0NBQXNDO0FBQ3RDLDBDQUEwQztBQUMxQyxvQ0FBb0M7QUFDcEMsK0JBQStCO0FBQy9CLG1DQUFtQztBQUNuQyxpQ0FBaUM7QUFDakMscUNBQXFDO0FBQ3JDLGtDQUFrQztBQUNsQyx1Q0FBdUM7QUFDdkMsNENBQTRDO0FBQzVDLHVDQUF1QztBQUN2Qyw2Q0FBNkM7QUFDN0MsNENBQTRDO0FBQzVDLDRDQUE0QztBQUM1Qyw2Q0FBNkM7QUFDN0MscUNBQXFDO0FBQ3JDLDJDQUEyQztBQUMzQyw4Q0FBOEM7QUFDOUMsMkNBQTJDO0FBQzNDLG1DQUFtQztBQUNuQyxtQ0FBbUM7QUFDbkMsb0NBQW9DO0FBQ3BDLHdDQUF3QztBQUN4QyxxQ0FBcUM7QUFDckMsbUNBQW1DO0FBQ25DLDJDQUEyQztBQUMzQyxzQ0FBc0M7QUFDdEMsK0NBQStDO0FBQy9DLGlDQUFpQztBQUNqQyw0QkFBNEI7QUFDNUIsa0NBQWtDO0FBQ2xDLHlDQUF5QztBQUN6Qyx3Q0FBd0M7QUFDeEMsbUNBQW1DO0FBQ25DLHlDQUF5QztBQUN6Qyw0Q0FBNEM7QUFDNUMsNENBQTRDO0FBQzVDLG1EQUFtRDtBQUNuRCxxQ0FBcUM7QUFDckMsdUNBQXVDO0FBQ3ZDLG1DQUFtQztBQUNuQyxzQ0FBc0M7QUFDdEMsdUNBQXVDO0FBQ3ZDLHFDQUFxQztBQUNyQyxvQ0FBb0M7QUFDcEMsb0NBQW9DO0FBQ3BDLG1DQUFtQztBQUNuQyxxQ0FBcUM7QUFDckMscUNBQXFDO0FBQ3JDLCtCQUErQjtBQUMvQixvQ0FBb0M7QUFDcEMsK0JBQStCO0FBQy9CLDZCQUE2QjtBQUM3QixvQ0FBb0M7QUFDcEMsa0NBQWtDO0FBQ2xDLG9DQUFvQztBQUNwQyxpQ0FBaUM7QUFDakMsa0NBQWtDO0FBQ2xDLHFDQUFxQztBQUNyQyxxQ0FBcUM7QUFDckMsZ0NBQWdDOztBQUVoQztBQUNBOzs7QUFHQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLFFBQVE7QUFDbkIsV0FBVyxRQUFRO0FBQ25CLFdBQVcsUUFBUTtBQUNuQixZQUFZO0FBQ1o7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsV0FBVyxRQUFRO0FBQ25CLFdBQVcsUUFBUTtBQUNuQixXQUFXLFFBQVE7QUFDbkIsWUFBWTtBQUNaO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsUUFBUTtBQUNuQixXQUFXLFFBQVE7QUFDbkIsWUFBWTtBQUNaO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUdBLGlCQUFpQjtBQUNqQiwyQkFBMkI7QUFDM0IsY0FBYztBQUNkLG9CQUFvQjtBQUNwQixxQkFBcUI7Ozs7Ozs7Ozs7O0FDN1lyQjtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLGNBQWMsbUJBQU8sQ0FBQywwREFBVztBQUNqQyxnQkFBZ0IsbUJBQU8sQ0FBQyxrREFBTzs7O0FBRy9CO0FBQ0E7QUFDQTtBQUNBLFdBQVcsUUFBUTtBQUNuQixXQUFXLFFBQVE7QUFDbkIsWUFBWTtBQUNaO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUdBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7O0FDL0JBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsUUFBUSxtQkFBTyxDQUFDLG9EQUFROzs7QUFHeEI7QUFDQTtBQUNBO0FBQ0EsV0FBVyxRQUFRO0FBQ25CLFdBQVcsVUFBVTtBQUNyQjtBQUNBLFlBQVk7QUFDWjtBQUNBO0FBQ0E7QUFDQSxnQ0FBZ0MsWUFBWTtBQUM1QztBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQ0FBc0M7QUFDdEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxTQUFTLGVBQWU7QUFDeEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQSxNQUFNO0FBQ047QUFDQSxNQUFNLGlCQUFpQjtBQUN2QjtBQUNBO0FBQ0EsUUFBUTtBQUNSO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7Ozs7Ozs7Ozs7O0FDekVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdDQUFnQyxPQUFPO0FBQ3ZDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdDQUFnQyxPQUFPO0FBQ3ZDO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7QUNsQ0EsZUFBZSxtQkFBTyxDQUFDLCtEQUFjO0FBQ3JDLGtCQUFrQixtQkFBTyxDQUFDLHFFQUFpQjtBQUMzQyxlQUFlLG1CQUFPLENBQUMsK0RBQWM7QUFDckMsYUFBYSxtQkFBTyxDQUFDLDJEQUFZOztBQUVqQyxzQkFBc0I7QUFDdEIsZ0JBQWdCO0FBQ2hCLGNBQWM7QUFDZCxjQUFjO0FBQ2QsaUJBQWlCO0FBQ2pCLGNBQWM7QUFDZCxnQkFBZ0I7QUFDaEIsZ0JBQWdCO0FBQ2hCO0FBQ0Esc0JBQXNCO0FBQ3RCO0FBQ0E7Ozs7Ozs7Ozs7O0FDaEJBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQSxXQUFXLFFBQVE7QUFDbkIsV0FBVyxNQUFNO0FBQ2pCLFlBQVksZ0JBQWdCO0FBQzVCO0FBQ0E7QUFDQSxzQ0FBc0M7QUFDdEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLFFBQVE7QUFDbkIsV0FBVyxRQUFRO0FBQ25CLFdBQVcsTUFBTTtBQUNqQixZQUFZLFNBQVM7QUFDckI7QUFDQTtBQUNBO0FBQ0EseUJBQXlCLElBQUksR0FBRyxPQUFPLFVBQVUsUUFBUTtBQUN6RDtBQUNBO0FBQ0E7QUFDQSxXQUFXLFFBQVE7QUFDbkIsWUFBWSxNQUFNO0FBQ2xCO0FBQ0E7QUFDQSx5QkFBeUIsSUFBSSxJQUFJLFFBQVEsVUFBVSwwQkFBMEI7QUFDN0U7QUFDQTtBQUNBO0FBQ0EsWUFBWSxNQUFNO0FBQ2xCO0FBQ0E7QUFDQSwyQ0FBMkM7QUFDM0Msb0JBQW9CLGlCQUFpQjtBQUNyQztBQUNBO0FBQ0EsMkJBQTJCLFFBQVEsVUFBVSwwQkFBMEI7QUFDdkU7O0FBRUE7Ozs7Ozs7Ozs7O0FDdERBLFlBQVksbUJBQU8sQ0FBQyw0Q0FBSztBQUN6QjtBQUNBO0FBQ0EsV0FBVyxRQUFRO0FBQ25CLFdBQVcsT0FBTztBQUNsQixXQUFXLE9BQU87QUFDbEIsWUFBWSxRQUFRO0FBQ3BCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0Esd0JBQXdCLG9CQUFvQjtBQUM1QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7O0FBRUE7Ozs7Ozs7Ozs7O0FDMURBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsZUFBZSxHQUFHO0FBQ2xCLGVBQWUsZUFBZTtBQUM5QixnQkFBZ0IsUUFBUTtBQUN4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxlQUFlLEdBQUc7QUFDbEIsZ0JBQWdCLGVBQWU7QUFDL0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsZUFBZSxHQUFHO0FBQ2xCLGdCQUFnQjtBQUNoQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQjtBQUNsQjtBQUNBO0FBQ0EsY0FBYztBQUNkO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxlQUFlLEdBQUc7QUFDbEIsZ0JBQWdCLFFBQVE7QUFDeEI7QUFDQTtBQUNBO0FBQ0EscUJBQXFCO0FBQ3JCOztBQUVBO0FBQ0E7QUFDQSxnQkFBZ0IsUUFBUTtBQUN4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7Ozs7Ozs7Ozs7QUMvRUE7QUFDQTtBQUNBLFdBQVcsUUFBUTtBQUNuQixZQUFZLFNBQVM7QUFDckI7QUFDQTtBQUNBLDBCQUEwQixFQUFFO0FBQzVCOztBQUVBO0FBQ0E7QUFDQSxXQUFXLFFBQVE7QUFDbkIsWUFBWSxTQUFTO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxXQUFXLFFBQVE7QUFDbkIsWUFBWSxnQkFBZ0I7QUFDNUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWEsc0JBQXNCO0FBQ25DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFZO0FBQ1o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7O0FDbkVBOzs7Ozs7Ozs7OztBQ0FBLHFDQUFxQzs7Ozs7Ozs7OztBQ0FyQyxxQ0FBcUM7Ozs7Ozs7Ozs7QUNBckMscUNBQXFDOzs7Ozs7Ozs7O0FDQXJDLHFDQUFxQzs7Ozs7Ozs7OztBQ0FyQyxxQ0FBcUM7Ozs7Ozs7Ozs7QUNBckM7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxnQkFBZ0IseUZBQThCO0FBQzlDLDZCQUE2QixtR0FBd0M7QUFDckUsUUFBUSxtQkFBTyxDQUFDLDhDQUFROztBQUV4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLFFBQVE7QUFDbkIsV0FBVyxRQUFRO0FBQ25CLFdBQVcsUUFBUTtBQUNuQixZQUFZO0FBQ1o7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsV0FBVyxRQUFRO0FBQ25CLFdBQVcsUUFBUTtBQUNuQixXQUFXLFFBQVE7QUFDbkIsWUFBWTtBQUNaO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsUUFBUTtBQUNuQixXQUFXLFFBQVE7QUFDbkIsV0FBVyxRQUFRO0FBQ25CLFlBQVk7QUFDWjtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLFFBQVE7QUFDbkIsV0FBVyxRQUFRO0FBQ25CLFdBQVcsUUFBUTtBQUNuQixZQUFZO0FBQ1o7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsV0FBVyxRQUFRO0FBQ25CO0FBQ0E7QUFDQSxzQ0FBc0MsMkJBQTJCO0FBQ2pFOztBQUVBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsUUFBUTtBQUNuQixXQUFXLFFBQVE7QUFDbkIsV0FBVyxRQUFRO0FBQ25CLFdBQVcsUUFBUTtBQUNuQixZQUFZO0FBQ1o7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0QkFBNEI7QUFDNUIsNENBQTRDO0FBQzVDLHNDQUFzQztBQUN0QywwQ0FBMEM7QUFDMUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLFFBQVE7QUFDbkIsWUFBWSxRQUFRO0FBQ3BCO0FBQ0E7QUFDQSwwQ0FBMEM7QUFDMUM7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsV0FBVyxRQUFRO0FBQ25CLFlBQVksUUFBUTtBQUNwQjtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLFFBQVE7QUFDbkIsWUFBWTtBQUNaO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLFFBQVE7QUFDbkIsWUFBWTtBQUNaO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLFFBQVE7QUFDbkIsWUFBWTtBQUNaO0FBQ0E7QUFDQTtBQUNBLG9DQUFvQyxTQUFTO0FBQzdDO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsUUFBUTtBQUNuQixZQUFZO0FBQ1o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLFFBQVE7QUFDbkIsWUFBWTtBQUNaO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLE9BQU87QUFDbEIsV0FBVyxVQUFVO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQVU7QUFDVjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsUUFBUTtBQUNSO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLFFBQVE7QUFDbkIsWUFBWTtBQUNaO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsUUFBUTtBQUNuQixZQUFZO0FBQ1o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBOztBQUVBLGlCQUFpQjtBQUNqQiwyQkFBMkI7QUFDM0IsYUFBYTtBQUNiLG1CQUFtQjtBQUNuQixpQkFBaUI7QUFDakIsdUJBQXVCO0FBQ3ZCLHFCQUFxQjtBQUNyQixrQkFBa0I7QUFDbEIsbUJBQW1CO0FBQ25CLHFCQUFxQjtBQUNyQiwwQkFBMEI7QUFDMUIsaUNBQWlDO0FBQ2pDLGtDQUFrQztBQUNsQyx5QkFBeUI7QUFDekIsdUJBQXVCO0FBQ3ZCLDJCQUEyQjtBQUMzQixvQkFBb0I7QUFDcEIsdUJBQXVCO0FBQ3ZCLHNCQUFzQjtBQUN0QixpQkFBaUI7QUFDakIsOEJBQThCOzs7Ozs7Ozs7OztBQzFjOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxjQUFjLG1CQUFPLENBQUMsb0RBQVc7QUFDakMsYUFBYSxtQkFBTyxDQUFDLGtEQUFVO0FBQy9CLGdCQUFnQixtQkFBTyxDQUFDLDRDQUFPOztBQUUvQjtBQUNBO0FBQ0E7QUFDQSxXQUFXLFFBQVE7QUFDbkIsV0FBVyxRQUFRLFVBQVU7QUFDN0IsWUFBWTtBQUNaO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxpQkFBaUI7QUFDakIsaUJBQWlCO0FBQ2pCO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7QUMzQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxRQUFRLG1CQUFPLENBQUMsOENBQVE7O0FBRXhCO0FBQ0E7QUFDQTtBQUNBLFdBQVcsUUFBUTtBQUNuQixZQUFZO0FBQ1o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLFFBQVE7QUFDbkIsWUFBWTtBQUNaO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsUUFBUTtBQUNuQixXQUFXLFVBQVU7QUFDckIsV0FBVyxVQUFVO0FBQ3JCLFlBQVk7QUFDWjtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxxQ0FBcUMsa0JBQWtCO0FBQ3ZEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsUUFBUTtBQUNSO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsV0FBVyxRQUFRO0FBQ25CLFdBQVcsVUFBVTtBQUNyQixZQUFZO0FBQ1o7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0Esa0JBQWtCLFNBQVM7QUFDM0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxVQUFVO0FBQ1Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxVQUFVO0FBQ1Y7QUFDQTtBQUNBO0FBQ0EsUUFBUTtBQUNSO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxVQUFVO0FBQ1Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQSxTQUFTLGdCQUFnQjtBQUN6QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxTQUFTLE9BQU87QUFDaEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTs7QUFFQSxnQkFBZ0I7QUFDaEIsaUJBQWlCOzs7Ozs7Ozs7OztBQ3RQakI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0NBQWdDLE9BQU87QUFDdkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0NBQWdDLE9BQU87QUFDdkM7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIOzs7Ozs7Ozs7OztBQ2pDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLGdCQUFnQix5RkFBOEI7QUFDOUMsY0FBYyxtQkFBTyxDQUFDLG9EQUFXO0FBQ2pDLGFBQWEsbUJBQU8sQ0FBQyxrREFBVTtBQUMvQjtBQUNBO0FBQ0EsUUFBUSxtQkFBTyxDQUFDLDhDQUFROztBQUV4QjtBQUNBO0FBQ0E7QUFDQSxXQUFXLFFBQVE7QUFDbkIsWUFBWTtBQUNaO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsUUFBUTtBQUNuQixZQUFZO0FBQ1osUUFBUSxRQUFRO0FBQ2hCLFFBQVEsU0FBUztBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsUUFBUTtBQUNuQixZQUFZO0FBQ1o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLFFBQVE7QUFDbkI7QUFDQTtBQUNBO0FBQ0EsY0FBYyxpQ0FBaUM7QUFDL0M7QUFDQTtBQUNBLDJDQUEyQzs7QUFFM0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsV0FBVyxRQUFRO0FBQ25CLFlBQVk7QUFDWjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGNBQWM7QUFDZDtBQUNBO0FBQ0EsWUFBWTtBQUNaO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTOztBQUVUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQVE7QUFDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTs7Ozs7Ozs7Ozs7QUNsTkE7QUFDQTtBQUNBOzs7Ozs7Ozs7OztBQ0ZBLE9BQU8sUUFBUSxFQUFFLG1CQUFPLENBQUMsc0RBQVU7O0FBRW5DLGNBQWMsbUJBQU8sQ0FBQyxnRUFBdUI7QUFDN0MsZUFBZSxtQkFBTyxDQUFDLGtFQUF3QjtBQUMvQyxlQUFlLG1CQUFPLENBQUMsa0VBQXdCO0FBQy9DLGFBQWEsbUJBQU8sQ0FBQyw0REFBcUI7QUFDMUMsYUFBYSxtQkFBTyxDQUFDLDhEQUFzQjs7QUFFM0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLGlCQUFpQjtBQUNqQixlQUFlO0FBQ2YsbUJBQW1CO0FBQ25CLFdBQVc7Ozs7Ozs7VUN0RFg7VUFDQTs7VUFFQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTs7VUFFQTtVQUNBOztVQUVBO1VBQ0E7VUFDQTs7Ozs7V0N0QkE7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBLGlDQUFpQyxXQUFXO1dBQzVDO1dBQ0E7Ozs7O1dDUEE7V0FDQTtXQUNBO1dBQ0E7V0FDQSx5Q0FBeUMsd0NBQXdDO1dBQ2pGO1dBQ0E7V0FDQTs7Ozs7V0NQQTs7Ozs7V0NBQTtXQUNBO1dBQ0E7V0FDQSx1REFBdUQsaUJBQWlCO1dBQ3hFO1dBQ0EsZ0RBQWdELGFBQWE7V0FDN0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDTjBCO0FBQ3NDO0FBQ3RCO0FBQ0o7QUFDVDtBQUNIOztBQUUxQjtBQUNBLCtEQUFzQjtBQUN0QjtBQUNBLElBQUksK0RBQXNCO0FBQzFCO0FBQ0E7QUFDQTtBQUNBLHFFQUE4QjtBQUM5Qix5RUFBeUU7QUFDekU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtCQUErQjtBQUMvQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxDQUFDO0FBQ0Qsc0RBQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQkFBcUIsZ0RBQVU7QUFDL0I7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCLDJDQUFHO0FBQ3BCLHVCQUF1QjtBQUN2QjtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2Isa0JBQWtCLGdEQUFVO0FBQzVCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQjtBQUNsQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQVkscURBQVM7QUFDckIsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQjtBQUNyQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkJBQTJCLElBQUksS0FBSyxFQUFFLE1BQU0sSUFBSTtBQUNoRDtBQUNBO0FBQ0E7QUFDQTtBQUNBLDRCQUE0QixJQUFJO0FBQ2hDLDJCQUEyQixJQUFJO0FBQy9CO0FBQ0EscUNBQXFDLHFCQUFxQjs7QUFFMUQsb0NBQW9DLE1BQU0sMkRBQTJELEtBQUssMkJBQTJCLEtBQUs7QUFDMUksK0NBQStDO0FBQy9DO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsY0FBYztBQUNkO0FBQ0E7QUFDQSxTQUFTO0FBQ1QsWUFBWSxJQUFJO0FBQ2hCO0FBQ0E7QUFDQTtBQUNBLDhCQUE4QjtBQUM5QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjs7QUFFakIsZ0JBQWdCLGdEQUFVO0FBQzFCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0JBQWtCO0FBQ2xCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0EsbUJBQW1CLGtCQUFrQjtBQUNyQztBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQVksbURBQU87QUFDbkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDhCQUE4QixnREFBUztBQUN2Qyw4QkFBOEIsaURBQVU7QUFDeEM7QUFDQSxZQUFZLGdEQUFVO0FBQ3RCO0FBQ0E7QUFDQTtBQUNBLHVCQUF1QixxQkFBcUI7QUFDNUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBLFlBQVksZ0RBQVU7QUFDdEI7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUJBQXlCLGdEQUFVO0FBQ25DO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUZBQWlGLFlBQVk7QUFDN0Y7QUFDQTtBQUNBLHFCQUFxQjtBQUNyQjtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4QkFBOEIsZ0JBQWdCO0FBQzlDO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQjtBQUNwQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLFFBQVEsc0RBQU87QUFDZjtBQUNBO0FBQ0EsWUFBWSxnREFBVTtBQUN0QixTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRDtBQUNBO0FBQ0EsQ0FBQyxHQUFHLGVBQWU7O0FBRW5CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQVU7QUFDVjtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUMsR0FBRyxlQUFlOztBQUVuQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVCxNQUFNO0FBQ047QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBOztBQUVBO0FBQ0Esa0NBQWtDLGtEQUFROztBQUUxQyxzREFBTztBQUNQO0FBQ0E7QUFDQSxDQUFDOztBQUVEO0FBQ0E7QUFDQSxvQ0FBb0M7QUFDcEM7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CLGtCQUFrQjtBQUN0QztBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBLFdBQVcsZ0RBQVU7QUFDckI7QUFDQTtBQUNBLFFBQVEsZ0RBQVU7QUFDbEIsTUFBTTtBQUNOO0FBQ0E7QUFDQSxrRUFBa0UsR0FBRztBQUNyRTtBQUNBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vb25lTmF2Ly4vbm9kZV9tb2R1bGVzL2F4aW9zL2luZGV4LmpzIiwid2VicGFjazovL29uZU5hdi8uL25vZGVfbW9kdWxlcy9heGlvcy9saWIvYWRhcHRlcnMveGhyLmpzIiwid2VicGFjazovL29uZU5hdi8uL25vZGVfbW9kdWxlcy9heGlvcy9saWIvYXhpb3MuanMiLCJ3ZWJwYWNrOi8vb25lTmF2Ly4vbm9kZV9tb2R1bGVzL2F4aW9zL2xpYi9jYW5jZWwvQ2FuY2VsLmpzIiwid2VicGFjazovL29uZU5hdi8uL25vZGVfbW9kdWxlcy9heGlvcy9saWIvY2FuY2VsL0NhbmNlbFRva2VuLmpzIiwid2VicGFjazovL29uZU5hdi8uL25vZGVfbW9kdWxlcy9heGlvcy9saWIvY2FuY2VsL2lzQ2FuY2VsLmpzIiwid2VicGFjazovL29uZU5hdi8uL25vZGVfbW9kdWxlcy9heGlvcy9saWIvY29yZS9BeGlvcy5qcyIsIndlYnBhY2s6Ly9vbmVOYXYvLi9ub2RlX21vZHVsZXMvYXhpb3MvbGliL2NvcmUvSW50ZXJjZXB0b3JNYW5hZ2VyLmpzIiwid2VicGFjazovL29uZU5hdi8uL25vZGVfbW9kdWxlcy9heGlvcy9saWIvY29yZS9idWlsZEZ1bGxQYXRoLmpzIiwid2VicGFjazovL29uZU5hdi8uL25vZGVfbW9kdWxlcy9heGlvcy9saWIvY29yZS9jcmVhdGVFcnJvci5qcyIsIndlYnBhY2s6Ly9vbmVOYXYvLi9ub2RlX21vZHVsZXMvYXhpb3MvbGliL2NvcmUvZGlzcGF0Y2hSZXF1ZXN0LmpzIiwid2VicGFjazovL29uZU5hdi8uL25vZGVfbW9kdWxlcy9heGlvcy9saWIvY29yZS9lbmhhbmNlRXJyb3IuanMiLCJ3ZWJwYWNrOi8vb25lTmF2Ly4vbm9kZV9tb2R1bGVzL2F4aW9zL2xpYi9jb3JlL21lcmdlQ29uZmlnLmpzIiwid2VicGFjazovL29uZU5hdi8uL25vZGVfbW9kdWxlcy9heGlvcy9saWIvY29yZS9zZXR0bGUuanMiLCJ3ZWJwYWNrOi8vb25lTmF2Ly4vbm9kZV9tb2R1bGVzL2F4aW9zL2xpYi9jb3JlL3RyYW5zZm9ybURhdGEuanMiLCJ3ZWJwYWNrOi8vb25lTmF2Ly4vbm9kZV9tb2R1bGVzL2F4aW9zL2xpYi9kZWZhdWx0cy9pbmRleC5qcyIsIndlYnBhY2s6Ly9vbmVOYXYvLi9ub2RlX21vZHVsZXMvYXhpb3MvbGliL2RlZmF1bHRzL3RyYW5zaXRpb25hbC5qcyIsIndlYnBhY2s6Ly9vbmVOYXYvLi9ub2RlX21vZHVsZXMvYXhpb3MvbGliL2Vudi9kYXRhLmpzIiwid2VicGFjazovL29uZU5hdi8uL25vZGVfbW9kdWxlcy9heGlvcy9saWIvaGVscGVycy9iaW5kLmpzIiwid2VicGFjazovL29uZU5hdi8uL25vZGVfbW9kdWxlcy9heGlvcy9saWIvaGVscGVycy9idWlsZFVSTC5qcyIsIndlYnBhY2s6Ly9vbmVOYXYvLi9ub2RlX21vZHVsZXMvYXhpb3MvbGliL2hlbHBlcnMvY29tYmluZVVSTHMuanMiLCJ3ZWJwYWNrOi8vb25lTmF2Ly4vbm9kZV9tb2R1bGVzL2F4aW9zL2xpYi9oZWxwZXJzL2Nvb2tpZXMuanMiLCJ3ZWJwYWNrOi8vb25lTmF2Ly4vbm9kZV9tb2R1bGVzL2F4aW9zL2xpYi9oZWxwZXJzL2lzQWJzb2x1dGVVUkwuanMiLCJ3ZWJwYWNrOi8vb25lTmF2Ly4vbm9kZV9tb2R1bGVzL2F4aW9zL2xpYi9oZWxwZXJzL2lzQXhpb3NFcnJvci5qcyIsIndlYnBhY2s6Ly9vbmVOYXYvLi9ub2RlX21vZHVsZXMvYXhpb3MvbGliL2hlbHBlcnMvaXNVUkxTYW1lT3JpZ2luLmpzIiwid2VicGFjazovL29uZU5hdi8uL25vZGVfbW9kdWxlcy9heGlvcy9saWIvaGVscGVycy9ub3JtYWxpemVIZWFkZXJOYW1lLmpzIiwid2VicGFjazovL29uZU5hdi8uL25vZGVfbW9kdWxlcy9heGlvcy9saWIvaGVscGVycy9wYXJzZUhlYWRlcnMuanMiLCJ3ZWJwYWNrOi8vb25lTmF2Ly4vbm9kZV9tb2R1bGVzL2F4aW9zL2xpYi9oZWxwZXJzL3NwcmVhZC5qcyIsIndlYnBhY2s6Ly9vbmVOYXYvLi9ub2RlX21vZHVsZXMvYXhpb3MvbGliL2hlbHBlcnMvdmFsaWRhdG9yLmpzIiwid2VicGFjazovL29uZU5hdi8uL25vZGVfbW9kdWxlcy9heGlvcy9saWIvdXRpbHMuanMiLCJ3ZWJwYWNrOi8vb25lTmF2Ly4vc3JjL2pzL21lbnUuanN4Iiwid2VicGFjazovL29uZU5hdi8uL25vZGVfbW9kdWxlcy9jc3NmaWx0ZXIvbGliL2Nzcy5qcyIsIndlYnBhY2s6Ly9vbmVOYXYvLi9ub2RlX21vZHVsZXMvY3NzZmlsdGVyL2xpYi9kZWZhdWx0LmpzIiwid2VicGFjazovL29uZU5hdi8uL25vZGVfbW9kdWxlcy9jc3NmaWx0ZXIvbGliL2luZGV4LmpzIiwid2VicGFjazovL29uZU5hdi8uL25vZGVfbW9kdWxlcy9jc3NmaWx0ZXIvbGliL3BhcnNlci5qcyIsIndlYnBhY2s6Ly9vbmVOYXYvLi9ub2RlX21vZHVsZXMvY3NzZmlsdGVyL2xpYi91dGlsLmpzIiwid2VicGFjazovL29uZU5hdi8uL25vZGVfbW9kdWxlcy9qc2ItdXRpbC9zcmMvaW5kZXguanMiLCJ3ZWJwYWNrOi8vb25lTmF2Ly4vbm9kZV9tb2R1bGVzL2pzYi11dGlsL3NyYy9saWIvY29va2llLmpzIiwid2VicGFjazovL29uZU5hdi8uL25vZGVfbW9kdWxlcy9qc2ItdXRpbC9zcmMvbGliL2Zvcm1hdFhzcy5qcyIsIndlYnBhY2s6Ly9vbmVOYXYvLi9ub2RlX21vZHVsZXMvanNiLXV0aWwvc3JjL2xpYi9tZW1vcnkuanMiLCJ3ZWJwYWNrOi8vb25lTmF2Ly4vbm9kZV9tb2R1bGVzL2pzYi11dGlsL3NyYy9saWIvdXRpbC5qcyIsIndlYnBhY2s6Ly9vbmVOYXYvLi9zcmMvY3NzL2luZGV4LnNjc3M/YjliNCIsIndlYnBhY2s6Ly9vbmVOYXYvLi9zcmMvYXNzZXRzLzM2MC5zdmciLCJ3ZWJwYWNrOi8vb25lTmF2Ly4vc3JjL2Fzc2V0cy9iYWlkdS5zdmciLCJ3ZWJwYWNrOi8vb25lTmF2Ly4vc3JjL2Fzc2V0cy9iaW5nLnN2ZyIsIndlYnBhY2s6Ly9vbmVOYXYvLi9zcmMvYXNzZXRzL2dvb2dsZS5zdmciLCJ3ZWJwYWNrOi8vb25lTmF2Ly4vc3JjL2Fzc2V0cy9zb3Vnb3Uuc3ZnIiwid2VicGFjazovL29uZU5hdi8uL25vZGVfbW9kdWxlcy94c3MvbGliL2RlZmF1bHQuanMiLCJ3ZWJwYWNrOi8vb25lTmF2Ly4vbm9kZV9tb2R1bGVzL3hzcy9saWIvaW5kZXguanMiLCJ3ZWJwYWNrOi8vb25lTmF2Ly4vbm9kZV9tb2R1bGVzL3hzcy9saWIvcGFyc2VyLmpzIiwid2VicGFjazovL29uZU5hdi8uL25vZGVfbW9kdWxlcy94c3MvbGliL3V0aWwuanMiLCJ3ZWJwYWNrOi8vb25lTmF2Ly4vbm9kZV9tb2R1bGVzL3hzcy9saWIveHNzLmpzIiwid2VicGFjazovL29uZU5hdi8uL3NyYy9qcy9idXMuanMiLCJ3ZWJwYWNrOi8vb25lTmF2Ly4vc3JjL2pzL3NvdXN1by5qcyIsIndlYnBhY2s6Ly9vbmVOYXYvd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vb25lTmF2L3dlYnBhY2svcnVudGltZS9jb21wYXQgZ2V0IGRlZmF1bHQgZXhwb3J0Iiwid2VicGFjazovL29uZU5hdi93ZWJwYWNrL3J1bnRpbWUvZGVmaW5lIHByb3BlcnR5IGdldHRlcnMiLCJ3ZWJwYWNrOi8vb25lTmF2L3dlYnBhY2svcnVudGltZS9oYXNPd25Qcm9wZXJ0eSBzaG9ydGhhbmQiLCJ3ZWJwYWNrOi8vb25lTmF2L3dlYnBhY2svcnVudGltZS9tYWtlIG5hbWVzcGFjZSBvYmplY3QiLCJ3ZWJwYWNrOi8vb25lTmF2Ly4vc3JjL2luZGV4LmpzIl0sInNvdXJjZXNDb250ZW50IjpbIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZSgnLi9saWIvYXhpb3MnKTsiLCIndXNlIHN0cmljdCc7XG5cbnZhciB1dGlscyA9IHJlcXVpcmUoJy4vLi4vdXRpbHMnKTtcbnZhciBzZXR0bGUgPSByZXF1aXJlKCcuLy4uL2NvcmUvc2V0dGxlJyk7XG52YXIgY29va2llcyA9IHJlcXVpcmUoJy4vLi4vaGVscGVycy9jb29raWVzJyk7XG52YXIgYnVpbGRVUkwgPSByZXF1aXJlKCcuLy4uL2hlbHBlcnMvYnVpbGRVUkwnKTtcbnZhciBidWlsZEZ1bGxQYXRoID0gcmVxdWlyZSgnLi4vY29yZS9idWlsZEZ1bGxQYXRoJyk7XG52YXIgcGFyc2VIZWFkZXJzID0gcmVxdWlyZSgnLi8uLi9oZWxwZXJzL3BhcnNlSGVhZGVycycpO1xudmFyIGlzVVJMU2FtZU9yaWdpbiA9IHJlcXVpcmUoJy4vLi4vaGVscGVycy9pc1VSTFNhbWVPcmlnaW4nKTtcbnZhciBjcmVhdGVFcnJvciA9IHJlcXVpcmUoJy4uL2NvcmUvY3JlYXRlRXJyb3InKTtcbnZhciB0cmFuc2l0aW9uYWxEZWZhdWx0cyA9IHJlcXVpcmUoJy4uL2RlZmF1bHRzL3RyYW5zaXRpb25hbCcpO1xudmFyIENhbmNlbCA9IHJlcXVpcmUoJy4uL2NhbmNlbC9DYW5jZWwnKTtcblxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiB4aHJBZGFwdGVyKGNvbmZpZykge1xuICByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gZGlzcGF0Y2hYaHJSZXF1ZXN0KHJlc29sdmUsIHJlamVjdCkge1xuICAgIHZhciByZXF1ZXN0RGF0YSA9IGNvbmZpZy5kYXRhO1xuICAgIHZhciByZXF1ZXN0SGVhZGVycyA9IGNvbmZpZy5oZWFkZXJzO1xuICAgIHZhciByZXNwb25zZVR5cGUgPSBjb25maWcucmVzcG9uc2VUeXBlO1xuICAgIHZhciBvbkNhbmNlbGVkO1xuICAgIGZ1bmN0aW9uIGRvbmUoKSB7XG4gICAgICBpZiAoY29uZmlnLmNhbmNlbFRva2VuKSB7XG4gICAgICAgIGNvbmZpZy5jYW5jZWxUb2tlbi51bnN1YnNjcmliZShvbkNhbmNlbGVkKTtcbiAgICAgIH1cblxuICAgICAgaWYgKGNvbmZpZy5zaWduYWwpIHtcbiAgICAgICAgY29uZmlnLnNpZ25hbC5yZW1vdmVFdmVudExpc3RlbmVyKCdhYm9ydCcsIG9uQ2FuY2VsZWQpO1xuICAgICAgfVxuICAgIH1cblxuICAgIGlmICh1dGlscy5pc0Zvcm1EYXRhKHJlcXVlc3REYXRhKSkge1xuICAgICAgZGVsZXRlIHJlcXVlc3RIZWFkZXJzWydDb250ZW50LVR5cGUnXTsgLy8gTGV0IHRoZSBicm93c2VyIHNldCBpdFxuICAgIH1cblxuICAgIHZhciByZXF1ZXN0ID0gbmV3IFhNTEh0dHBSZXF1ZXN0KCk7XG5cbiAgICAvLyBIVFRQIGJhc2ljIGF1dGhlbnRpY2F0aW9uXG4gICAgaWYgKGNvbmZpZy5hdXRoKSB7XG4gICAgICB2YXIgdXNlcm5hbWUgPSBjb25maWcuYXV0aC51c2VybmFtZSB8fCAnJztcbiAgICAgIHZhciBwYXNzd29yZCA9IGNvbmZpZy5hdXRoLnBhc3N3b3JkID8gdW5lc2NhcGUoZW5jb2RlVVJJQ29tcG9uZW50KGNvbmZpZy5hdXRoLnBhc3N3b3JkKSkgOiAnJztcbiAgICAgIHJlcXVlc3RIZWFkZXJzLkF1dGhvcml6YXRpb24gPSAnQmFzaWMgJyArIGJ0b2EodXNlcm5hbWUgKyAnOicgKyBwYXNzd29yZCk7XG4gICAgfVxuXG4gICAgdmFyIGZ1bGxQYXRoID0gYnVpbGRGdWxsUGF0aChjb25maWcuYmFzZVVSTCwgY29uZmlnLnVybCk7XG4gICAgcmVxdWVzdC5vcGVuKGNvbmZpZy5tZXRob2QudG9VcHBlckNhc2UoKSwgYnVpbGRVUkwoZnVsbFBhdGgsIGNvbmZpZy5wYXJhbXMsIGNvbmZpZy5wYXJhbXNTZXJpYWxpemVyKSwgdHJ1ZSk7XG5cbiAgICAvLyBTZXQgdGhlIHJlcXVlc3QgdGltZW91dCBpbiBNU1xuICAgIHJlcXVlc3QudGltZW91dCA9IGNvbmZpZy50aW1lb3V0O1xuXG4gICAgZnVuY3Rpb24gb25sb2FkZW5kKCkge1xuICAgICAgaWYgKCFyZXF1ZXN0KSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIC8vIFByZXBhcmUgdGhlIHJlc3BvbnNlXG4gICAgICB2YXIgcmVzcG9uc2VIZWFkZXJzID0gJ2dldEFsbFJlc3BvbnNlSGVhZGVycycgaW4gcmVxdWVzdCA/IHBhcnNlSGVhZGVycyhyZXF1ZXN0LmdldEFsbFJlc3BvbnNlSGVhZGVycygpKSA6IG51bGw7XG4gICAgICB2YXIgcmVzcG9uc2VEYXRhID0gIXJlc3BvbnNlVHlwZSB8fCByZXNwb25zZVR5cGUgPT09ICd0ZXh0JyB8fCAgcmVzcG9uc2VUeXBlID09PSAnanNvbicgP1xuICAgICAgICByZXF1ZXN0LnJlc3BvbnNlVGV4dCA6IHJlcXVlc3QucmVzcG9uc2U7XG4gICAgICB2YXIgcmVzcG9uc2UgPSB7XG4gICAgICAgIGRhdGE6IHJlc3BvbnNlRGF0YSxcbiAgICAgICAgc3RhdHVzOiByZXF1ZXN0LnN0YXR1cyxcbiAgICAgICAgc3RhdHVzVGV4dDogcmVxdWVzdC5zdGF0dXNUZXh0LFxuICAgICAgICBoZWFkZXJzOiByZXNwb25zZUhlYWRlcnMsXG4gICAgICAgIGNvbmZpZzogY29uZmlnLFxuICAgICAgICByZXF1ZXN0OiByZXF1ZXN0XG4gICAgICB9O1xuXG4gICAgICBzZXR0bGUoZnVuY3Rpb24gX3Jlc29sdmUodmFsdWUpIHtcbiAgICAgICAgcmVzb2x2ZSh2YWx1ZSk7XG4gICAgICAgIGRvbmUoKTtcbiAgICAgIH0sIGZ1bmN0aW9uIF9yZWplY3QoZXJyKSB7XG4gICAgICAgIHJlamVjdChlcnIpO1xuICAgICAgICBkb25lKCk7XG4gICAgICB9LCByZXNwb25zZSk7XG5cbiAgICAgIC8vIENsZWFuIHVwIHJlcXVlc3RcbiAgICAgIHJlcXVlc3QgPSBudWxsO1xuICAgIH1cblxuICAgIGlmICgnb25sb2FkZW5kJyBpbiByZXF1ZXN0KSB7XG4gICAgICAvLyBVc2Ugb25sb2FkZW5kIGlmIGF2YWlsYWJsZVxuICAgICAgcmVxdWVzdC5vbmxvYWRlbmQgPSBvbmxvYWRlbmQ7XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIExpc3RlbiBmb3IgcmVhZHkgc3RhdGUgdG8gZW11bGF0ZSBvbmxvYWRlbmRcbiAgICAgIHJlcXVlc3Qub25yZWFkeXN0YXRlY2hhbmdlID0gZnVuY3Rpb24gaGFuZGxlTG9hZCgpIHtcbiAgICAgICAgaWYgKCFyZXF1ZXN0IHx8IHJlcXVlc3QucmVhZHlTdGF0ZSAhPT0gNCkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIFRoZSByZXF1ZXN0IGVycm9yZWQgb3V0IGFuZCB3ZSBkaWRuJ3QgZ2V0IGEgcmVzcG9uc2UsIHRoaXMgd2lsbCBiZVxuICAgICAgICAvLyBoYW5kbGVkIGJ5IG9uZXJyb3IgaW5zdGVhZFxuICAgICAgICAvLyBXaXRoIG9uZSBleGNlcHRpb246IHJlcXVlc3QgdGhhdCB1c2luZyBmaWxlOiBwcm90b2NvbCwgbW9zdCBicm93c2Vyc1xuICAgICAgICAvLyB3aWxsIHJldHVybiBzdGF0dXMgYXMgMCBldmVuIHRob3VnaCBpdCdzIGEgc3VjY2Vzc2Z1bCByZXF1ZXN0XG4gICAgICAgIGlmIChyZXF1ZXN0LnN0YXR1cyA9PT0gMCAmJiAhKHJlcXVlc3QucmVzcG9uc2VVUkwgJiYgcmVxdWVzdC5yZXNwb25zZVVSTC5pbmRleE9mKCdmaWxlOicpID09PSAwKSkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICAvLyByZWFkeXN0YXRlIGhhbmRsZXIgaXMgY2FsbGluZyBiZWZvcmUgb25lcnJvciBvciBvbnRpbWVvdXQgaGFuZGxlcnMsXG4gICAgICAgIC8vIHNvIHdlIHNob3VsZCBjYWxsIG9ubG9hZGVuZCBvbiB0aGUgbmV4dCAndGljaydcbiAgICAgICAgc2V0VGltZW91dChvbmxvYWRlbmQpO1xuICAgICAgfTtcbiAgICB9XG5cbiAgICAvLyBIYW5kbGUgYnJvd3NlciByZXF1ZXN0IGNhbmNlbGxhdGlvbiAoYXMgb3Bwb3NlZCB0byBhIG1hbnVhbCBjYW5jZWxsYXRpb24pXG4gICAgcmVxdWVzdC5vbmFib3J0ID0gZnVuY3Rpb24gaGFuZGxlQWJvcnQoKSB7XG4gICAgICBpZiAoIXJlcXVlc3QpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICByZWplY3QoY3JlYXRlRXJyb3IoJ1JlcXVlc3QgYWJvcnRlZCcsIGNvbmZpZywgJ0VDT05OQUJPUlRFRCcsIHJlcXVlc3QpKTtcblxuICAgICAgLy8gQ2xlYW4gdXAgcmVxdWVzdFxuICAgICAgcmVxdWVzdCA9IG51bGw7XG4gICAgfTtcblxuICAgIC8vIEhhbmRsZSBsb3cgbGV2ZWwgbmV0d29yayBlcnJvcnNcbiAgICByZXF1ZXN0Lm9uZXJyb3IgPSBmdW5jdGlvbiBoYW5kbGVFcnJvcigpIHtcbiAgICAgIC8vIFJlYWwgZXJyb3JzIGFyZSBoaWRkZW4gZnJvbSB1cyBieSB0aGUgYnJvd3NlclxuICAgICAgLy8gb25lcnJvciBzaG91bGQgb25seSBmaXJlIGlmIGl0J3MgYSBuZXR3b3JrIGVycm9yXG4gICAgICByZWplY3QoY3JlYXRlRXJyb3IoJ05ldHdvcmsgRXJyb3InLCBjb25maWcsIG51bGwsIHJlcXVlc3QpKTtcblxuICAgICAgLy8gQ2xlYW4gdXAgcmVxdWVzdFxuICAgICAgcmVxdWVzdCA9IG51bGw7XG4gICAgfTtcblxuICAgIC8vIEhhbmRsZSB0aW1lb3V0XG4gICAgcmVxdWVzdC5vbnRpbWVvdXQgPSBmdW5jdGlvbiBoYW5kbGVUaW1lb3V0KCkge1xuICAgICAgdmFyIHRpbWVvdXRFcnJvck1lc3NhZ2UgPSBjb25maWcudGltZW91dCA/ICd0aW1lb3V0IG9mICcgKyBjb25maWcudGltZW91dCArICdtcyBleGNlZWRlZCcgOiAndGltZW91dCBleGNlZWRlZCc7XG4gICAgICB2YXIgdHJhbnNpdGlvbmFsID0gY29uZmlnLnRyYW5zaXRpb25hbCB8fCB0cmFuc2l0aW9uYWxEZWZhdWx0cztcbiAgICAgIGlmIChjb25maWcudGltZW91dEVycm9yTWVzc2FnZSkge1xuICAgICAgICB0aW1lb3V0RXJyb3JNZXNzYWdlID0gY29uZmlnLnRpbWVvdXRFcnJvck1lc3NhZ2U7XG4gICAgICB9XG4gICAgICByZWplY3QoY3JlYXRlRXJyb3IoXG4gICAgICAgIHRpbWVvdXRFcnJvck1lc3NhZ2UsXG4gICAgICAgIGNvbmZpZyxcbiAgICAgICAgdHJhbnNpdGlvbmFsLmNsYXJpZnlUaW1lb3V0RXJyb3IgPyAnRVRJTUVET1VUJyA6ICdFQ09OTkFCT1JURUQnLFxuICAgICAgICByZXF1ZXN0KSk7XG5cbiAgICAgIC8vIENsZWFuIHVwIHJlcXVlc3RcbiAgICAgIHJlcXVlc3QgPSBudWxsO1xuICAgIH07XG5cbiAgICAvLyBBZGQgeHNyZiBoZWFkZXJcbiAgICAvLyBUaGlzIGlzIG9ubHkgZG9uZSBpZiBydW5uaW5nIGluIGEgc3RhbmRhcmQgYnJvd3NlciBlbnZpcm9ubWVudC5cbiAgICAvLyBTcGVjaWZpY2FsbHkgbm90IGlmIHdlJ3JlIGluIGEgd2ViIHdvcmtlciwgb3IgcmVhY3QtbmF0aXZlLlxuICAgIGlmICh1dGlscy5pc1N0YW5kYXJkQnJvd3NlckVudigpKSB7XG4gICAgICAvLyBBZGQgeHNyZiBoZWFkZXJcbiAgICAgIHZhciB4c3JmVmFsdWUgPSAoY29uZmlnLndpdGhDcmVkZW50aWFscyB8fCBpc1VSTFNhbWVPcmlnaW4oZnVsbFBhdGgpKSAmJiBjb25maWcueHNyZkNvb2tpZU5hbWUgP1xuICAgICAgICBjb29raWVzLnJlYWQoY29uZmlnLnhzcmZDb29raWVOYW1lKSA6XG4gICAgICAgIHVuZGVmaW5lZDtcblxuICAgICAgaWYgKHhzcmZWYWx1ZSkge1xuICAgICAgICByZXF1ZXN0SGVhZGVyc1tjb25maWcueHNyZkhlYWRlck5hbWVdID0geHNyZlZhbHVlO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIEFkZCBoZWFkZXJzIHRvIHRoZSByZXF1ZXN0XG4gICAgaWYgKCdzZXRSZXF1ZXN0SGVhZGVyJyBpbiByZXF1ZXN0KSB7XG4gICAgICB1dGlscy5mb3JFYWNoKHJlcXVlc3RIZWFkZXJzLCBmdW5jdGlvbiBzZXRSZXF1ZXN0SGVhZGVyKHZhbCwga2V5KSB7XG4gICAgICAgIGlmICh0eXBlb2YgcmVxdWVzdERhdGEgPT09ICd1bmRlZmluZWQnICYmIGtleS50b0xvd2VyQ2FzZSgpID09PSAnY29udGVudC10eXBlJykge1xuICAgICAgICAgIC8vIFJlbW92ZSBDb250ZW50LVR5cGUgaWYgZGF0YSBpcyB1bmRlZmluZWRcbiAgICAgICAgICBkZWxldGUgcmVxdWVzdEhlYWRlcnNba2V5XTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAvLyBPdGhlcndpc2UgYWRkIGhlYWRlciB0byB0aGUgcmVxdWVzdFxuICAgICAgICAgIHJlcXVlc3Quc2V0UmVxdWVzdEhlYWRlcihrZXksIHZhbCk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH1cblxuICAgIC8vIEFkZCB3aXRoQ3JlZGVudGlhbHMgdG8gcmVxdWVzdCBpZiBuZWVkZWRcbiAgICBpZiAoIXV0aWxzLmlzVW5kZWZpbmVkKGNvbmZpZy53aXRoQ3JlZGVudGlhbHMpKSB7XG4gICAgICByZXF1ZXN0LndpdGhDcmVkZW50aWFscyA9ICEhY29uZmlnLndpdGhDcmVkZW50aWFscztcbiAgICB9XG5cbiAgICAvLyBBZGQgcmVzcG9uc2VUeXBlIHRvIHJlcXVlc3QgaWYgbmVlZGVkXG4gICAgaWYgKHJlc3BvbnNlVHlwZSAmJiByZXNwb25zZVR5cGUgIT09ICdqc29uJykge1xuICAgICAgcmVxdWVzdC5yZXNwb25zZVR5cGUgPSBjb25maWcucmVzcG9uc2VUeXBlO1xuICAgIH1cblxuICAgIC8vIEhhbmRsZSBwcm9ncmVzcyBpZiBuZWVkZWRcbiAgICBpZiAodHlwZW9mIGNvbmZpZy5vbkRvd25sb2FkUHJvZ3Jlc3MgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgIHJlcXVlc3QuYWRkRXZlbnRMaXN0ZW5lcigncHJvZ3Jlc3MnLCBjb25maWcub25Eb3dubG9hZFByb2dyZXNzKTtcbiAgICB9XG5cbiAgICAvLyBOb3QgYWxsIGJyb3dzZXJzIHN1cHBvcnQgdXBsb2FkIGV2ZW50c1xuICAgIGlmICh0eXBlb2YgY29uZmlnLm9uVXBsb2FkUHJvZ3Jlc3MgPT09ICdmdW5jdGlvbicgJiYgcmVxdWVzdC51cGxvYWQpIHtcbiAgICAgIHJlcXVlc3QudXBsb2FkLmFkZEV2ZW50TGlzdGVuZXIoJ3Byb2dyZXNzJywgY29uZmlnLm9uVXBsb2FkUHJvZ3Jlc3MpO1xuICAgIH1cblxuICAgIGlmIChjb25maWcuY2FuY2VsVG9rZW4gfHwgY29uZmlnLnNpZ25hbCkge1xuICAgICAgLy8gSGFuZGxlIGNhbmNlbGxhdGlvblxuICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGZ1bmMtbmFtZXNcbiAgICAgIG9uQ2FuY2VsZWQgPSBmdW5jdGlvbihjYW5jZWwpIHtcbiAgICAgICAgaWYgKCFyZXF1ZXN0KSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHJlamVjdCghY2FuY2VsIHx8IChjYW5jZWwgJiYgY2FuY2VsLnR5cGUpID8gbmV3IENhbmNlbCgnY2FuY2VsZWQnKSA6IGNhbmNlbCk7XG4gICAgICAgIHJlcXVlc3QuYWJvcnQoKTtcbiAgICAgICAgcmVxdWVzdCA9IG51bGw7XG4gICAgICB9O1xuXG4gICAgICBjb25maWcuY2FuY2VsVG9rZW4gJiYgY29uZmlnLmNhbmNlbFRva2VuLnN1YnNjcmliZShvbkNhbmNlbGVkKTtcbiAgICAgIGlmIChjb25maWcuc2lnbmFsKSB7XG4gICAgICAgIGNvbmZpZy5zaWduYWwuYWJvcnRlZCA/IG9uQ2FuY2VsZWQoKSA6IGNvbmZpZy5zaWduYWwuYWRkRXZlbnRMaXN0ZW5lcignYWJvcnQnLCBvbkNhbmNlbGVkKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAoIXJlcXVlc3REYXRhKSB7XG4gICAgICByZXF1ZXN0RGF0YSA9IG51bGw7XG4gICAgfVxuXG4gICAgLy8gU2VuZCB0aGUgcmVxdWVzdFxuICAgIHJlcXVlc3Quc2VuZChyZXF1ZXN0RGF0YSk7XG4gIH0pO1xufTtcbiIsIid1c2Ugc3RyaWN0JztcblxudmFyIHV0aWxzID0gcmVxdWlyZSgnLi91dGlscycpO1xudmFyIGJpbmQgPSByZXF1aXJlKCcuL2hlbHBlcnMvYmluZCcpO1xudmFyIEF4aW9zID0gcmVxdWlyZSgnLi9jb3JlL0F4aW9zJyk7XG52YXIgbWVyZ2VDb25maWcgPSByZXF1aXJlKCcuL2NvcmUvbWVyZ2VDb25maWcnKTtcbnZhciBkZWZhdWx0cyA9IHJlcXVpcmUoJy4vZGVmYXVsdHMnKTtcblxuLyoqXG4gKiBDcmVhdGUgYW4gaW5zdGFuY2Ugb2YgQXhpb3NcbiAqXG4gKiBAcGFyYW0ge09iamVjdH0gZGVmYXVsdENvbmZpZyBUaGUgZGVmYXVsdCBjb25maWcgZm9yIHRoZSBpbnN0YW5jZVxuICogQHJldHVybiB7QXhpb3N9IEEgbmV3IGluc3RhbmNlIG9mIEF4aW9zXG4gKi9cbmZ1bmN0aW9uIGNyZWF0ZUluc3RhbmNlKGRlZmF1bHRDb25maWcpIHtcbiAgdmFyIGNvbnRleHQgPSBuZXcgQXhpb3MoZGVmYXVsdENvbmZpZyk7XG4gIHZhciBpbnN0YW5jZSA9IGJpbmQoQXhpb3MucHJvdG90eXBlLnJlcXVlc3QsIGNvbnRleHQpO1xuXG4gIC8vIENvcHkgYXhpb3MucHJvdG90eXBlIHRvIGluc3RhbmNlXG4gIHV0aWxzLmV4dGVuZChpbnN0YW5jZSwgQXhpb3MucHJvdG90eXBlLCBjb250ZXh0KTtcblxuICAvLyBDb3B5IGNvbnRleHQgdG8gaW5zdGFuY2VcbiAgdXRpbHMuZXh0ZW5kKGluc3RhbmNlLCBjb250ZXh0KTtcblxuICAvLyBGYWN0b3J5IGZvciBjcmVhdGluZyBuZXcgaW5zdGFuY2VzXG4gIGluc3RhbmNlLmNyZWF0ZSA9IGZ1bmN0aW9uIGNyZWF0ZShpbnN0YW5jZUNvbmZpZykge1xuICAgIHJldHVybiBjcmVhdGVJbnN0YW5jZShtZXJnZUNvbmZpZyhkZWZhdWx0Q29uZmlnLCBpbnN0YW5jZUNvbmZpZykpO1xuICB9O1xuXG4gIHJldHVybiBpbnN0YW5jZTtcbn1cblxuLy8gQ3JlYXRlIHRoZSBkZWZhdWx0IGluc3RhbmNlIHRvIGJlIGV4cG9ydGVkXG52YXIgYXhpb3MgPSBjcmVhdGVJbnN0YW5jZShkZWZhdWx0cyk7XG5cbi8vIEV4cG9zZSBBeGlvcyBjbGFzcyB0byBhbGxvdyBjbGFzcyBpbmhlcml0YW5jZVxuYXhpb3MuQXhpb3MgPSBBeGlvcztcblxuLy8gRXhwb3NlIENhbmNlbCAmIENhbmNlbFRva2VuXG5heGlvcy5DYW5jZWwgPSByZXF1aXJlKCcuL2NhbmNlbC9DYW5jZWwnKTtcbmF4aW9zLkNhbmNlbFRva2VuID0gcmVxdWlyZSgnLi9jYW5jZWwvQ2FuY2VsVG9rZW4nKTtcbmF4aW9zLmlzQ2FuY2VsID0gcmVxdWlyZSgnLi9jYW5jZWwvaXNDYW5jZWwnKTtcbmF4aW9zLlZFUlNJT04gPSByZXF1aXJlKCcuL2Vudi9kYXRhJykudmVyc2lvbjtcblxuLy8gRXhwb3NlIGFsbC9zcHJlYWRcbmF4aW9zLmFsbCA9IGZ1bmN0aW9uIGFsbChwcm9taXNlcykge1xuICByZXR1cm4gUHJvbWlzZS5hbGwocHJvbWlzZXMpO1xufTtcbmF4aW9zLnNwcmVhZCA9IHJlcXVpcmUoJy4vaGVscGVycy9zcHJlYWQnKTtcblxuLy8gRXhwb3NlIGlzQXhpb3NFcnJvclxuYXhpb3MuaXNBeGlvc0Vycm9yID0gcmVxdWlyZSgnLi9oZWxwZXJzL2lzQXhpb3NFcnJvcicpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IGF4aW9zO1xuXG4vLyBBbGxvdyB1c2Ugb2YgZGVmYXVsdCBpbXBvcnQgc3ludGF4IGluIFR5cGVTY3JpcHRcbm1vZHVsZS5leHBvcnRzLmRlZmF1bHQgPSBheGlvcztcbiIsIid1c2Ugc3RyaWN0JztcblxuLyoqXG4gKiBBIGBDYW5jZWxgIGlzIGFuIG9iamVjdCB0aGF0IGlzIHRocm93biB3aGVuIGFuIG9wZXJhdGlvbiBpcyBjYW5jZWxlZC5cbiAqXG4gKiBAY2xhc3NcbiAqIEBwYXJhbSB7c3RyaW5nPX0gbWVzc2FnZSBUaGUgbWVzc2FnZS5cbiAqL1xuZnVuY3Rpb24gQ2FuY2VsKG1lc3NhZ2UpIHtcbiAgdGhpcy5tZXNzYWdlID0gbWVzc2FnZTtcbn1cblxuQ2FuY2VsLnByb3RvdHlwZS50b1N0cmluZyA9IGZ1bmN0aW9uIHRvU3RyaW5nKCkge1xuICByZXR1cm4gJ0NhbmNlbCcgKyAodGhpcy5tZXNzYWdlID8gJzogJyArIHRoaXMubWVzc2FnZSA6ICcnKTtcbn07XG5cbkNhbmNlbC5wcm90b3R5cGUuX19DQU5DRUxfXyA9IHRydWU7XG5cbm1vZHVsZS5leHBvcnRzID0gQ2FuY2VsO1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG52YXIgQ2FuY2VsID0gcmVxdWlyZSgnLi9DYW5jZWwnKTtcblxuLyoqXG4gKiBBIGBDYW5jZWxUb2tlbmAgaXMgYW4gb2JqZWN0IHRoYXQgY2FuIGJlIHVzZWQgdG8gcmVxdWVzdCBjYW5jZWxsYXRpb24gb2YgYW4gb3BlcmF0aW9uLlxuICpcbiAqIEBjbGFzc1xuICogQHBhcmFtIHtGdW5jdGlvbn0gZXhlY3V0b3IgVGhlIGV4ZWN1dG9yIGZ1bmN0aW9uLlxuICovXG5mdW5jdGlvbiBDYW5jZWxUb2tlbihleGVjdXRvcikge1xuICBpZiAodHlwZW9mIGV4ZWN1dG9yICE9PSAnZnVuY3Rpb24nKSB7XG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcignZXhlY3V0b3IgbXVzdCBiZSBhIGZ1bmN0aW9uLicpO1xuICB9XG5cbiAgdmFyIHJlc29sdmVQcm9taXNlO1xuXG4gIHRoaXMucHJvbWlzZSA9IG5ldyBQcm9taXNlKGZ1bmN0aW9uIHByb21pc2VFeGVjdXRvcihyZXNvbHZlKSB7XG4gICAgcmVzb2x2ZVByb21pc2UgPSByZXNvbHZlO1xuICB9KTtcblxuICB2YXIgdG9rZW4gPSB0aGlzO1xuXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBmdW5jLW5hbWVzXG4gIHRoaXMucHJvbWlzZS50aGVuKGZ1bmN0aW9uKGNhbmNlbCkge1xuICAgIGlmICghdG9rZW4uX2xpc3RlbmVycykgcmV0dXJuO1xuXG4gICAgdmFyIGk7XG4gICAgdmFyIGwgPSB0b2tlbi5fbGlzdGVuZXJzLmxlbmd0aDtcblxuICAgIGZvciAoaSA9IDA7IGkgPCBsOyBpKyspIHtcbiAgICAgIHRva2VuLl9saXN0ZW5lcnNbaV0oY2FuY2VsKTtcbiAgICB9XG4gICAgdG9rZW4uX2xpc3RlbmVycyA9IG51bGw7XG4gIH0pO1xuXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBmdW5jLW5hbWVzXG4gIHRoaXMucHJvbWlzZS50aGVuID0gZnVuY3Rpb24ob25mdWxmaWxsZWQpIHtcbiAgICB2YXIgX3Jlc29sdmU7XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGZ1bmMtbmFtZXNcbiAgICB2YXIgcHJvbWlzZSA9IG5ldyBQcm9taXNlKGZ1bmN0aW9uKHJlc29sdmUpIHtcbiAgICAgIHRva2VuLnN1YnNjcmliZShyZXNvbHZlKTtcbiAgICAgIF9yZXNvbHZlID0gcmVzb2x2ZTtcbiAgICB9KS50aGVuKG9uZnVsZmlsbGVkKTtcblxuICAgIHByb21pc2UuY2FuY2VsID0gZnVuY3Rpb24gcmVqZWN0KCkge1xuICAgICAgdG9rZW4udW5zdWJzY3JpYmUoX3Jlc29sdmUpO1xuICAgIH07XG5cbiAgICByZXR1cm4gcHJvbWlzZTtcbiAgfTtcblxuICBleGVjdXRvcihmdW5jdGlvbiBjYW5jZWwobWVzc2FnZSkge1xuICAgIGlmICh0b2tlbi5yZWFzb24pIHtcbiAgICAgIC8vIENhbmNlbGxhdGlvbiBoYXMgYWxyZWFkeSBiZWVuIHJlcXVlc3RlZFxuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHRva2VuLnJlYXNvbiA9IG5ldyBDYW5jZWwobWVzc2FnZSk7XG4gICAgcmVzb2x2ZVByb21pc2UodG9rZW4ucmVhc29uKTtcbiAgfSk7XG59XG5cbi8qKlxuICogVGhyb3dzIGEgYENhbmNlbGAgaWYgY2FuY2VsbGF0aW9uIGhhcyBiZWVuIHJlcXVlc3RlZC5cbiAqL1xuQ2FuY2VsVG9rZW4ucHJvdG90eXBlLnRocm93SWZSZXF1ZXN0ZWQgPSBmdW5jdGlvbiB0aHJvd0lmUmVxdWVzdGVkKCkge1xuICBpZiAodGhpcy5yZWFzb24pIHtcbiAgICB0aHJvdyB0aGlzLnJlYXNvbjtcbiAgfVxufTtcblxuLyoqXG4gKiBTdWJzY3JpYmUgdG8gdGhlIGNhbmNlbCBzaWduYWxcbiAqL1xuXG5DYW5jZWxUb2tlbi5wcm90b3R5cGUuc3Vic2NyaWJlID0gZnVuY3Rpb24gc3Vic2NyaWJlKGxpc3RlbmVyKSB7XG4gIGlmICh0aGlzLnJlYXNvbikge1xuICAgIGxpc3RlbmVyKHRoaXMucmVhc29uKTtcbiAgICByZXR1cm47XG4gIH1cblxuICBpZiAodGhpcy5fbGlzdGVuZXJzKSB7XG4gICAgdGhpcy5fbGlzdGVuZXJzLnB1c2gobGlzdGVuZXIpO1xuICB9IGVsc2Uge1xuICAgIHRoaXMuX2xpc3RlbmVycyA9IFtsaXN0ZW5lcl07XG4gIH1cbn07XG5cbi8qKlxuICogVW5zdWJzY3JpYmUgZnJvbSB0aGUgY2FuY2VsIHNpZ25hbFxuICovXG5cbkNhbmNlbFRva2VuLnByb3RvdHlwZS51bnN1YnNjcmliZSA9IGZ1bmN0aW9uIHVuc3Vic2NyaWJlKGxpc3RlbmVyKSB7XG4gIGlmICghdGhpcy5fbGlzdGVuZXJzKSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIHZhciBpbmRleCA9IHRoaXMuX2xpc3RlbmVycy5pbmRleE9mKGxpc3RlbmVyKTtcbiAgaWYgKGluZGV4ICE9PSAtMSkge1xuICAgIHRoaXMuX2xpc3RlbmVycy5zcGxpY2UoaW5kZXgsIDEpO1xuICB9XG59O1xuXG4vKipcbiAqIFJldHVybnMgYW4gb2JqZWN0IHRoYXQgY29udGFpbnMgYSBuZXcgYENhbmNlbFRva2VuYCBhbmQgYSBmdW5jdGlvbiB0aGF0LCB3aGVuIGNhbGxlZCxcbiAqIGNhbmNlbHMgdGhlIGBDYW5jZWxUb2tlbmAuXG4gKi9cbkNhbmNlbFRva2VuLnNvdXJjZSA9IGZ1bmN0aW9uIHNvdXJjZSgpIHtcbiAgdmFyIGNhbmNlbDtcbiAgdmFyIHRva2VuID0gbmV3IENhbmNlbFRva2VuKGZ1bmN0aW9uIGV4ZWN1dG9yKGMpIHtcbiAgICBjYW5jZWwgPSBjO1xuICB9KTtcbiAgcmV0dXJuIHtcbiAgICB0b2tlbjogdG9rZW4sXG4gICAgY2FuY2VsOiBjYW5jZWxcbiAgfTtcbn07XG5cbm1vZHVsZS5leHBvcnRzID0gQ2FuY2VsVG9rZW47XG4iLCIndXNlIHN0cmljdCc7XG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gaXNDYW5jZWwodmFsdWUpIHtcbiAgcmV0dXJuICEhKHZhbHVlICYmIHZhbHVlLl9fQ0FOQ0VMX18pO1xufTtcbiIsIid1c2Ugc3RyaWN0JztcblxudmFyIHV0aWxzID0gcmVxdWlyZSgnLi8uLi91dGlscycpO1xudmFyIGJ1aWxkVVJMID0gcmVxdWlyZSgnLi4vaGVscGVycy9idWlsZFVSTCcpO1xudmFyIEludGVyY2VwdG9yTWFuYWdlciA9IHJlcXVpcmUoJy4vSW50ZXJjZXB0b3JNYW5hZ2VyJyk7XG52YXIgZGlzcGF0Y2hSZXF1ZXN0ID0gcmVxdWlyZSgnLi9kaXNwYXRjaFJlcXVlc3QnKTtcbnZhciBtZXJnZUNvbmZpZyA9IHJlcXVpcmUoJy4vbWVyZ2VDb25maWcnKTtcbnZhciB2YWxpZGF0b3IgPSByZXF1aXJlKCcuLi9oZWxwZXJzL3ZhbGlkYXRvcicpO1xuXG52YXIgdmFsaWRhdG9ycyA9IHZhbGlkYXRvci52YWxpZGF0b3JzO1xuLyoqXG4gKiBDcmVhdGUgYSBuZXcgaW5zdGFuY2Ugb2YgQXhpb3NcbiAqXG4gKiBAcGFyYW0ge09iamVjdH0gaW5zdGFuY2VDb25maWcgVGhlIGRlZmF1bHQgY29uZmlnIGZvciB0aGUgaW5zdGFuY2VcbiAqL1xuZnVuY3Rpb24gQXhpb3MoaW5zdGFuY2VDb25maWcpIHtcbiAgdGhpcy5kZWZhdWx0cyA9IGluc3RhbmNlQ29uZmlnO1xuICB0aGlzLmludGVyY2VwdG9ycyA9IHtcbiAgICByZXF1ZXN0OiBuZXcgSW50ZXJjZXB0b3JNYW5hZ2VyKCksXG4gICAgcmVzcG9uc2U6IG5ldyBJbnRlcmNlcHRvck1hbmFnZXIoKVxuICB9O1xufVxuXG4vKipcbiAqIERpc3BhdGNoIGEgcmVxdWVzdFxuICpcbiAqIEBwYXJhbSB7T2JqZWN0fSBjb25maWcgVGhlIGNvbmZpZyBzcGVjaWZpYyBmb3IgdGhpcyByZXF1ZXN0IChtZXJnZWQgd2l0aCB0aGlzLmRlZmF1bHRzKVxuICovXG5BeGlvcy5wcm90b3R5cGUucmVxdWVzdCA9IGZ1bmN0aW9uIHJlcXVlc3QoY29uZmlnT3JVcmwsIGNvbmZpZykge1xuICAvKmVzbGludCBuby1wYXJhbS1yZWFzc2lnbjowKi9cbiAgLy8gQWxsb3cgZm9yIGF4aW9zKCdleGFtcGxlL3VybCdbLCBjb25maWddKSBhIGxhIGZldGNoIEFQSVxuICBpZiAodHlwZW9mIGNvbmZpZ09yVXJsID09PSAnc3RyaW5nJykge1xuICAgIGNvbmZpZyA9IGNvbmZpZyB8fCB7fTtcbiAgICBjb25maWcudXJsID0gY29uZmlnT3JVcmw7XG4gIH0gZWxzZSB7XG4gICAgY29uZmlnID0gY29uZmlnT3JVcmwgfHwge307XG4gIH1cblxuICBjb25maWcgPSBtZXJnZUNvbmZpZyh0aGlzLmRlZmF1bHRzLCBjb25maWcpO1xuXG4gIC8vIFNldCBjb25maWcubWV0aG9kXG4gIGlmIChjb25maWcubWV0aG9kKSB7XG4gICAgY29uZmlnLm1ldGhvZCA9IGNvbmZpZy5tZXRob2QudG9Mb3dlckNhc2UoKTtcbiAgfSBlbHNlIGlmICh0aGlzLmRlZmF1bHRzLm1ldGhvZCkge1xuICAgIGNvbmZpZy5tZXRob2QgPSB0aGlzLmRlZmF1bHRzLm1ldGhvZC50b0xvd2VyQ2FzZSgpO1xuICB9IGVsc2Uge1xuICAgIGNvbmZpZy5tZXRob2QgPSAnZ2V0JztcbiAgfVxuXG4gIHZhciB0cmFuc2l0aW9uYWwgPSBjb25maWcudHJhbnNpdGlvbmFsO1xuXG4gIGlmICh0cmFuc2l0aW9uYWwgIT09IHVuZGVmaW5lZCkge1xuICAgIHZhbGlkYXRvci5hc3NlcnRPcHRpb25zKHRyYW5zaXRpb25hbCwge1xuICAgICAgc2lsZW50SlNPTlBhcnNpbmc6IHZhbGlkYXRvcnMudHJhbnNpdGlvbmFsKHZhbGlkYXRvcnMuYm9vbGVhbiksXG4gICAgICBmb3JjZWRKU09OUGFyc2luZzogdmFsaWRhdG9ycy50cmFuc2l0aW9uYWwodmFsaWRhdG9ycy5ib29sZWFuKSxcbiAgICAgIGNsYXJpZnlUaW1lb3V0RXJyb3I6IHZhbGlkYXRvcnMudHJhbnNpdGlvbmFsKHZhbGlkYXRvcnMuYm9vbGVhbilcbiAgICB9LCBmYWxzZSk7XG4gIH1cblxuICAvLyBmaWx0ZXIgb3V0IHNraXBwZWQgaW50ZXJjZXB0b3JzXG4gIHZhciByZXF1ZXN0SW50ZXJjZXB0b3JDaGFpbiA9IFtdO1xuICB2YXIgc3luY2hyb25vdXNSZXF1ZXN0SW50ZXJjZXB0b3JzID0gdHJ1ZTtcbiAgdGhpcy5pbnRlcmNlcHRvcnMucmVxdWVzdC5mb3JFYWNoKGZ1bmN0aW9uIHVuc2hpZnRSZXF1ZXN0SW50ZXJjZXB0b3JzKGludGVyY2VwdG9yKSB7XG4gICAgaWYgKHR5cGVvZiBpbnRlcmNlcHRvci5ydW5XaGVuID09PSAnZnVuY3Rpb24nICYmIGludGVyY2VwdG9yLnJ1bldoZW4oY29uZmlnKSA9PT0gZmFsc2UpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBzeW5jaHJvbm91c1JlcXVlc3RJbnRlcmNlcHRvcnMgPSBzeW5jaHJvbm91c1JlcXVlc3RJbnRlcmNlcHRvcnMgJiYgaW50ZXJjZXB0b3Iuc3luY2hyb25vdXM7XG5cbiAgICByZXF1ZXN0SW50ZXJjZXB0b3JDaGFpbi51bnNoaWZ0KGludGVyY2VwdG9yLmZ1bGZpbGxlZCwgaW50ZXJjZXB0b3IucmVqZWN0ZWQpO1xuICB9KTtcblxuICB2YXIgcmVzcG9uc2VJbnRlcmNlcHRvckNoYWluID0gW107XG4gIHRoaXMuaW50ZXJjZXB0b3JzLnJlc3BvbnNlLmZvckVhY2goZnVuY3Rpb24gcHVzaFJlc3BvbnNlSW50ZXJjZXB0b3JzKGludGVyY2VwdG9yKSB7XG4gICAgcmVzcG9uc2VJbnRlcmNlcHRvckNoYWluLnB1c2goaW50ZXJjZXB0b3IuZnVsZmlsbGVkLCBpbnRlcmNlcHRvci5yZWplY3RlZCk7XG4gIH0pO1xuXG4gIHZhciBwcm9taXNlO1xuXG4gIGlmICghc3luY2hyb25vdXNSZXF1ZXN0SW50ZXJjZXB0b3JzKSB7XG4gICAgdmFyIGNoYWluID0gW2Rpc3BhdGNoUmVxdWVzdCwgdW5kZWZpbmVkXTtcblxuICAgIEFycmF5LnByb3RvdHlwZS51bnNoaWZ0LmFwcGx5KGNoYWluLCByZXF1ZXN0SW50ZXJjZXB0b3JDaGFpbik7XG4gICAgY2hhaW4gPSBjaGFpbi5jb25jYXQocmVzcG9uc2VJbnRlcmNlcHRvckNoYWluKTtcblxuICAgIHByb21pc2UgPSBQcm9taXNlLnJlc29sdmUoY29uZmlnKTtcbiAgICB3aGlsZSAoY2hhaW4ubGVuZ3RoKSB7XG4gICAgICBwcm9taXNlID0gcHJvbWlzZS50aGVuKGNoYWluLnNoaWZ0KCksIGNoYWluLnNoaWZ0KCkpO1xuICAgIH1cblxuICAgIHJldHVybiBwcm9taXNlO1xuICB9XG5cblxuICB2YXIgbmV3Q29uZmlnID0gY29uZmlnO1xuICB3aGlsZSAocmVxdWVzdEludGVyY2VwdG9yQ2hhaW4ubGVuZ3RoKSB7XG4gICAgdmFyIG9uRnVsZmlsbGVkID0gcmVxdWVzdEludGVyY2VwdG9yQ2hhaW4uc2hpZnQoKTtcbiAgICB2YXIgb25SZWplY3RlZCA9IHJlcXVlc3RJbnRlcmNlcHRvckNoYWluLnNoaWZ0KCk7XG4gICAgdHJ5IHtcbiAgICAgIG5ld0NvbmZpZyA9IG9uRnVsZmlsbGVkKG5ld0NvbmZpZyk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIG9uUmVqZWN0ZWQoZXJyb3IpO1xuICAgICAgYnJlYWs7XG4gICAgfVxuICB9XG5cbiAgdHJ5IHtcbiAgICBwcm9taXNlID0gZGlzcGF0Y2hSZXF1ZXN0KG5ld0NvbmZpZyk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgcmV0dXJuIFByb21pc2UucmVqZWN0KGVycm9yKTtcbiAgfVxuXG4gIHdoaWxlIChyZXNwb25zZUludGVyY2VwdG9yQ2hhaW4ubGVuZ3RoKSB7XG4gICAgcHJvbWlzZSA9IHByb21pc2UudGhlbihyZXNwb25zZUludGVyY2VwdG9yQ2hhaW4uc2hpZnQoKSwgcmVzcG9uc2VJbnRlcmNlcHRvckNoYWluLnNoaWZ0KCkpO1xuICB9XG5cbiAgcmV0dXJuIHByb21pc2U7XG59O1xuXG5BeGlvcy5wcm90b3R5cGUuZ2V0VXJpID0gZnVuY3Rpb24gZ2V0VXJpKGNvbmZpZykge1xuICBjb25maWcgPSBtZXJnZUNvbmZpZyh0aGlzLmRlZmF1bHRzLCBjb25maWcpO1xuICByZXR1cm4gYnVpbGRVUkwoY29uZmlnLnVybCwgY29uZmlnLnBhcmFtcywgY29uZmlnLnBhcmFtc1NlcmlhbGl6ZXIpLnJlcGxhY2UoL15cXD8vLCAnJyk7XG59O1xuXG4vLyBQcm92aWRlIGFsaWFzZXMgZm9yIHN1cHBvcnRlZCByZXF1ZXN0IG1ldGhvZHNcbnV0aWxzLmZvckVhY2goWydkZWxldGUnLCAnZ2V0JywgJ2hlYWQnLCAnb3B0aW9ucyddLCBmdW5jdGlvbiBmb3JFYWNoTWV0aG9kTm9EYXRhKG1ldGhvZCkge1xuICAvKmVzbGludCBmdW5jLW5hbWVzOjAqL1xuICBBeGlvcy5wcm90b3R5cGVbbWV0aG9kXSA9IGZ1bmN0aW9uKHVybCwgY29uZmlnKSB7XG4gICAgcmV0dXJuIHRoaXMucmVxdWVzdChtZXJnZUNvbmZpZyhjb25maWcgfHwge30sIHtcbiAgICAgIG1ldGhvZDogbWV0aG9kLFxuICAgICAgdXJsOiB1cmwsXG4gICAgICBkYXRhOiAoY29uZmlnIHx8IHt9KS5kYXRhXG4gICAgfSkpO1xuICB9O1xufSk7XG5cbnV0aWxzLmZvckVhY2goWydwb3N0JywgJ3B1dCcsICdwYXRjaCddLCBmdW5jdGlvbiBmb3JFYWNoTWV0aG9kV2l0aERhdGEobWV0aG9kKSB7XG4gIC8qZXNsaW50IGZ1bmMtbmFtZXM6MCovXG4gIEF4aW9zLnByb3RvdHlwZVttZXRob2RdID0gZnVuY3Rpb24odXJsLCBkYXRhLCBjb25maWcpIHtcbiAgICByZXR1cm4gdGhpcy5yZXF1ZXN0KG1lcmdlQ29uZmlnKGNvbmZpZyB8fCB7fSwge1xuICAgICAgbWV0aG9kOiBtZXRob2QsXG4gICAgICB1cmw6IHVybCxcbiAgICAgIGRhdGE6IGRhdGFcbiAgICB9KSk7XG4gIH07XG59KTtcblxubW9kdWxlLmV4cG9ydHMgPSBBeGlvcztcbiIsIid1c2Ugc3RyaWN0JztcblxudmFyIHV0aWxzID0gcmVxdWlyZSgnLi8uLi91dGlscycpO1xuXG5mdW5jdGlvbiBJbnRlcmNlcHRvck1hbmFnZXIoKSB7XG4gIHRoaXMuaGFuZGxlcnMgPSBbXTtcbn1cblxuLyoqXG4gKiBBZGQgYSBuZXcgaW50ZXJjZXB0b3IgdG8gdGhlIHN0YWNrXG4gKlxuICogQHBhcmFtIHtGdW5jdGlvbn0gZnVsZmlsbGVkIFRoZSBmdW5jdGlvbiB0byBoYW5kbGUgYHRoZW5gIGZvciBhIGBQcm9taXNlYFxuICogQHBhcmFtIHtGdW5jdGlvbn0gcmVqZWN0ZWQgVGhlIGZ1bmN0aW9uIHRvIGhhbmRsZSBgcmVqZWN0YCBmb3IgYSBgUHJvbWlzZWBcbiAqXG4gKiBAcmV0dXJuIHtOdW1iZXJ9IEFuIElEIHVzZWQgdG8gcmVtb3ZlIGludGVyY2VwdG9yIGxhdGVyXG4gKi9cbkludGVyY2VwdG9yTWFuYWdlci5wcm90b3R5cGUudXNlID0gZnVuY3Rpb24gdXNlKGZ1bGZpbGxlZCwgcmVqZWN0ZWQsIG9wdGlvbnMpIHtcbiAgdGhpcy5oYW5kbGVycy5wdXNoKHtcbiAgICBmdWxmaWxsZWQ6IGZ1bGZpbGxlZCxcbiAgICByZWplY3RlZDogcmVqZWN0ZWQsXG4gICAgc3luY2hyb25vdXM6IG9wdGlvbnMgPyBvcHRpb25zLnN5bmNocm9ub3VzIDogZmFsc2UsXG4gICAgcnVuV2hlbjogb3B0aW9ucyA/IG9wdGlvbnMucnVuV2hlbiA6IG51bGxcbiAgfSk7XG4gIHJldHVybiB0aGlzLmhhbmRsZXJzLmxlbmd0aCAtIDE7XG59O1xuXG4vKipcbiAqIFJlbW92ZSBhbiBpbnRlcmNlcHRvciBmcm9tIHRoZSBzdGFja1xuICpcbiAqIEBwYXJhbSB7TnVtYmVyfSBpZCBUaGUgSUQgdGhhdCB3YXMgcmV0dXJuZWQgYnkgYHVzZWBcbiAqL1xuSW50ZXJjZXB0b3JNYW5hZ2VyLnByb3RvdHlwZS5lamVjdCA9IGZ1bmN0aW9uIGVqZWN0KGlkKSB7XG4gIGlmICh0aGlzLmhhbmRsZXJzW2lkXSkge1xuICAgIHRoaXMuaGFuZGxlcnNbaWRdID0gbnVsbDtcbiAgfVxufTtcblxuLyoqXG4gKiBJdGVyYXRlIG92ZXIgYWxsIHRoZSByZWdpc3RlcmVkIGludGVyY2VwdG9yc1xuICpcbiAqIFRoaXMgbWV0aG9kIGlzIHBhcnRpY3VsYXJseSB1c2VmdWwgZm9yIHNraXBwaW5nIG92ZXIgYW55XG4gKiBpbnRlcmNlcHRvcnMgdGhhdCBtYXkgaGF2ZSBiZWNvbWUgYG51bGxgIGNhbGxpbmcgYGVqZWN0YC5cbiAqXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSBmbiBUaGUgZnVuY3Rpb24gdG8gY2FsbCBmb3IgZWFjaCBpbnRlcmNlcHRvclxuICovXG5JbnRlcmNlcHRvck1hbmFnZXIucHJvdG90eXBlLmZvckVhY2ggPSBmdW5jdGlvbiBmb3JFYWNoKGZuKSB7XG4gIHV0aWxzLmZvckVhY2godGhpcy5oYW5kbGVycywgZnVuY3Rpb24gZm9yRWFjaEhhbmRsZXIoaCkge1xuICAgIGlmIChoICE9PSBudWxsKSB7XG4gICAgICBmbihoKTtcbiAgICB9XG4gIH0pO1xufTtcblxubW9kdWxlLmV4cG9ydHMgPSBJbnRlcmNlcHRvck1hbmFnZXI7XG4iLCIndXNlIHN0cmljdCc7XG5cbnZhciBpc0Fic29sdXRlVVJMID0gcmVxdWlyZSgnLi4vaGVscGVycy9pc0Fic29sdXRlVVJMJyk7XG52YXIgY29tYmluZVVSTHMgPSByZXF1aXJlKCcuLi9oZWxwZXJzL2NvbWJpbmVVUkxzJyk7XG5cbi8qKlxuICogQ3JlYXRlcyBhIG5ldyBVUkwgYnkgY29tYmluaW5nIHRoZSBiYXNlVVJMIHdpdGggdGhlIHJlcXVlc3RlZFVSTCxcbiAqIG9ubHkgd2hlbiB0aGUgcmVxdWVzdGVkVVJMIGlzIG5vdCBhbHJlYWR5IGFuIGFic29sdXRlIFVSTC5cbiAqIElmIHRoZSByZXF1ZXN0VVJMIGlzIGFic29sdXRlLCB0aGlzIGZ1bmN0aW9uIHJldHVybnMgdGhlIHJlcXVlc3RlZFVSTCB1bnRvdWNoZWQuXG4gKlxuICogQHBhcmFtIHtzdHJpbmd9IGJhc2VVUkwgVGhlIGJhc2UgVVJMXG4gKiBAcGFyYW0ge3N0cmluZ30gcmVxdWVzdGVkVVJMIEFic29sdXRlIG9yIHJlbGF0aXZlIFVSTCB0byBjb21iaW5lXG4gKiBAcmV0dXJucyB7c3RyaW5nfSBUaGUgY29tYmluZWQgZnVsbCBwYXRoXG4gKi9cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gYnVpbGRGdWxsUGF0aChiYXNlVVJMLCByZXF1ZXN0ZWRVUkwpIHtcbiAgaWYgKGJhc2VVUkwgJiYgIWlzQWJzb2x1dGVVUkwocmVxdWVzdGVkVVJMKSkge1xuICAgIHJldHVybiBjb21iaW5lVVJMcyhiYXNlVVJMLCByZXF1ZXN0ZWRVUkwpO1xuICB9XG4gIHJldHVybiByZXF1ZXN0ZWRVUkw7XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG52YXIgZW5oYW5jZUVycm9yID0gcmVxdWlyZSgnLi9lbmhhbmNlRXJyb3InKTtcblxuLyoqXG4gKiBDcmVhdGUgYW4gRXJyb3Igd2l0aCB0aGUgc3BlY2lmaWVkIG1lc3NhZ2UsIGNvbmZpZywgZXJyb3IgY29kZSwgcmVxdWVzdCBhbmQgcmVzcG9uc2UuXG4gKlxuICogQHBhcmFtIHtzdHJpbmd9IG1lc3NhZ2UgVGhlIGVycm9yIG1lc3NhZ2UuXG4gKiBAcGFyYW0ge09iamVjdH0gY29uZmlnIFRoZSBjb25maWcuXG4gKiBAcGFyYW0ge3N0cmluZ30gW2NvZGVdIFRoZSBlcnJvciBjb2RlIChmb3IgZXhhbXBsZSwgJ0VDT05OQUJPUlRFRCcpLlxuICogQHBhcmFtIHtPYmplY3R9IFtyZXF1ZXN0XSBUaGUgcmVxdWVzdC5cbiAqIEBwYXJhbSB7T2JqZWN0fSBbcmVzcG9uc2VdIFRoZSByZXNwb25zZS5cbiAqIEByZXR1cm5zIHtFcnJvcn0gVGhlIGNyZWF0ZWQgZXJyb3IuXG4gKi9cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gY3JlYXRlRXJyb3IobWVzc2FnZSwgY29uZmlnLCBjb2RlLCByZXF1ZXN0LCByZXNwb25zZSkge1xuICB2YXIgZXJyb3IgPSBuZXcgRXJyb3IobWVzc2FnZSk7XG4gIHJldHVybiBlbmhhbmNlRXJyb3IoZXJyb3IsIGNvbmZpZywgY29kZSwgcmVxdWVzdCwgcmVzcG9uc2UpO1xufTtcbiIsIid1c2Ugc3RyaWN0JztcblxudmFyIHV0aWxzID0gcmVxdWlyZSgnLi8uLi91dGlscycpO1xudmFyIHRyYW5zZm9ybURhdGEgPSByZXF1aXJlKCcuL3RyYW5zZm9ybURhdGEnKTtcbnZhciBpc0NhbmNlbCA9IHJlcXVpcmUoJy4uL2NhbmNlbC9pc0NhbmNlbCcpO1xudmFyIGRlZmF1bHRzID0gcmVxdWlyZSgnLi4vZGVmYXVsdHMnKTtcbnZhciBDYW5jZWwgPSByZXF1aXJlKCcuLi9jYW5jZWwvQ2FuY2VsJyk7XG5cbi8qKlxuICogVGhyb3dzIGEgYENhbmNlbGAgaWYgY2FuY2VsbGF0aW9uIGhhcyBiZWVuIHJlcXVlc3RlZC5cbiAqL1xuZnVuY3Rpb24gdGhyb3dJZkNhbmNlbGxhdGlvblJlcXVlc3RlZChjb25maWcpIHtcbiAgaWYgKGNvbmZpZy5jYW5jZWxUb2tlbikge1xuICAgIGNvbmZpZy5jYW5jZWxUb2tlbi50aHJvd0lmUmVxdWVzdGVkKCk7XG4gIH1cblxuICBpZiAoY29uZmlnLnNpZ25hbCAmJiBjb25maWcuc2lnbmFsLmFib3J0ZWQpIHtcbiAgICB0aHJvdyBuZXcgQ2FuY2VsKCdjYW5jZWxlZCcpO1xuICB9XG59XG5cbi8qKlxuICogRGlzcGF0Y2ggYSByZXF1ZXN0IHRvIHRoZSBzZXJ2ZXIgdXNpbmcgdGhlIGNvbmZpZ3VyZWQgYWRhcHRlci5cbiAqXG4gKiBAcGFyYW0ge29iamVjdH0gY29uZmlnIFRoZSBjb25maWcgdGhhdCBpcyB0byBiZSB1c2VkIGZvciB0aGUgcmVxdWVzdFxuICogQHJldHVybnMge1Byb21pc2V9IFRoZSBQcm9taXNlIHRvIGJlIGZ1bGZpbGxlZFxuICovXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIGRpc3BhdGNoUmVxdWVzdChjb25maWcpIHtcbiAgdGhyb3dJZkNhbmNlbGxhdGlvblJlcXVlc3RlZChjb25maWcpO1xuXG4gIC8vIEVuc3VyZSBoZWFkZXJzIGV4aXN0XG4gIGNvbmZpZy5oZWFkZXJzID0gY29uZmlnLmhlYWRlcnMgfHwge307XG5cbiAgLy8gVHJhbnNmb3JtIHJlcXVlc3QgZGF0YVxuICBjb25maWcuZGF0YSA9IHRyYW5zZm9ybURhdGEuY2FsbChcbiAgICBjb25maWcsXG4gICAgY29uZmlnLmRhdGEsXG4gICAgY29uZmlnLmhlYWRlcnMsXG4gICAgY29uZmlnLnRyYW5zZm9ybVJlcXVlc3RcbiAgKTtcblxuICAvLyBGbGF0dGVuIGhlYWRlcnNcbiAgY29uZmlnLmhlYWRlcnMgPSB1dGlscy5tZXJnZShcbiAgICBjb25maWcuaGVhZGVycy5jb21tb24gfHwge30sXG4gICAgY29uZmlnLmhlYWRlcnNbY29uZmlnLm1ldGhvZF0gfHwge30sXG4gICAgY29uZmlnLmhlYWRlcnNcbiAgKTtcblxuICB1dGlscy5mb3JFYWNoKFxuICAgIFsnZGVsZXRlJywgJ2dldCcsICdoZWFkJywgJ3Bvc3QnLCAncHV0JywgJ3BhdGNoJywgJ2NvbW1vbiddLFxuICAgIGZ1bmN0aW9uIGNsZWFuSGVhZGVyQ29uZmlnKG1ldGhvZCkge1xuICAgICAgZGVsZXRlIGNvbmZpZy5oZWFkZXJzW21ldGhvZF07XG4gICAgfVxuICApO1xuXG4gIHZhciBhZGFwdGVyID0gY29uZmlnLmFkYXB0ZXIgfHwgZGVmYXVsdHMuYWRhcHRlcjtcblxuICByZXR1cm4gYWRhcHRlcihjb25maWcpLnRoZW4oZnVuY3Rpb24gb25BZGFwdGVyUmVzb2x1dGlvbihyZXNwb25zZSkge1xuICAgIHRocm93SWZDYW5jZWxsYXRpb25SZXF1ZXN0ZWQoY29uZmlnKTtcblxuICAgIC8vIFRyYW5zZm9ybSByZXNwb25zZSBkYXRhXG4gICAgcmVzcG9uc2UuZGF0YSA9IHRyYW5zZm9ybURhdGEuY2FsbChcbiAgICAgIGNvbmZpZyxcbiAgICAgIHJlc3BvbnNlLmRhdGEsXG4gICAgICByZXNwb25zZS5oZWFkZXJzLFxuICAgICAgY29uZmlnLnRyYW5zZm9ybVJlc3BvbnNlXG4gICAgKTtcblxuICAgIHJldHVybiByZXNwb25zZTtcbiAgfSwgZnVuY3Rpb24gb25BZGFwdGVyUmVqZWN0aW9uKHJlYXNvbikge1xuICAgIGlmICghaXNDYW5jZWwocmVhc29uKSkge1xuICAgICAgdGhyb3dJZkNhbmNlbGxhdGlvblJlcXVlc3RlZChjb25maWcpO1xuXG4gICAgICAvLyBUcmFuc2Zvcm0gcmVzcG9uc2UgZGF0YVxuICAgICAgaWYgKHJlYXNvbiAmJiByZWFzb24ucmVzcG9uc2UpIHtcbiAgICAgICAgcmVhc29uLnJlc3BvbnNlLmRhdGEgPSB0cmFuc2Zvcm1EYXRhLmNhbGwoXG4gICAgICAgICAgY29uZmlnLFxuICAgICAgICAgIHJlYXNvbi5yZXNwb25zZS5kYXRhLFxuICAgICAgICAgIHJlYXNvbi5yZXNwb25zZS5oZWFkZXJzLFxuICAgICAgICAgIGNvbmZpZy50cmFuc2Zvcm1SZXNwb25zZVxuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBQcm9taXNlLnJlamVjdChyZWFzb24pO1xuICB9KTtcbn07XG4iLCIndXNlIHN0cmljdCc7XG5cbi8qKlxuICogVXBkYXRlIGFuIEVycm9yIHdpdGggdGhlIHNwZWNpZmllZCBjb25maWcsIGVycm9yIGNvZGUsIGFuZCByZXNwb25zZS5cbiAqXG4gKiBAcGFyYW0ge0Vycm9yfSBlcnJvciBUaGUgZXJyb3IgdG8gdXBkYXRlLlxuICogQHBhcmFtIHtPYmplY3R9IGNvbmZpZyBUaGUgY29uZmlnLlxuICogQHBhcmFtIHtzdHJpbmd9IFtjb2RlXSBUaGUgZXJyb3IgY29kZSAoZm9yIGV4YW1wbGUsICdFQ09OTkFCT1JURUQnKS5cbiAqIEBwYXJhbSB7T2JqZWN0fSBbcmVxdWVzdF0gVGhlIHJlcXVlc3QuXG4gKiBAcGFyYW0ge09iamVjdH0gW3Jlc3BvbnNlXSBUaGUgcmVzcG9uc2UuXG4gKiBAcmV0dXJucyB7RXJyb3J9IFRoZSBlcnJvci5cbiAqL1xubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiBlbmhhbmNlRXJyb3IoZXJyb3IsIGNvbmZpZywgY29kZSwgcmVxdWVzdCwgcmVzcG9uc2UpIHtcbiAgZXJyb3IuY29uZmlnID0gY29uZmlnO1xuICBpZiAoY29kZSkge1xuICAgIGVycm9yLmNvZGUgPSBjb2RlO1xuICB9XG5cbiAgZXJyb3IucmVxdWVzdCA9IHJlcXVlc3Q7XG4gIGVycm9yLnJlc3BvbnNlID0gcmVzcG9uc2U7XG4gIGVycm9yLmlzQXhpb3NFcnJvciA9IHRydWU7XG5cbiAgZXJyb3IudG9KU09OID0gZnVuY3Rpb24gdG9KU09OKCkge1xuICAgIHJldHVybiB7XG4gICAgICAvLyBTdGFuZGFyZFxuICAgICAgbWVzc2FnZTogdGhpcy5tZXNzYWdlLFxuICAgICAgbmFtZTogdGhpcy5uYW1lLFxuICAgICAgLy8gTWljcm9zb2Z0XG4gICAgICBkZXNjcmlwdGlvbjogdGhpcy5kZXNjcmlwdGlvbixcbiAgICAgIG51bWJlcjogdGhpcy5udW1iZXIsXG4gICAgICAvLyBNb3ppbGxhXG4gICAgICBmaWxlTmFtZTogdGhpcy5maWxlTmFtZSxcbiAgICAgIGxpbmVOdW1iZXI6IHRoaXMubGluZU51bWJlcixcbiAgICAgIGNvbHVtbk51bWJlcjogdGhpcy5jb2x1bW5OdW1iZXIsXG4gICAgICBzdGFjazogdGhpcy5zdGFjayxcbiAgICAgIC8vIEF4aW9zXG4gICAgICBjb25maWc6IHRoaXMuY29uZmlnLFxuICAgICAgY29kZTogdGhpcy5jb2RlLFxuICAgICAgc3RhdHVzOiB0aGlzLnJlc3BvbnNlICYmIHRoaXMucmVzcG9uc2Uuc3RhdHVzID8gdGhpcy5yZXNwb25zZS5zdGF0dXMgOiBudWxsXG4gICAgfTtcbiAgfTtcbiAgcmV0dXJuIGVycm9yO1xufTtcbiIsIid1c2Ugc3RyaWN0JztcblxudmFyIHV0aWxzID0gcmVxdWlyZSgnLi4vdXRpbHMnKTtcblxuLyoqXG4gKiBDb25maWctc3BlY2lmaWMgbWVyZ2UtZnVuY3Rpb24gd2hpY2ggY3JlYXRlcyBhIG5ldyBjb25maWctb2JqZWN0XG4gKiBieSBtZXJnaW5nIHR3byBjb25maWd1cmF0aW9uIG9iamVjdHMgdG9nZXRoZXIuXG4gKlxuICogQHBhcmFtIHtPYmplY3R9IGNvbmZpZzFcbiAqIEBwYXJhbSB7T2JqZWN0fSBjb25maWcyXG4gKiBAcmV0dXJucyB7T2JqZWN0fSBOZXcgb2JqZWN0IHJlc3VsdGluZyBmcm9tIG1lcmdpbmcgY29uZmlnMiB0byBjb25maWcxXG4gKi9cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gbWVyZ2VDb25maWcoY29uZmlnMSwgY29uZmlnMikge1xuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tcGFyYW0tcmVhc3NpZ25cbiAgY29uZmlnMiA9IGNvbmZpZzIgfHwge307XG4gIHZhciBjb25maWcgPSB7fTtcblxuICBmdW5jdGlvbiBnZXRNZXJnZWRWYWx1ZSh0YXJnZXQsIHNvdXJjZSkge1xuICAgIGlmICh1dGlscy5pc1BsYWluT2JqZWN0KHRhcmdldCkgJiYgdXRpbHMuaXNQbGFpbk9iamVjdChzb3VyY2UpKSB7XG4gICAgICByZXR1cm4gdXRpbHMubWVyZ2UodGFyZ2V0LCBzb3VyY2UpO1xuICAgIH0gZWxzZSBpZiAodXRpbHMuaXNQbGFpbk9iamVjdChzb3VyY2UpKSB7XG4gICAgICByZXR1cm4gdXRpbHMubWVyZ2Uoe30sIHNvdXJjZSk7XG4gICAgfSBlbHNlIGlmICh1dGlscy5pc0FycmF5KHNvdXJjZSkpIHtcbiAgICAgIHJldHVybiBzb3VyY2Uuc2xpY2UoKTtcbiAgICB9XG4gICAgcmV0dXJuIHNvdXJjZTtcbiAgfVxuXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBjb25zaXN0ZW50LXJldHVyblxuICBmdW5jdGlvbiBtZXJnZURlZXBQcm9wZXJ0aWVzKHByb3ApIHtcbiAgICBpZiAoIXV0aWxzLmlzVW5kZWZpbmVkKGNvbmZpZzJbcHJvcF0pKSB7XG4gICAgICByZXR1cm4gZ2V0TWVyZ2VkVmFsdWUoY29uZmlnMVtwcm9wXSwgY29uZmlnMltwcm9wXSk7XG4gICAgfSBlbHNlIGlmICghdXRpbHMuaXNVbmRlZmluZWQoY29uZmlnMVtwcm9wXSkpIHtcbiAgICAgIHJldHVybiBnZXRNZXJnZWRWYWx1ZSh1bmRlZmluZWQsIGNvbmZpZzFbcHJvcF0pO1xuICAgIH1cbiAgfVxuXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBjb25zaXN0ZW50LXJldHVyblxuICBmdW5jdGlvbiB2YWx1ZUZyb21Db25maWcyKHByb3ApIHtcbiAgICBpZiAoIXV0aWxzLmlzVW5kZWZpbmVkKGNvbmZpZzJbcHJvcF0pKSB7XG4gICAgICByZXR1cm4gZ2V0TWVyZ2VkVmFsdWUodW5kZWZpbmVkLCBjb25maWcyW3Byb3BdKTtcbiAgICB9XG4gIH1cblxuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgY29uc2lzdGVudC1yZXR1cm5cbiAgZnVuY3Rpb24gZGVmYXVsdFRvQ29uZmlnMihwcm9wKSB7XG4gICAgaWYgKCF1dGlscy5pc1VuZGVmaW5lZChjb25maWcyW3Byb3BdKSkge1xuICAgICAgcmV0dXJuIGdldE1lcmdlZFZhbHVlKHVuZGVmaW5lZCwgY29uZmlnMltwcm9wXSk7XG4gICAgfSBlbHNlIGlmICghdXRpbHMuaXNVbmRlZmluZWQoY29uZmlnMVtwcm9wXSkpIHtcbiAgICAgIHJldHVybiBnZXRNZXJnZWRWYWx1ZSh1bmRlZmluZWQsIGNvbmZpZzFbcHJvcF0pO1xuICAgIH1cbiAgfVxuXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBjb25zaXN0ZW50LXJldHVyblxuICBmdW5jdGlvbiBtZXJnZURpcmVjdEtleXMocHJvcCkge1xuICAgIGlmIChwcm9wIGluIGNvbmZpZzIpIHtcbiAgICAgIHJldHVybiBnZXRNZXJnZWRWYWx1ZShjb25maWcxW3Byb3BdLCBjb25maWcyW3Byb3BdKTtcbiAgICB9IGVsc2UgaWYgKHByb3AgaW4gY29uZmlnMSkge1xuICAgICAgcmV0dXJuIGdldE1lcmdlZFZhbHVlKHVuZGVmaW5lZCwgY29uZmlnMVtwcm9wXSk7XG4gICAgfVxuICB9XG5cbiAgdmFyIG1lcmdlTWFwID0ge1xuICAgICd1cmwnOiB2YWx1ZUZyb21Db25maWcyLFxuICAgICdtZXRob2QnOiB2YWx1ZUZyb21Db25maWcyLFxuICAgICdkYXRhJzogdmFsdWVGcm9tQ29uZmlnMixcbiAgICAnYmFzZVVSTCc6IGRlZmF1bHRUb0NvbmZpZzIsXG4gICAgJ3RyYW5zZm9ybVJlcXVlc3QnOiBkZWZhdWx0VG9Db25maWcyLFxuICAgICd0cmFuc2Zvcm1SZXNwb25zZSc6IGRlZmF1bHRUb0NvbmZpZzIsXG4gICAgJ3BhcmFtc1NlcmlhbGl6ZXInOiBkZWZhdWx0VG9Db25maWcyLFxuICAgICd0aW1lb3V0JzogZGVmYXVsdFRvQ29uZmlnMixcbiAgICAndGltZW91dE1lc3NhZ2UnOiBkZWZhdWx0VG9Db25maWcyLFxuICAgICd3aXRoQ3JlZGVudGlhbHMnOiBkZWZhdWx0VG9Db25maWcyLFxuICAgICdhZGFwdGVyJzogZGVmYXVsdFRvQ29uZmlnMixcbiAgICAncmVzcG9uc2VUeXBlJzogZGVmYXVsdFRvQ29uZmlnMixcbiAgICAneHNyZkNvb2tpZU5hbWUnOiBkZWZhdWx0VG9Db25maWcyLFxuICAgICd4c3JmSGVhZGVyTmFtZSc6IGRlZmF1bHRUb0NvbmZpZzIsXG4gICAgJ29uVXBsb2FkUHJvZ3Jlc3MnOiBkZWZhdWx0VG9Db25maWcyLFxuICAgICdvbkRvd25sb2FkUHJvZ3Jlc3MnOiBkZWZhdWx0VG9Db25maWcyLFxuICAgICdkZWNvbXByZXNzJzogZGVmYXVsdFRvQ29uZmlnMixcbiAgICAnbWF4Q29udGVudExlbmd0aCc6IGRlZmF1bHRUb0NvbmZpZzIsXG4gICAgJ21heEJvZHlMZW5ndGgnOiBkZWZhdWx0VG9Db25maWcyLFxuICAgICd0cmFuc3BvcnQnOiBkZWZhdWx0VG9Db25maWcyLFxuICAgICdodHRwQWdlbnQnOiBkZWZhdWx0VG9Db25maWcyLFxuICAgICdodHRwc0FnZW50JzogZGVmYXVsdFRvQ29uZmlnMixcbiAgICAnY2FuY2VsVG9rZW4nOiBkZWZhdWx0VG9Db25maWcyLFxuICAgICdzb2NrZXRQYXRoJzogZGVmYXVsdFRvQ29uZmlnMixcbiAgICAncmVzcG9uc2VFbmNvZGluZyc6IGRlZmF1bHRUb0NvbmZpZzIsXG4gICAgJ3ZhbGlkYXRlU3RhdHVzJzogbWVyZ2VEaXJlY3RLZXlzXG4gIH07XG5cbiAgdXRpbHMuZm9yRWFjaChPYmplY3Qua2V5cyhjb25maWcxKS5jb25jYXQoT2JqZWN0LmtleXMoY29uZmlnMikpLCBmdW5jdGlvbiBjb21wdXRlQ29uZmlnVmFsdWUocHJvcCkge1xuICAgIHZhciBtZXJnZSA9IG1lcmdlTWFwW3Byb3BdIHx8IG1lcmdlRGVlcFByb3BlcnRpZXM7XG4gICAgdmFyIGNvbmZpZ1ZhbHVlID0gbWVyZ2UocHJvcCk7XG4gICAgKHV0aWxzLmlzVW5kZWZpbmVkKGNvbmZpZ1ZhbHVlKSAmJiBtZXJnZSAhPT0gbWVyZ2VEaXJlY3RLZXlzKSB8fCAoY29uZmlnW3Byb3BdID0gY29uZmlnVmFsdWUpO1xuICB9KTtcblxuICByZXR1cm4gY29uZmlnO1xufTtcbiIsIid1c2Ugc3RyaWN0JztcblxudmFyIGNyZWF0ZUVycm9yID0gcmVxdWlyZSgnLi9jcmVhdGVFcnJvcicpO1xuXG4vKipcbiAqIFJlc29sdmUgb3IgcmVqZWN0IGEgUHJvbWlzZSBiYXNlZCBvbiByZXNwb25zZSBzdGF0dXMuXG4gKlxuICogQHBhcmFtIHtGdW5jdGlvbn0gcmVzb2x2ZSBBIGZ1bmN0aW9uIHRoYXQgcmVzb2x2ZXMgdGhlIHByb21pc2UuXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSByZWplY3QgQSBmdW5jdGlvbiB0aGF0IHJlamVjdHMgdGhlIHByb21pc2UuXG4gKiBAcGFyYW0ge29iamVjdH0gcmVzcG9uc2UgVGhlIHJlc3BvbnNlLlxuICovXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIHNldHRsZShyZXNvbHZlLCByZWplY3QsIHJlc3BvbnNlKSB7XG4gIHZhciB2YWxpZGF0ZVN0YXR1cyA9IHJlc3BvbnNlLmNvbmZpZy52YWxpZGF0ZVN0YXR1cztcbiAgaWYgKCFyZXNwb25zZS5zdGF0dXMgfHwgIXZhbGlkYXRlU3RhdHVzIHx8IHZhbGlkYXRlU3RhdHVzKHJlc3BvbnNlLnN0YXR1cykpIHtcbiAgICByZXNvbHZlKHJlc3BvbnNlKTtcbiAgfSBlbHNlIHtcbiAgICByZWplY3QoY3JlYXRlRXJyb3IoXG4gICAgICAnUmVxdWVzdCBmYWlsZWQgd2l0aCBzdGF0dXMgY29kZSAnICsgcmVzcG9uc2Uuc3RhdHVzLFxuICAgICAgcmVzcG9uc2UuY29uZmlnLFxuICAgICAgbnVsbCxcbiAgICAgIHJlc3BvbnNlLnJlcXVlc3QsXG4gICAgICByZXNwb25zZVxuICAgICkpO1xuICB9XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG52YXIgdXRpbHMgPSByZXF1aXJlKCcuLy4uL3V0aWxzJyk7XG52YXIgZGVmYXVsdHMgPSByZXF1aXJlKCcuLi9kZWZhdWx0cycpO1xuXG4vKipcbiAqIFRyYW5zZm9ybSB0aGUgZGF0YSBmb3IgYSByZXF1ZXN0IG9yIGEgcmVzcG9uc2VcbiAqXG4gKiBAcGFyYW0ge09iamVjdHxTdHJpbmd9IGRhdGEgVGhlIGRhdGEgdG8gYmUgdHJhbnNmb3JtZWRcbiAqIEBwYXJhbSB7QXJyYXl9IGhlYWRlcnMgVGhlIGhlYWRlcnMgZm9yIHRoZSByZXF1ZXN0IG9yIHJlc3BvbnNlXG4gKiBAcGFyYW0ge0FycmF5fEZ1bmN0aW9ufSBmbnMgQSBzaW5nbGUgZnVuY3Rpb24gb3IgQXJyYXkgb2YgZnVuY3Rpb25zXG4gKiBAcmV0dXJucyB7Kn0gVGhlIHJlc3VsdGluZyB0cmFuc2Zvcm1lZCBkYXRhXG4gKi9cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gdHJhbnNmb3JtRGF0YShkYXRhLCBoZWFkZXJzLCBmbnMpIHtcbiAgdmFyIGNvbnRleHQgPSB0aGlzIHx8IGRlZmF1bHRzO1xuICAvKmVzbGludCBuby1wYXJhbS1yZWFzc2lnbjowKi9cbiAgdXRpbHMuZm9yRWFjaChmbnMsIGZ1bmN0aW9uIHRyYW5zZm9ybShmbikge1xuICAgIGRhdGEgPSBmbi5jYWxsKGNvbnRleHQsIGRhdGEsIGhlYWRlcnMpO1xuICB9KTtcblxuICByZXR1cm4gZGF0YTtcbn07XG4iLCIndXNlIHN0cmljdCc7XG5cbnZhciB1dGlscyA9IHJlcXVpcmUoJy4uL3V0aWxzJyk7XG52YXIgbm9ybWFsaXplSGVhZGVyTmFtZSA9IHJlcXVpcmUoJy4uL2hlbHBlcnMvbm9ybWFsaXplSGVhZGVyTmFtZScpO1xudmFyIGVuaGFuY2VFcnJvciA9IHJlcXVpcmUoJy4uL2NvcmUvZW5oYW5jZUVycm9yJyk7XG52YXIgdHJhbnNpdGlvbmFsRGVmYXVsdHMgPSByZXF1aXJlKCcuL3RyYW5zaXRpb25hbCcpO1xuXG52YXIgREVGQVVMVF9DT05URU5UX1RZUEUgPSB7XG4gICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24veC13d3ctZm9ybS11cmxlbmNvZGVkJ1xufTtcblxuZnVuY3Rpb24gc2V0Q29udGVudFR5cGVJZlVuc2V0KGhlYWRlcnMsIHZhbHVlKSB7XG4gIGlmICghdXRpbHMuaXNVbmRlZmluZWQoaGVhZGVycykgJiYgdXRpbHMuaXNVbmRlZmluZWQoaGVhZGVyc1snQ29udGVudC1UeXBlJ10pKSB7XG4gICAgaGVhZGVyc1snQ29udGVudC1UeXBlJ10gPSB2YWx1ZTtcbiAgfVxufVxuXG5mdW5jdGlvbiBnZXREZWZhdWx0QWRhcHRlcigpIHtcbiAgdmFyIGFkYXB0ZXI7XG4gIGlmICh0eXBlb2YgWE1MSHR0cFJlcXVlc3QgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgLy8gRm9yIGJyb3dzZXJzIHVzZSBYSFIgYWRhcHRlclxuICAgIGFkYXB0ZXIgPSByZXF1aXJlKCcuLi9hZGFwdGVycy94aHInKTtcbiAgfSBlbHNlIGlmICh0eXBlb2YgcHJvY2VzcyAhPT0gJ3VuZGVmaW5lZCcgJiYgT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKHByb2Nlc3MpID09PSAnW29iamVjdCBwcm9jZXNzXScpIHtcbiAgICAvLyBGb3Igbm9kZSB1c2UgSFRUUCBhZGFwdGVyXG4gICAgYWRhcHRlciA9IHJlcXVpcmUoJy4uL2FkYXB0ZXJzL2h0dHAnKTtcbiAgfVxuICByZXR1cm4gYWRhcHRlcjtcbn1cblxuZnVuY3Rpb24gc3RyaW5naWZ5U2FmZWx5KHJhd1ZhbHVlLCBwYXJzZXIsIGVuY29kZXIpIHtcbiAgaWYgKHV0aWxzLmlzU3RyaW5nKHJhd1ZhbHVlKSkge1xuICAgIHRyeSB7XG4gICAgICAocGFyc2VyIHx8IEpTT04ucGFyc2UpKHJhd1ZhbHVlKTtcbiAgICAgIHJldHVybiB1dGlscy50cmltKHJhd1ZhbHVlKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBpZiAoZS5uYW1lICE9PSAnU3ludGF4RXJyb3InKSB7XG4gICAgICAgIHRocm93IGU7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIChlbmNvZGVyIHx8IEpTT04uc3RyaW5naWZ5KShyYXdWYWx1ZSk7XG59XG5cbnZhciBkZWZhdWx0cyA9IHtcblxuICB0cmFuc2l0aW9uYWw6IHRyYW5zaXRpb25hbERlZmF1bHRzLFxuXG4gIGFkYXB0ZXI6IGdldERlZmF1bHRBZGFwdGVyKCksXG5cbiAgdHJhbnNmb3JtUmVxdWVzdDogW2Z1bmN0aW9uIHRyYW5zZm9ybVJlcXVlc3QoZGF0YSwgaGVhZGVycykge1xuICAgIG5vcm1hbGl6ZUhlYWRlck5hbWUoaGVhZGVycywgJ0FjY2VwdCcpO1xuICAgIG5vcm1hbGl6ZUhlYWRlck5hbWUoaGVhZGVycywgJ0NvbnRlbnQtVHlwZScpO1xuXG4gICAgaWYgKHV0aWxzLmlzRm9ybURhdGEoZGF0YSkgfHxcbiAgICAgIHV0aWxzLmlzQXJyYXlCdWZmZXIoZGF0YSkgfHxcbiAgICAgIHV0aWxzLmlzQnVmZmVyKGRhdGEpIHx8XG4gICAgICB1dGlscy5pc1N0cmVhbShkYXRhKSB8fFxuICAgICAgdXRpbHMuaXNGaWxlKGRhdGEpIHx8XG4gICAgICB1dGlscy5pc0Jsb2IoZGF0YSlcbiAgICApIHtcbiAgICAgIHJldHVybiBkYXRhO1xuICAgIH1cbiAgICBpZiAodXRpbHMuaXNBcnJheUJ1ZmZlclZpZXcoZGF0YSkpIHtcbiAgICAgIHJldHVybiBkYXRhLmJ1ZmZlcjtcbiAgICB9XG4gICAgaWYgKHV0aWxzLmlzVVJMU2VhcmNoUGFyYW1zKGRhdGEpKSB7XG4gICAgICBzZXRDb250ZW50VHlwZUlmVW5zZXQoaGVhZGVycywgJ2FwcGxpY2F0aW9uL3gtd3d3LWZvcm0tdXJsZW5jb2RlZDtjaGFyc2V0PXV0Zi04Jyk7XG4gICAgICByZXR1cm4gZGF0YS50b1N0cmluZygpO1xuICAgIH1cbiAgICBpZiAodXRpbHMuaXNPYmplY3QoZGF0YSkgfHwgKGhlYWRlcnMgJiYgaGVhZGVyc1snQ29udGVudC1UeXBlJ10gPT09ICdhcHBsaWNhdGlvbi9qc29uJykpIHtcbiAgICAgIHNldENvbnRlbnRUeXBlSWZVbnNldChoZWFkZXJzLCAnYXBwbGljYXRpb24vanNvbicpO1xuICAgICAgcmV0dXJuIHN0cmluZ2lmeVNhZmVseShkYXRhKTtcbiAgICB9XG4gICAgcmV0dXJuIGRhdGE7XG4gIH1dLFxuXG4gIHRyYW5zZm9ybVJlc3BvbnNlOiBbZnVuY3Rpb24gdHJhbnNmb3JtUmVzcG9uc2UoZGF0YSkge1xuICAgIHZhciB0cmFuc2l0aW9uYWwgPSB0aGlzLnRyYW5zaXRpb25hbCB8fCBkZWZhdWx0cy50cmFuc2l0aW9uYWw7XG4gICAgdmFyIHNpbGVudEpTT05QYXJzaW5nID0gdHJhbnNpdGlvbmFsICYmIHRyYW5zaXRpb25hbC5zaWxlbnRKU09OUGFyc2luZztcbiAgICB2YXIgZm9yY2VkSlNPTlBhcnNpbmcgPSB0cmFuc2l0aW9uYWwgJiYgdHJhbnNpdGlvbmFsLmZvcmNlZEpTT05QYXJzaW5nO1xuICAgIHZhciBzdHJpY3RKU09OUGFyc2luZyA9ICFzaWxlbnRKU09OUGFyc2luZyAmJiB0aGlzLnJlc3BvbnNlVHlwZSA9PT0gJ2pzb24nO1xuXG4gICAgaWYgKHN0cmljdEpTT05QYXJzaW5nIHx8IChmb3JjZWRKU09OUGFyc2luZyAmJiB1dGlscy5pc1N0cmluZyhkYXRhKSAmJiBkYXRhLmxlbmd0aCkpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIHJldHVybiBKU09OLnBhcnNlKGRhdGEpO1xuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICBpZiAoc3RyaWN0SlNPTlBhcnNpbmcpIHtcbiAgICAgICAgICBpZiAoZS5uYW1lID09PSAnU3ludGF4RXJyb3InKSB7XG4gICAgICAgICAgICB0aHJvdyBlbmhhbmNlRXJyb3IoZSwgdGhpcywgJ0VfSlNPTl9QQVJTRScpO1xuICAgICAgICAgIH1cbiAgICAgICAgICB0aHJvdyBlO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIGRhdGE7XG4gIH1dLFxuXG4gIC8qKlxuICAgKiBBIHRpbWVvdXQgaW4gbWlsbGlzZWNvbmRzIHRvIGFib3J0IGEgcmVxdWVzdC4gSWYgc2V0IHRvIDAgKGRlZmF1bHQpIGFcbiAgICogdGltZW91dCBpcyBub3QgY3JlYXRlZC5cbiAgICovXG4gIHRpbWVvdXQ6IDAsXG5cbiAgeHNyZkNvb2tpZU5hbWU6ICdYU1JGLVRPS0VOJyxcbiAgeHNyZkhlYWRlck5hbWU6ICdYLVhTUkYtVE9LRU4nLFxuXG4gIG1heENvbnRlbnRMZW5ndGg6IC0xLFxuICBtYXhCb2R5TGVuZ3RoOiAtMSxcblxuICB2YWxpZGF0ZVN0YXR1czogZnVuY3Rpb24gdmFsaWRhdGVTdGF0dXMoc3RhdHVzKSB7XG4gICAgcmV0dXJuIHN0YXR1cyA+PSAyMDAgJiYgc3RhdHVzIDwgMzAwO1xuICB9LFxuXG4gIGhlYWRlcnM6IHtcbiAgICBjb21tb246IHtcbiAgICAgICdBY2NlcHQnOiAnYXBwbGljYXRpb24vanNvbiwgdGV4dC9wbGFpbiwgKi8qJ1xuICAgIH1cbiAgfVxufTtcblxudXRpbHMuZm9yRWFjaChbJ2RlbGV0ZScsICdnZXQnLCAnaGVhZCddLCBmdW5jdGlvbiBmb3JFYWNoTWV0aG9kTm9EYXRhKG1ldGhvZCkge1xuICBkZWZhdWx0cy5oZWFkZXJzW21ldGhvZF0gPSB7fTtcbn0pO1xuXG51dGlscy5mb3JFYWNoKFsncG9zdCcsICdwdXQnLCAncGF0Y2gnXSwgZnVuY3Rpb24gZm9yRWFjaE1ldGhvZFdpdGhEYXRhKG1ldGhvZCkge1xuICBkZWZhdWx0cy5oZWFkZXJzW21ldGhvZF0gPSB1dGlscy5tZXJnZShERUZBVUxUX0NPTlRFTlRfVFlQRSk7XG59KTtcblxubW9kdWxlLmV4cG9ydHMgPSBkZWZhdWx0cztcbiIsIid1c2Ugc3RyaWN0JztcblxubW9kdWxlLmV4cG9ydHMgPSB7XG4gIHNpbGVudEpTT05QYXJzaW5nOiB0cnVlLFxuICBmb3JjZWRKU09OUGFyc2luZzogdHJ1ZSxcbiAgY2xhcmlmeVRpbWVvdXRFcnJvcjogZmFsc2Vcbn07XG4iLCJtb2R1bGUuZXhwb3J0cyA9IHtcbiAgXCJ2ZXJzaW9uXCI6IFwiMC4yNi4xXCJcbn07IiwiJ3VzZSBzdHJpY3QnO1xuXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIGJpbmQoZm4sIHRoaXNBcmcpIHtcbiAgcmV0dXJuIGZ1bmN0aW9uIHdyYXAoKSB7XG4gICAgdmFyIGFyZ3MgPSBuZXcgQXJyYXkoYXJndW1lbnRzLmxlbmd0aCk7XG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCBhcmdzLmxlbmd0aDsgaSsrKSB7XG4gICAgICBhcmdzW2ldID0gYXJndW1lbnRzW2ldO1xuICAgIH1cbiAgICByZXR1cm4gZm4uYXBwbHkodGhpc0FyZywgYXJncyk7XG4gIH07XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG52YXIgdXRpbHMgPSByZXF1aXJlKCcuLy4uL3V0aWxzJyk7XG5cbmZ1bmN0aW9uIGVuY29kZSh2YWwpIHtcbiAgcmV0dXJuIGVuY29kZVVSSUNvbXBvbmVudCh2YWwpLlxuICAgIHJlcGxhY2UoLyUzQS9naSwgJzonKS5cbiAgICByZXBsYWNlKC8lMjQvZywgJyQnKS5cbiAgICByZXBsYWNlKC8lMkMvZ2ksICcsJykuXG4gICAgcmVwbGFjZSgvJTIwL2csICcrJykuXG4gICAgcmVwbGFjZSgvJTVCL2dpLCAnWycpLlxuICAgIHJlcGxhY2UoLyU1RC9naSwgJ10nKTtcbn1cblxuLyoqXG4gKiBCdWlsZCBhIFVSTCBieSBhcHBlbmRpbmcgcGFyYW1zIHRvIHRoZSBlbmRcbiAqXG4gKiBAcGFyYW0ge3N0cmluZ30gdXJsIFRoZSBiYXNlIG9mIHRoZSB1cmwgKGUuZy4sIGh0dHA6Ly93d3cuZ29vZ2xlLmNvbSlcbiAqIEBwYXJhbSB7b2JqZWN0fSBbcGFyYW1zXSBUaGUgcGFyYW1zIHRvIGJlIGFwcGVuZGVkXG4gKiBAcmV0dXJucyB7c3RyaW5nfSBUaGUgZm9ybWF0dGVkIHVybFxuICovXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIGJ1aWxkVVJMKHVybCwgcGFyYW1zLCBwYXJhbXNTZXJpYWxpemVyKSB7XG4gIC8qZXNsaW50IG5vLXBhcmFtLXJlYXNzaWduOjAqL1xuICBpZiAoIXBhcmFtcykge1xuICAgIHJldHVybiB1cmw7XG4gIH1cblxuICB2YXIgc2VyaWFsaXplZFBhcmFtcztcbiAgaWYgKHBhcmFtc1NlcmlhbGl6ZXIpIHtcbiAgICBzZXJpYWxpemVkUGFyYW1zID0gcGFyYW1zU2VyaWFsaXplcihwYXJhbXMpO1xuICB9IGVsc2UgaWYgKHV0aWxzLmlzVVJMU2VhcmNoUGFyYW1zKHBhcmFtcykpIHtcbiAgICBzZXJpYWxpemVkUGFyYW1zID0gcGFyYW1zLnRvU3RyaW5nKCk7XG4gIH0gZWxzZSB7XG4gICAgdmFyIHBhcnRzID0gW107XG5cbiAgICB1dGlscy5mb3JFYWNoKHBhcmFtcywgZnVuY3Rpb24gc2VyaWFsaXplKHZhbCwga2V5KSB7XG4gICAgICBpZiAodmFsID09PSBudWxsIHx8IHR5cGVvZiB2YWwgPT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgaWYgKHV0aWxzLmlzQXJyYXkodmFsKSkge1xuICAgICAgICBrZXkgPSBrZXkgKyAnW10nO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdmFsID0gW3ZhbF07XG4gICAgICB9XG5cbiAgICAgIHV0aWxzLmZvckVhY2godmFsLCBmdW5jdGlvbiBwYXJzZVZhbHVlKHYpIHtcbiAgICAgICAgaWYgKHV0aWxzLmlzRGF0ZSh2KSkge1xuICAgICAgICAgIHYgPSB2LnRvSVNPU3RyaW5nKCk7XG4gICAgICAgIH0gZWxzZSBpZiAodXRpbHMuaXNPYmplY3QodikpIHtcbiAgICAgICAgICB2ID0gSlNPTi5zdHJpbmdpZnkodik7XG4gICAgICAgIH1cbiAgICAgICAgcGFydHMucHVzaChlbmNvZGUoa2V5KSArICc9JyArIGVuY29kZSh2KSk7XG4gICAgICB9KTtcbiAgICB9KTtcblxuICAgIHNlcmlhbGl6ZWRQYXJhbXMgPSBwYXJ0cy5qb2luKCcmJyk7XG4gIH1cblxuICBpZiAoc2VyaWFsaXplZFBhcmFtcykge1xuICAgIHZhciBoYXNobWFya0luZGV4ID0gdXJsLmluZGV4T2YoJyMnKTtcbiAgICBpZiAoaGFzaG1hcmtJbmRleCAhPT0gLTEpIHtcbiAgICAgIHVybCA9IHVybC5zbGljZSgwLCBoYXNobWFya0luZGV4KTtcbiAgICB9XG5cbiAgICB1cmwgKz0gKHVybC5pbmRleE9mKCc/JykgPT09IC0xID8gJz8nIDogJyYnKSArIHNlcmlhbGl6ZWRQYXJhbXM7XG4gIH1cblxuICByZXR1cm4gdXJsO1xufTtcbiIsIid1c2Ugc3RyaWN0JztcblxuLyoqXG4gKiBDcmVhdGVzIGEgbmV3IFVSTCBieSBjb21iaW5pbmcgdGhlIHNwZWNpZmllZCBVUkxzXG4gKlxuICogQHBhcmFtIHtzdHJpbmd9IGJhc2VVUkwgVGhlIGJhc2UgVVJMXG4gKiBAcGFyYW0ge3N0cmluZ30gcmVsYXRpdmVVUkwgVGhlIHJlbGF0aXZlIFVSTFxuICogQHJldHVybnMge3N0cmluZ30gVGhlIGNvbWJpbmVkIFVSTFxuICovXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIGNvbWJpbmVVUkxzKGJhc2VVUkwsIHJlbGF0aXZlVVJMKSB7XG4gIHJldHVybiByZWxhdGl2ZVVSTFxuICAgID8gYmFzZVVSTC5yZXBsYWNlKC9cXC8rJC8sICcnKSArICcvJyArIHJlbGF0aXZlVVJMLnJlcGxhY2UoL15cXC8rLywgJycpXG4gICAgOiBiYXNlVVJMO1xufTtcbiIsIid1c2Ugc3RyaWN0JztcblxudmFyIHV0aWxzID0gcmVxdWlyZSgnLi8uLi91dGlscycpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IChcbiAgdXRpbHMuaXNTdGFuZGFyZEJyb3dzZXJFbnYoKSA/XG5cbiAgLy8gU3RhbmRhcmQgYnJvd3NlciBlbnZzIHN1cHBvcnQgZG9jdW1lbnQuY29va2llXG4gICAgKGZ1bmN0aW9uIHN0YW5kYXJkQnJvd3NlckVudigpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHdyaXRlOiBmdW5jdGlvbiB3cml0ZShuYW1lLCB2YWx1ZSwgZXhwaXJlcywgcGF0aCwgZG9tYWluLCBzZWN1cmUpIHtcbiAgICAgICAgICB2YXIgY29va2llID0gW107XG4gICAgICAgICAgY29va2llLnB1c2gobmFtZSArICc9JyArIGVuY29kZVVSSUNvbXBvbmVudCh2YWx1ZSkpO1xuXG4gICAgICAgICAgaWYgKHV0aWxzLmlzTnVtYmVyKGV4cGlyZXMpKSB7XG4gICAgICAgICAgICBjb29raWUucHVzaCgnZXhwaXJlcz0nICsgbmV3IERhdGUoZXhwaXJlcykudG9HTVRTdHJpbmcoKSk7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgaWYgKHV0aWxzLmlzU3RyaW5nKHBhdGgpKSB7XG4gICAgICAgICAgICBjb29raWUucHVzaCgncGF0aD0nICsgcGF0aCk7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgaWYgKHV0aWxzLmlzU3RyaW5nKGRvbWFpbikpIHtcbiAgICAgICAgICAgIGNvb2tpZS5wdXNoKCdkb21haW49JyArIGRvbWFpbik7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgaWYgKHNlY3VyZSA9PT0gdHJ1ZSkge1xuICAgICAgICAgICAgY29va2llLnB1c2goJ3NlY3VyZScpO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIGRvY3VtZW50LmNvb2tpZSA9IGNvb2tpZS5qb2luKCc7ICcpO1xuICAgICAgICB9LFxuXG4gICAgICAgIHJlYWQ6IGZ1bmN0aW9uIHJlYWQobmFtZSkge1xuICAgICAgICAgIHZhciBtYXRjaCA9IGRvY3VtZW50LmNvb2tpZS5tYXRjaChuZXcgUmVnRXhwKCcoXnw7XFxcXHMqKSgnICsgbmFtZSArICcpPShbXjtdKiknKSk7XG4gICAgICAgICAgcmV0dXJuIChtYXRjaCA/IGRlY29kZVVSSUNvbXBvbmVudChtYXRjaFszXSkgOiBudWxsKTtcbiAgICAgICAgfSxcblxuICAgICAgICByZW1vdmU6IGZ1bmN0aW9uIHJlbW92ZShuYW1lKSB7XG4gICAgICAgICAgdGhpcy53cml0ZShuYW1lLCAnJywgRGF0ZS5ub3coKSAtIDg2NDAwMDAwKTtcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICB9KSgpIDpcblxuICAvLyBOb24gc3RhbmRhcmQgYnJvd3NlciBlbnYgKHdlYiB3b3JrZXJzLCByZWFjdC1uYXRpdmUpIGxhY2sgbmVlZGVkIHN1cHBvcnQuXG4gICAgKGZ1bmN0aW9uIG5vblN0YW5kYXJkQnJvd3NlckVudigpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHdyaXRlOiBmdW5jdGlvbiB3cml0ZSgpIHt9LFxuICAgICAgICByZWFkOiBmdW5jdGlvbiByZWFkKCkgeyByZXR1cm4gbnVsbDsgfSxcbiAgICAgICAgcmVtb3ZlOiBmdW5jdGlvbiByZW1vdmUoKSB7fVxuICAgICAgfTtcbiAgICB9KSgpXG4pO1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG4vKipcbiAqIERldGVybWluZXMgd2hldGhlciB0aGUgc3BlY2lmaWVkIFVSTCBpcyBhYnNvbHV0ZVxuICpcbiAqIEBwYXJhbSB7c3RyaW5nfSB1cmwgVGhlIFVSTCB0byB0ZXN0XG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB0aGUgc3BlY2lmaWVkIFVSTCBpcyBhYnNvbHV0ZSwgb3RoZXJ3aXNlIGZhbHNlXG4gKi9cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gaXNBYnNvbHV0ZVVSTCh1cmwpIHtcbiAgLy8gQSBVUkwgaXMgY29uc2lkZXJlZCBhYnNvbHV0ZSBpZiBpdCBiZWdpbnMgd2l0aCBcIjxzY2hlbWU+Oi8vXCIgb3IgXCIvL1wiIChwcm90b2NvbC1yZWxhdGl2ZSBVUkwpLlxuICAvLyBSRkMgMzk4NiBkZWZpbmVzIHNjaGVtZSBuYW1lIGFzIGEgc2VxdWVuY2Ugb2YgY2hhcmFjdGVycyBiZWdpbm5pbmcgd2l0aCBhIGxldHRlciBhbmQgZm9sbG93ZWRcbiAgLy8gYnkgYW55IGNvbWJpbmF0aW9uIG9mIGxldHRlcnMsIGRpZ2l0cywgcGx1cywgcGVyaW9kLCBvciBoeXBoZW4uXG4gIHJldHVybiAvXihbYS16XVthLXpcXGQrXFwtLl0qOik/XFwvXFwvL2kudGVzdCh1cmwpO1xufTtcbiIsIid1c2Ugc3RyaWN0JztcblxudmFyIHV0aWxzID0gcmVxdWlyZSgnLi8uLi91dGlscycpO1xuXG4vKipcbiAqIERldGVybWluZXMgd2hldGhlciB0aGUgcGF5bG9hZCBpcyBhbiBlcnJvciB0aHJvd24gYnkgQXhpb3NcbiAqXG4gKiBAcGFyYW0geyp9IHBheWxvYWQgVGhlIHZhbHVlIHRvIHRlc3RcbiAqIEByZXR1cm5zIHtib29sZWFufSBUcnVlIGlmIHRoZSBwYXlsb2FkIGlzIGFuIGVycm9yIHRocm93biBieSBBeGlvcywgb3RoZXJ3aXNlIGZhbHNlXG4gKi9cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gaXNBeGlvc0Vycm9yKHBheWxvYWQpIHtcbiAgcmV0dXJuIHV0aWxzLmlzT2JqZWN0KHBheWxvYWQpICYmIChwYXlsb2FkLmlzQXhpb3NFcnJvciA9PT0gdHJ1ZSk7XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG52YXIgdXRpbHMgPSByZXF1aXJlKCcuLy4uL3V0aWxzJyk7XG5cbm1vZHVsZS5leHBvcnRzID0gKFxuICB1dGlscy5pc1N0YW5kYXJkQnJvd3NlckVudigpID9cblxuICAvLyBTdGFuZGFyZCBicm93c2VyIGVudnMgaGF2ZSBmdWxsIHN1cHBvcnQgb2YgdGhlIEFQSXMgbmVlZGVkIHRvIHRlc3RcbiAgLy8gd2hldGhlciB0aGUgcmVxdWVzdCBVUkwgaXMgb2YgdGhlIHNhbWUgb3JpZ2luIGFzIGN1cnJlbnQgbG9jYXRpb24uXG4gICAgKGZ1bmN0aW9uIHN0YW5kYXJkQnJvd3NlckVudigpIHtcbiAgICAgIHZhciBtc2llID0gLyhtc2llfHRyaWRlbnQpL2kudGVzdChuYXZpZ2F0b3IudXNlckFnZW50KTtcbiAgICAgIHZhciB1cmxQYXJzaW5nTm9kZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKTtcbiAgICAgIHZhciBvcmlnaW5VUkw7XG5cbiAgICAgIC8qKlxuICAgICogUGFyc2UgYSBVUkwgdG8gZGlzY292ZXIgaXQncyBjb21wb25lbnRzXG4gICAgKlxuICAgICogQHBhcmFtIHtTdHJpbmd9IHVybCBUaGUgVVJMIHRvIGJlIHBhcnNlZFxuICAgICogQHJldHVybnMge09iamVjdH1cbiAgICAqL1xuICAgICAgZnVuY3Rpb24gcmVzb2x2ZVVSTCh1cmwpIHtcbiAgICAgICAgdmFyIGhyZWYgPSB1cmw7XG5cbiAgICAgICAgaWYgKG1zaWUpIHtcbiAgICAgICAgLy8gSUUgbmVlZHMgYXR0cmlidXRlIHNldCB0d2ljZSB0byBub3JtYWxpemUgcHJvcGVydGllc1xuICAgICAgICAgIHVybFBhcnNpbmdOb2RlLnNldEF0dHJpYnV0ZSgnaHJlZicsIGhyZWYpO1xuICAgICAgICAgIGhyZWYgPSB1cmxQYXJzaW5nTm9kZS5ocmVmO1xuICAgICAgICB9XG5cbiAgICAgICAgdXJsUGFyc2luZ05vZGUuc2V0QXR0cmlidXRlKCdocmVmJywgaHJlZik7XG5cbiAgICAgICAgLy8gdXJsUGFyc2luZ05vZGUgcHJvdmlkZXMgdGhlIFVybFV0aWxzIGludGVyZmFjZSAtIGh0dHA6Ly91cmwuc3BlYy53aGF0d2cub3JnLyN1cmx1dGlsc1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIGhyZWY6IHVybFBhcnNpbmdOb2RlLmhyZWYsXG4gICAgICAgICAgcHJvdG9jb2w6IHVybFBhcnNpbmdOb2RlLnByb3RvY29sID8gdXJsUGFyc2luZ05vZGUucHJvdG9jb2wucmVwbGFjZSgvOiQvLCAnJykgOiAnJyxcbiAgICAgICAgICBob3N0OiB1cmxQYXJzaW5nTm9kZS5ob3N0LFxuICAgICAgICAgIHNlYXJjaDogdXJsUGFyc2luZ05vZGUuc2VhcmNoID8gdXJsUGFyc2luZ05vZGUuc2VhcmNoLnJlcGxhY2UoL15cXD8vLCAnJykgOiAnJyxcbiAgICAgICAgICBoYXNoOiB1cmxQYXJzaW5nTm9kZS5oYXNoID8gdXJsUGFyc2luZ05vZGUuaGFzaC5yZXBsYWNlKC9eIy8sICcnKSA6ICcnLFxuICAgICAgICAgIGhvc3RuYW1lOiB1cmxQYXJzaW5nTm9kZS5ob3N0bmFtZSxcbiAgICAgICAgICBwb3J0OiB1cmxQYXJzaW5nTm9kZS5wb3J0LFxuICAgICAgICAgIHBhdGhuYW1lOiAodXJsUGFyc2luZ05vZGUucGF0aG5hbWUuY2hhckF0KDApID09PSAnLycpID9cbiAgICAgICAgICAgIHVybFBhcnNpbmdOb2RlLnBhdGhuYW1lIDpcbiAgICAgICAgICAgICcvJyArIHVybFBhcnNpbmdOb2RlLnBhdGhuYW1lXG4gICAgICAgIH07XG4gICAgICB9XG5cbiAgICAgIG9yaWdpblVSTCA9IHJlc29sdmVVUkwod2luZG93LmxvY2F0aW9uLmhyZWYpO1xuXG4gICAgICAvKipcbiAgICAqIERldGVybWluZSBpZiBhIFVSTCBzaGFyZXMgdGhlIHNhbWUgb3JpZ2luIGFzIHRoZSBjdXJyZW50IGxvY2F0aW9uXG4gICAgKlxuICAgICogQHBhcmFtIHtTdHJpbmd9IHJlcXVlc3RVUkwgVGhlIFVSTCB0byB0ZXN0XG4gICAgKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiBVUkwgc2hhcmVzIHRoZSBzYW1lIG9yaWdpbiwgb3RoZXJ3aXNlIGZhbHNlXG4gICAgKi9cbiAgICAgIHJldHVybiBmdW5jdGlvbiBpc1VSTFNhbWVPcmlnaW4ocmVxdWVzdFVSTCkge1xuICAgICAgICB2YXIgcGFyc2VkID0gKHV0aWxzLmlzU3RyaW5nKHJlcXVlc3RVUkwpKSA/IHJlc29sdmVVUkwocmVxdWVzdFVSTCkgOiByZXF1ZXN0VVJMO1xuICAgICAgICByZXR1cm4gKHBhcnNlZC5wcm90b2NvbCA9PT0gb3JpZ2luVVJMLnByb3RvY29sICYmXG4gICAgICAgICAgICBwYXJzZWQuaG9zdCA9PT0gb3JpZ2luVVJMLmhvc3QpO1xuICAgICAgfTtcbiAgICB9KSgpIDpcblxuICAvLyBOb24gc3RhbmRhcmQgYnJvd3NlciBlbnZzICh3ZWIgd29ya2VycywgcmVhY3QtbmF0aXZlKSBsYWNrIG5lZWRlZCBzdXBwb3J0LlxuICAgIChmdW5jdGlvbiBub25TdGFuZGFyZEJyb3dzZXJFbnYoKSB7XG4gICAgICByZXR1cm4gZnVuY3Rpb24gaXNVUkxTYW1lT3JpZ2luKCkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH07XG4gICAgfSkoKVxuKTtcbiIsIid1c2Ugc3RyaWN0JztcblxudmFyIHV0aWxzID0gcmVxdWlyZSgnLi4vdXRpbHMnKTtcblxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiBub3JtYWxpemVIZWFkZXJOYW1lKGhlYWRlcnMsIG5vcm1hbGl6ZWROYW1lKSB7XG4gIHV0aWxzLmZvckVhY2goaGVhZGVycywgZnVuY3Rpb24gcHJvY2Vzc0hlYWRlcih2YWx1ZSwgbmFtZSkge1xuICAgIGlmIChuYW1lICE9PSBub3JtYWxpemVkTmFtZSAmJiBuYW1lLnRvVXBwZXJDYXNlKCkgPT09IG5vcm1hbGl6ZWROYW1lLnRvVXBwZXJDYXNlKCkpIHtcbiAgICAgIGhlYWRlcnNbbm9ybWFsaXplZE5hbWVdID0gdmFsdWU7XG4gICAgICBkZWxldGUgaGVhZGVyc1tuYW1lXTtcbiAgICB9XG4gIH0pO1xufTtcbiIsIid1c2Ugc3RyaWN0JztcblxudmFyIHV0aWxzID0gcmVxdWlyZSgnLi8uLi91dGlscycpO1xuXG4vLyBIZWFkZXJzIHdob3NlIGR1cGxpY2F0ZXMgYXJlIGlnbm9yZWQgYnkgbm9kZVxuLy8gYy5mLiBodHRwczovL25vZGVqcy5vcmcvYXBpL2h0dHAuaHRtbCNodHRwX21lc3NhZ2VfaGVhZGVyc1xudmFyIGlnbm9yZUR1cGxpY2F0ZU9mID0gW1xuICAnYWdlJywgJ2F1dGhvcml6YXRpb24nLCAnY29udGVudC1sZW5ndGgnLCAnY29udGVudC10eXBlJywgJ2V0YWcnLFxuICAnZXhwaXJlcycsICdmcm9tJywgJ2hvc3QnLCAnaWYtbW9kaWZpZWQtc2luY2UnLCAnaWYtdW5tb2RpZmllZC1zaW5jZScsXG4gICdsYXN0LW1vZGlmaWVkJywgJ2xvY2F0aW9uJywgJ21heC1mb3J3YXJkcycsICdwcm94eS1hdXRob3JpemF0aW9uJyxcbiAgJ3JlZmVyZXInLCAncmV0cnktYWZ0ZXInLCAndXNlci1hZ2VudCdcbl07XG5cbi8qKlxuICogUGFyc2UgaGVhZGVycyBpbnRvIGFuIG9iamVjdFxuICpcbiAqIGBgYFxuICogRGF0ZTogV2VkLCAyNyBBdWcgMjAxNCAwODo1ODo0OSBHTVRcbiAqIENvbnRlbnQtVHlwZTogYXBwbGljYXRpb24vanNvblxuICogQ29ubmVjdGlvbjoga2VlcC1hbGl2ZVxuICogVHJhbnNmZXItRW5jb2Rpbmc6IGNodW5rZWRcbiAqIGBgYFxuICpcbiAqIEBwYXJhbSB7U3RyaW5nfSBoZWFkZXJzIEhlYWRlcnMgbmVlZGluZyB0byBiZSBwYXJzZWRcbiAqIEByZXR1cm5zIHtPYmplY3R9IEhlYWRlcnMgcGFyc2VkIGludG8gYW4gb2JqZWN0XG4gKi9cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gcGFyc2VIZWFkZXJzKGhlYWRlcnMpIHtcbiAgdmFyIHBhcnNlZCA9IHt9O1xuICB2YXIga2V5O1xuICB2YXIgdmFsO1xuICB2YXIgaTtcblxuICBpZiAoIWhlYWRlcnMpIHsgcmV0dXJuIHBhcnNlZDsgfVxuXG4gIHV0aWxzLmZvckVhY2goaGVhZGVycy5zcGxpdCgnXFxuJyksIGZ1bmN0aW9uIHBhcnNlcihsaW5lKSB7XG4gICAgaSA9IGxpbmUuaW5kZXhPZignOicpO1xuICAgIGtleSA9IHV0aWxzLnRyaW0obGluZS5zdWJzdHIoMCwgaSkpLnRvTG93ZXJDYXNlKCk7XG4gICAgdmFsID0gdXRpbHMudHJpbShsaW5lLnN1YnN0cihpICsgMSkpO1xuXG4gICAgaWYgKGtleSkge1xuICAgICAgaWYgKHBhcnNlZFtrZXldICYmIGlnbm9yZUR1cGxpY2F0ZU9mLmluZGV4T2Yoa2V5KSA+PSAwKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmIChrZXkgPT09ICdzZXQtY29va2llJykge1xuICAgICAgICBwYXJzZWRba2V5XSA9IChwYXJzZWRba2V5XSA/IHBhcnNlZFtrZXldIDogW10pLmNvbmNhdChbdmFsXSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBwYXJzZWRba2V5XSA9IHBhcnNlZFtrZXldID8gcGFyc2VkW2tleV0gKyAnLCAnICsgdmFsIDogdmFsO1xuICAgICAgfVxuICAgIH1cbiAgfSk7XG5cbiAgcmV0dXJuIHBhcnNlZDtcbn07XG4iLCIndXNlIHN0cmljdCc7XG5cbi8qKlxuICogU3ludGFjdGljIHN1Z2FyIGZvciBpbnZva2luZyBhIGZ1bmN0aW9uIGFuZCBleHBhbmRpbmcgYW4gYXJyYXkgZm9yIGFyZ3VtZW50cy5cbiAqXG4gKiBDb21tb24gdXNlIGNhc2Ugd291bGQgYmUgdG8gdXNlIGBGdW5jdGlvbi5wcm90b3R5cGUuYXBwbHlgLlxuICpcbiAqICBgYGBqc1xuICogIGZ1bmN0aW9uIGYoeCwgeSwgeikge31cbiAqICB2YXIgYXJncyA9IFsxLCAyLCAzXTtcbiAqICBmLmFwcGx5KG51bGwsIGFyZ3MpO1xuICogIGBgYFxuICpcbiAqIFdpdGggYHNwcmVhZGAgdGhpcyBleGFtcGxlIGNhbiBiZSByZS13cml0dGVuLlxuICpcbiAqICBgYGBqc1xuICogIHNwcmVhZChmdW5jdGlvbih4LCB5LCB6KSB7fSkoWzEsIDIsIDNdKTtcbiAqICBgYGBcbiAqXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSBjYWxsYmFja1xuICogQHJldHVybnMge0Z1bmN0aW9ufVxuICovXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIHNwcmVhZChjYWxsYmFjaykge1xuICByZXR1cm4gZnVuY3Rpb24gd3JhcChhcnIpIHtcbiAgICByZXR1cm4gY2FsbGJhY2suYXBwbHkobnVsbCwgYXJyKTtcbiAgfTtcbn07XG4iLCIndXNlIHN0cmljdCc7XG5cbnZhciBWRVJTSU9OID0gcmVxdWlyZSgnLi4vZW52L2RhdGEnKS52ZXJzaW9uO1xuXG52YXIgdmFsaWRhdG9ycyA9IHt9O1xuXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZnVuYy1uYW1lc1xuWydvYmplY3QnLCAnYm9vbGVhbicsICdudW1iZXInLCAnZnVuY3Rpb24nLCAnc3RyaW5nJywgJ3N5bWJvbCddLmZvckVhY2goZnVuY3Rpb24odHlwZSwgaSkge1xuICB2YWxpZGF0b3JzW3R5cGVdID0gZnVuY3Rpb24gdmFsaWRhdG9yKHRoaW5nKSB7XG4gICAgcmV0dXJuIHR5cGVvZiB0aGluZyA9PT0gdHlwZSB8fCAnYScgKyAoaSA8IDEgPyAnbiAnIDogJyAnKSArIHR5cGU7XG4gIH07XG59KTtcblxudmFyIGRlcHJlY2F0ZWRXYXJuaW5ncyA9IHt9O1xuXG4vKipcbiAqIFRyYW5zaXRpb25hbCBvcHRpb24gdmFsaWRhdG9yXG4gKiBAcGFyYW0ge2Z1bmN0aW9ufGJvb2xlYW4/fSB2YWxpZGF0b3IgLSBzZXQgdG8gZmFsc2UgaWYgdGhlIHRyYW5zaXRpb25hbCBvcHRpb24gaGFzIGJlZW4gcmVtb3ZlZFxuICogQHBhcmFtIHtzdHJpbmc/fSB2ZXJzaW9uIC0gZGVwcmVjYXRlZCB2ZXJzaW9uIC8gcmVtb3ZlZCBzaW5jZSB2ZXJzaW9uXG4gKiBAcGFyYW0ge3N0cmluZz99IG1lc3NhZ2UgLSBzb21lIG1lc3NhZ2Ugd2l0aCBhZGRpdGlvbmFsIGluZm9cbiAqIEByZXR1cm5zIHtmdW5jdGlvbn1cbiAqL1xudmFsaWRhdG9ycy50cmFuc2l0aW9uYWwgPSBmdW5jdGlvbiB0cmFuc2l0aW9uYWwodmFsaWRhdG9yLCB2ZXJzaW9uLCBtZXNzYWdlKSB7XG4gIGZ1bmN0aW9uIGZvcm1hdE1lc3NhZ2Uob3B0LCBkZXNjKSB7XG4gICAgcmV0dXJuICdbQXhpb3MgdicgKyBWRVJTSU9OICsgJ10gVHJhbnNpdGlvbmFsIG9wdGlvbiBcXCcnICsgb3B0ICsgJ1xcJycgKyBkZXNjICsgKG1lc3NhZ2UgPyAnLiAnICsgbWVzc2FnZSA6ICcnKTtcbiAgfVxuXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBmdW5jLW5hbWVzXG4gIHJldHVybiBmdW5jdGlvbih2YWx1ZSwgb3B0LCBvcHRzKSB7XG4gICAgaWYgKHZhbGlkYXRvciA9PT0gZmFsc2UpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihmb3JtYXRNZXNzYWdlKG9wdCwgJyBoYXMgYmVlbiByZW1vdmVkJyArICh2ZXJzaW9uID8gJyBpbiAnICsgdmVyc2lvbiA6ICcnKSkpO1xuICAgIH1cblxuICAgIGlmICh2ZXJzaW9uICYmICFkZXByZWNhdGVkV2FybmluZ3Nbb3B0XSkge1xuICAgICAgZGVwcmVjYXRlZFdhcm5pbmdzW29wdF0gPSB0cnVlO1xuICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLWNvbnNvbGVcbiAgICAgIGNvbnNvbGUud2FybihcbiAgICAgICAgZm9ybWF0TWVzc2FnZShcbiAgICAgICAgICBvcHQsXG4gICAgICAgICAgJyBoYXMgYmVlbiBkZXByZWNhdGVkIHNpbmNlIHYnICsgdmVyc2lvbiArICcgYW5kIHdpbGwgYmUgcmVtb3ZlZCBpbiB0aGUgbmVhciBmdXR1cmUnXG4gICAgICAgIClcbiAgICAgICk7XG4gICAgfVxuXG4gICAgcmV0dXJuIHZhbGlkYXRvciA/IHZhbGlkYXRvcih2YWx1ZSwgb3B0LCBvcHRzKSA6IHRydWU7XG4gIH07XG59O1xuXG4vKipcbiAqIEFzc2VydCBvYmplY3QncyBwcm9wZXJ0aWVzIHR5cGVcbiAqIEBwYXJhbSB7b2JqZWN0fSBvcHRpb25zXG4gKiBAcGFyYW0ge29iamVjdH0gc2NoZW1hXG4gKiBAcGFyYW0ge2Jvb2xlYW4/fSBhbGxvd1Vua25vd25cbiAqL1xuXG5mdW5jdGlvbiBhc3NlcnRPcHRpb25zKG9wdGlvbnMsIHNjaGVtYSwgYWxsb3dVbmtub3duKSB7XG4gIGlmICh0eXBlb2Ygb3B0aW9ucyAhPT0gJ29iamVjdCcpIHtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdvcHRpb25zIG11c3QgYmUgYW4gb2JqZWN0Jyk7XG4gIH1cbiAgdmFyIGtleXMgPSBPYmplY3Qua2V5cyhvcHRpb25zKTtcbiAgdmFyIGkgPSBrZXlzLmxlbmd0aDtcbiAgd2hpbGUgKGktLSA+IDApIHtcbiAgICB2YXIgb3B0ID0ga2V5c1tpXTtcbiAgICB2YXIgdmFsaWRhdG9yID0gc2NoZW1hW29wdF07XG4gICAgaWYgKHZhbGlkYXRvcikge1xuICAgICAgdmFyIHZhbHVlID0gb3B0aW9uc1tvcHRdO1xuICAgICAgdmFyIHJlc3VsdCA9IHZhbHVlID09PSB1bmRlZmluZWQgfHwgdmFsaWRhdG9yKHZhbHVlLCBvcHQsIG9wdGlvbnMpO1xuICAgICAgaWYgKHJlc3VsdCAhPT0gdHJ1ZSkge1xuICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdvcHRpb24gJyArIG9wdCArICcgbXVzdCBiZSAnICsgcmVzdWx0KTtcbiAgICAgIH1cbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBpZiAoYWxsb3dVbmtub3duICE9PSB0cnVlKSB7XG4gICAgICB0aHJvdyBFcnJvcignVW5rbm93biBvcHRpb24gJyArIG9wdCk7XG4gICAgfVxuICB9XG59XG5cbm1vZHVsZS5leHBvcnRzID0ge1xuICBhc3NlcnRPcHRpb25zOiBhc3NlcnRPcHRpb25zLFxuICB2YWxpZGF0b3JzOiB2YWxpZGF0b3JzXG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG52YXIgYmluZCA9IHJlcXVpcmUoJy4vaGVscGVycy9iaW5kJyk7XG5cbi8vIHV0aWxzIGlzIGEgbGlicmFyeSBvZiBnZW5lcmljIGhlbHBlciBmdW5jdGlvbnMgbm9uLXNwZWNpZmljIHRvIGF4aW9zXG5cbnZhciB0b1N0cmluZyA9IE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmc7XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYW4gQXJyYXlcbiAqXG4gKiBAcGFyYW0ge09iamVjdH0gdmFsIFRoZSB2YWx1ZSB0byB0ZXN0XG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBpcyBhbiBBcnJheSwgb3RoZXJ3aXNlIGZhbHNlXG4gKi9cbmZ1bmN0aW9uIGlzQXJyYXkodmFsKSB7XG4gIHJldHVybiBBcnJheS5pc0FycmF5KHZhbCk7XG59XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgdW5kZWZpbmVkXG4gKlxuICogQHBhcmFtIHtPYmplY3R9IHZhbCBUaGUgdmFsdWUgdG8gdGVzdFxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdGhlIHZhbHVlIGlzIHVuZGVmaW5lZCwgb3RoZXJ3aXNlIGZhbHNlXG4gKi9cbmZ1bmN0aW9uIGlzVW5kZWZpbmVkKHZhbCkge1xuICByZXR1cm4gdHlwZW9mIHZhbCA9PT0gJ3VuZGVmaW5lZCc7XG59XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBCdWZmZXJcbiAqXG4gKiBAcGFyYW0ge09iamVjdH0gdmFsIFRoZSB2YWx1ZSB0byB0ZXN0XG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBpcyBhIEJ1ZmZlciwgb3RoZXJ3aXNlIGZhbHNlXG4gKi9cbmZ1bmN0aW9uIGlzQnVmZmVyKHZhbCkge1xuICByZXR1cm4gdmFsICE9PSBudWxsICYmICFpc1VuZGVmaW5lZCh2YWwpICYmIHZhbC5jb25zdHJ1Y3RvciAhPT0gbnVsbCAmJiAhaXNVbmRlZmluZWQodmFsLmNvbnN0cnVjdG9yKVxuICAgICYmIHR5cGVvZiB2YWwuY29uc3RydWN0b3IuaXNCdWZmZXIgPT09ICdmdW5jdGlvbicgJiYgdmFsLmNvbnN0cnVjdG9yLmlzQnVmZmVyKHZhbCk7XG59XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYW4gQXJyYXlCdWZmZXJcbiAqXG4gKiBAcGFyYW0ge09iamVjdH0gdmFsIFRoZSB2YWx1ZSB0byB0ZXN0XG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBpcyBhbiBBcnJheUJ1ZmZlciwgb3RoZXJ3aXNlIGZhbHNlXG4gKi9cbmZ1bmN0aW9uIGlzQXJyYXlCdWZmZXIodmFsKSB7XG4gIHJldHVybiB0b1N0cmluZy5jYWxsKHZhbCkgPT09ICdbb2JqZWN0IEFycmF5QnVmZmVyXSc7XG59XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBGb3JtRGF0YVxuICpcbiAqIEBwYXJhbSB7T2JqZWN0fSB2YWwgVGhlIHZhbHVlIHRvIHRlc3RcbiAqIEByZXR1cm5zIHtib29sZWFufSBUcnVlIGlmIHZhbHVlIGlzIGFuIEZvcm1EYXRhLCBvdGhlcndpc2UgZmFsc2VcbiAqL1xuZnVuY3Rpb24gaXNGb3JtRGF0YSh2YWwpIHtcbiAgcmV0dXJuIHRvU3RyaW5nLmNhbGwodmFsKSA9PT0gJ1tvYmplY3QgRm9ybURhdGFdJztcbn1cblxuLyoqXG4gKiBEZXRlcm1pbmUgaWYgYSB2YWx1ZSBpcyBhIHZpZXcgb24gYW4gQXJyYXlCdWZmZXJcbiAqXG4gKiBAcGFyYW0ge09iamVjdH0gdmFsIFRoZSB2YWx1ZSB0byB0ZXN0XG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBpcyBhIHZpZXcgb24gYW4gQXJyYXlCdWZmZXIsIG90aGVyd2lzZSBmYWxzZVxuICovXG5mdW5jdGlvbiBpc0FycmF5QnVmZmVyVmlldyh2YWwpIHtcbiAgdmFyIHJlc3VsdDtcbiAgaWYgKCh0eXBlb2YgQXJyYXlCdWZmZXIgIT09ICd1bmRlZmluZWQnKSAmJiAoQXJyYXlCdWZmZXIuaXNWaWV3KSkge1xuICAgIHJlc3VsdCA9IEFycmF5QnVmZmVyLmlzVmlldyh2YWwpO1xuICB9IGVsc2Uge1xuICAgIHJlc3VsdCA9ICh2YWwpICYmICh2YWwuYnVmZmVyKSAmJiAoaXNBcnJheUJ1ZmZlcih2YWwuYnVmZmVyKSk7XG4gIH1cbiAgcmV0dXJuIHJlc3VsdDtcbn1cblxuLyoqXG4gKiBEZXRlcm1pbmUgaWYgYSB2YWx1ZSBpcyBhIFN0cmluZ1xuICpcbiAqIEBwYXJhbSB7T2JqZWN0fSB2YWwgVGhlIHZhbHVlIHRvIHRlc3RcbiAqIEByZXR1cm5zIHtib29sZWFufSBUcnVlIGlmIHZhbHVlIGlzIGEgU3RyaW5nLCBvdGhlcndpc2UgZmFsc2VcbiAqL1xuZnVuY3Rpb24gaXNTdHJpbmcodmFsKSB7XG4gIHJldHVybiB0eXBlb2YgdmFsID09PSAnc3RyaW5nJztcbn1cblxuLyoqXG4gKiBEZXRlcm1pbmUgaWYgYSB2YWx1ZSBpcyBhIE51bWJlclxuICpcbiAqIEBwYXJhbSB7T2JqZWN0fSB2YWwgVGhlIHZhbHVlIHRvIHRlc3RcbiAqIEByZXR1cm5zIHtib29sZWFufSBUcnVlIGlmIHZhbHVlIGlzIGEgTnVtYmVyLCBvdGhlcndpc2UgZmFsc2VcbiAqL1xuZnVuY3Rpb24gaXNOdW1iZXIodmFsKSB7XG4gIHJldHVybiB0eXBlb2YgdmFsID09PSAnbnVtYmVyJztcbn1cblxuLyoqXG4gKiBEZXRlcm1pbmUgaWYgYSB2YWx1ZSBpcyBhbiBPYmplY3RcbiAqXG4gKiBAcGFyYW0ge09iamVjdH0gdmFsIFRoZSB2YWx1ZSB0byB0ZXN0XG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBpcyBhbiBPYmplY3QsIG90aGVyd2lzZSBmYWxzZVxuICovXG5mdW5jdGlvbiBpc09iamVjdCh2YWwpIHtcbiAgcmV0dXJuIHZhbCAhPT0gbnVsbCAmJiB0eXBlb2YgdmFsID09PSAnb2JqZWN0Jztcbn1cblxuLyoqXG4gKiBEZXRlcm1pbmUgaWYgYSB2YWx1ZSBpcyBhIHBsYWluIE9iamVjdFxuICpcbiAqIEBwYXJhbSB7T2JqZWN0fSB2YWwgVGhlIHZhbHVlIHRvIHRlc3RcbiAqIEByZXR1cm4ge2Jvb2xlYW59IFRydWUgaWYgdmFsdWUgaXMgYSBwbGFpbiBPYmplY3QsIG90aGVyd2lzZSBmYWxzZVxuICovXG5mdW5jdGlvbiBpc1BsYWluT2JqZWN0KHZhbCkge1xuICBpZiAodG9TdHJpbmcuY2FsbCh2YWwpICE9PSAnW29iamVjdCBPYmplY3RdJykge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIHZhciBwcm90b3R5cGUgPSBPYmplY3QuZ2V0UHJvdG90eXBlT2YodmFsKTtcbiAgcmV0dXJuIHByb3RvdHlwZSA9PT0gbnVsbCB8fCBwcm90b3R5cGUgPT09IE9iamVjdC5wcm90b3R5cGU7XG59XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBEYXRlXG4gKlxuICogQHBhcmFtIHtPYmplY3R9IHZhbCBUaGUgdmFsdWUgdG8gdGVzdFxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdmFsdWUgaXMgYSBEYXRlLCBvdGhlcndpc2UgZmFsc2VcbiAqL1xuZnVuY3Rpb24gaXNEYXRlKHZhbCkge1xuICByZXR1cm4gdG9TdHJpbmcuY2FsbCh2YWwpID09PSAnW29iamVjdCBEYXRlXSc7XG59XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBGaWxlXG4gKlxuICogQHBhcmFtIHtPYmplY3R9IHZhbCBUaGUgdmFsdWUgdG8gdGVzdFxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdmFsdWUgaXMgYSBGaWxlLCBvdGhlcndpc2UgZmFsc2VcbiAqL1xuZnVuY3Rpb24gaXNGaWxlKHZhbCkge1xuICByZXR1cm4gdG9TdHJpbmcuY2FsbCh2YWwpID09PSAnW29iamVjdCBGaWxlXSc7XG59XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBCbG9iXG4gKlxuICogQHBhcmFtIHtPYmplY3R9IHZhbCBUaGUgdmFsdWUgdG8gdGVzdFxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdmFsdWUgaXMgYSBCbG9iLCBvdGhlcndpc2UgZmFsc2VcbiAqL1xuZnVuY3Rpb24gaXNCbG9iKHZhbCkge1xuICByZXR1cm4gdG9TdHJpbmcuY2FsbCh2YWwpID09PSAnW29iamVjdCBCbG9iXSc7XG59XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBGdW5jdGlvblxuICpcbiAqIEBwYXJhbSB7T2JqZWN0fSB2YWwgVGhlIHZhbHVlIHRvIHRlc3RcbiAqIEByZXR1cm5zIHtib29sZWFufSBUcnVlIGlmIHZhbHVlIGlzIGEgRnVuY3Rpb24sIG90aGVyd2lzZSBmYWxzZVxuICovXG5mdW5jdGlvbiBpc0Z1bmN0aW9uKHZhbCkge1xuICByZXR1cm4gdG9TdHJpbmcuY2FsbCh2YWwpID09PSAnW29iamVjdCBGdW5jdGlvbl0nO1xufVxuXG4vKipcbiAqIERldGVybWluZSBpZiBhIHZhbHVlIGlzIGEgU3RyZWFtXG4gKlxuICogQHBhcmFtIHtPYmplY3R9IHZhbCBUaGUgdmFsdWUgdG8gdGVzdFxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdmFsdWUgaXMgYSBTdHJlYW0sIG90aGVyd2lzZSBmYWxzZVxuICovXG5mdW5jdGlvbiBpc1N0cmVhbSh2YWwpIHtcbiAgcmV0dXJuIGlzT2JqZWN0KHZhbCkgJiYgaXNGdW5jdGlvbih2YWwucGlwZSk7XG59XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBVUkxTZWFyY2hQYXJhbXMgb2JqZWN0XG4gKlxuICogQHBhcmFtIHtPYmplY3R9IHZhbCBUaGUgdmFsdWUgdG8gdGVzdFxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdmFsdWUgaXMgYSBVUkxTZWFyY2hQYXJhbXMgb2JqZWN0LCBvdGhlcndpc2UgZmFsc2VcbiAqL1xuZnVuY3Rpb24gaXNVUkxTZWFyY2hQYXJhbXModmFsKSB7XG4gIHJldHVybiB0b1N0cmluZy5jYWxsKHZhbCkgPT09ICdbb2JqZWN0IFVSTFNlYXJjaFBhcmFtc10nO1xufVxuXG4vKipcbiAqIFRyaW0gZXhjZXNzIHdoaXRlc3BhY2Ugb2ZmIHRoZSBiZWdpbm5pbmcgYW5kIGVuZCBvZiBhIHN0cmluZ1xuICpcbiAqIEBwYXJhbSB7U3RyaW5nfSBzdHIgVGhlIFN0cmluZyB0byB0cmltXG4gKiBAcmV0dXJucyB7U3RyaW5nfSBUaGUgU3RyaW5nIGZyZWVkIG9mIGV4Y2VzcyB3aGl0ZXNwYWNlXG4gKi9cbmZ1bmN0aW9uIHRyaW0oc3RyKSB7XG4gIHJldHVybiBzdHIudHJpbSA/IHN0ci50cmltKCkgOiBzdHIucmVwbGFjZSgvXlxccyt8XFxzKyQvZywgJycpO1xufVxuXG4vKipcbiAqIERldGVybWluZSBpZiB3ZSdyZSBydW5uaW5nIGluIGEgc3RhbmRhcmQgYnJvd3NlciBlbnZpcm9ubWVudFxuICpcbiAqIFRoaXMgYWxsb3dzIGF4aW9zIHRvIHJ1biBpbiBhIHdlYiB3b3JrZXIsIGFuZCByZWFjdC1uYXRpdmUuXG4gKiBCb3RoIGVudmlyb25tZW50cyBzdXBwb3J0IFhNTEh0dHBSZXF1ZXN0LCBidXQgbm90IGZ1bGx5IHN0YW5kYXJkIGdsb2JhbHMuXG4gKlxuICogd2ViIHdvcmtlcnM6XG4gKiAgdHlwZW9mIHdpbmRvdyAtPiB1bmRlZmluZWRcbiAqICB0eXBlb2YgZG9jdW1lbnQgLT4gdW5kZWZpbmVkXG4gKlxuICogcmVhY3QtbmF0aXZlOlxuICogIG5hdmlnYXRvci5wcm9kdWN0IC0+ICdSZWFjdE5hdGl2ZSdcbiAqIG5hdGl2ZXNjcmlwdFxuICogIG5hdmlnYXRvci5wcm9kdWN0IC0+ICdOYXRpdmVTY3JpcHQnIG9yICdOUydcbiAqL1xuZnVuY3Rpb24gaXNTdGFuZGFyZEJyb3dzZXJFbnYoKSB7XG4gIGlmICh0eXBlb2YgbmF2aWdhdG9yICE9PSAndW5kZWZpbmVkJyAmJiAobmF2aWdhdG9yLnByb2R1Y3QgPT09ICdSZWFjdE5hdGl2ZScgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYXZpZ2F0b3IucHJvZHVjdCA9PT0gJ05hdGl2ZVNjcmlwdCcgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYXZpZ2F0b3IucHJvZHVjdCA9PT0gJ05TJykpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgcmV0dXJuIChcbiAgICB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyAmJlxuICAgIHR5cGVvZiBkb2N1bWVudCAhPT0gJ3VuZGVmaW5lZCdcbiAgKTtcbn1cblxuLyoqXG4gKiBJdGVyYXRlIG92ZXIgYW4gQXJyYXkgb3IgYW4gT2JqZWN0IGludm9raW5nIGEgZnVuY3Rpb24gZm9yIGVhY2ggaXRlbS5cbiAqXG4gKiBJZiBgb2JqYCBpcyBhbiBBcnJheSBjYWxsYmFjayB3aWxsIGJlIGNhbGxlZCBwYXNzaW5nXG4gKiB0aGUgdmFsdWUsIGluZGV4LCBhbmQgY29tcGxldGUgYXJyYXkgZm9yIGVhY2ggaXRlbS5cbiAqXG4gKiBJZiAnb2JqJyBpcyBhbiBPYmplY3QgY2FsbGJhY2sgd2lsbCBiZSBjYWxsZWQgcGFzc2luZ1xuICogdGhlIHZhbHVlLCBrZXksIGFuZCBjb21wbGV0ZSBvYmplY3QgZm9yIGVhY2ggcHJvcGVydHkuXG4gKlxuICogQHBhcmFtIHtPYmplY3R8QXJyYXl9IG9iaiBUaGUgb2JqZWN0IHRvIGl0ZXJhdGVcbiAqIEBwYXJhbSB7RnVuY3Rpb259IGZuIFRoZSBjYWxsYmFjayB0byBpbnZva2UgZm9yIGVhY2ggaXRlbVxuICovXG5mdW5jdGlvbiBmb3JFYWNoKG9iaiwgZm4pIHtcbiAgLy8gRG9uJ3QgYm90aGVyIGlmIG5vIHZhbHVlIHByb3ZpZGVkXG4gIGlmIChvYmogPT09IG51bGwgfHwgdHlwZW9mIG9iaiA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICByZXR1cm47XG4gIH1cblxuICAvLyBGb3JjZSBhbiBhcnJheSBpZiBub3QgYWxyZWFkeSBzb21ldGhpbmcgaXRlcmFibGVcbiAgaWYgKHR5cGVvZiBvYmogIT09ICdvYmplY3QnKSB7XG4gICAgLyplc2xpbnQgbm8tcGFyYW0tcmVhc3NpZ246MCovXG4gICAgb2JqID0gW29ial07XG4gIH1cblxuICBpZiAoaXNBcnJheShvYmopKSB7XG4gICAgLy8gSXRlcmF0ZSBvdmVyIGFycmF5IHZhbHVlc1xuICAgIGZvciAodmFyIGkgPSAwLCBsID0gb2JqLmxlbmd0aDsgaSA8IGw7IGkrKykge1xuICAgICAgZm4uY2FsbChudWxsLCBvYmpbaV0sIGksIG9iaik7XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIC8vIEl0ZXJhdGUgb3ZlciBvYmplY3Qga2V5c1xuICAgIGZvciAodmFyIGtleSBpbiBvYmopIHtcbiAgICAgIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqLCBrZXkpKSB7XG4gICAgICAgIGZuLmNhbGwobnVsbCwgb2JqW2tleV0sIGtleSwgb2JqKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cblxuLyoqXG4gKiBBY2NlcHRzIHZhcmFyZ3MgZXhwZWN0aW5nIGVhY2ggYXJndW1lbnQgdG8gYmUgYW4gb2JqZWN0LCB0aGVuXG4gKiBpbW11dGFibHkgbWVyZ2VzIHRoZSBwcm9wZXJ0aWVzIG9mIGVhY2ggb2JqZWN0IGFuZCByZXR1cm5zIHJlc3VsdC5cbiAqXG4gKiBXaGVuIG11bHRpcGxlIG9iamVjdHMgY29udGFpbiB0aGUgc2FtZSBrZXkgdGhlIGxhdGVyIG9iamVjdCBpblxuICogdGhlIGFyZ3VtZW50cyBsaXN0IHdpbGwgdGFrZSBwcmVjZWRlbmNlLlxuICpcbiAqIEV4YW1wbGU6XG4gKlxuICogYGBganNcbiAqIHZhciByZXN1bHQgPSBtZXJnZSh7Zm9vOiAxMjN9LCB7Zm9vOiA0NTZ9KTtcbiAqIGNvbnNvbGUubG9nKHJlc3VsdC5mb28pOyAvLyBvdXRwdXRzIDQ1NlxuICogYGBgXG4gKlxuICogQHBhcmFtIHtPYmplY3R9IG9iajEgT2JqZWN0IHRvIG1lcmdlXG4gKiBAcmV0dXJucyB7T2JqZWN0fSBSZXN1bHQgb2YgYWxsIG1lcmdlIHByb3BlcnRpZXNcbiAqL1xuZnVuY3Rpb24gbWVyZ2UoLyogb2JqMSwgb2JqMiwgb2JqMywgLi4uICovKSB7XG4gIHZhciByZXN1bHQgPSB7fTtcbiAgZnVuY3Rpb24gYXNzaWduVmFsdWUodmFsLCBrZXkpIHtcbiAgICBpZiAoaXNQbGFpbk9iamVjdChyZXN1bHRba2V5XSkgJiYgaXNQbGFpbk9iamVjdCh2YWwpKSB7XG4gICAgICByZXN1bHRba2V5XSA9IG1lcmdlKHJlc3VsdFtrZXldLCB2YWwpO1xuICAgIH0gZWxzZSBpZiAoaXNQbGFpbk9iamVjdCh2YWwpKSB7XG4gICAgICByZXN1bHRba2V5XSA9IG1lcmdlKHt9LCB2YWwpO1xuICAgIH0gZWxzZSBpZiAoaXNBcnJheSh2YWwpKSB7XG4gICAgICByZXN1bHRba2V5XSA9IHZhbC5zbGljZSgpO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXN1bHRba2V5XSA9IHZhbDtcbiAgICB9XG4gIH1cblxuICBmb3IgKHZhciBpID0gMCwgbCA9IGFyZ3VtZW50cy5sZW5ndGg7IGkgPCBsOyBpKyspIHtcbiAgICBmb3JFYWNoKGFyZ3VtZW50c1tpXSwgYXNzaWduVmFsdWUpO1xuICB9XG4gIHJldHVybiByZXN1bHQ7XG59XG5cbi8qKlxuICogRXh0ZW5kcyBvYmplY3QgYSBieSBtdXRhYmx5IGFkZGluZyB0byBpdCB0aGUgcHJvcGVydGllcyBvZiBvYmplY3QgYi5cbiAqXG4gKiBAcGFyYW0ge09iamVjdH0gYSBUaGUgb2JqZWN0IHRvIGJlIGV4dGVuZGVkXG4gKiBAcGFyYW0ge09iamVjdH0gYiBUaGUgb2JqZWN0IHRvIGNvcHkgcHJvcGVydGllcyBmcm9tXG4gKiBAcGFyYW0ge09iamVjdH0gdGhpc0FyZyBUaGUgb2JqZWN0IHRvIGJpbmQgZnVuY3Rpb24gdG9cbiAqIEByZXR1cm4ge09iamVjdH0gVGhlIHJlc3VsdGluZyB2YWx1ZSBvZiBvYmplY3QgYVxuICovXG5mdW5jdGlvbiBleHRlbmQoYSwgYiwgdGhpc0FyZykge1xuICBmb3JFYWNoKGIsIGZ1bmN0aW9uIGFzc2lnblZhbHVlKHZhbCwga2V5KSB7XG4gICAgaWYgKHRoaXNBcmcgJiYgdHlwZW9mIHZhbCA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgYVtrZXldID0gYmluZCh2YWwsIHRoaXNBcmcpO1xuICAgIH0gZWxzZSB7XG4gICAgICBhW2tleV0gPSB2YWw7XG4gICAgfVxuICB9KTtcbiAgcmV0dXJuIGE7XG59XG5cbi8qKlxuICogUmVtb3ZlIGJ5dGUgb3JkZXIgbWFya2VyLiBUaGlzIGNhdGNoZXMgRUYgQkIgQkYgKHRoZSBVVEYtOCBCT00pXG4gKlxuICogQHBhcmFtIHtzdHJpbmd9IGNvbnRlbnQgd2l0aCBCT01cbiAqIEByZXR1cm4ge3N0cmluZ30gY29udGVudCB2YWx1ZSB3aXRob3V0IEJPTVxuICovXG5mdW5jdGlvbiBzdHJpcEJPTShjb250ZW50KSB7XG4gIGlmIChjb250ZW50LmNoYXJDb2RlQXQoMCkgPT09IDB4RkVGRikge1xuICAgIGNvbnRlbnQgPSBjb250ZW50LnNsaWNlKDEpO1xuICB9XG4gIHJldHVybiBjb250ZW50O1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IHtcbiAgaXNBcnJheTogaXNBcnJheSxcbiAgaXNBcnJheUJ1ZmZlcjogaXNBcnJheUJ1ZmZlcixcbiAgaXNCdWZmZXI6IGlzQnVmZmVyLFxuICBpc0Zvcm1EYXRhOiBpc0Zvcm1EYXRhLFxuICBpc0FycmF5QnVmZmVyVmlldzogaXNBcnJheUJ1ZmZlclZpZXcsXG4gIGlzU3RyaW5nOiBpc1N0cmluZyxcbiAgaXNOdW1iZXI6IGlzTnVtYmVyLFxuICBpc09iamVjdDogaXNPYmplY3QsXG4gIGlzUGxhaW5PYmplY3Q6IGlzUGxhaW5PYmplY3QsXG4gIGlzVW5kZWZpbmVkOiBpc1VuZGVmaW5lZCxcbiAgaXNEYXRlOiBpc0RhdGUsXG4gIGlzRmlsZTogaXNGaWxlLFxuICBpc0Jsb2I6IGlzQmxvYixcbiAgaXNGdW5jdGlvbjogaXNGdW5jdGlvbixcbiAgaXNTdHJlYW06IGlzU3RyZWFtLFxuICBpc1VSTFNlYXJjaFBhcmFtczogaXNVUkxTZWFyY2hQYXJhbXMsXG4gIGlzU3RhbmRhcmRCcm93c2VyRW52OiBpc1N0YW5kYXJkQnJvd3NlckVudixcbiAgZm9yRWFjaDogZm9yRWFjaCxcbiAgbWVyZ2U6IG1lcmdlLFxuICBleHRlbmQ6IGV4dGVuZCxcbiAgdHJpbTogdHJpbSxcbiAgc3RyaXBCT006IHN0cmlwQk9NXG59O1xuIiwiY29uc3QgYnVzID0gcmVxdWlyZShcIi4vYnVzXCIpO1xuY29uc3QgYXhpb3MgPSByZXF1aXJlKFwiYXhpb3NcIik7XG5jb25zdCB7bWVtb3J5fSA9IHJlcXVpcmUoXCJqc2ItdXRpbFwiKTtcbmV4cG9ydHMuaW5zdGFsbCA9IGZ1bmN0aW9uIGluc3RhbGwoVnVlKSB7XG4gICAgVnVlLmNvbXBvbmVudCgnYWRkX2xpbmsnLFxuICAgICAgICB7XG4gICAgICAgICAgICB0ZW1wbGF0ZTogKGBcbiAgICAgICAgICAgICAgICAgPGVsLWRpYWxvZyA6Y2xvc2Utb24tY2xpY2stbW9kYWw9XCJmYWxzZVwiIGFwcGVuZC10by1ib2R5IDp2aXNpYmxlLnN5bmM9XCJkaWFsb2dWaXNpYmxlXCIgOnRpdGxlPVwiIWlzZWRpdD8n5re75Yqg6ZO+5o6lJzon5L+u5pS56ZO+5o6lJ1wiIDp3aWR0aD1cInN1bXdpZHRoKGRpYWxvZ1Zpc2libGUpXCI+XG4gICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwibWVudV9hZGRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICA8ZWwtaW5wdXQgcGxhY2Vob2xkZXI9XCLor7fovpPlhaXlrozmlbTnmoTnvZHlnYDpk77mjqVcIiB2LW1vZGVsPVwiYWRkSW5mby51cmxcIj48L2VsLWlucHV0PlxuICAgICAgICAgICAgICAgICAgICAgICAgIDxlbC1pbnB1dCBwbGFjZWhvbGRlcj1cIuivt+i+k+WFpeWkh+eUqOmTvuaOpe+8jOayoeacieivt+eVmeepulwiIHYtbW9kZWw9XCJhZGRJbmZvLnVybF9zdGFuZGJ5XCI+PC9lbC1pbnB1dD5cbiAgICAgICAgICAgICAgICAgICAgICAgICA8ZWwtaW5wdXQgcGxhY2Vob2xkZXI9XCLor7fovpPlhaXmoIfpophcIiB2LW1vZGVsPVwiYWRkSW5mby50aXRsZVwiPjwvZWwtaW5wdXQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgPGVsLWlucHV0IHBsYWNlaG9sZGVyPVwi6K+36L6T5YWl56uZ54K55o+P6L+w77yI5a6M5pW077yJXCIgc2hvdy13b3JkLWxpbWl0IG1heGxlbmd0aD1cIjMwMFwiIHR5cGU9XCJ0ZXh0YXJlYVwiIHYtbW9kZWw9XCJhZGRJbmZvLmRlc2NyaXB0aW9uXCI+PC9lbC1pbnB1dD5cbiAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwib3RoZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICA8ZWwtc2VsZWN0IHYtbW9kZWw9XCJhZGRJbmZvLmZpZFwiIHBsYWNlaG9sZGVyPVwi6K+36YCJ5oup55uu5b2VXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGVsLW9wdGlvbiA6dmFsdWU9XCJpdC5pZFwiIDpsYWJlbD1cIml0Lm5hbWVcIiB2LWZvcj1cIihpdCxpbmRleCkgaW4gb3B0aW9uXCIgOmtleT1cImluZGV4XCI+PC9lbC1vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgPC9lbC1zZWxlY3Q+XG4gICAgICAgICAgICAgICAgICAgICAgICAgPGVsLWlucHV0IHBsYWNlaG9sZGVyPVwi5p2D6YeN77yIMC05Oe+8iVwiIHR5cGU9XCJudW1iZXJcIiB2LW1vZGVsPVwiYWRkSW5mby53ZWlnaHRcIj48L2VsLWlucHV0PlxuICAgICAgICAgICAgICAgICAgICAgICAgIDxlbC1zd2l0Y2hcbiAgICAgICAgICAgICAgICAgICAgICAgIHYtbW9kZWw9XCJhZGRJbmZvLnByb3BlcnR5XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjdGl2ZS1jb2xvcj1cIiMxM2NlNjZcIlxuICAgICAgICAgICAgICAgICAgICAgICAgaW5hY3RpdmUtdGV4dD1cIuaYr+WQpuWFrOW8gFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBpbmFjdGl2ZS1jb2xvcj1cIiNmZjQ5NDlcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZWwtc3dpdGNoPlxuICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgIDxzcGFuIHNsb3Q9XCJmb290ZXJcIiBjbGFzcz1cImRpYWxvZy1mb290ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgPGVsLWJ1dHRvbiBAY2xpY2s9XCJkaWFsb2dWaXNpYmxlID0gZmFsc2VcIj7lj5Yg5raIPC9lbC1idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgIDxlbC1idXR0b24gdHlwZT1cInByaW1hcnlcIiAgQGNsaWNrPVwic3VibWl0XCI+56GuIOWumjwvZWwtYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgPC9lbC1kaWFsb2c+XG4gICAgICAgICAgICAgICAgYCksXG4gICAgICAgICAgICBtZXRob2RzOiB7XG4gICAgICAgICAgICAgICAgc3VibWl0KHR5cGUpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuYWRkSW5mby51cmwgPT09IFwiXCIpIHJldHVybiB0aGlzLiRtZXNzYWdlLmVycm9yKFwi57y65bCRdXJs5Zyw5Z2AXCIpXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmFkZEluZm8udGl0bGUgPT09IFwiXCIpIHJldHVybiB0aGlzLiRtZXNzYWdlLmVycm9yKFwi57y65bCR5qCH6aKYXCIpXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGRhdGEgPSB7Li4udGhpcy5hZGRJbmZvfTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHVybCA9IFwiXCJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuaXNlZGl0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB1cmwgPSBcIi9pbmRleC5waHA/Yz1hcGkmbWV0aG9kPWVkaXRfbGlua1wiXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB1cmwgPSBcIi9pbmRleC5waHA/Yz1hcGkmbWV0aG9kPWFkZF9saW5rXCJcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBkYXRhLnByb3BlcnR5ID0gdGhpcy5hZGRJbmZvLnByb3BlcnR5ID8gMCA6IDE7XG4gICAgICAgICAgICAgICAgICAgIGF4aW9zLnBvc3QodXJsLCBkYXRhKS50aGVuKGUgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qge2NvZGV9ID0gZS5kYXRhO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGNvZGUgPT09IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRtZXNzYWdlLnN1Y2Nlc3MoXCLmt7vliqDmiJDlip9cIilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KF8gPT4gbG9jYXRpb24ucmVsb2FkKCksIDEwMDApXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5kaWFsb2dWaXNpYmxlID0gZmFsc2VcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kbWVzc2FnZS5lcnJvcihcIua3u+WKoOWksei0pVwiKVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9KVxuXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBzdW13aWR0aCgpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKG91dGVyV2lkdGggPiA1MDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAnNTAwcHgnXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFwiMzc1cHhcIlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBkYXRhKCkge1xuICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgIGRpYWxvZ1Zpc2libGU6IGZhbHNlLFxuICAgICAgICAgICAgICAgICAgICBvcHRpb246IFtdLFxuICAgICAgICAgICAgICAgICAgICBhZGRJbmZvOiB7fSxcbiAgICAgICAgICAgICAgICAgICAgdG1wOiB7Ly/ov5nkuKrmmK/kuLrkuoblnKjkuIvmrKHmiZPlvIDnmoTml7blgJnmuIXnqbrlhoXlrrnnmoTmlbDmja7nu5PmnoRcbiAgICAgICAgICAgICAgICAgICAgICAgIHVybDogJycsXG4gICAgICAgICAgICAgICAgICAgICAgICB3ZWlnaHQ6ICcnLFxuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU6ICcnLFxuICAgICAgICAgICAgICAgICAgICAgICAgcHJvcGVydHk6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBmaWQ6IFwiXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICB1cmxfc3RhbmRieTogJycsXG4gICAgICAgICAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogJydcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgaXNlZGl0OiBmYWxzZVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB3YXRjaDoge1xuICAgICAgICAgICAgICAgIGRpYWxvZ1Zpc2libGUoZSkge1xuICAgICAgICAgICAgICAgICAgICBpZiAoZSA9PT0gZmFsc2UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHdpbmRvdy5zY3JvbGxsb2NrID0gZmFsc2VcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChlID09PSB0cnVlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmFkZEluZm8gPSBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KHRoaXMudG1wKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB3aW5kb3cuc2Nyb2xsbG9jayA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgbW91bnRlZCgpIHtcbiAgICAgICAgICAgICAgICBidXMuJG9uKFwic2hvd1wiLCAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMub3B0aW9uID0gbWVtb3J5LmdldChcImxpc3RcIikgfHwgW107XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZGlhbG9nVmlzaWJsZSA9IHRydWVcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgIGJ1cy4kb24oXCJzaG93YW5kdXBkYXRlXCIsIChlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZGlhbG9nVmlzaWJsZSA9IHRydWVcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5pc2VkaXQgPSB0cnVlXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuJG5leHRUaWNrKF8gPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5vcHRpb24gPSBtZW1vcnkuZ2V0KFwibGlzdFwiKSB8fCBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYWRkSW5mbyA9IGVcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYWRkSW5mby5wcm9wZXJ0eSA9IGUucHJvcGVydHkgPT0gMCA/IHRydWUgOiBmYWxzZVxuICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICB9XG4gICAgICAgIH0pXG5cblxuICAgIFZ1ZS5jb21wb25lbnQoXCJ0YWJhclwiLCB7XG4gICAgICAgIHRlbXBsYXRlOiAoYDxkaXYgdi1zaG93PVwic2hvd1wiIGNsYXNzPVwidGFiYXJcIiA6c3R5bGU9XCJ7bGVmdDptb3VzZVJpZ2h0LngsdG9wOm1vdXNlUmlnaHQueX1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgQGNsaWNrPVwiYWRkbWVudVwiPuaWsOWinuebruW9lTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiB2LWlmPVwiY2Fuc2hvdygxKVwiIEBjbGljaz1cInVwZGF0ZW1lbnVcIj7kv67mlLnnm67lvZU8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgdi1pZj1cImNhbnNob3coMilcIiBAY2xpY2s9XCJkZWxtZW51XCIgPuWIoOmZpOebruW9lTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImFkZGxpbmtcIiAgIEBjbGljaz1cImFkZGxpbmtcIj7mlrDlop7pk77mjqU8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgdi1pZj1cImNhbnNob3coMylcIiBAY2xpY2s9XCJkZWxsaW5rXCI+5Yig6Zmk6ZO+5o6lPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHYtaWY9XCJjYW5zaG93KDQpXCIgQGNsaWNrPVwidXBkYXRlbGlua1wiPuS/ruaUuemTvuaOpTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiB2LWlmPVwiY2Fuc2hvdyg1KVwiIEBjbGljaz1cImRlbGhpc3RvcnlcIj7liKDpmaTorrDlvZU8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgdi1pZj1cImNhbnNob3coNilcIiBAY2xpY2s9XCJzd2lwdEJnXCI+5o2i5Liq6IOM5pmvPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHYtaWY9XCJjYW5zaG93KDYpXCIgQGNsaWNrPVwiZG93bmJnXCIgPuS4i+i9veWjgee6uDwvZGl2PlxuPCEtLSAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgQGNsaWNrPVwic2V0dGluZ1wiPuS4quaAp+iuvue9rjwvZGl2Pi0tPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5gKSxcbiAgICAgICAgZGF0YSgpIHtcbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgbW91c2VSaWdodDoge1xuICAgICAgICAgICAgICAgICAgICB4OiAwLFxuICAgICAgICAgICAgICAgICAgICB5OiAwXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBzaG93OiBmYWxzZSxcbiAgICAgICAgICAgICAgICBpbmZvOiB7fSxcbiAgICAgICAgICAgICAgICBjdHlwZTogW10sXG4gICAgICAgICAgICAgICAgZWxlbWVudDogbnVsbFxuICAgICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBwcm9wczogW1wieHlcIiwgXCJ0eXBlXCJdLFxuICAgICAgICBtZXRob2RzOiB7XG4gICAgICAgICAgICBhZGRtZW51KCkge1xuICAgICAgICAgICAgICAgIGJ1cy4kZW1pdChcIm1lbnVzaG93XCIsIHRydWUpXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgZG93bmJnKCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGRhdGEgPSBiYXNlNjRUb0Jsb2IobWVtb3J5LmdldChcImJnXCIpKTtcbiAgICAgICAgICAgICAgICBsZXQgYSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJhXCIpO1xuICAgICAgICAgICAgICAgIGEuaHJlZiA9IFVSTC5jcmVhdGVPYmplY3RVUkwoZGF0YSk7XG4gICAgICAgICAgICAgICAgYS5kb3dubG9hZCA9IFwi5aOB57q4LmpwZ1wiXG4gICAgICAgICAgICAgICAgYS5jbGljaygpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHVwZGF0ZW1lbnUoKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgbGlzdCA9IG1lbW9yeS5nZXQoXCJsaXN0XCIpIHx8IFtdXG4gICAgICAgICAgICAgICAgY29uc3QgaW5kZXggPSBsaXN0LmZpbmRJbmRleChlID0+IGUuaWQgPT0gdGhpcy5pbmZvKVxuICAgICAgICAgICAgICAgIGlmIChpbmRleCA9PT0gLTEpIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgICAgICBjb25zdCBpbmZvID0gbGlzdFtpbmRleF07XG4gICAgICAgICAgICAgICAgYnVzLiRlbWl0KFwibWVudXNob3dcIiwgaW5mbylcbiAgICAgICAgICAgICAgICB0aGlzLnNob3cgPSBmYWxzZVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGFkZGxpbmsoKSB7XG4gICAgICAgICAgICAgICAgYnVzLiRlbWl0KFwic2hvd1wiLCB0cnVlKVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGRlbGhpc3RvcnkoKSB7XG4gICAgICAgICAgICAgICAgYnVzLiRlbWl0KFwiZGVsaGlzdG9yeVwiLCB0aGlzLmluZm8pXG4gICAgICAgICAgICAgICAgdGhpcy5zaG93ID0gZmFsc2VcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzd2lwdEJnKCkge1xuICAgICAgICAgICAgICAgIGxldCBkYXRhID0gbmV3IEZpbGVSZWFkZXIoKVxuICAgICAgICAgICAgICAgIGRhdGEub25sb2FkID0gKGVyKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGJhc2UgPSBkYXRhLnJlc3VsdDtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGJhc2UubGVuZ3RoIDwgMTAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRub3RpZnkuZXJyb3Ioe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlOiAn5Ye6546w5byC5bi4JyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiAn5rKh5pyJ5YiH5o2i5oiQ5YqfJ1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgbWVtb3J5LnNldChcImJnXCIsIGJhc2UpXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHRoaXMuJG5vdGlmeS5pbmZvKHtcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU6ICfliIfmjaLkuK0nLFxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiAn6K+356iN562J54mH5Yi777yM5oiR5aSE55CG5LiA5LiLJ1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIGZldGNoKGF4aW9zLmRlZmF1bHRzLmJhc2VVUkwgKyBcIi9iYWNrZ3JvdW5kLnBocFwiKS50aGVuKGVsbCA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGVsbC5ibG9iKCkudGhlbihjYyA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBkYXRhLnJlYWRBc0RhdGFVUkwoY2MpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgYWMgPSBVUkwuY3JlYXRlT2JqZWN0VVJMKGNjKVxuICAgICAgICAgICAgICAgICAgICAgICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiNyb290XCIpLnN0eWxlLmJhY2tncm91bmQgPSBgdXJsKCR7YWN9KSBuby1yZXBlYXQgY2VudGVyL2NvdmVyYFxuICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgdGhpcy5zaG93ID0gZmFsc2VcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBhc3luYyBkZWxtZW51KCkge1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIGF3YWl0IHRoaXMuJGNvbmZpcm0oXCLmmK/lkKbliKDpmaTvvJ9cIilcbiAgICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYXhpb3MucG9zdChcIi9pbmRleC5waHA/Yz1hcGkmbWV0aG9kPWRlbF9jYXRlZ29yeVwiLCB7XG4gICAgICAgICAgICAgICAgICAgIGlkOiB0aGlzLmluZm9cbiAgICAgICAgICAgICAgICB9KS50aGVuKGVsID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3Qge2NvZGV9ID0gZWwuZGF0YTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGNvZGUgPT09IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZWxlbWVudC5wYXJlbnROb2RlLnJlbW92ZSgpXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRtZXNzYWdlLnN1Y2Nlc3MoXCLliKDpmaTmiJDlip9cIilcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJG1lc3NhZ2UuZXJyb3IoXCLliKDpmaTlpLHotKVcIilcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgdGhpcy5zaG93ID0gZmFsc2VcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBhc3luYyBkZWxsaW5rKCkge1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIGF3YWl0IHRoaXMuJGNvbmZpcm0oXCLmmK/lkKbliKDpmaTvvJ9cIilcbiAgICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY29uc3QgbGlzdHMgPSBtZW1vcnkuZ2V0KFwibGlzdHNcIikgfHwgW11cbiAgICAgICAgICAgICAgICBjb25zdCBpbmRleCA9IGxpc3RzLmZpbmRJbmRleChlID0+IGUuaWQgPT0gdGhpcy5pbmZvKVxuICAgICAgICAgICAgICAgIGlmIChpbmRleCA9PT0gLTEpIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgICAgICBjb25zdCBpbmZvID0gbGlzdHNbaW5kZXhdO1xuICAgICAgICAgICAgICAgIGF4aW9zLnBvc3QoXCIvaW5kZXgucGhwP2M9YXBpJm1ldGhvZD1kZWxfbGlua1wiLCB7XG4gICAgICAgICAgICAgICAgICAgIGlkOiBpbmZvLmlkXG4gICAgICAgICAgICAgICAgfSkudGhlbihlbCA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHtjb2RlfSA9IGVsLmRhdGE7XG4gICAgICAgICAgICAgICAgICAgIGlmIChjb2RlID09PSAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmVsZW1lbnQucmVtb3ZlKClcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJG1lc3NhZ2Uuc3VjY2VzcyhcIuWIoOmZpOaIkOWKn1wiKVxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kbWVzc2FnZS5lcnJvcihcIuWIoOmZpOWksei0pVwiKVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICB0aGlzLnNob3cgPSBmYWxzZVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHNldHRpbmcoKSB7XG5cbiAgICAgICAgICAgICAgICB0aGlzLnNob3cgPSBmYWxzZTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB1cGRhdGVsaW5rKCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGxpc3RzID0gbWVtb3J5LmdldChcImxpc3RzXCIpIHx8IFtdXG4gICAgICAgICAgICAgICAgY29uc3QgaW5kZXggPSBsaXN0cy5maW5kSW5kZXgoZSA9PiBlLmlkID09IHRoaXMuaW5mbylcbiAgICAgICAgICAgICAgICBpZiAoaW5kZXggPT09IC0xKSByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICAgICAgY29uc3QgaW5mbyA9IGxpc3RzW2luZGV4XTtcbiAgICAgICAgICAgICAgICBidXMuJGVtaXQoXCJzaG93YW5kdXBkYXRlXCIsIGluZm8pXG4gICAgICAgICAgICAgICAgdGhpcy5zaG93ID0gZmFsc2VcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBjYW5zaG93KGluZGV4KSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIEJvb2xlYW4odGhpcy5jdHlwZS5pbmRleE9mKGluZGV4KSA+IC0xKVxuICAgICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBtb3VudGVkKCkge1xuICAgICAgICAgICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIi50YWJhclwiKS5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgZnVuY3Rpb24gKGV2ZW50KSB7XG4gICAgICAgICAgICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICAgICAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKGV2ZW50KSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5zaG93ID0gZmFsc2U7XG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgY29uc3QgdG91Y2ggPSB7XG4gICAgICAgICAgICAgICAgaXNkb3duOiBmYWxzZSxcbiAgICAgICAgICAgICAgICB0aW1lOiBudWxsLFxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJ0b3VjaHN0YXJ0XCIsIChlKSA9PiB7XG4gICAgICAgICAgICAgICAgdG91Y2guaXNkb3duID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICB0b3VjaC50aW1lID0gbmV3IERhdGUoKS5nZXRUaW1lKCk7XG4gICAgICAgICAgICAgICAgdG91Y2gudGltZSA9IHNldFRpbWVvdXQoXyA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMubW91c2VSaWdodCA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHg6IGUuY2hhbmdlZFRvdWNoZXNbMF0uY2xpZW50WCArICdweCcsXG4gICAgICAgICAgICAgICAgICAgICAgICB5OiBlLmNoYW5nZWRUb3VjaGVzWzBdLmNsaWVudFkgKyAncHgnXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCB0ID0gSlNPTi5wYXJzZShlLnRhcmdldC5hdHRyaWJ1dGVzLmN0eXBlLnZhbHVlKVxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHQubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY3R5cGUgPSB0O1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmN0eXBlID0gW11cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGluZm8gPSBlLnRhcmdldC5hdHRyaWJ1dGVzLmNkYXRhLnZhbHVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5pbmZvID0gaW5mb1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5lbGVtZW50ID0gZS50YXJnZXRcbiAgICAgICAgICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc2hvdyA9IHRydWU7XG4gICAgICAgICAgICAgICAgfSwgNTAwKVxuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwidG91Y2hlbmRcIiwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIHRvdWNoLmlzZG93biA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIGNsZWFyVGltZW91dCh0b3VjaC50aW1lKVxuICAgICAgICAgICAgICAgIHRvdWNoLnRpbWUgPSBudWxsO1xuXG4gICAgICAgICAgICB9KVxuXG5cbiAgICAgICAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwibW91c2V1cFwiLCAoZSkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChlLmJ1dHRvbiA9PT0gMikge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLm1vdXNlUmlnaHQgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB4OiBlLmNsaWVudFggKyAncHgnLFxuICAgICAgICAgICAgICAgICAgICAgICAgeTogZS5jbGllbnRZICsgJ3B4J1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgdCA9IEpTT04ucGFyc2UoZS50b0VsZW1lbnQuYXR0cmlidXRlcy5jdHlwZS52YWx1ZSlcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0Lmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmN0eXBlID0gdDtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jdHlwZSA9IFtdXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBpbmZvID0gZS50b0VsZW1lbnQuYXR0cmlidXRlcy5jZGF0YS52YWx1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuaW5mbyA9IGluZm9cbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZWxlbWVudCA9IGUudGFyZ2V0XG4gICAgICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcblxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc2hvdyA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgICAgICAgICAgICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pXG4gICAgICAgIH0sXG4gICAgfSlcblxuXG4gICAgVnVlLmNvbXBvbmVudCgnYWRkX21lbnVzJyxcbiAgICAgICAge1xuICAgICAgICAgICAgdGVtcGxhdGU6IChgXG4gICAgICAgICAgICAgICAgIDxlbC1kaWFsb2cgOmNsb3NlLW9uLWNsaWNrLW1vZGFsPVwiZmFsc2VcIiBhcHBlbmQtdG8tYm9keSA6dmlzaWJsZS5zeW5jPVwiZGlhbG9nVmlzaWJsZVwiIHRpdGxlPVwi5re75Yqg55uu5b2VXCIgOndpZHRoPVwic3Vtd2lkdGgoZGlhbG9nVmlzaWJsZSlcIj5cbiAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJtZW51X2FkZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgIDxlbC1pbnB1dCBwbGFjZWhvbGRlcj1cIuivt+i+k+WFpeWIhuexu+WQjeensFwiIHYtbW9kZWw9XCJhZGRJbmZvLm5hbWVcIj48L2VsLWlucHV0PlxuICAgICAgICAgICAgICAgICAgICAgICAgIDxlbC1pbnB1dCBwbGFjZWhvbGRlcj1cIuivt+i+k+WFpeWbvuagh+exu+WQjSDkuI3opoHliKDpmaRmYSAoZmEg5Zu+5qCH5ZCN56ewKVwiIHYtbW9kZWw9XCJhZGRJbmZvLmZvbnRfaWNvblwiID48L2VsLWlucHV0PlxuICAgICAgICAgICAgICAgICAgICAgICAgIDxlbC1pbnB1dCBwbGFjZWhvbGRlcj1cIuivt+i+k+WFpeermeeCueaPj+i/sO+8iOWujOaVtO+8iVwiIHNob3ctd29yZC1saW1pdCBtYXhsZW5ndGg9XCIzMDBcIiB0eXBlPVwidGV4dGFyZWFcIiB2LW1vZGVsPVwiYWRkSW5mby5kZXNjcmlwdGlvblwiPjwvZWwtaW5wdXQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cIm90aGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxlbC1zZWxlY3Qgdi1tb2RlbD1cImFkZEluZm8uZmlkXCIgcGxhY2Vob2xkZXI9XCLniLbnuqfoj5zljZXvvIzpnZ7lv4XpgIlcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZWwtb3B0aW9uIDp2YWx1ZT1cIml0LmlkXCIgOmxhYmVsPVwiaXQubmFtZVwiIHYtZm9yPVwiKGl0LGluZGV4KSBpbiBvcHRpb25cIiA6a2V5PVwiaW5kZXhcIj48L2VsLW9wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICA8L2VsLXNlbGVjdD5cbiAgICAgICAgICAgICAgICAgICAgICAgICA8ZWwtaW5wdXQgcGxhY2Vob2xkZXI9XCLmnYPph43vvIgwLTk577yJXCIgdHlwZT1cIm51bWJlclwiIHYtbW9kZWw9XCJhZGRJbmZvLndlaWdodFwiPjwvZWwtaW5wdXQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgPGVsLXN3aXRjaFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2LW1vZGVsPVwiYWRkSW5mby5wcm9wZXJ0eVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFjdGl2ZS1jb2xvcj1cIiMxM2NlNjZcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbmFjdGl2ZS10ZXh0PVwi5piv5ZCm5YWs5byAXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5hY3RpdmUtY29sb3I9XCIjZmY0OTQ5XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2VsLXN3aXRjaD5cbiAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPVwibWFyZ2luOjE1cHggMHB4O1wiPuWbvuagh+afpeeci+WcsOWdgCA8YSBocmVmPVwiaHR0cHM6Ly9mb250YXdlc29tZS5kYXNoZ2FtZS5jb21cIiB0YXJnZXQ9XCJfYmxhbmtcIj5odHRwczovL2ZvbnRhd2Vzb21lLmRhc2hnYW1lLmNvbTwvYT48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICA8c3BhbiBzbG90PVwiZm9vdGVyXCIgY2xhc3M9XCJkaWFsb2ctZm9vdGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgIDxlbC1idXR0b24gQGNsaWNrPVwiZGlhbG9nVmlzaWJsZSA9IGZhbHNlXCI+5Y+WIOa2iDwvZWwtYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICA8ZWwtYnV0dG9uIHR5cGU9XCJwcmltYXJ5XCIgIEBjbGljaz1cInN1Ym1pdFwiPuehriDlrpo8L2VsLWJ1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgIDwvZWwtZGlhbG9nPlxuICAgICAgICAgICAgICAgIGApLFxuICAgICAgICAgICAgbWV0aG9kczoge1xuICAgICAgICAgICAgICAgIHN1Ym1pdCgpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuYWRkSW5mby5uYW1lID09PSBcIlwiKSByZXR1cm4gdGhpcy4kbWVzc2FnZS5lcnJvcihcIue8uuWwkeebruW9leWQjeensFwiKVxuICAgICAgICAgICAgICAgICAgICBjb25zdCBkYXRhID0gey4uLnRoaXMuYWRkSW5mb307XG4gICAgICAgICAgICAgICAgICAgIGRhdGEucHJvcGVydHkgPSB0aGlzLmFkZEluZm8ucHJvcGVydHkgPyAwIDogMTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHVybCA9IFwiL2luZGV4LnBocD9jPWFwaSZtZXRob2Q9YWRkX2NhdGVnb3J5XCJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuaXNlZGl0KVxuICAgICAgICAgICAgICAgICAgICAgICAgdXJsID0gXCIvaW5kZXgucGhwP2M9YXBpJm1ldGhvZD1lZGl0X2NhdGVnb3J5XCJcbiAgICAgICAgICAgICAgICAgICAgYXhpb3MucG9zdCh1cmwsIGRhdGEpLnRoZW4oZSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB7Y29kZX0gPSBlLmRhdGE7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoY29kZSA9PT0gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJG1lc3NhZ2Uuc3VjY2VzcyhcIua3u+WKoOaIkOWKn1wiKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoXyA9PiBsb2NhdGlvbi5yZWxvYWQoKSwgMTAwMClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmRpYWxvZ1Zpc2libGUgPSBmYWxzZVxuICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRtZXNzYWdlLmVycm9yKFwi5re75Yqg5aSx6LSlXCIpXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH0pXG5cbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHN1bXdpZHRoKCkge1xuICAgICAgICAgICAgICAgICAgICBpZiAob3V0ZXJXaWR0aCA+IDUwMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuICc1MDBweCdcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCIzNzVweFwiXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGRhdGEoKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgZGlhbG9nVmlzaWJsZTogZmFsc2UsXG4gICAgICAgICAgICAgICAgICAgIG9wdGlvbjogW10sXG4gICAgICAgICAgICAgICAgICAgIGFkZEluZm86IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6ICcnLFxuICAgICAgICAgICAgICAgICAgICAgICAgd2VpZ2h0OiAnJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHByb3BlcnR5OiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgICAgICAgICAgICAgICAgICAgZm9udF9pY29uOiAnZmEgJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGZpZDogXCJcIlxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICB0bXA6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6ICcnLFxuICAgICAgICAgICAgICAgICAgICAgICAgd2VpZ2h0OiAnJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHByb3BlcnR5OiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgICAgICAgICAgICAgICAgICAgZm9udF9pY29uOiAnZmEgJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGZpZDogXCJcIlxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICBpc2VkaXQ6IGZhbHNlXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHdhdGNoOiB7XG4gICAgICAgICAgICAgICAgZGlhbG9nVmlzaWJsZShlKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChlID09PSBmYWxzZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgd2luZG93LnNjcm9sbGxvY2sgPSBmYWxzZVxuICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKGUgPT09IHRydWUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYWRkSW5mbyA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkodGhpcy50bXApKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHdpbmRvdy5zY3JvbGxsb2NrID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBtb3VudGVkKCkge1xuICAgICAgICAgICAgICAgIGJ1cy4kb24oXCJtZW51c2hvd1wiLCAoaW5mbykgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmRpYWxvZ1Zpc2libGUgPSB0cnVlXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuJG5leHRUaWNrKF8gPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGFyciA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgbWVtb3J5LmdldChcImxpc3RcIikuZm9yRWFjaChlbCA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGVsLmZpZCA9PSAnMCcpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXJyLnB1c2goZWwpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMub3B0aW9uID0gYXJyO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGluZm8gIT09IHRydWUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3IgKGNvbnN0IGl0ZW0gaW4gdGhpcy5hZGRJbmZvKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYWRkSW5mb1tpdGVtXSA9IGluZm9baXRlbV1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5hZGRJbmZvLnByb3BlcnR5ID0gQm9vbGVhbihpbmZvW1wicHJvcGVydHlcIl0gIT09IDEpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5hZGRJbmZvLmlkID0gaW5mby5pZDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmFkZEluZm8uZmlkID0gaW5mby5maWQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5pc2VkaXQgPSB0cnVlXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH0pXG5cbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgfVxuICAgICAgICB9KVxuXG59XG4iLCIvKipcbiAqIGNzc2ZpbHRlclxuICpcbiAqIEBhdXRob3Ig6ICB6Zu3PGxlaXpvbmdtaW5AZ21haWwuY29tPlxuICovXG5cbnZhciBERUZBVUxUID0gcmVxdWlyZSgnLi9kZWZhdWx0Jyk7XG52YXIgcGFyc2VTdHlsZSA9IHJlcXVpcmUoJy4vcGFyc2VyJyk7XG52YXIgXyA9IHJlcXVpcmUoJy4vdXRpbCcpO1xuXG5cbi8qKlxuICog6L+U5Zue5YC85piv5ZCm5Li656m6XG4gKlxuICogQHBhcmFtIHtPYmplY3R9IG9ialxuICogQHJldHVybiB7Qm9vbGVhbn1cbiAqL1xuZnVuY3Rpb24gaXNOdWxsIChvYmopIHtcbiAgcmV0dXJuIChvYmogPT09IHVuZGVmaW5lZCB8fCBvYmogPT09IG51bGwpO1xufVxuXG4vKipcbiAqIOa1heaLt+i0neWvueixoVxuICpcbiAqIEBwYXJhbSB7T2JqZWN0fSBvYmpcbiAqIEByZXR1cm4ge09iamVjdH1cbiAqL1xuZnVuY3Rpb24gc2hhbGxvd0NvcHlPYmplY3QgKG9iaikge1xuICB2YXIgcmV0ID0ge307XG4gIGZvciAodmFyIGkgaW4gb2JqKSB7XG4gICAgcmV0W2ldID0gb2JqW2ldO1xuICB9XG4gIHJldHVybiByZXQ7XG59XG5cbi8qKlxuICog5Yib5bu6Q1NT6L+H5ruk5ZmoXG4gKlxuICogQHBhcmFtIHtPYmplY3R9IG9wdGlvbnNcbiAqICAgLSB7T2JqZWN0fSB3aGl0ZUxpc3RcbiAqICAgLSB7RnVuY3Rpb259IG9uQXR0clxuICogICAtIHtGdW5jdGlvbn0gb25JZ25vcmVBdHRyXG4gKiAgIC0ge0Z1bmN0aW9ufSBzYWZlQXR0clZhbHVlXG4gKi9cbmZ1bmN0aW9uIEZpbHRlckNTUyAob3B0aW9ucykge1xuICBvcHRpb25zID0gc2hhbGxvd0NvcHlPYmplY3Qob3B0aW9ucyB8fCB7fSk7XG4gIG9wdGlvbnMud2hpdGVMaXN0ID0gb3B0aW9ucy53aGl0ZUxpc3QgfHwgREVGQVVMVC53aGl0ZUxpc3Q7XG4gIG9wdGlvbnMub25BdHRyID0gb3B0aW9ucy5vbkF0dHIgfHwgREVGQVVMVC5vbkF0dHI7XG4gIG9wdGlvbnMub25JZ25vcmVBdHRyID0gb3B0aW9ucy5vbklnbm9yZUF0dHIgfHwgREVGQVVMVC5vbklnbm9yZUF0dHI7XG4gIG9wdGlvbnMuc2FmZUF0dHJWYWx1ZSA9IG9wdGlvbnMuc2FmZUF0dHJWYWx1ZSB8fCBERUZBVUxULnNhZmVBdHRyVmFsdWU7XG4gIHRoaXMub3B0aW9ucyA9IG9wdGlvbnM7XG59XG5cbkZpbHRlckNTUy5wcm90b3R5cGUucHJvY2VzcyA9IGZ1bmN0aW9uIChjc3MpIHtcbiAgLy8g5YW85a655ZCE56eN5aWH6JGp6L6T5YWlXG4gIGNzcyA9IGNzcyB8fCAnJztcbiAgY3NzID0gY3NzLnRvU3RyaW5nKCk7XG4gIGlmICghY3NzKSByZXR1cm4gJyc7XG5cbiAgdmFyIG1lID0gdGhpcztcbiAgdmFyIG9wdGlvbnMgPSBtZS5vcHRpb25zO1xuICB2YXIgd2hpdGVMaXN0ID0gb3B0aW9ucy53aGl0ZUxpc3Q7XG4gIHZhciBvbkF0dHIgPSBvcHRpb25zLm9uQXR0cjtcbiAgdmFyIG9uSWdub3JlQXR0ciA9IG9wdGlvbnMub25JZ25vcmVBdHRyO1xuICB2YXIgc2FmZUF0dHJWYWx1ZSA9IG9wdGlvbnMuc2FmZUF0dHJWYWx1ZTtcblxuICB2YXIgcmV0Q1NTID0gcGFyc2VTdHlsZShjc3MsIGZ1bmN0aW9uIChzb3VyY2VQb3NpdGlvbiwgcG9zaXRpb24sIG5hbWUsIHZhbHVlLCBzb3VyY2UpIHtcblxuICAgIHZhciBjaGVjayA9IHdoaXRlTGlzdFtuYW1lXTtcbiAgICB2YXIgaXNXaGl0ZSA9IGZhbHNlO1xuICAgIGlmIChjaGVjayA9PT0gdHJ1ZSkgaXNXaGl0ZSA9IGNoZWNrO1xuICAgIGVsc2UgaWYgKHR5cGVvZiBjaGVjayA9PT0gJ2Z1bmN0aW9uJykgaXNXaGl0ZSA9IGNoZWNrKHZhbHVlKTtcbiAgICBlbHNlIGlmIChjaGVjayBpbnN0YW5jZW9mIFJlZ0V4cCkgaXNXaGl0ZSA9IGNoZWNrLnRlc3QodmFsdWUpO1xuICAgIGlmIChpc1doaXRlICE9PSB0cnVlKSBpc1doaXRlID0gZmFsc2U7XG5cbiAgICAvLyDlpoLmnpzov4fmu6TlkI4gdmFsdWUg5Li656m65YiZ55u05o6l5b+955WlXG4gICAgdmFsdWUgPSBzYWZlQXR0clZhbHVlKG5hbWUsIHZhbHVlKTtcbiAgICBpZiAoIXZhbHVlKSByZXR1cm47XG5cbiAgICB2YXIgb3B0cyA9IHtcbiAgICAgIHBvc2l0aW9uOiBwb3NpdGlvbixcbiAgICAgIHNvdXJjZVBvc2l0aW9uOiBzb3VyY2VQb3NpdGlvbixcbiAgICAgIHNvdXJjZTogc291cmNlLFxuICAgICAgaXNXaGl0ZTogaXNXaGl0ZVxuICAgIH07XG5cbiAgICBpZiAoaXNXaGl0ZSkge1xuXG4gICAgICB2YXIgcmV0ID0gb25BdHRyKG5hbWUsIHZhbHVlLCBvcHRzKTtcbiAgICAgIGlmIChpc051bGwocmV0KSkge1xuICAgICAgICByZXR1cm4gbmFtZSArICc6JyArIHZhbHVlO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIHJldDtcbiAgICAgIH1cblxuICAgIH0gZWxzZSB7XG5cbiAgICAgIHZhciByZXQgPSBvbklnbm9yZUF0dHIobmFtZSwgdmFsdWUsIG9wdHMpO1xuICAgICAgaWYgKCFpc051bGwocmV0KSkge1xuICAgICAgICByZXR1cm4gcmV0O1xuICAgICAgfVxuXG4gICAgfVxuICB9KTtcblxuICByZXR1cm4gcmV0Q1NTO1xufTtcblxuXG5tb2R1bGUuZXhwb3J0cyA9IEZpbHRlckNTUztcbiIsIi8qKlxuICogY3NzZmlsdGVyXG4gKlxuICogQGF1dGhvciDogIHpm7c8bGVpem9uZ21pbkBnbWFpbC5jb20+XG4gKi9cblxuZnVuY3Rpb24gZ2V0RGVmYXVsdFdoaXRlTGlzdCAoKSB7XG4gIC8vIOeZveWQjeWNleWAvOivtOaYju+8mlxuICAvLyB0cnVlOiDlhYHorrjor6XlsZ7mgKdcbiAgLy8gRnVuY3Rpb246IGZ1bmN0aW9uICh2YWwpIHsgfSDov5Tlm550cnVl6KGo56S65YWB6K646K+l5bGe5oCn77yM5YW25LuW5YC85Z2H6KGo56S65LiN5YWB6K64XG4gIC8vIFJlZ0V4cDogcmVnZXhwLnRlc3QodmFsKSDov5Tlm550cnVl6KGo56S65YWB6K646K+l5bGe5oCn77yM5YW25LuW5YC85Z2H6KGo56S65LiN5YWB6K64XG4gIC8vIOmZpOS4iumdouWIl+WHuueahOWAvOWkluWdh+ihqOekuuS4jeWFgeiuuFxuICB2YXIgd2hpdGVMaXN0ID0ge307XG5cbiAgd2hpdGVMaXN0WydhbGlnbi1jb250ZW50J10gPSBmYWxzZTsgLy8gZGVmYXVsdDogYXV0b1xuICB3aGl0ZUxpc3RbJ2FsaWduLWl0ZW1zJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogYXV0b1xuICB3aGl0ZUxpc3RbJ2FsaWduLXNlbGYnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBhdXRvXG4gIHdoaXRlTGlzdFsnYWxpZ25tZW50LWFkanVzdCddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IGF1dG9cbiAgd2hpdGVMaXN0WydhbGlnbm1lbnQtYmFzZWxpbmUnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBiYXNlbGluZVxuICB3aGl0ZUxpc3RbJ2FsbCddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IGRlcGVuZGluZyBvbiBpbmRpdmlkdWFsIHByb3BlcnRpZXNcbiAgd2hpdGVMaXN0WydhbmNob3ItcG9pbnQnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBub25lXG4gIHdoaXRlTGlzdFsnYW5pbWF0aW9uJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogZGVwZW5kaW5nIG9uIGluZGl2aWR1YWwgcHJvcGVydGllc1xuICB3aGl0ZUxpc3RbJ2FuaW1hdGlvbi1kZWxheSddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IDBcbiAgd2hpdGVMaXN0WydhbmltYXRpb24tZGlyZWN0aW9uJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogbm9ybWFsXG4gIHdoaXRlTGlzdFsnYW5pbWF0aW9uLWR1cmF0aW9uJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogMFxuICB3aGl0ZUxpc3RbJ2FuaW1hdGlvbi1maWxsLW1vZGUnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBub25lXG4gIHdoaXRlTGlzdFsnYW5pbWF0aW9uLWl0ZXJhdGlvbi1jb3VudCddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IDFcbiAgd2hpdGVMaXN0WydhbmltYXRpb24tbmFtZSddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IG5vbmVcbiAgd2hpdGVMaXN0WydhbmltYXRpb24tcGxheS1zdGF0ZSddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IHJ1bm5pbmdcbiAgd2hpdGVMaXN0WydhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogZWFzZVxuICB3aGl0ZUxpc3RbJ2F6aW11dGgnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBjZW50ZXJcbiAgd2hpdGVMaXN0WydiYWNrZmFjZS12aXNpYmlsaXR5J10gPSBmYWxzZTsgLy8gZGVmYXVsdDogdmlzaWJsZVxuICB3aGl0ZUxpc3RbJ2JhY2tncm91bmQnXSA9IHRydWU7IC8vIGRlZmF1bHQ6IGRlcGVuZGluZyBvbiBpbmRpdmlkdWFsIHByb3BlcnRpZXNcbiAgd2hpdGVMaXN0WydiYWNrZ3JvdW5kLWF0dGFjaG1lbnQnXSA9IHRydWU7IC8vIGRlZmF1bHQ6IHNjcm9sbFxuICB3aGl0ZUxpc3RbJ2JhY2tncm91bmQtY2xpcCddID0gdHJ1ZTsgLy8gZGVmYXVsdDogYm9yZGVyLWJveFxuICB3aGl0ZUxpc3RbJ2JhY2tncm91bmQtY29sb3InXSA9IHRydWU7IC8vIGRlZmF1bHQ6IHRyYW5zcGFyZW50XG4gIHdoaXRlTGlzdFsnYmFja2dyb3VuZC1pbWFnZSddID0gdHJ1ZTsgLy8gZGVmYXVsdDogbm9uZVxuICB3aGl0ZUxpc3RbJ2JhY2tncm91bmQtb3JpZ2luJ10gPSB0cnVlOyAvLyBkZWZhdWx0OiBwYWRkaW5nLWJveFxuICB3aGl0ZUxpc3RbJ2JhY2tncm91bmQtcG9zaXRpb24nXSA9IHRydWU7IC8vIGRlZmF1bHQ6IDAlIDAlXG4gIHdoaXRlTGlzdFsnYmFja2dyb3VuZC1yZXBlYXQnXSA9IHRydWU7IC8vIGRlZmF1bHQ6IHJlcGVhdFxuICB3aGl0ZUxpc3RbJ2JhY2tncm91bmQtc2l6ZSddID0gdHJ1ZTsgLy8gZGVmYXVsdDogYXV0b1xuICB3aGl0ZUxpc3RbJ2Jhc2VsaW5lLXNoaWZ0J10gPSBmYWxzZTsgLy8gZGVmYXVsdDogYmFzZWxpbmVcbiAgd2hpdGVMaXN0WydiaW5kaW5nJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogbm9uZVxuICB3aGl0ZUxpc3RbJ2JsZWVkJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogNnB0XG4gIHdoaXRlTGlzdFsnYm9va21hcmstbGFiZWwnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBjb250ZW50KClcbiAgd2hpdGVMaXN0Wydib29rbWFyay1sZXZlbCddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IG5vbmVcbiAgd2hpdGVMaXN0Wydib29rbWFyay1zdGF0ZSddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IG9wZW5cbiAgd2hpdGVMaXN0Wydib3JkZXInXSA9IHRydWU7IC8vIGRlZmF1bHQ6IGRlcGVuZGluZyBvbiBpbmRpdmlkdWFsIHByb3BlcnRpZXNcbiAgd2hpdGVMaXN0Wydib3JkZXItYm90dG9tJ10gPSB0cnVlOyAvLyBkZWZhdWx0OiBkZXBlbmRpbmcgb24gaW5kaXZpZHVhbCBwcm9wZXJ0aWVzXG4gIHdoaXRlTGlzdFsnYm9yZGVyLWJvdHRvbS1jb2xvciddID0gdHJ1ZTsgLy8gZGVmYXVsdDogY3VycmVudCBjb2xvclxuICB3aGl0ZUxpc3RbJ2JvcmRlci1ib3R0b20tbGVmdC1yYWRpdXMnXSA9IHRydWU7IC8vIGRlZmF1bHQ6IDBcbiAgd2hpdGVMaXN0Wydib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1cyddID0gdHJ1ZTsgLy8gZGVmYXVsdDogMFxuICB3aGl0ZUxpc3RbJ2JvcmRlci1ib3R0b20tc3R5bGUnXSA9IHRydWU7IC8vIGRlZmF1bHQ6IG5vbmVcbiAgd2hpdGVMaXN0Wydib3JkZXItYm90dG9tLXdpZHRoJ10gPSB0cnVlOyAvLyBkZWZhdWx0OiBtZWRpdW1cbiAgd2hpdGVMaXN0Wydib3JkZXItY29sbGFwc2UnXSA9IHRydWU7IC8vIGRlZmF1bHQ6IHNlcGFyYXRlXG4gIHdoaXRlTGlzdFsnYm9yZGVyLWNvbG9yJ10gPSB0cnVlOyAvLyBkZWZhdWx0OiBkZXBlbmRpbmcgb24gaW5kaXZpZHVhbCBwcm9wZXJ0aWVzXG4gIHdoaXRlTGlzdFsnYm9yZGVyLWltYWdlJ10gPSB0cnVlOyAvLyBkZWZhdWx0OiBub25lXG4gIHdoaXRlTGlzdFsnYm9yZGVyLWltYWdlLW91dHNldCddID0gdHJ1ZTsgLy8gZGVmYXVsdDogMFxuICB3aGl0ZUxpc3RbJ2JvcmRlci1pbWFnZS1yZXBlYXQnXSA9IHRydWU7IC8vIGRlZmF1bHQ6IHN0cmV0Y2hcbiAgd2hpdGVMaXN0Wydib3JkZXItaW1hZ2Utc2xpY2UnXSA9IHRydWU7IC8vIGRlZmF1bHQ6IDEwMCVcbiAgd2hpdGVMaXN0Wydib3JkZXItaW1hZ2Utc291cmNlJ10gPSB0cnVlOyAvLyBkZWZhdWx0OiBub25lXG4gIHdoaXRlTGlzdFsnYm9yZGVyLWltYWdlLXdpZHRoJ10gPSB0cnVlOyAvLyBkZWZhdWx0OiAxXG4gIHdoaXRlTGlzdFsnYm9yZGVyLWxlZnQnXSA9IHRydWU7IC8vIGRlZmF1bHQ6IGRlcGVuZGluZyBvbiBpbmRpdmlkdWFsIHByb3BlcnRpZXNcbiAgd2hpdGVMaXN0Wydib3JkZXItbGVmdC1jb2xvciddID0gdHJ1ZTsgLy8gZGVmYXVsdDogY3VycmVudCBjb2xvclxuICB3aGl0ZUxpc3RbJ2JvcmRlci1sZWZ0LXN0eWxlJ10gPSB0cnVlOyAvLyBkZWZhdWx0OiBub25lXG4gIHdoaXRlTGlzdFsnYm9yZGVyLWxlZnQtd2lkdGgnXSA9IHRydWU7IC8vIGRlZmF1bHQ6IG1lZGl1bVxuICB3aGl0ZUxpc3RbJ2JvcmRlci1yYWRpdXMnXSA9IHRydWU7IC8vIGRlZmF1bHQ6IDBcbiAgd2hpdGVMaXN0Wydib3JkZXItcmlnaHQnXSA9IHRydWU7IC8vIGRlZmF1bHQ6IGRlcGVuZGluZyBvbiBpbmRpdmlkdWFsIHByb3BlcnRpZXNcbiAgd2hpdGVMaXN0Wydib3JkZXItcmlnaHQtY29sb3InXSA9IHRydWU7IC8vIGRlZmF1bHQ6IGN1cnJlbnQgY29sb3JcbiAgd2hpdGVMaXN0Wydib3JkZXItcmlnaHQtc3R5bGUnXSA9IHRydWU7IC8vIGRlZmF1bHQ6IG5vbmVcbiAgd2hpdGVMaXN0Wydib3JkZXItcmlnaHQtd2lkdGgnXSA9IHRydWU7IC8vIGRlZmF1bHQ6IG1lZGl1bVxuICB3aGl0ZUxpc3RbJ2JvcmRlci1zcGFjaW5nJ10gPSB0cnVlOyAvLyBkZWZhdWx0OiAwXG4gIHdoaXRlTGlzdFsnYm9yZGVyLXN0eWxlJ10gPSB0cnVlOyAvLyBkZWZhdWx0OiBkZXBlbmRpbmcgb24gaW5kaXZpZHVhbCBwcm9wZXJ0aWVzXG4gIHdoaXRlTGlzdFsnYm9yZGVyLXRvcCddID0gdHJ1ZTsgLy8gZGVmYXVsdDogZGVwZW5kaW5nIG9uIGluZGl2aWR1YWwgcHJvcGVydGllc1xuICB3aGl0ZUxpc3RbJ2JvcmRlci10b3AtY29sb3InXSA9IHRydWU7IC8vIGRlZmF1bHQ6IGN1cnJlbnQgY29sb3JcbiAgd2hpdGVMaXN0Wydib3JkZXItdG9wLWxlZnQtcmFkaXVzJ10gPSB0cnVlOyAvLyBkZWZhdWx0OiAwXG4gIHdoaXRlTGlzdFsnYm9yZGVyLXRvcC1yaWdodC1yYWRpdXMnXSA9IHRydWU7IC8vIGRlZmF1bHQ6IDBcbiAgd2hpdGVMaXN0Wydib3JkZXItdG9wLXN0eWxlJ10gPSB0cnVlOyAvLyBkZWZhdWx0OiBub25lXG4gIHdoaXRlTGlzdFsnYm9yZGVyLXRvcC13aWR0aCddID0gdHJ1ZTsgLy8gZGVmYXVsdDogbWVkaXVtXG4gIHdoaXRlTGlzdFsnYm9yZGVyLXdpZHRoJ10gPSB0cnVlOyAvLyBkZWZhdWx0OiBkZXBlbmRpbmcgb24gaW5kaXZpZHVhbCBwcm9wZXJ0aWVzXG4gIHdoaXRlTGlzdFsnYm90dG9tJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogYXV0b1xuICB3aGl0ZUxpc3RbJ2JveC1kZWNvcmF0aW9uLWJyZWFrJ10gPSB0cnVlOyAvLyBkZWZhdWx0OiBzbGljZVxuICB3aGl0ZUxpc3RbJ2JveC1zaGFkb3cnXSA9IHRydWU7IC8vIGRlZmF1bHQ6IG5vbmVcbiAgd2hpdGVMaXN0Wydib3gtc2l6aW5nJ10gPSB0cnVlOyAvLyBkZWZhdWx0OiBjb250ZW50LWJveFxuICB3aGl0ZUxpc3RbJ2JveC1zbmFwJ10gPSB0cnVlOyAvLyBkZWZhdWx0OiBub25lXG4gIHdoaXRlTGlzdFsnYm94LXN1cHByZXNzJ10gPSB0cnVlOyAvLyBkZWZhdWx0OiBzaG93XG4gIHdoaXRlTGlzdFsnYnJlYWstYWZ0ZXInXSA9IHRydWU7IC8vIGRlZmF1bHQ6IGF1dG9cbiAgd2hpdGVMaXN0WydicmVhay1iZWZvcmUnXSA9IHRydWU7IC8vIGRlZmF1bHQ6IGF1dG9cbiAgd2hpdGVMaXN0WydicmVhay1pbnNpZGUnXSA9IHRydWU7IC8vIGRlZmF1bHQ6IGF1dG9cbiAgd2hpdGVMaXN0WydjYXB0aW9uLXNpZGUnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiB0b3BcbiAgd2hpdGVMaXN0WydjaGFpbnMnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBub25lXG4gIHdoaXRlTGlzdFsnY2xlYXInXSA9IHRydWU7IC8vIGRlZmF1bHQ6IG5vbmVcbiAgd2hpdGVMaXN0WydjbGlwJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogYXV0b1xuICB3aGl0ZUxpc3RbJ2NsaXAtcGF0aCddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IG5vbmVcbiAgd2hpdGVMaXN0WydjbGlwLXJ1bGUnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBub256ZXJvXG4gIHdoaXRlTGlzdFsnY29sb3InXSA9IHRydWU7IC8vIGRlZmF1bHQ6IGltcGxlbWVudGF0aW9uIGRlcGVuZGVudFxuICB3aGl0ZUxpc3RbJ2NvbG9yLWludGVycG9sYXRpb24tZmlsdGVycyddID0gdHJ1ZTsgLy8gZGVmYXVsdDogYXV0b1xuICB3aGl0ZUxpc3RbJ2NvbHVtbi1jb3VudCddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IGF1dG9cbiAgd2hpdGVMaXN0Wydjb2x1bW4tZmlsbCddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IGJhbGFuY2VcbiAgd2hpdGVMaXN0Wydjb2x1bW4tZ2FwJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogbm9ybWFsXG4gIHdoaXRlTGlzdFsnY29sdW1uLXJ1bGUnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBkZXBlbmRpbmcgb24gaW5kaXZpZHVhbCBwcm9wZXJ0aWVzXG4gIHdoaXRlTGlzdFsnY29sdW1uLXJ1bGUtY29sb3InXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBjdXJyZW50IGNvbG9yXG4gIHdoaXRlTGlzdFsnY29sdW1uLXJ1bGUtc3R5bGUnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBtZWRpdW1cbiAgd2hpdGVMaXN0Wydjb2x1bW4tcnVsZS13aWR0aCddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IG1lZGl1bVxuICB3aGl0ZUxpc3RbJ2NvbHVtbi1zcGFuJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogbm9uZVxuICB3aGl0ZUxpc3RbJ2NvbHVtbi13aWR0aCddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IGF1dG9cbiAgd2hpdGVMaXN0Wydjb2x1bW5zJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogZGVwZW5kaW5nIG9uIGluZGl2aWR1YWwgcHJvcGVydGllc1xuICB3aGl0ZUxpc3RbJ2NvbnRhaW4nXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBub25lXG4gIHdoaXRlTGlzdFsnY29udGVudCddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IG5vcm1hbFxuICB3aGl0ZUxpc3RbJ2NvdW50ZXItaW5jcmVtZW50J10gPSBmYWxzZTsgLy8gZGVmYXVsdDogbm9uZVxuICB3aGl0ZUxpc3RbJ2NvdW50ZXItcmVzZXQnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBub25lXG4gIHdoaXRlTGlzdFsnY291bnRlci1zZXQnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBub25lXG4gIHdoaXRlTGlzdFsnY3JvcCddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IGF1dG9cbiAgd2hpdGVMaXN0WydjdWUnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBkZXBlbmRpbmcgb24gaW5kaXZpZHVhbCBwcm9wZXJ0aWVzXG4gIHdoaXRlTGlzdFsnY3VlLWFmdGVyJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogbm9uZVxuICB3aGl0ZUxpc3RbJ2N1ZS1iZWZvcmUnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBub25lXG4gIHdoaXRlTGlzdFsnY3Vyc29yJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogYXV0b1xuICB3aGl0ZUxpc3RbJ2RpcmVjdGlvbiddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IGx0clxuICB3aGl0ZUxpc3RbJ2Rpc3BsYXknXSA9IHRydWU7IC8vIGRlZmF1bHQ6IGRlcGVuZGluZyBvbiBpbmRpdmlkdWFsIHByb3BlcnRpZXNcbiAgd2hpdGVMaXN0WydkaXNwbGF5LWluc2lkZSddID0gdHJ1ZTsgLy8gZGVmYXVsdDogYXV0b1xuICB3aGl0ZUxpc3RbJ2Rpc3BsYXktbGlzdCddID0gdHJ1ZTsgLy8gZGVmYXVsdDogbm9uZVxuICB3aGl0ZUxpc3RbJ2Rpc3BsYXktb3V0c2lkZSddID0gdHJ1ZTsgLy8gZGVmYXVsdDogaW5saW5lLWxldmVsXG4gIHdoaXRlTGlzdFsnZG9taW5hbnQtYmFzZWxpbmUnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBhdXRvXG4gIHdoaXRlTGlzdFsnZWxldmF0aW9uJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogbGV2ZWxcbiAgd2hpdGVMaXN0WydlbXB0eS1jZWxscyddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IHNob3dcbiAgd2hpdGVMaXN0WydmaWx0ZXInXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBub25lXG4gIHdoaXRlTGlzdFsnZmxleCddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IGRlcGVuZGluZyBvbiBpbmRpdmlkdWFsIHByb3BlcnRpZXNcbiAgd2hpdGVMaXN0WydmbGV4LWJhc2lzJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogYXV0b1xuICB3aGl0ZUxpc3RbJ2ZsZXgtZGlyZWN0aW9uJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogcm93XG4gIHdoaXRlTGlzdFsnZmxleC1mbG93J10gPSBmYWxzZTsgLy8gZGVmYXVsdDogZGVwZW5kaW5nIG9uIGluZGl2aWR1YWwgcHJvcGVydGllc1xuICB3aGl0ZUxpc3RbJ2ZsZXgtZ3JvdyddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IDBcbiAgd2hpdGVMaXN0WydmbGV4LXNocmluayddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IDFcbiAgd2hpdGVMaXN0WydmbGV4LXdyYXAnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBub3dyYXBcbiAgd2hpdGVMaXN0WydmbG9hdCddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IG5vbmVcbiAgd2hpdGVMaXN0WydmbG9hdC1vZmZzZXQnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiAwIDBcbiAgd2hpdGVMaXN0WydmbG9vZC1jb2xvciddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IGJsYWNrXG4gIHdoaXRlTGlzdFsnZmxvb2Qtb3BhY2l0eSddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IDFcbiAgd2hpdGVMaXN0WydmbG93LWZyb20nXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBub25lXG4gIHdoaXRlTGlzdFsnZmxvdy1pbnRvJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogbm9uZVxuICB3aGl0ZUxpc3RbJ2ZvbnQnXSA9IHRydWU7IC8vIGRlZmF1bHQ6IGRlcGVuZGluZyBvbiBpbmRpdmlkdWFsIHByb3BlcnRpZXNcbiAgd2hpdGVMaXN0Wydmb250LWZhbWlseSddID0gdHJ1ZTsgLy8gZGVmYXVsdDogaW1wbGVtZW50YXRpb24gZGVwZW5kZW50XG4gIHdoaXRlTGlzdFsnZm9udC1mZWF0dXJlLXNldHRpbmdzJ10gPSB0cnVlOyAvLyBkZWZhdWx0OiBub3JtYWxcbiAgd2hpdGVMaXN0Wydmb250LWtlcm5pbmcnXSA9IHRydWU7IC8vIGRlZmF1bHQ6IGF1dG9cbiAgd2hpdGVMaXN0Wydmb250LWxhbmd1YWdlLW92ZXJyaWRlJ10gPSB0cnVlOyAvLyBkZWZhdWx0OiBub3JtYWxcbiAgd2hpdGVMaXN0Wydmb250LXNpemUnXSA9IHRydWU7IC8vIGRlZmF1bHQ6IG1lZGl1bVxuICB3aGl0ZUxpc3RbJ2ZvbnQtc2l6ZS1hZGp1c3QnXSA9IHRydWU7IC8vIGRlZmF1bHQ6IG5vbmVcbiAgd2hpdGVMaXN0Wydmb250LXN0cmV0Y2gnXSA9IHRydWU7IC8vIGRlZmF1bHQ6IG5vcm1hbFxuICB3aGl0ZUxpc3RbJ2ZvbnQtc3R5bGUnXSA9IHRydWU7IC8vIGRlZmF1bHQ6IG5vcm1hbFxuICB3aGl0ZUxpc3RbJ2ZvbnQtc3ludGhlc2lzJ10gPSB0cnVlOyAvLyBkZWZhdWx0OiB3ZWlnaHQgc3R5bGVcbiAgd2hpdGVMaXN0Wydmb250LXZhcmlhbnQnXSA9IHRydWU7IC8vIGRlZmF1bHQ6IG5vcm1hbFxuICB3aGl0ZUxpc3RbJ2ZvbnQtdmFyaWFudC1hbHRlcm5hdGVzJ10gPSB0cnVlOyAvLyBkZWZhdWx0OiBub3JtYWxcbiAgd2hpdGVMaXN0Wydmb250LXZhcmlhbnQtY2FwcyddID0gdHJ1ZTsgLy8gZGVmYXVsdDogbm9ybWFsXG4gIHdoaXRlTGlzdFsnZm9udC12YXJpYW50LWVhc3QtYXNpYW4nXSA9IHRydWU7IC8vIGRlZmF1bHQ6IG5vcm1hbFxuICB3aGl0ZUxpc3RbJ2ZvbnQtdmFyaWFudC1saWdhdHVyZXMnXSA9IHRydWU7IC8vIGRlZmF1bHQ6IG5vcm1hbFxuICB3aGl0ZUxpc3RbJ2ZvbnQtdmFyaWFudC1udW1lcmljJ10gPSB0cnVlOyAvLyBkZWZhdWx0OiBub3JtYWxcbiAgd2hpdGVMaXN0Wydmb250LXZhcmlhbnQtcG9zaXRpb24nXSA9IHRydWU7IC8vIGRlZmF1bHQ6IG5vcm1hbFxuICB3aGl0ZUxpc3RbJ2ZvbnQtd2VpZ2h0J10gPSB0cnVlOyAvLyBkZWZhdWx0OiBub3JtYWxcbiAgd2hpdGVMaXN0WydncmlkJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogZGVwZW5kaW5nIG9uIGluZGl2aWR1YWwgcHJvcGVydGllc1xuICB3aGl0ZUxpc3RbJ2dyaWQtYXJlYSddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IGRlcGVuZGluZyBvbiBpbmRpdmlkdWFsIHByb3BlcnRpZXNcbiAgd2hpdGVMaXN0WydncmlkLWF1dG8tY29sdW1ucyddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IGF1dG9cbiAgd2hpdGVMaXN0WydncmlkLWF1dG8tZmxvdyddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IG5vbmVcbiAgd2hpdGVMaXN0WydncmlkLWF1dG8tcm93cyddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IGF1dG9cbiAgd2hpdGVMaXN0WydncmlkLWNvbHVtbiddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IGRlcGVuZGluZyBvbiBpbmRpdmlkdWFsIHByb3BlcnRpZXNcbiAgd2hpdGVMaXN0WydncmlkLWNvbHVtbi1lbmQnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBhdXRvXG4gIHdoaXRlTGlzdFsnZ3JpZC1jb2x1bW4tc3RhcnQnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBhdXRvXG4gIHdoaXRlTGlzdFsnZ3JpZC1yb3cnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBkZXBlbmRpbmcgb24gaW5kaXZpZHVhbCBwcm9wZXJ0aWVzXG4gIHdoaXRlTGlzdFsnZ3JpZC1yb3ctZW5kJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogYXV0b1xuICB3aGl0ZUxpc3RbJ2dyaWQtcm93LXN0YXJ0J10gPSBmYWxzZTsgLy8gZGVmYXVsdDogYXV0b1xuICB3aGl0ZUxpc3RbJ2dyaWQtdGVtcGxhdGUnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBkZXBlbmRpbmcgb24gaW5kaXZpZHVhbCBwcm9wZXJ0aWVzXG4gIHdoaXRlTGlzdFsnZ3JpZC10ZW1wbGF0ZS1hcmVhcyddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IG5vbmVcbiAgd2hpdGVMaXN0WydncmlkLXRlbXBsYXRlLWNvbHVtbnMnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBub25lXG4gIHdoaXRlTGlzdFsnZ3JpZC10ZW1wbGF0ZS1yb3dzJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogbm9uZVxuICB3aGl0ZUxpc3RbJ2hhbmdpbmctcHVuY3R1YXRpb24nXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBub25lXG4gIHdoaXRlTGlzdFsnaGVpZ2h0J10gPSB0cnVlOyAvLyBkZWZhdWx0OiBhdXRvXG4gIHdoaXRlTGlzdFsnaHlwaGVucyddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IG1hbnVhbFxuICB3aGl0ZUxpc3RbJ2ljb24nXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBhdXRvXG4gIHdoaXRlTGlzdFsnaW1hZ2Utb3JpZW50YXRpb24nXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBhdXRvXG4gIHdoaXRlTGlzdFsnaW1hZ2UtcmVzb2x1dGlvbiddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IG5vcm1hbFxuICB3aGl0ZUxpc3RbJ2ltZS1tb2RlJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogYXV0b1xuICB3aGl0ZUxpc3RbJ2luaXRpYWwtbGV0dGVycyddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IG5vcm1hbFxuICB3aGl0ZUxpc3RbJ2lubGluZS1ib3gtYWxpZ24nXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBsYXN0XG4gIHdoaXRlTGlzdFsnanVzdGlmeS1jb250ZW50J10gPSBmYWxzZTsgLy8gZGVmYXVsdDogYXV0b1xuICB3aGl0ZUxpc3RbJ2p1c3RpZnktaXRlbXMnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBhdXRvXG4gIHdoaXRlTGlzdFsnanVzdGlmeS1zZWxmJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogYXV0b1xuICB3aGl0ZUxpc3RbJ2xlZnQnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBhdXRvXG4gIHdoaXRlTGlzdFsnbGV0dGVyLXNwYWNpbmcnXSA9IHRydWU7IC8vIGRlZmF1bHQ6IG5vcm1hbFxuICB3aGl0ZUxpc3RbJ2xpZ2h0aW5nLWNvbG9yJ10gPSB0cnVlOyAvLyBkZWZhdWx0OiB3aGl0ZVxuICB3aGl0ZUxpc3RbJ2xpbmUtYm94LWNvbnRhaW4nXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBibG9jayBpbmxpbmUgcmVwbGFjZWRcbiAgd2hpdGVMaXN0WydsaW5lLWJyZWFrJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogYXV0b1xuICB3aGl0ZUxpc3RbJ2xpbmUtZ3JpZCddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IG1hdGNoLXBhcmVudFxuICB3aGl0ZUxpc3RbJ2xpbmUtaGVpZ2h0J10gPSBmYWxzZTsgLy8gZGVmYXVsdDogbm9ybWFsXG4gIHdoaXRlTGlzdFsnbGluZS1zbmFwJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogbm9uZVxuICB3aGl0ZUxpc3RbJ2xpbmUtc3RhY2tpbmcnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBkZXBlbmRpbmcgb24gaW5kaXZpZHVhbCBwcm9wZXJ0aWVzXG4gIHdoaXRlTGlzdFsnbGluZS1zdGFja2luZy1ydWJ5J10gPSBmYWxzZTsgLy8gZGVmYXVsdDogZXhjbHVkZS1ydWJ5XG4gIHdoaXRlTGlzdFsnbGluZS1zdGFja2luZy1zaGlmdCddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IGNvbnNpZGVyLXNoaWZ0c1xuICB3aGl0ZUxpc3RbJ2xpbmUtc3RhY2tpbmctc3RyYXRlZ3knXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBpbmxpbmUtbGluZS1oZWlnaHRcbiAgd2hpdGVMaXN0WydsaXN0LXN0eWxlJ10gPSB0cnVlOyAvLyBkZWZhdWx0OiBkZXBlbmRpbmcgb24gaW5kaXZpZHVhbCBwcm9wZXJ0aWVzXG4gIHdoaXRlTGlzdFsnbGlzdC1zdHlsZS1pbWFnZSddID0gdHJ1ZTsgLy8gZGVmYXVsdDogbm9uZVxuICB3aGl0ZUxpc3RbJ2xpc3Qtc3R5bGUtcG9zaXRpb24nXSA9IHRydWU7IC8vIGRlZmF1bHQ6IG91dHNpZGVcbiAgd2hpdGVMaXN0WydsaXN0LXN0eWxlLXR5cGUnXSA9IHRydWU7IC8vIGRlZmF1bHQ6IGRpc2NcbiAgd2hpdGVMaXN0WydtYXJnaW4nXSA9IHRydWU7IC8vIGRlZmF1bHQ6IGRlcGVuZGluZyBvbiBpbmRpdmlkdWFsIHByb3BlcnRpZXNcbiAgd2hpdGVMaXN0WydtYXJnaW4tYm90dG9tJ10gPSB0cnVlOyAvLyBkZWZhdWx0OiAwXG4gIHdoaXRlTGlzdFsnbWFyZ2luLWxlZnQnXSA9IHRydWU7IC8vIGRlZmF1bHQ6IDBcbiAgd2hpdGVMaXN0WydtYXJnaW4tcmlnaHQnXSA9IHRydWU7IC8vIGRlZmF1bHQ6IDBcbiAgd2hpdGVMaXN0WydtYXJnaW4tdG9wJ10gPSB0cnVlOyAvLyBkZWZhdWx0OiAwXG4gIHdoaXRlTGlzdFsnbWFya2VyLW9mZnNldCddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IGF1dG9cbiAgd2hpdGVMaXN0WydtYXJrZXItc2lkZSddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IGxpc3QtaXRlbVxuICB3aGl0ZUxpc3RbJ21hcmtzJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogbm9uZVxuICB3aGl0ZUxpc3RbJ21hc2snXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBib3JkZXItYm94XG4gIHdoaXRlTGlzdFsnbWFzay1ib3gnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBzZWUgaW5kaXZpZHVhbCBwcm9wZXJ0aWVzXG4gIHdoaXRlTGlzdFsnbWFzay1ib3gtb3V0c2V0J10gPSBmYWxzZTsgLy8gZGVmYXVsdDogMFxuICB3aGl0ZUxpc3RbJ21hc2stYm94LXJlcGVhdCddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IHN0cmV0Y2hcbiAgd2hpdGVMaXN0WydtYXNrLWJveC1zbGljZSddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IDAgZmlsbFxuICB3aGl0ZUxpc3RbJ21hc2stYm94LXNvdXJjZSddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IG5vbmVcbiAgd2hpdGVMaXN0WydtYXNrLWJveC13aWR0aCddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IGF1dG9cbiAgd2hpdGVMaXN0WydtYXNrLWNsaXAnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBib3JkZXItYm94XG4gIHdoaXRlTGlzdFsnbWFzay1pbWFnZSddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IG5vbmVcbiAgd2hpdGVMaXN0WydtYXNrLW9yaWdpbiddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IGJvcmRlci1ib3hcbiAgd2hpdGVMaXN0WydtYXNrLXBvc2l0aW9uJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogY2VudGVyXG4gIHdoaXRlTGlzdFsnbWFzay1yZXBlYXQnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBuby1yZXBlYXRcbiAgd2hpdGVMaXN0WydtYXNrLXNpemUnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBib3JkZXItYm94XG4gIHdoaXRlTGlzdFsnbWFzay1zb3VyY2UtdHlwZSddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IGF1dG9cbiAgd2hpdGVMaXN0WydtYXNrLXR5cGUnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBsdW1pbmFuY2VcbiAgd2hpdGVMaXN0WydtYXgtaGVpZ2h0J10gPSB0cnVlOyAvLyBkZWZhdWx0OiBub25lXG4gIHdoaXRlTGlzdFsnbWF4LWxpbmVzJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogbm9uZVxuICB3aGl0ZUxpc3RbJ21heC13aWR0aCddID0gdHJ1ZTsgLy8gZGVmYXVsdDogbm9uZVxuICB3aGl0ZUxpc3RbJ21pbi1oZWlnaHQnXSA9IHRydWU7IC8vIGRlZmF1bHQ6IDBcbiAgd2hpdGVMaXN0WydtaW4td2lkdGgnXSA9IHRydWU7IC8vIGRlZmF1bHQ6IDBcbiAgd2hpdGVMaXN0Wydtb3ZlLXRvJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogbm9ybWFsXG4gIHdoaXRlTGlzdFsnbmF2LWRvd24nXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBhdXRvXG4gIHdoaXRlTGlzdFsnbmF2LWluZGV4J10gPSBmYWxzZTsgLy8gZGVmYXVsdDogYXV0b1xuICB3aGl0ZUxpc3RbJ25hdi1sZWZ0J10gPSBmYWxzZTsgLy8gZGVmYXVsdDogYXV0b1xuICB3aGl0ZUxpc3RbJ25hdi1yaWdodCddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IGF1dG9cbiAgd2hpdGVMaXN0WyduYXYtdXAnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBhdXRvXG4gIHdoaXRlTGlzdFsnb2JqZWN0LWZpdCddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IGZpbGxcbiAgd2hpdGVMaXN0WydvYmplY3QtcG9zaXRpb24nXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiA1MCUgNTAlXG4gIHdoaXRlTGlzdFsnb3BhY2l0eSddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IDFcbiAgd2hpdGVMaXN0WydvcmRlciddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IDBcbiAgd2hpdGVMaXN0WydvcnBoYW5zJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogMlxuICB3aGl0ZUxpc3RbJ291dGxpbmUnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBkZXBlbmRpbmcgb24gaW5kaXZpZHVhbCBwcm9wZXJ0aWVzXG4gIHdoaXRlTGlzdFsnb3V0bGluZS1jb2xvciddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IGludmVydFxuICB3aGl0ZUxpc3RbJ291dGxpbmUtb2Zmc2V0J10gPSBmYWxzZTsgLy8gZGVmYXVsdDogMFxuICB3aGl0ZUxpc3RbJ291dGxpbmUtc3R5bGUnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBub25lXG4gIHdoaXRlTGlzdFsnb3V0bGluZS13aWR0aCddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IG1lZGl1bVxuICB3aGl0ZUxpc3RbJ292ZXJmbG93J10gPSBmYWxzZTsgLy8gZGVmYXVsdDogZGVwZW5kaW5nIG9uIGluZGl2aWR1YWwgcHJvcGVydGllc1xuICB3aGl0ZUxpc3RbJ292ZXJmbG93LXdyYXAnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBub3JtYWxcbiAgd2hpdGVMaXN0WydvdmVyZmxvdy14J10gPSBmYWxzZTsgLy8gZGVmYXVsdDogdmlzaWJsZVxuICB3aGl0ZUxpc3RbJ292ZXJmbG93LXknXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiB2aXNpYmxlXG4gIHdoaXRlTGlzdFsncGFkZGluZyddID0gdHJ1ZTsgLy8gZGVmYXVsdDogZGVwZW5kaW5nIG9uIGluZGl2aWR1YWwgcHJvcGVydGllc1xuICB3aGl0ZUxpc3RbJ3BhZGRpbmctYm90dG9tJ10gPSB0cnVlOyAvLyBkZWZhdWx0OiAwXG4gIHdoaXRlTGlzdFsncGFkZGluZy1sZWZ0J10gPSB0cnVlOyAvLyBkZWZhdWx0OiAwXG4gIHdoaXRlTGlzdFsncGFkZGluZy1yaWdodCddID0gdHJ1ZTsgLy8gZGVmYXVsdDogMFxuICB3aGl0ZUxpc3RbJ3BhZGRpbmctdG9wJ10gPSB0cnVlOyAvLyBkZWZhdWx0OiAwXG4gIHdoaXRlTGlzdFsncGFnZSddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IGF1dG9cbiAgd2hpdGVMaXN0WydwYWdlLWJyZWFrLWFmdGVyJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogYXV0b1xuICB3aGl0ZUxpc3RbJ3BhZ2UtYnJlYWstYmVmb3JlJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogYXV0b1xuICB3aGl0ZUxpc3RbJ3BhZ2UtYnJlYWstaW5zaWRlJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogYXV0b1xuICB3aGl0ZUxpc3RbJ3BhZ2UtcG9saWN5J10gPSBmYWxzZTsgLy8gZGVmYXVsdDogc3RhcnRcbiAgd2hpdGVMaXN0WydwYXVzZSddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IGltcGxlbWVudGF0aW9uIGRlcGVuZGVudFxuICB3aGl0ZUxpc3RbJ3BhdXNlLWFmdGVyJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogaW1wbGVtZW50YXRpb24gZGVwZW5kZW50XG4gIHdoaXRlTGlzdFsncGF1c2UtYmVmb3JlJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogaW1wbGVtZW50YXRpb24gZGVwZW5kZW50XG4gIHdoaXRlTGlzdFsncGVyc3BlY3RpdmUnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBub25lXG4gIHdoaXRlTGlzdFsncGVyc3BlY3RpdmUtb3JpZ2luJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogNTAlIDUwJVxuICB3aGl0ZUxpc3RbJ3BpdGNoJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogbWVkaXVtXG4gIHdoaXRlTGlzdFsncGl0Y2gtcmFuZ2UnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiA1MFxuICB3aGl0ZUxpc3RbJ3BsYXktZHVyaW5nJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogYXV0b1xuICB3aGl0ZUxpc3RbJ3Bvc2l0aW9uJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogc3RhdGljXG4gIHdoaXRlTGlzdFsncHJlc2VudGF0aW9uLWxldmVsJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogMFxuICB3aGl0ZUxpc3RbJ3F1b3RlcyddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IHRleHRcbiAgd2hpdGVMaXN0WydyZWdpb24tZnJhZ21lbnQnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBhdXRvXG4gIHdoaXRlTGlzdFsncmVzaXplJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogbm9uZVxuICB3aGl0ZUxpc3RbJ3Jlc3QnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBkZXBlbmRpbmcgb24gaW5kaXZpZHVhbCBwcm9wZXJ0aWVzXG4gIHdoaXRlTGlzdFsncmVzdC1hZnRlciddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IG5vbmVcbiAgd2hpdGVMaXN0WydyZXN0LWJlZm9yZSddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IG5vbmVcbiAgd2hpdGVMaXN0WydyaWNobmVzcyddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IDUwXG4gIHdoaXRlTGlzdFsncmlnaHQnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBhdXRvXG4gIHdoaXRlTGlzdFsncm90YXRpb24nXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiAwXG4gIHdoaXRlTGlzdFsncm90YXRpb24tcG9pbnQnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiA1MCUgNTAlXG4gIHdoaXRlTGlzdFsncnVieS1hbGlnbiddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IGF1dG9cbiAgd2hpdGVMaXN0WydydWJ5LW1lcmdlJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogc2VwYXJhdGVcbiAgd2hpdGVMaXN0WydydWJ5LXBvc2l0aW9uJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogYmVmb3JlXG4gIHdoaXRlTGlzdFsnc2hhcGUtaW1hZ2UtdGhyZXNob2xkJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogMC4wXG4gIHdoaXRlTGlzdFsnc2hhcGUtb3V0c2lkZSddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IG5vbmVcbiAgd2hpdGVMaXN0WydzaGFwZS1tYXJnaW4nXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiAwXG4gIHdoaXRlTGlzdFsnc2l6ZSddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IGF1dG9cbiAgd2hpdGVMaXN0WydzcGVhayddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IGF1dG9cbiAgd2hpdGVMaXN0WydzcGVhay1hcyddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IG5vcm1hbFxuICB3aGl0ZUxpc3RbJ3NwZWFrLWhlYWRlciddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IG9uY2VcbiAgd2hpdGVMaXN0WydzcGVhay1udW1lcmFsJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogY29udGludW91c1xuICB3aGl0ZUxpc3RbJ3NwZWFrLXB1bmN0dWF0aW9uJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogbm9uZVxuICB3aGl0ZUxpc3RbJ3NwZWVjaC1yYXRlJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogbWVkaXVtXG4gIHdoaXRlTGlzdFsnc3RyZXNzJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogNTBcbiAgd2hpdGVMaXN0WydzdHJpbmctc2V0J10gPSBmYWxzZTsgLy8gZGVmYXVsdDogbm9uZVxuICB3aGl0ZUxpc3RbJ3RhYi1zaXplJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogOFxuICB3aGl0ZUxpc3RbJ3RhYmxlLWxheW91dCddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IGF1dG9cbiAgd2hpdGVMaXN0Wyd0ZXh0LWFsaWduJ10gPSB0cnVlOyAvLyBkZWZhdWx0OiBzdGFydFxuICB3aGl0ZUxpc3RbJ3RleHQtYWxpZ24tbGFzdCddID0gdHJ1ZTsgLy8gZGVmYXVsdDogYXV0b1xuICB3aGl0ZUxpc3RbJ3RleHQtY29tYmluZS11cHJpZ2h0J10gPSB0cnVlOyAvLyBkZWZhdWx0OiBub25lXG4gIHdoaXRlTGlzdFsndGV4dC1kZWNvcmF0aW9uJ10gPSB0cnVlOyAvLyBkZWZhdWx0OiBub25lXG4gIHdoaXRlTGlzdFsndGV4dC1kZWNvcmF0aW9uLWNvbG9yJ10gPSB0cnVlOyAvLyBkZWZhdWx0OiBjdXJyZW50Q29sb3JcbiAgd2hpdGVMaXN0Wyd0ZXh0LWRlY29yYXRpb24tbGluZSddID0gdHJ1ZTsgLy8gZGVmYXVsdDogbm9uZVxuICB3aGl0ZUxpc3RbJ3RleHQtZGVjb3JhdGlvbi1za2lwJ10gPSB0cnVlOyAvLyBkZWZhdWx0OiBvYmplY3RzXG4gIHdoaXRlTGlzdFsndGV4dC1kZWNvcmF0aW9uLXN0eWxlJ10gPSB0cnVlOyAvLyBkZWZhdWx0OiBzb2xpZFxuICB3aGl0ZUxpc3RbJ3RleHQtZW1waGFzaXMnXSA9IHRydWU7IC8vIGRlZmF1bHQ6IGRlcGVuZGluZyBvbiBpbmRpdmlkdWFsIHByb3BlcnRpZXNcbiAgd2hpdGVMaXN0Wyd0ZXh0LWVtcGhhc2lzLWNvbG9yJ10gPSB0cnVlOyAvLyBkZWZhdWx0OiBjdXJyZW50Q29sb3JcbiAgd2hpdGVMaXN0Wyd0ZXh0LWVtcGhhc2lzLXBvc2l0aW9uJ10gPSB0cnVlOyAvLyBkZWZhdWx0OiBvdmVyIHJpZ2h0XG4gIHdoaXRlTGlzdFsndGV4dC1lbXBoYXNpcy1zdHlsZSddID0gdHJ1ZTsgLy8gZGVmYXVsdDogbm9uZVxuICB3aGl0ZUxpc3RbJ3RleHQtaGVpZ2h0J10gPSB0cnVlOyAvLyBkZWZhdWx0OiBhdXRvXG4gIHdoaXRlTGlzdFsndGV4dC1pbmRlbnQnXSA9IHRydWU7IC8vIGRlZmF1bHQ6IDBcbiAgd2hpdGVMaXN0Wyd0ZXh0LWp1c3RpZnknXSA9IHRydWU7IC8vIGRlZmF1bHQ6IGF1dG9cbiAgd2hpdGVMaXN0Wyd0ZXh0LW9yaWVudGF0aW9uJ10gPSB0cnVlOyAvLyBkZWZhdWx0OiBtaXhlZFxuICB3aGl0ZUxpc3RbJ3RleHQtb3ZlcmZsb3cnXSA9IHRydWU7IC8vIGRlZmF1bHQ6IGNsaXBcbiAgd2hpdGVMaXN0Wyd0ZXh0LXNoYWRvdyddID0gdHJ1ZTsgLy8gZGVmYXVsdDogbm9uZVxuICB3aGl0ZUxpc3RbJ3RleHQtc3BhY2UtY29sbGFwc2UnXSA9IHRydWU7IC8vIGRlZmF1bHQ6IGNvbGxhcHNlXG4gIHdoaXRlTGlzdFsndGV4dC10cmFuc2Zvcm0nXSA9IHRydWU7IC8vIGRlZmF1bHQ6IG5vbmVcbiAgd2hpdGVMaXN0Wyd0ZXh0LXVuZGVybGluZS1wb3NpdGlvbiddID0gdHJ1ZTsgLy8gZGVmYXVsdDogYXV0b1xuICB3aGl0ZUxpc3RbJ3RleHQtd3JhcCddID0gdHJ1ZTsgLy8gZGVmYXVsdDogbm9ybWFsXG4gIHdoaXRlTGlzdFsndG9wJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogYXV0b1xuICB3aGl0ZUxpc3RbJ3RyYW5zZm9ybSddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IG5vbmVcbiAgd2hpdGVMaXN0Wyd0cmFuc2Zvcm0tb3JpZ2luJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogNTAlIDUwJSAwXG4gIHdoaXRlTGlzdFsndHJhbnNmb3JtLXN0eWxlJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogZmxhdFxuICB3aGl0ZUxpc3RbJ3RyYW5zaXRpb24nXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBkZXBlbmRpbmcgb24gaW5kaXZpZHVhbCBwcm9wZXJ0aWVzXG4gIHdoaXRlTGlzdFsndHJhbnNpdGlvbi1kZWxheSddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IDBzXG4gIHdoaXRlTGlzdFsndHJhbnNpdGlvbi1kdXJhdGlvbiddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IDBzXG4gIHdoaXRlTGlzdFsndHJhbnNpdGlvbi1wcm9wZXJ0eSddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IGFsbFxuICB3aGl0ZUxpc3RbJ3RyYW5zaXRpb24tdGltaW5nLWZ1bmN0aW9uJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogZWFzZVxuICB3aGl0ZUxpc3RbJ3VuaWNvZGUtYmlkaSddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IG5vcm1hbFxuICB3aGl0ZUxpc3RbJ3ZlcnRpY2FsLWFsaWduJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogYmFzZWxpbmVcbiAgd2hpdGVMaXN0Wyd2aXNpYmlsaXR5J10gPSBmYWxzZTsgLy8gZGVmYXVsdDogdmlzaWJsZVxuICB3aGl0ZUxpc3RbJ3ZvaWNlLWJhbGFuY2UnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBjZW50ZXJcbiAgd2hpdGVMaXN0Wyd2b2ljZS1kdXJhdGlvbiddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IGF1dG9cbiAgd2hpdGVMaXN0Wyd2b2ljZS1mYW1pbHknXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBpbXBsZW1lbnRhdGlvbiBkZXBlbmRlbnRcbiAgd2hpdGVMaXN0Wyd2b2ljZS1waXRjaCddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IG1lZGl1bVxuICB3aGl0ZUxpc3RbJ3ZvaWNlLXJhbmdlJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogbWVkaXVtXG4gIHdoaXRlTGlzdFsndm9pY2UtcmF0ZSddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IG5vcm1hbFxuICB3aGl0ZUxpc3RbJ3ZvaWNlLXN0cmVzcyddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IG5vcm1hbFxuICB3aGl0ZUxpc3RbJ3ZvaWNlLXZvbHVtZSddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IG1lZGl1bVxuICB3aGl0ZUxpc3RbJ3ZvbHVtZSddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IG1lZGl1bVxuICB3aGl0ZUxpc3RbJ3doaXRlLXNwYWNlJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogbm9ybWFsXG4gIHdoaXRlTGlzdFsnd2lkb3dzJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogMlxuICB3aGl0ZUxpc3RbJ3dpZHRoJ10gPSB0cnVlOyAvLyBkZWZhdWx0OiBhdXRvXG4gIHdoaXRlTGlzdFsnd2lsbC1jaGFuZ2UnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBhdXRvXG4gIHdoaXRlTGlzdFsnd29yZC1icmVhayddID0gdHJ1ZTsgLy8gZGVmYXVsdDogbm9ybWFsXG4gIHdoaXRlTGlzdFsnd29yZC1zcGFjaW5nJ10gPSB0cnVlOyAvLyBkZWZhdWx0OiBub3JtYWxcbiAgd2hpdGVMaXN0Wyd3b3JkLXdyYXAnXSA9IHRydWU7IC8vIGRlZmF1bHQ6IG5vcm1hbFxuICB3aGl0ZUxpc3RbJ3dyYXAtZmxvdyddID0gZmFsc2U7IC8vIGRlZmF1bHQ6IGF1dG9cbiAgd2hpdGVMaXN0Wyd3cmFwLXRocm91Z2gnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiB3cmFwXG4gIHdoaXRlTGlzdFsnd3JpdGluZy1tb2RlJ10gPSBmYWxzZTsgLy8gZGVmYXVsdDogaG9yaXpvbnRhbC10YlxuICB3aGl0ZUxpc3RbJ3otaW5kZXgnXSA9IGZhbHNlOyAvLyBkZWZhdWx0OiBhdXRvXG5cbiAgcmV0dXJuIHdoaXRlTGlzdDtcbn1cblxuXG4vKipcbiAqIOWMuemFjeWIsOeZveWQjeWNleS4iueahOS4gOS4quWxnuaAp+aXtlxuICpcbiAqIEBwYXJhbSB7U3RyaW5nfSBuYW1lXG4gKiBAcGFyYW0ge1N0cmluZ30gdmFsdWVcbiAqIEBwYXJhbSB7T2JqZWN0fSBvcHRpb25zXG4gKiBAcmV0dXJuIHtTdHJpbmd9XG4gKi9cbmZ1bmN0aW9uIG9uQXR0ciAobmFtZSwgdmFsdWUsIG9wdGlvbnMpIHtcbiAgLy8gZG8gbm90aGluZ1xufVxuXG4vKipcbiAqIOWMuemFjeWIsOS4jeWcqOeZveWQjeWNleS4iueahOS4gOS4quWxnuaAp+aXtlxuICpcbiAqIEBwYXJhbSB7U3RyaW5nfSBuYW1lXG4gKiBAcGFyYW0ge1N0cmluZ30gdmFsdWVcbiAqIEBwYXJhbSB7T2JqZWN0fSBvcHRpb25zXG4gKiBAcmV0dXJuIHtTdHJpbmd9XG4gKi9cbmZ1bmN0aW9uIG9uSWdub3JlQXR0ciAobmFtZSwgdmFsdWUsIG9wdGlvbnMpIHtcbiAgLy8gZG8gbm90aGluZ1xufVxuXG52YXIgUkVHRVhQX1VSTF9KQVZBU0NSSVBUID0gL2phdmFzY3JpcHRcXHMqXFw6L2ltZztcblxuLyoqXG4gKiDov4fmu6TlsZ7mgKflgLxcbiAqXG4gKiBAcGFyYW0ge1N0cmluZ30gbmFtZVxuICogQHBhcmFtIHtTdHJpbmd9IHZhbHVlXG4gKiBAcmV0dXJuIHtTdHJpbmd9XG4gKi9cbmZ1bmN0aW9uIHNhZmVBdHRyVmFsdWUobmFtZSwgdmFsdWUpIHtcbiAgaWYgKFJFR0VYUF9VUkxfSkFWQVNDUklQVC50ZXN0KHZhbHVlKSkgcmV0dXJuICcnO1xuICByZXR1cm4gdmFsdWU7XG59XG5cblxuZXhwb3J0cy53aGl0ZUxpc3QgPSBnZXREZWZhdWx0V2hpdGVMaXN0KCk7XG5leHBvcnRzLmdldERlZmF1bHRXaGl0ZUxpc3QgPSBnZXREZWZhdWx0V2hpdGVMaXN0O1xuZXhwb3J0cy5vbkF0dHIgPSBvbkF0dHI7XG5leHBvcnRzLm9uSWdub3JlQXR0ciA9IG9uSWdub3JlQXR0cjtcbmV4cG9ydHMuc2FmZUF0dHJWYWx1ZSA9IHNhZmVBdHRyVmFsdWU7XG4iLCIvKipcbiAqIGNzc2ZpbHRlclxuICpcbiAqIEBhdXRob3Ig6ICB6Zu3PGxlaXpvbmdtaW5AZ21haWwuY29tPlxuICovXG5cbnZhciBERUZBVUxUID0gcmVxdWlyZSgnLi9kZWZhdWx0Jyk7XG52YXIgRmlsdGVyQ1NTID0gcmVxdWlyZSgnLi9jc3MnKTtcblxuXG4vKipcbiAqIFhTU+i/h+a7pFxuICpcbiAqIEBwYXJhbSB7U3RyaW5nfSBjc3Mg6KaB6L+H5ruk55qEQ1NT5Luj56CBXG4gKiBAcGFyYW0ge09iamVjdH0gb3B0aW9ucyDpgInpobnvvJp3aGl0ZUxpc3QsIG9uQXR0ciwgb25JZ25vcmVBdHRyXG4gKiBAcmV0dXJuIHtTdHJpbmd9XG4gKi9cbmZ1bmN0aW9uIGZpbHRlckNTUyAoaHRtbCwgb3B0aW9ucykge1xuICB2YXIgeHNzID0gbmV3IEZpbHRlckNTUyhvcHRpb25zKTtcbiAgcmV0dXJuIHhzcy5wcm9jZXNzKGh0bWwpO1xufVxuXG5cbi8vIOi+k+WHulxuZXhwb3J0cyA9IG1vZHVsZS5leHBvcnRzID0gZmlsdGVyQ1NTO1xuZXhwb3J0cy5GaWx0ZXJDU1MgPSBGaWx0ZXJDU1M7XG5mb3IgKHZhciBpIGluIERFRkFVTFQpIGV4cG9ydHNbaV0gPSBERUZBVUxUW2ldO1xuXG4vLyDlnKjmtY/op4jlmajnq6/kvb/nlKhcbmlmICh0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJykge1xuICB3aW5kb3cuZmlsdGVyQ1NTID0gbW9kdWxlLmV4cG9ydHM7XG59XG4iLCIvKipcbiAqIGNzc2ZpbHRlclxuICpcbiAqIEBhdXRob3Ig6ICB6Zu3PGxlaXpvbmdtaW5AZ21haWwuY29tPlxuICovXG5cbnZhciBfID0gcmVxdWlyZSgnLi91dGlsJyk7XG5cblxuLyoqXG4gKiDop6PmnpBzdHlsZVxuICpcbiAqIEBwYXJhbSB7U3RyaW5nfSBjc3NcbiAqIEBwYXJhbSB7RnVuY3Rpb259IG9uQXR0ciDlpITnkIblsZ7mgKfnmoTlh73mlbBcbiAqICAg5Y+C5pWw5qC85byP77yaIGZ1bmN0aW9uIChzb3VyY2VQb3NpdGlvbiwgcG9zaXRpb24sIG5hbWUsIHZhbHVlLCBzb3VyY2UpXG4gKiBAcmV0dXJuIHtTdHJpbmd9XG4gKi9cbmZ1bmN0aW9uIHBhcnNlU3R5bGUgKGNzcywgb25BdHRyKSB7XG4gIGNzcyA9IF8udHJpbVJpZ2h0KGNzcyk7XG4gIGlmIChjc3NbY3NzLmxlbmd0aCAtIDFdICE9PSAnOycpIGNzcyArPSAnOyc7XG4gIHZhciBjc3NMZW5ndGggPSBjc3MubGVuZ3RoO1xuICB2YXIgaXNQYXJlbnRoZXNpc09wZW4gPSBmYWxzZTtcbiAgdmFyIGxhc3RQb3MgPSAwO1xuICB2YXIgaSA9IDA7XG4gIHZhciByZXRDU1MgPSAnJztcblxuICBmdW5jdGlvbiBhZGROZXdBdHRyICgpIHtcbiAgICAvLyDlpoLmnpzmsqHmnInmraPluLjnmoTpl63lkIjlnIbmi6zlj7fvvIzliJnnm7TmjqXlv73nlaXlvZPliY3lsZ7mgKdcbiAgICBpZiAoIWlzUGFyZW50aGVzaXNPcGVuKSB7XG4gICAgICB2YXIgc291cmNlID0gXy50cmltKGNzcy5zbGljZShsYXN0UG9zLCBpKSk7XG4gICAgICB2YXIgaiA9IHNvdXJjZS5pbmRleE9mKCc6Jyk7XG4gICAgICBpZiAoaiAhPT0gLTEpIHtcbiAgICAgICAgdmFyIG5hbWUgPSBfLnRyaW0oc291cmNlLnNsaWNlKDAsIGopKTtcbiAgICAgICAgdmFyIHZhbHVlID0gXy50cmltKHNvdXJjZS5zbGljZShqICsgMSkpO1xuICAgICAgICAvLyDlv4XpobvmnInlsZ7mgKflkI3np7BcbiAgICAgICAgaWYgKG5hbWUpIHtcbiAgICAgICAgICB2YXIgcmV0ID0gb25BdHRyKGxhc3RQb3MsIHJldENTUy5sZW5ndGgsIG5hbWUsIHZhbHVlLCBzb3VyY2UpO1xuICAgICAgICAgIGlmIChyZXQpIHJldENTUyArPSByZXQgKyAnOyAnO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIGxhc3RQb3MgPSBpICsgMTtcbiAgfVxuXG4gIGZvciAoOyBpIDwgY3NzTGVuZ3RoOyBpKyspIHtcbiAgICB2YXIgYyA9IGNzc1tpXTtcbiAgICBpZiAoYyA9PT0gJy8nICYmIGNzc1tpICsgMV0gPT09ICcqJykge1xuICAgICAgLy8g5aSH5rOo5byA5aeLXG4gICAgICB2YXIgaiA9IGNzcy5pbmRleE9mKCcqLycsIGkgKyAyKTtcbiAgICAgIC8vIOWmguaenOayoeacieato+W4uOeahOWkh+azqOe7k+adn++8jOWImeWQjumdoueahOmDqOWIhuWFqOmDqOi3s+i/h1xuICAgICAgaWYgKGogPT09IC0xKSBicmVhaztcbiAgICAgIC8vIOebtOaOpeWwhuW9k+WJjeS9jee9ruiwg+WIsOWkh+azqOe7k+Wwvu+8jOW5tuS4lOWIneWni+WMlueKtuaAgVxuICAgICAgaSA9IGogKyAxO1xuICAgICAgbGFzdFBvcyA9IGkgKyAxO1xuICAgICAgaXNQYXJlbnRoZXNpc09wZW4gPSBmYWxzZTtcbiAgICB9IGVsc2UgaWYgKGMgPT09ICcoJykge1xuICAgICAgaXNQYXJlbnRoZXNpc09wZW4gPSB0cnVlO1xuICAgIH0gZWxzZSBpZiAoYyA9PT0gJyknKSB7XG4gICAgICBpc1BhcmVudGhlc2lzT3BlbiA9IGZhbHNlO1xuICAgIH0gZWxzZSBpZiAoYyA9PT0gJzsnKSB7XG4gICAgICBpZiAoaXNQYXJlbnRoZXNpc09wZW4pIHtcbiAgICAgICAgLy8g5Zyo5ZyG5ous5Y+36YeM6Z2i77yM5b+955WlXG4gICAgICB9IGVsc2Uge1xuICAgICAgICBhZGROZXdBdHRyKCk7XG4gICAgICB9XG4gICAgfSBlbHNlIGlmIChjID09PSAnXFxuJykge1xuICAgICAgYWRkTmV3QXR0cigpO1xuICAgIH1cbiAgfVxuXG4gIHJldHVybiBfLnRyaW0ocmV0Q1NTKTtcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBwYXJzZVN0eWxlO1xuIiwibW9kdWxlLmV4cG9ydHMgPSB7XG4gIGluZGV4T2Y6IGZ1bmN0aW9uIChhcnIsIGl0ZW0pIHtcbiAgICB2YXIgaSwgajtcbiAgICBpZiAoQXJyYXkucHJvdG90eXBlLmluZGV4T2YpIHtcbiAgICAgIHJldHVybiBhcnIuaW5kZXhPZihpdGVtKTtcbiAgICB9XG4gICAgZm9yIChpID0gMCwgaiA9IGFyci5sZW5ndGg7IGkgPCBqOyBpKyspIHtcbiAgICAgIGlmIChhcnJbaV0gPT09IGl0ZW0pIHtcbiAgICAgICAgcmV0dXJuIGk7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiAtMTtcbiAgfSxcbiAgZm9yRWFjaDogZnVuY3Rpb24gKGFyciwgZm4sIHNjb3BlKSB7XG4gICAgdmFyIGksIGo7XG4gICAgaWYgKEFycmF5LnByb3RvdHlwZS5mb3JFYWNoKSB7XG4gICAgICByZXR1cm4gYXJyLmZvckVhY2goZm4sIHNjb3BlKTtcbiAgICB9XG4gICAgZm9yIChpID0gMCwgaiA9IGFyci5sZW5ndGg7IGkgPCBqOyBpKyspIHtcbiAgICAgIGZuLmNhbGwoc2NvcGUsIGFycltpXSwgaSwgYXJyKTtcbiAgICB9XG4gIH0sXG4gIHRyaW06IGZ1bmN0aW9uIChzdHIpIHtcbiAgICBpZiAoU3RyaW5nLnByb3RvdHlwZS50cmltKSB7XG4gICAgICByZXR1cm4gc3RyLnRyaW0oKTtcbiAgICB9XG4gICAgcmV0dXJuIHN0ci5yZXBsYWNlKC8oXlxccyopfChcXHMqJCkvZywgJycpO1xuICB9LFxuICB0cmltUmlnaHQ6IGZ1bmN0aW9uIChzdHIpIHtcbiAgICBpZiAoU3RyaW5nLnByb3RvdHlwZS50cmltUmlnaHQpIHtcbiAgICAgIHJldHVybiBzdHIudHJpbVJpZ2h0KCk7XG4gICAgfVxuICAgIHJldHVybiBzdHIucmVwbGFjZSgvKFxccyokKS9nLCAnJyk7XG4gIH1cbn07XG4iLCJjb25zdCBtZW1vcnkgPSByZXF1aXJlKCcuL2xpYi9tZW1vcnknKVxuY29uc3QgZm9ybWF0WHNzID0gcmVxdWlyZShcIi4vbGliL2Zvcm1hdFhzc1wiKVxuY29uc3QgY29va2llID0gcmVxdWlyZShcIi4vbGliL2Nvb2tpZVwiKVxuY29uc3QgdXRpbCA9IHJlcXVpcmUoXCIuL2xpYi91dGlsXCIpXG5cbmV4cG9ydHMuaXNNb2JpbGVPck1haWwgPSB1dGlsLmlzTW9iaWxlT3JNYWlsO1xuZXhwb3J0cy5pc01vYmlsZSA9IHV0aWwuaXNNb2JpbGU7XG5leHBvcnRzLmlzTWFpbCA9IHV0aWwuaXNNYWlsO1xuZXhwb3J0cy5tZW1vcnkgPSBtZW1vcnk7XG5leHBvcnRzLmZvcm1hdFhzcyA9IGZvcm1hdFhzcztcbmV4cG9ydHMuY29va2llID0gY29va2llO1xuZXhwb3J0cy5kZWJvdW5jZSA9IHV0aWwuZGVib3VuY2U7XG5leHBvcnRzLnRocm90dGxlID0gdXRpbC50aHJvdHRsZVxuLy/lsIbmlbTkuKrmqKHlnZflr7zlh7pcbm1vZHVsZS5leHBvcnRzLmpzYlV0aWwgPSB7XG4gICAgLi4udXRpbCwgZm9ybWF0WHNzLCBtZW1vcnksIGNvb2tpZVxufVxuIiwiLyoqXG4gKiBAZGVzY3JpcHRpb246Y29va2ll5Z+65pys566h55CGXG4gKi9cbmZ1bmN0aW9uIENvb2tpZSgpIHtcblxufVxuXG4vKipcbiAqIEBkZXNjcmlwdGlvbjrojrflj5blr7nlupTnmoRrZXlcbiAqIEBwYXJhbSB7c3RyaW5nfSBrZXkga2V5XG4gKiBAcGFyYW0ge2FueXN9IHZhbHVlIOayoeacieaJvuWIsOaXtui/lOWbnueahOmihOiuvuWAvO+8jOm7mOiupGZhbHNlXG4gKiBAcmV0dXJuIHtzdHJpbmd8Qm9vbGVhbn0gc3RyaW5nIC8gZmFsc2VcbiAqL1xuQ29va2llLnByb3RvdHlwZS5nZXQgPSBmdW5jdGlvbiAoa2V5LCBkZWYgPSBmYWxzZSkge1xuICAgIGxldCBhcnIgPSBkb2N1bWVudC5jb29raWUuc3BsaXQoXCI7XCIpO1xuICAgIGZvciAobGV0IGl0ZW0gb2YgYXJyKSB7XG4gICAgICAgIGNvbnN0IGVsID0gaXRlbS5zcGxpdChcIj1cIik7XG4gICAgICAgIGlmIChlbFswXS50cmltKCkgPT09IGtleSkge1xuICAgICAgICAgICAgcmV0dXJuIGVsWzFdO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBkZWY7XG59XG4vKipcbiAqIEBkZXNjcmlwdGlvbjrorr7nva7lr7nlupTnmoRrZXkgdmFsdWVcbiAqIEBwYXJhbSB7c3RyaW5nfSBrZXkga2V5XG4gKiBAcGFyYW0ge3N0cmluZ30gdmFsdWUgdmFsdWVcbiAqIEBwYXJhbSB7RGF0ZX0gZXhwaXJlcyDov4fmnJ/ml7bpl7QgRGF0ZeWvueixoVxuICogQHJldHVybiB7Qm9vbGVhbn0gQm9vbGVhblxuICovXG5Db29raWUucHJvdG90eXBlLnNldCA9IGZ1bmN0aW9uIChrZXksIHZhbHVlLCBleHBpcmVzID0gXCJcIikge1xuICAgIGlmIChrZXkudHJpbSgpID09IFwiXCIpIHJldHVybiBmYWxzZTtcbiAgICBkb2N1bWVudC5jb29raWUgPSBgJHtrZXl9PSR7dmFsdWV9O2V4cGlyZXM9JHtleHBpcmVzfWA7XG59XG4vKipcbiAqIEBkZXNjcmlwdGlvbjrliKDpmaTlr7nlupTnmoRrZXlcbiAqIEBwYXJhbSB7c3RyaW5nfSBrZXkga2V5XG4gKiBAcmV0dXJuIHt2b2lkfSB2b2lkXG4gKi9cbkNvb2tpZS5wcm90b3R5cGUuZGVsID0gZnVuY3Rpb24gKGtleSkge1xuICAgIGRvY3VtZW50LmNvb2tpZSA9IGAke2tleX09MDsgcGF0aD0vOyBleHBpcmVzPSR7bmV3IERhdGUoMCkudG9VVENTdHJpbmcoKX1gXG59XG4vKipcbiAqIEBkZXNjcmlwdGlvbjrmuIXpmaTmnKzlnLDmiYDmnIljb29raWVcbiAqIEByZXR1cm4ge3ZvaWR9IHZvaWRcbiAqL1xuQ29va2llLnByb3RvdHlwZS5jbGVhciA9IGZ1bmN0aW9uICgpIHtcbiAgICBsZXQgbGlzdCA9IGRvY3VtZW50LmNvb2tpZS5tYXRjaCgvW14gPTtdKyg/PVxcPSkvZyk7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBsaXN0Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIHRoaXMuZGVsKGxpc3RbaV0pO1xuICAgIH1cbiAgICBkb2N1bWVudC5jb29raWUgPSBgPTA7IHBhdGg9LzsgZXhwaXJlcz0ke25ldyBEYXRlKDApLnRvVVRDU3RyaW5nKCl9YFxufVxuXG5tb2R1bGUuZXhwb3J0cyA9IG5ldyBDb29raWUoKVxuIiwiY29uc3QgeHNzID0gcmVxdWlyZShcInhzc1wiKTtcbi8qKlxuICogQGRlc2NyaXB0aW9uOnhzc+i/h+a7pFxuICogQHBhcmFtIHtzdHJpbmd9IEh0bWwg5a+M5paH5pys5YaF5a65XG4gKiBAcGFyYW0ge2FycmF5fSBmb3JtYXQg5YWB6K645pS+6KGM55qEaHRtbOagh+etvlxuICogQHBhcmFtIHthcnJheX0gYXR0ciDlhYHorrjmlL7ooYznmoTmoIfnrb7lsZ7mgKfmoIfnrb5cbiAqIEByZXR1cm4ge3N0cmluZ30gaHRtbFN0cmluZ1xuICovXG5mdW5jdGlvbiBmb3JtYXRYc3MoSHRtbCwgZm9ybWF0ID0gW10sIGF0dHIgPSBbXSl7XG4gICAgLy/lhYHorrjpgJrov4fnmoTmoIfnrb5cbiAgICBjb25zdCB0YWcgPSBbXG4gICAgICAgIFwicFwiLFxuICAgICAgICBcImFcIixcbiAgICAgICAgXCJpbWdcIixcbiAgICAgICAgXCJmb250XCIsXG4gICAgICAgIFwic3BhblwiLFxuICAgICAgICBcImJcIixcbiAgICAgICAgXCJibG9ja3F1b3RlXCIsXG4gICAgICAgIFwiY29kZVwiLFxuICAgICAgICBcImgxXCIsXG4gICAgICAgIFwiaDJcIixcbiAgICAgICAgXCJoM1wiLFxuICAgICAgICBcImg0XCIsXG4gICAgICAgIFwiaDVcIixcbiAgICAgICAgXCJoNlwiLFxuICAgICAgICBcImhyXCIsXG4gICAgICAgIFwiYnJcIixcbiAgICAgICAgXCJzXCIsXG4gICAgICAgIFwiaVwiLFxuICAgICAgICBcInVcIixcbiAgICAgICAgXCJzdHJpa2VcIixcbiAgICAgICAgXCJkaXZcIixcbiAgICAgICAgXCJzdHJvbmdcIixcbiAgICAgICAgXCJwcmVcIlxuICAgIF07XG4gICAgaWYgKGZvcm1hdC5sZW5ndGggPiAwKSB7XG4gICAgICAgIGZvcm1hdC5mb3JFYWNoKGVsID0+IHtcbiAgICAgICAgICAgIHRhZy5wdXNoKGVsKTtcbiAgICAgICAgfSlcbiAgICB9XG4gICAgLy/lhYHorrjkvb/nlKjnmoTlsZ7mgKdcbiAgICBjb25zdCBjYW4gPSBbXCJjb2xvclwiLCBcInNpemVcIiwgXCJzdHlsZVwiLCBcImhyZWZcIiwgXCJzcmNcIl07XG4gICAgaWYgKGF0dHIubGVuZ3RoID4gMCkge1xuICAgICAgICBhdHRyLm1hcChlID0+IHtcbiAgICAgICAgICAgIGNhbi5wdXNoKGUpXG4gICAgICAgIH0pXG4gICAgfVxuICAgIGxldCB0bXAgPSB7fTtcbiAgICBmb3IgKGxldCBpbmRleCA9IDA7IGluZGV4IDwgdGFnLmxlbmd0aDsgaW5kZXgrKykge1xuICAgICAgICBjb25zdCBlbGVtZW50ID0gdGFnW2luZGV4XTtcbiAgICAgICAgdG1wW2VsZW1lbnRdID0gY2FuO1xuICAgIH1cbiAgICBsZXQgdGV4dCA9IHhzcyhIdG1sLCB7XG4gICAgICAgIHdoaXRlTGlzdDogdG1wLFxuICAgIH0pO1xuICAgIHJldHVybiB0ZXh0O1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IGZvcm1hdFhzc1xuIiwiLyoqXG4gKiBAZGVzY3JpcHRpb246bG9jYWxTdG9yYWdl5YKo5a2Y566h55CGXG4gKiBAcmV0dXJucyB7TWVtb3J5fVxuICovXG5jbGFzcyBNZW1vcnkge1xuICAgIExvY2FsID0gbnVsbDtcblxuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICB0aGlzLkxvY2FsID0gbG9jYWxTdG9yYWdlIHx8IHdpbmRvdy5sb2NhbFN0b3JhZ2U7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQGRlc2NyaXB0aW9uOiDorr7nva7mnKzlnLBsb2NhbFN0b3JhZ2XlgqjlrZhcbiAgICAgKiBAcGFyYW0geyp9IGtleSDplK5cbiAgICAgKiBAcGFyYW0ge09iamVjdHxTdHJpbmd9IHZhbHVlIOWAvFxuICAgICAqIEByZXR1cm4ge01lbW9yeX0gTWVtb3J5IOWPr+WunueOsOmTvuW8j+i/nue7reiwg+eUqFxuICAgICAqL1xuICAgIHNldChrZXksIHZhbHVlKSB7XG4gICAgICAgIGlmICh0eXBlb2YgdmFsdWUgPT0gXCJvYmplY3RcIikge1xuICAgICAgICAgICAgdmFsdWUgPSBKU09OLnN0cmluZ2lmeSh2YWx1ZSk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5Mb2NhbC5zZXRJdGVtKGtleSwgdmFsdWUpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBAZGVzY3JpcHRpb246IOiOt+WPlumUrlxuICAgICAqIEBwYXJhbSB7Kn0ga2V5XG4gICAgICogQHJldHVybiB7T2JqZWN0fFN0cmluZ30gdmFsdWUg6L+U5Zue5YC8XG4gICAgICovXG4gICAgZ2V0KGtleSkge1xuICAgICAgICBsZXQgaW5mbyA9IHRoaXMuTG9jYWwuZ2V0SXRlbShrZXkpO1xuICAgICAgICBpZiAoaW5mbyA9PT0gXCJcIiB8fCAhaW5mbykge1xuICAgICAgICAgICAgcmV0dXJuIFwiXCI7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMuaXNPYmooaW5mbyk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQGRlc2NyaXB0aW9uOiDliKTmlq3lrZfnrKbkuLLmmK/kuI3mmK9qc29u5a+56LGhXG4gICAgICogQHBhcmFtIHsqfSBzdHJcbiAgICAgKiBAcmV0dXJuIHsqfVxuICAgICAqL1xuICAgIGlzT2JqKHN0cikge1xuICAgICAgICBpZiAodHlwZW9mIHN0ciA9PSBcInN0cmluZ1wiKSB7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGxldCBvYmogPSBKU09OLnBhcnNlKHN0cik7XG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBvYmogPT0gXCJvYmplY3RcIiAmJiBvYmopIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG9iajtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gc3RyO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gc3RyO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQGRlc2NyaXB0aW9uOiDliKDpmaTmnKzlnLBsb2NhbFN0b3JhZ2XlgqjlrZhrZXlcbiAgICAgKiBAcGFyYW0geyp9IGtleVxuICAgICAqIEByZXR1cm4ge01lbW9yeX0gYm9vbGVhblxuICAgICAqL1xuICAgIGRlbChrZXkpIHtcbiAgICAgICAgdGhpcy5Mb2NhbC5yZW1vdmVJdGVtKGtleSk7XG4gICAgICAgIHJldHVybiB0aGlzOyAvL+i/lOWbnuiHqui6q++8jOWPr+S7peWunueOsOmTvuW8j+iwg+eUqE1lbW9yeSgpLmRlbChrZXkpLmRlbChrZXkpLnNldChrZXksdmFsdWUpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEBkZXNjcmlwdGlvbjog5riF6Zmk5YWo6YOo5pys5ZywbG9jYWxTdG9yYWdl5YKo5a2YXG4gICAgICogQHJldHVybiB7TWVtb3J5fSBib29sZWFuXG4gICAgICovXG4gICAgY2xlYXIoKSB7XG4gICAgICAgIHRoaXMuTG9jYWwuY2xlYXIoKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxufVxuXG52YXIgbWVtb3J5ID0gbmV3IE1lbW9yeSgpXG5tb2R1bGUuZXhwb3J0cyA9IG1lbW9yeTtcbiIsIi8qKlxuICogQGRlc2NyaXB0aW9uOumqjOivgeaYr+WQpuS4uuaJi+acuui0puWPt1xuICogQHBhcmFtIHtzdHJpbmd9IE1vYmlsZSDmiYvmnLrotKblj7dcbiAqIEByZXR1cm4ge0Jvb2xlYW59IEJvb2xlYW5cbiAqL1xuY29uc3QgaXNNb2JpbGUgPSAoTW9iaWxlID0gXCJcIikgPT4ge1xuICAgIHJldHVybiAvXjFbMzQ1Njc4OV1cXGR7OX0kLy50ZXN0KE1vYmlsZSk7XG59XG5cbi8qKlxuICogQGRlc2NyaXB0aW9uOumqjOivgeaYr+WQpuS4uumCrueusVxuICogQHBhcmFtIHtzdHJpbmd9IE1haWwg6YKu566x6LSm5Y+3XG4gKiBAcmV0dXJuIHtCb29sZWFufSBCb29sZWFuXG4gKi9cbmNvbnN0IGlzTWFpbCA9IChNYWlsID0gXCJcIikgPT4ge1xuICAgIHJldHVybiAvXltBLVphLXowLTlcXHU0ZTAwLVxcdTlmYTVdK0BbYS16QS1aMC05Xy1dKyhcXC5bYS16QS1aMC05Xy1dKykrJC8udGVzdChNYWlsKVxufVxuXG4vKipcbiAqIEBkZXNjcmlwdGlvbjrpqozor4HkuIDmrrXlrZfnrKbkuLLmmK/pgq7nrrHov5jmmK/miYvmnLrlj7fnoIFcbiAqIEBwYXJhbSB7c3RyaW5nfSBhY2NvdW50IOWtl+espuS4slxuICogQHJldHVybiB7U3RyaW5nfEJvb2xlYW59IG1haWwgLyBtb2JpbGUgLyBmYWxzZVxuICovXG5jb25zdCBpc01vYmlsZU9yTWFpbCA9IChhY2NvdW50KSA9PiB7XG4gICAgaWYgKGlzTWFpbChhY2NvdW50KSkge1xuICAgICAgICByZXR1cm4gXCJtYWlsXCJcbiAgICB9XG4gICAgaWYgKGlzTW9iaWxlKGFjY291bnQpKSB7XG4gICAgICAgIHJldHVybiBcIm1vYmlsZVwiXG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbn1cbi8qKlxuICogQGRlc2NyaXB0aW9uOumYsuaKllxuICogQHBhcmFtIGZuIOaWueazleWQjXzlm57osIPlh73mlbBcbiAqIEBwYXJhbSB3YWl0IOWJjeWQjumXtOmalOaXtumXtOmXtOi3nVxuICogQHJldHVybnMgeyhmdW5jdGlvbigpOiB2b2lkKXwqfSDpl63ljIXmlrnms5VcbiAqL1xuY29uc3QgZGVib3VuY2UgPSAoZm4sIHdhaXQpID0+IHtcbiAgICBsZXQgdGltZXIgPSBudWxsO1xuICAgIHJldHVybiBmdW5jdGlvbiAoKSB7XG4gICAgICAgIGlmICh0aW1lciAhPT0gbnVsbCkge1xuICAgICAgICAgICAgY2xlYXJUaW1lb3V0KHRpbWVyKTtcbiAgICAgICAgfVxuICAgICAgICB0aW1lciA9IHNldFRpbWVvdXQoZm4sIHdhaXQpO1xuICAgIH1cbn1cbi8qKlxuICogQGRlc2NyaXB0aW9uOuaIqua1gVxuICogQHBhcmFtIGZuIOaWueazleWQje+9nOWbnuiwg+WHveaVsFxuICogQHBhcmFtIHdhaXQg5q+P5qyh6LCD55So6Ze06ZqUXG4gKiBAcmV0dXJuIHsoZnVuY3Rpb24oKTogdm9pZCl8Kn1cbiAqL1xuY29uc3QgdGhyb3R0bGUgPSAoZm4sIHdhaXQpID0+IHtcbiAgICBsZXQgdGltZXIgPSB0cnVlO1xuICAgIHJldHVybiBmdW5jdGlvbiAoKSB7XG4gICAgICAgIGlmICghdGltZXIpIHJldHVybjtcbiAgICAgICAgdGltZXIgPSBmYWxzZTtcbiAgICAgICAgc2V0VGltZW91dChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBmbi5hcHBseSh0aGlzLCBhcmd1bWVudHMpXG4gICAgICAgICAgICB0aW1lciA9IHRydWU7XG4gICAgICAgIH0sIHdhaXQpXG4gICAgfVxufVxuXG5tb2R1bGUuZXhwb3J0cyA9IHtcbiAgICBkZWJvdW5jZSwgaXNNb2JpbGVPck1haWwsIGlzTWFpbCwgaXNNb2JpbGUsIHRocm90dGxlXG59XG4iLCIvLyBleHRyYWN0ZWQgYnkgbWluaS1jc3MtZXh0cmFjdC1wbHVnaW5cbmV4cG9ydCB7fTsiLCJtb2R1bGUuZXhwb3J0cyA9IFwiZGF0YTppbWFnZS9zdmcreG1sO2Jhc2U2NCxQSE4yWnlCMFBTSXhOalV3TkRJd05URTFPVEEwSWlCamJHRnpjejBpYVdOdmJpSWdkbWxsZDBKdmVEMGlNQ0F3SURFd01qUWdNVEF5TkNJZ2RtVnljMmx2YmowaU1TNHhJaUI0Yld4dWN6MGlhSFIwY0RvdkwzZDNkeTUzTXk1dmNtY3ZNakF3TUM5emRtY2lJSEF0YVdROUlqWTNPREVpSUhkcFpIUm9QU0l5TURBaUlHaGxhV2RvZEQwaU1qQXdJajQ4Y0dGMGFDQmtQU0pOTkRVM0xqZzRNVFlnT1RVMExqSTJOVFpETWpFMExqQXhOaUE1TlRRdU1qWTFOaUF4TlM0Mk1UWWdOelUxTGpnMk5UWWdNVFV1TmpFMklEVXhNbE15TVRRdU1ERTJJRFk1TGpjek5EUWdORFUzTGpnNE1UWWdOamt1TnpNME5ITTBOREl1TWpZMU5pQXhPVGd1TkNBME5ESXVNalkxTmlBME5ESXVNalkxTmkweE9UZ3VOREV3TWpRZ05EUXlMakkyTlRZdE5EUXlMakkyTlRZZ05EUXlMakkyTlRaNklHMHdMVGMwTWk0eU5UWTJOR010TVRZMUxqUXhOamsySURBdE1qazVMams1TVRBMElERXpOQzQxTnpRd09DMHlPVGt1T1RreE1EUWdNams1TGprNU1UQTBVekk1TWk0ME5UUTBJRGd4TVM0NU9URXdOQ0EwTlRjdU9EZ3hOaUE0TVRFdU9Ua3hNRFFnTnpVM0xqZzNNalkwSURZM055NDBNVFk1TmlBM05UY3VPRGN5TmpRZ05URXlJRFl5TXk0eU9UZzFOaUF5TVRJdU1EQTRPVFlnTkRVM0xqZzRNVFlnTWpFeUxqQXdPRGsyZWlJZ1ptbHNiRDBpSXpKRFFVTTFOeUlnY0MxcFpEMGlOamM0TWlJK1BDOXdZWFJvUGp4d1lYUm9JR1E5SWswNU16Y3VNalEyTnpJZ09EUTVMakV4TVRBMGJTMDNNUzR4TXpjeU9DQXdZVGN4TGpFek56STRJRGN4TGpFek56STRJREFnTVNBd0lERTBNaTR5TnpRMU5pQXdJRGN4TGpFek56STRJRGN4TGpFek56STRJREFnTVNBd0xURTBNaTR5TnpRMU5pQXdXaUlnWm1sc2JEMGlJMFkwUWpFeU1pSWdjQzFwWkQwaU5qYzRNeUkrUEM5d1lYUm9Qanh3WVhSb0lHUTlJazAwTlRjdU9EZ3hOaUE1TlRRdU1qWTFObU10TVRjMUxqTXpPVFV5SURBdE16TTBMakk0TkRndE1UQXpMamN4TURjeUxUUXdOQzQ1TkRBNExUSTJOQzR5TVRJME9Hd3RNUzQ1TlRVNE5DMDBMalV3TlRaakxURTFMalF4TVRJdE16WXVNVE0yT1RZZ01TNHpPVEkyTkMwM055NDVNalkwSURNM0xqVXhPVE0yTFRrekxqTXpOellnTXpZdU1USTJOekl0TVRVdU5ERXhNaUEzTnk0NU1qWTBJREV1TXpneU5DQTVNeTR6TXpjMklETTNMalV4T1RNMmJERXVNamt3TWpRZ01pNDVOamsyWXpRM0xqazFNemt5SURFd09DNDVNek14TWlBeE5UVXVOemt4TXpZZ01UYzVMakk1TWpFMklESTNOQzQzTXpreUlERTNPUzR5T1RJeE5pQXhNVGN1TlRVMU1pQXdJREl5TkM0NE9EQTJOQzAyT1M0eU1USXhOaUF5TnpNdU5ERTRNalF0TVRjMkxqTXlNalUySURBdU5qVTFNell0TVM0ME5ETTROQ0F4TGpNeE1EY3lMVEl1T1RFNE5DQXhMamswTlRZdE5DNHpPVEk1TmlBeE5TNDJNRFUzTmkwek5pNHdOVFV3TkNBMU55NDBOemN4TWkwMU1pNDJNek0ySURrekxqVXpNakUyTFRNM0xqQXlOemcwSURNMkxqQTFOVEEwSURFMUxqWXdOVGMySURVeUxqWXpNellnTlRjdU5EYzNNVElnTXpjdU1ESTNPRFFnT1RNdU5UTXlNVFl0TUM0NU5USXpNaUF5TGpJeE1UZzBMVEV1T1RNMU16WWdOQzQwTURNeUxUSXVPVEk0TmpRZ05pNDFPVFExTmkwM01TNDFNelkyTkNBeE5UY3VPRGd3TXpJdE1qSTVMamN5TkRFMklESTFPUzQ0T1RFeUxUUXdNaTQ1T0RRNU5pQXlOVGt1T0RreE1ub2lJR1pwYkd3OUlpTkdORUl4TWpJaUlIQXRhV1E5SWpZM09EUWlQand2Y0dGMGFENDhMM04yWno0S1wiIiwibW9kdWxlLmV4cG9ydHMgPSBcImRhdGE6aW1hZ2Uvc3ZnK3htbDtiYXNlNjQsUEhOMlp5QjBQU0l4TmpVd05ESXdNRFkzT1RNd0lpQmpiR0Z6Y3owaWFXTnZiaUlnZG1sbGQwSnZlRDBpTUNBd0lERXdNalFnTVRBeU5DSWdkbVZ5YzJsdmJqMGlNUzR4SWlCNGJXeHVjejBpYUhSMGNEb3ZMM2QzZHk1M015NXZjbWN2TWpBd01DOXpkbWNpSUhBdGFXUTlJak16TmpnaUlIZHBaSFJvUFNJeU1EQWlJR2hsYVdkb2REMGlNakF3SWo0OGNHRjBhQ0JrUFNKTk1UZzBMalk0TWlBMU16Z3VOelU1WXpFeE1TNHhOemN0TWpNdU9EYzBJRGsyTGpBekxURTFOaTQzTXpjZ09USXVOekF5TFRFNE5TNDNOell0TlM0ME5EVXRORFF1TnpZNExUVTRMakV3TWkweE1qTXVNREl0TVRJNUxqWXdOaTB4TVRZdU9ETXhMVGc1TGprNElEZ3VNRGMwTFRFd015NHhNallnTVRNNExqQTFNaTB4TURNdU1USTJJREV6T0M0d05USXRNVEl1TVRjZ05qQXVNRGdnTWprdU1UTXlJREU0T0M0ME5USWdNVFF3TGpBeklERTJOQzQxTlRWNlRUTXdNaTQzTkRZZ056WTVMamcyWXkwekxqSTFOeUE1TGpNek1TMHhNQzQxTVRjZ016TXVNakk0TFRRdU1qTTBJRFUwTGpBeklERXlMalF3TWlBME5pNDJOemNnTlRJdU9URXlJRFE0TGpjM0lEVXlMamt4TWlBME9DNDNOMmcxT0M0eU1UaDJMVEUwTWk0ek1XZ3ROakl1TXpNMll5MHlPQzR3TVRZZ09DNHpOVFF0TkRFdU5UTTFJRE13TGpFMU55MDBOQzQxTmlBek9TNDFNWG9nYlRnNExqSTRNUzAwTlRNdU9EazRZell4TGpRd05pQXdJREV4TVM0d016Y3ROekF1TmpZM0lERXhNUzR3TXpjdE1UVTRMakEwUXpVd01pNHdOalFnTnpBdU5qUXpJRFExTWk0ME16TWdNQ0F6T1RFdU1ESTNJREJqTFRZeExqTXhNaUF3TFRFeE1TNHdOaUEzTUM0Mk5ETXRNVEV4TGpBMklERTFOeTQ1TWpNZ01DQTROeTR6TnpNZ05Ea3VOemNnTVRVNExqQTBJREV4TVM0d05pQXhOVGd1TURSNklHMHlOalF1TkRjZ01UQXVORFEzWXpneUxqQTJPQ0F4TUM0Mk5UY2dNVE0wTGpnMExUYzJMamt5TlNBeE5EVXVNek0xTFRFME15NHpNU0F4TUM0M01ETXROall1TWpreUxUUXlMakkxTmkweE5ETXVNamc0TFRFd01DNHpOVGN0TVRVMkxqVXlOeTAxT0M0eU1UZ3RNVE11TXpVMkxURXpNQzQ1TURrZ056a3VPVEEwTFRFek55NDFOQ0F4TkRBdU56QTBMVGN1T1RFeUlEYzBMak15SURFd0xqWXpNeUF4TkRndU5Ua3pJRGt5TGpVMk1pQXhOVGt1TVRNemVpQnRNakF4TGpBNE5pQXpPVEF1TWpFemN5MHhNall1T1RjMkxUazRMakkwTFRJd01TNHhNUzB5TURRdU5ERTBRelUxTlNBek5UVXVOallnTkRFeUxqSTNNaUEwTVRrdU16Y2dNelkwTGpVeU5TQTBPVGd1T1RreklETXhOaTQ1T0RjZ05UYzRMalU1TkNBeU5ESXVPU0EyTWpndU9UUTNJREl6TWk0ek9ESWdOalF5TGpJNFl5MHhNQzQyT0NBeE15NHhNalF0TVRVekxqTTROU0E1TUM0eE5qWXRNVEl4TGpZNU5DQXlNekF1T0RjZ016RXVOalk1SURFME1DNDJNVElnTVRReUxqa3pPU0F4TXpjdU9UTTJJREUwTWk0NU16a2dNVE0zTGprek5uTTRNUzQ1T1RnZ09DNHdOelFnTVRjM0xqRXlMVEV6TGpJeE4yTTVOUzR4TmpndE1qRXVNVEEwSURFM055NHdPVFlnTlM0eU5pQXhOemN1TURrMklEVXVNalp6TWpJeUxqSTROQ0EzTkM0ME16VWdNamd6TGpFd09DMDJPQzQ0TlRKak5qQXVOelUwTFRFME15NHpNelF0TXpRdU16WTRMVEl4Tnk0Mk5UUXRNelF1TXpZNExUSXhOeTQyTlRSNlRUUTNOaTR5TmlBNU1qa3VPRGhJTXpNeExqY3pPV010TmpJdU5EQTJMVEV5TGpRME9TMDROeTR5TlRjdE5UVXVNRE10T1RBdU16azRMVFl5TGpJNUxUTXVNRGN5TFRjdU16YzJMVEl3TGpnd01pMDBNUzQyTURRdE1URXVOREkxTFRrNUxqZzBOU0F5Tmk0NU5qZ3RPRGN1TWpVM0lERXdNeTQ0TnkwNU15NDFNVFlnTVRBekxqZzNMVGt6TGpVeE5tZzNOaTQ1TWpaMkxUazBMalUyTTJ3Mk5TNDFNalFnTVZZNU1qa3VPRGg2SUcweU5qa3VNVFEyTFRGb0xURTJOaTR6WXkwMk5DNDBOVE10TVRZdU5qRTBMVFkzTGpRMU5TMDJNaTQwTURjdE5qY3VORFUxTFRZeUxqUXdOM1l0TVRnekxqZzViRFkzTGpRMU5TMHhMakE1TkhZeE5qVXVNamMyWXpRdU1URTVJREUzTGpZek55QXlOaTR3TVRVZ01qQXVPREkxSURJMkxqQXhOU0F5TUM0NE1qVm9Oamd1TlRJMVZqWTRNaTQxT0RGb056RXVOeloyTWpRMkxqSTVOM29nYlRJek5TNDBNRGd0TkRrd0xqazVZekF0TXpFdU56WXRNall1TXpnM0xURXlOeTR6T1RRdE1USTBMakl6TFRFeU55NHpPVFF0T1RndU1EQTRJREF0TVRFeExqRXdPQ0E1TUM0eU5UZ3RNVEV4TGpFd09DQXhOVFF1TURZZ01DQTJNQzQ0T1RRZ05TNHhORElnTVRRMUxqZzVOQ0F4TWpZdU9EZ3pJREUwTXk0eE9UVWdNVEl4TGpjNE9DMHlMamNnTVRBNExqUTFOUzB4TXpjdU9UTTJJREV3T0M0ME5UVXRNVFk1TGpnMmVpQnRNQ0F3SWlCbWFXeHNQU0lqTXpJME5VUkdJaUJ3TFdsa1BTSXpNelk1SWo0OEwzQmhkR2crUEM5emRtYytDZz09XCIiLCJtb2R1bGUuZXhwb3J0cyA9IFwiZGF0YTppbWFnZS9zdmcreG1sO2Jhc2U2NCxQSE4yWnlCMFBTSXhOalV3TkRJd05UUXpNVGt6SWlCamJHRnpjejBpYVdOdmJpSWdkbWxsZDBKdmVEMGlNQ0F3SURFd01qUWdNVEF5TkNJZ2RtVnljMmx2YmowaU1TNHhJaUI0Yld4dWN6MGlhSFIwY0RvdkwzZDNkeTUzTXk1dmNtY3ZNakF3TUM5emRtY2lJSEF0YVdROUlqZ3pORE1pSUhkcFpIUm9QU0l5TURBaUlHaGxhV2RvZEQwaU1qQXdJajQ4Y0dGMGFDQmtQU0pOTXpRd0xqVTRNalFnTnpBdU1UQTVPRFkzVERFd01pNDFNelkxTXpNZ01DNDJPREkyTmpkMk9EVXhMakl4TnpBMk5rd3pOREF1TmpVd05qWTNJRFkwTXk0ek5EVXdOamRXTnpBdU1UQTVPRFkzZWsweE1ESXVOVE0yTlRNeklEZzFNUzQzTmpNeWJESXpPQzR3TkRVNE5qY2dNVGN4TGpZeU1qUWdOVGd3TGpnNE1UQTJOeTB6TkRBdU9USXpOek16VmpReE1TNDNPRFExTXpOTU1UQXlMalV6TmpVek15QTROVEV1T0RNeE5EWTNlaUlnWm1sc2JEMGlJelF3T1VWR1JpSWdjQzFwWkQwaU9ETTBOQ0krUEM5d1lYUm9Qanh3WVhSb0lHUTlJazAwTURrdU5EWXpORFkzSURJMU5TNHpPRFUyYkRFeE15NDNNekl5TmpZZ01qTTRMamt6TXpNek15QXhNemd1T0RVME5DQTFOaTQ0TmpZeE16UWdNalU1TGpReE16TXpOQzB4TXprdU5EQXdOVE0wTFRVd05pNHdOakE0TFRFMU5pNHpNekEyTmpaNklpQm1hV3hzUFNJak5EQTVSVVpHSWlCd0xXbGtQU0k0TXpRMUlqNDhMM0JoZEdnK1BDOXpkbWMrQ2c9PVwiIiwibW9kdWxlLmV4cG9ydHMgPSBcImRhdGE6aW1hZ2Uvc3ZnK3htbDtiYXNlNjQsUEhOMlp5QjBQU0l4TmpVd05ERTVPVGczTmpnd0lpQmpiR0Z6Y3owaWFXTnZiaUlnZG1sbGQwSnZlRDBpTUNBd0lERXdNalFnTVRBeU5DSWdkbVZ5YzJsdmJqMGlNUzR4SWlCNGJXeHVjejBpYUhSMGNEb3ZMM2QzZHk1M015NXZjbWN2TWpBd01DOXpkbWNpSUhBdGFXUTlJakkxTmpJaUlIZHBaSFJvUFNJeU1EQWlJR2hsYVdkb2REMGlNakF3SWo0OGNHRjBhQ0JrUFNKTk1qRTBMakV3TVRNek15QTFNVEpqTUMwek1pNDFNVElnTlM0MU5EWTJOamN0TmpNdU56QXhNek16SURFMUxqTTJMVGt5TGpreU9FdzFOeTR4TnpNek16TWdNamt3TGpJeE9EWTJOMEUwT1RFdU9EWXhNek16SURRNU1TNDROakV6TXpNZ01DQXdJREFnTkM0Mk9UTXpNek1nTlRFeVl6QWdOemt1TnpBeE16TXpJREU0TGpnMU9EWTJOeUF4TlRRdU9EZ2dOVEl1TXprME5qWTNJREl5TVM0Mk1UQTJOamRzTVRjeUxqSXdNalkyTnkweE1qa3VNRFkyTmpZM1FUSTVNQzQxTmlBeU9UQXVOVFlnTUNBd0lERWdNakUwTGpFd01UTXpNeUExTVRJaUlHWnBiR3c5SWlOR1FrSkRNRFVpSUhBdGFXUTlJakkxTmpNaVBqd3ZjR0YwYUQ0OGNHRjBhQ0JrUFNKTk5URTJMalk1TXpNek15QXlNVFl1TVRreVl6Y3lMakV3TmpZMk55QXdJREV6Tnk0eU5UZzJOamNnTWpVdU1EQXlOalkzSURFNE9DNDBOVGcyTmpjZ05qVXVPVFl5TmpZM1REZzFOQzR4TURFek16TWdNVE0yTGpVek16TXpNME0zTmpNdU16UTVNek16SURVNUxqRTNPRFkyTnlBMk5EWXVPVGszTXpNeklERXhMak01TWlBMU1UWXVOamt6TXpNeklERXhMak01TW1NdE1qQXlMak15TlRNek15QXdMVE0zTmk0eU16UTJOamNnTVRFekxqSTRMVFExT1M0MU1pQXlOemd1T0RJMk5qWTNiREUzTWk0ek56TXpNelFnTVRJNExqZzFNek16TTJNek9TNDJPQzB4TVRndU1ERTJJREUxTWk0NE16SXRNakF5TGpnNElESTROeTR4TkRZMk5qWXRNakF5TGpnNElpQm1hV3hzUFNJalJVRTBNek0xSWlCd0xXbGtQU0l5TlRZMElqNDhMM0JoZEdnK1BIQmhkR2dnWkQwaVRUVXhOaTQyT1RNek16TWdPREEzTGpnd09HTXRNVE0wTGpNMU56TXpNeUF3TFRJME55NDFNRGt6TXpNdE9EUXVPRFkwTFRJNE55NHlNekl0TWpBeUxqZzRiQzB4TnpJdU1qZzRJREV5T0M0NE5UTXpNek5qT0RNdU1qUXlOalkzSURFMk5TNDFORFkyTmpjZ01qVTNMakUxTWlBeU56Z3VPREkyTmpZM0lEUTFPUzQxTWlBeU56Z3VPREkyTmpZM0lERXlOQzQ0TkRJMk5qY2dNQ0F5TkRRdU1EVXpNek16TFRRekxqTTVNaUF6TXpNdU5UWTRMVEV5TkM0M05UY3pNek5zTFRFMk15NDFPRFF0TVRJekxqZ3hPRFkyTjJNdE5EWXVNVEl5TmpZM0lESTRMalExT0RZMk55MHhNRFF1TWpNME5qWTNJRFF6TGpjM05pMHhOekF1TURJMk5qWTJJRFF6TGpjM05pSWdabWxzYkQwaUl6TTBRVGcxTXlJZ2NDMXBaRDBpTWpVMk5TSStQQzl3WVhSb1BqeHdZWFJvSUdROUlrMHhNREExTGpNNU56TXpNeUExTVRKak1DMHlPUzQxTmpndE5DNDJPVE16TXpNdE5qRXVORFF0TVRFdU5qUTRMVGt4TGpBd09FZzFNVFl1TmpVd05qWTNWall4TkM0MGFESTNOQzQyTURJMk5qWmpMVEV6TGpZNU5pQTJOUzQ1TmpJMk5qY3ROVEV1TURjeUlERXhOaTQyTlRBMk5qY3RNVEEwTGpVek16TXpNeUF4TkRrdU5qTXliREUyTXk0MU5ERXpNek1nTVRJekxqZ3hPRFkyTjJNNU15NDVPVFEyTmpjdE9EVXVOREU0TmpZM0lERTFOUzR4TXpZdE1qRXlMalkxTURZMk55QXhOVFV1TVRNMkxUTTNOUzQ0TlRBMk5qY2lJR1pwYkd3OUlpTTBNamcxUmpRaUlIQXRhV1E5SWpJMU5qWWlQand2Y0dGMGFENDhMM04yWno0S1wiIiwibW9kdWxlLmV4cG9ydHMgPSBcImRhdGE6aW1hZ2Uvc3ZnK3htbDtiYXNlNjQsUEhOMlp5QjBQU0l4TmpVd05ESXdOREV6TnpZMklpQmpiR0Z6Y3owaWFXTnZiaUlnZG1sbGQwSnZlRDBpTUNBd0lERXdNalFnTVRBeU5DSWdkbVZ5YzJsdmJqMGlNUzR4SWlCNGJXeHVjejBpYUhSMGNEb3ZMM2QzZHk1M015NXZjbWN2TWpBd01DOXpkbWNpSUhBdGFXUTlJalV3T1RBaUlIZHBaSFJvUFNJeU1EQWlJR2hsYVdkb2REMGlNakF3SWo0OGNHRjBhQ0JrUFNKTk5URXdMakExTURNd01pQXhNREE1TGpFeE16TXdPR0UxTURRdU5UUTROemdnTlRBMExqVTBPRGM0SURBZ01TQXhJRFV3TkM0ME56QTNPVE10TlRBMExqVTBPRGM0SURVd05TNHdPVFEyT1RZZ05UQTFMakE1TkRZNU5pQXdJREFnTVMwMU1EUXVORGN4TnpreklEVXdOQzQwTnpFM09USjZJRzB3TFRrNE1DNHdNREV3TnpGaE5EYzFMalExTWpJNU1TQTBOelV1TkRVeU1qa3hJREFnTVNBd0lEUTNOUzR6TnpRek1ETWdORGMxTGpRMU1qSTVNVUUwTnpVdU9UazRNakEySURRM05TNDVPVGd5TURZZ01DQXdJREFnTlRFd0xqQTFNRE13TWlBeU9TNHhNVEl5TXpkNklpQm1hV3hzUFNJak0wVkJNVVpESWlCd0xXbGtQU0kxTURreElqNDhMM0JoZEdnK1BIQmhkR2dnWkQwaVRUWTVOQzR6TURFM016Z2dPVEV6TGpFMk5URTRNMk14T0RRdU5qUXpNemMxTFRnNExqVXpPREkzTkNBeU56TXVPREEwTlRVeUxUSXpOeTR4TkRFeU16WWdNalkzTGpRd09EVTBOQzAwTkRVdU9UWTFPRFl6TFRJeUxqSXpNalUxTXkwek5EUXVOVFUyTlRnMExUUXpPQzQ1TkRRNU5URXRORGd5TGpnMk16RTBNaTAxTXpJdU9UUXpNemM0TFRJMk9DNDJOVFl6TlMwME5DNHpNRGd4TXpFZ01UazJMakU0TnpVNE5TQXlNak11TlRZM016UXhJREUzTkM0ME1qTTVOVGtnTXpJNUxqRTRPRGsyTmlBek1qQXVORFV6TXpJZ09UUXVNemc0TXpZM0lERXpNeTR3Tnprek5qa2dOek11TVRjd05qVTJJREkyTkM0ME5ETXdNRFF0TmpNdU5qVXpNVE15SURNNU5DNHhOamc0T1RONklpQm1hV3hzUFNJak0wVkJNVVpESWlCd0xXbGtQU0kxTURreUlqNDhMM0JoZEdnK1BIQmhkR2dnWkQwaVRUTXlNUzQyTmpNMU1EZ2dPVFl1TlRnNE56YzJRekV6Tnk0d01qQXhNek1nTVRnMUxqRXlOakExSURRM0xqZzFPRGsxTlNBek16TXVPREEzSURVMExqSTFORGsyTkNBMU5ESXVOVFV6TmpNNElEYzJMalE0TnpVeE55QTRPRGN1TVRFeE1qSXlJRFE1TXk0eE9UazVNVFVnTVRBeU5TNDBNVFkzT0NBMU9EY3VNVGs0TXpReUlEZ3hNUzR5TURrNU9EbGpORFF1TXpnMk1URTVMVEU1Tmk0eE9EYzFPRFV0TWpJekxqUTRPVE0xTXkweE56UXVOREl5T1RVNUxUTXlPUzR3TXpJNU9TMHpNakF1TXpjME16TXpMVGswTGpNNE9ETTJOeTB4TXpNdU16RTBNek15TFRjekxqTXlOall6TWkweU5qUXVOelUxT1RVMUlEWXpMalE1T0RFMU5pMHpPVFF1TWpRMk9EaDZJaUJtYVd4c1BTSWpNMFZCTVVaRElpQndMV2xrUFNJMU1Ea3pJajQ4TDNCaGRHZytQQzl6ZG1jK0NnPT1cIiIsIi8qKlxuICogZGVmYXVsdCBzZXR0aW5nc1xuICpcbiAqIEBhdXRob3IgWm9uZ21pbiBMZWk8bGVpem9uZ21pbkBnbWFpbC5jb20+XG4gKi9cblxudmFyIEZpbHRlckNTUyA9IHJlcXVpcmUoXCJjc3NmaWx0ZXJcIikuRmlsdGVyQ1NTO1xudmFyIGdldERlZmF1bHRDU1NXaGl0ZUxpc3QgPSByZXF1aXJlKFwiY3NzZmlsdGVyXCIpLmdldERlZmF1bHRXaGl0ZUxpc3Q7XG52YXIgXyA9IHJlcXVpcmUoXCIuL3V0aWxcIik7XG5cbmZ1bmN0aW9uIGdldERlZmF1bHRXaGl0ZUxpc3QoKSB7XG4gIHJldHVybiB7XG4gICAgYTogW1widGFyZ2V0XCIsIFwiaHJlZlwiLCBcInRpdGxlXCJdLFxuICAgIGFiYnI6IFtcInRpdGxlXCJdLFxuICAgIGFkZHJlc3M6IFtdLFxuICAgIGFyZWE6IFtcInNoYXBlXCIsIFwiY29vcmRzXCIsIFwiaHJlZlwiLCBcImFsdFwiXSxcbiAgICBhcnRpY2xlOiBbXSxcbiAgICBhc2lkZTogW10sXG4gICAgYXVkaW86IFtcbiAgICAgIFwiYXV0b3BsYXlcIixcbiAgICAgIFwiY29udHJvbHNcIixcbiAgICAgIFwiY3Jvc3NvcmlnaW5cIixcbiAgICAgIFwibG9vcFwiLFxuICAgICAgXCJtdXRlZFwiLFxuICAgICAgXCJwcmVsb2FkXCIsXG4gICAgICBcInNyY1wiLFxuICAgIF0sXG4gICAgYjogW10sXG4gICAgYmRpOiBbXCJkaXJcIl0sXG4gICAgYmRvOiBbXCJkaXJcIl0sXG4gICAgYmlnOiBbXSxcbiAgICBibG9ja3F1b3RlOiBbXCJjaXRlXCJdLFxuICAgIGJyOiBbXSxcbiAgICBjYXB0aW9uOiBbXSxcbiAgICBjZW50ZXI6IFtdLFxuICAgIGNpdGU6IFtdLFxuICAgIGNvZGU6IFtdLFxuICAgIGNvbDogW1wiYWxpZ25cIiwgXCJ2YWxpZ25cIiwgXCJzcGFuXCIsIFwid2lkdGhcIl0sXG4gICAgY29sZ3JvdXA6IFtcImFsaWduXCIsIFwidmFsaWduXCIsIFwic3BhblwiLCBcIndpZHRoXCJdLFxuICAgIGRkOiBbXSxcbiAgICBkZWw6IFtcImRhdGV0aW1lXCJdLFxuICAgIGRldGFpbHM6IFtcIm9wZW5cIl0sXG4gICAgZGl2OiBbXSxcbiAgICBkbDogW10sXG4gICAgZHQ6IFtdLFxuICAgIGVtOiBbXSxcbiAgICBmaWdjYXB0aW9uOiBbXSxcbiAgICBmaWd1cmU6IFtdLFxuICAgIGZvbnQ6IFtcImNvbG9yXCIsIFwic2l6ZVwiLCBcImZhY2VcIl0sXG4gICAgZm9vdGVyOiBbXSxcbiAgICBoMTogW10sXG4gICAgaDI6IFtdLFxuICAgIGgzOiBbXSxcbiAgICBoNDogW10sXG4gICAgaDU6IFtdLFxuICAgIGg2OiBbXSxcbiAgICBoZWFkZXI6IFtdLFxuICAgIGhyOiBbXSxcbiAgICBpOiBbXSxcbiAgICBpbWc6IFtcInNyY1wiLCBcImFsdFwiLCBcInRpdGxlXCIsIFwid2lkdGhcIiwgXCJoZWlnaHRcIl0sXG4gICAgaW5zOiBbXCJkYXRldGltZVwiXSxcbiAgICBsaTogW10sXG4gICAgbWFyazogW10sXG4gICAgbmF2OiBbXSxcbiAgICBvbDogW10sXG4gICAgcDogW10sXG4gICAgcHJlOiBbXSxcbiAgICBzOiBbXSxcbiAgICBzZWN0aW9uOiBbXSxcbiAgICBzbWFsbDogW10sXG4gICAgc3BhbjogW10sXG4gICAgc3ViOiBbXSxcbiAgICBzdW1tYXJ5OiBbXSxcbiAgICBzdXA6IFtdLFxuICAgIHN0cm9uZzogW10sXG4gICAgc3RyaWtlOiBbXSxcbiAgICB0YWJsZTogW1wid2lkdGhcIiwgXCJib3JkZXJcIiwgXCJhbGlnblwiLCBcInZhbGlnblwiXSxcbiAgICB0Ym9keTogW1wiYWxpZ25cIiwgXCJ2YWxpZ25cIl0sXG4gICAgdGQ6IFtcIndpZHRoXCIsIFwicm93c3BhblwiLCBcImNvbHNwYW5cIiwgXCJhbGlnblwiLCBcInZhbGlnblwiXSxcbiAgICB0Zm9vdDogW1wiYWxpZ25cIiwgXCJ2YWxpZ25cIl0sXG4gICAgdGg6IFtcIndpZHRoXCIsIFwicm93c3BhblwiLCBcImNvbHNwYW5cIiwgXCJhbGlnblwiLCBcInZhbGlnblwiXSxcbiAgICB0aGVhZDogW1wiYWxpZ25cIiwgXCJ2YWxpZ25cIl0sXG4gICAgdHI6IFtcInJvd3NwYW5cIiwgXCJhbGlnblwiLCBcInZhbGlnblwiXSxcbiAgICB0dDogW10sXG4gICAgdTogW10sXG4gICAgdWw6IFtdLFxuICAgIHZpZGVvOiBbXG4gICAgICBcImF1dG9wbGF5XCIsXG4gICAgICBcImNvbnRyb2xzXCIsXG4gICAgICBcImNyb3Nzb3JpZ2luXCIsXG4gICAgICBcImxvb3BcIixcbiAgICAgIFwibXV0ZWRcIixcbiAgICAgIFwicGxheXNpbmxpbmVcIixcbiAgICAgIFwicG9zdGVyXCIsXG4gICAgICBcInByZWxvYWRcIixcbiAgICAgIFwic3JjXCIsXG4gICAgICBcImhlaWdodFwiLFxuICAgICAgXCJ3aWR0aFwiLFxuICAgIF0sXG4gIH07XG59XG5cbnZhciBkZWZhdWx0Q1NTRmlsdGVyID0gbmV3IEZpbHRlckNTUygpO1xuXG4vKipcbiAqIGRlZmF1bHQgb25UYWcgZnVuY3Rpb25cbiAqXG4gKiBAcGFyYW0ge1N0cmluZ30gdGFnXG4gKiBAcGFyYW0ge1N0cmluZ30gaHRtbFxuICogQHBhcmFtIHtPYmplY3R9IG9wdGlvbnNcbiAqIEByZXR1cm4ge1N0cmluZ31cbiAqL1xuZnVuY3Rpb24gb25UYWcodGFnLCBodG1sLCBvcHRpb25zKSB7XG4gIC8vIGRvIG5vdGhpbmdcbn1cblxuLyoqXG4gKiBkZWZhdWx0IG9uSWdub3JlVGFnIGZ1bmN0aW9uXG4gKlxuICogQHBhcmFtIHtTdHJpbmd9IHRhZ1xuICogQHBhcmFtIHtTdHJpbmd9IGh0bWxcbiAqIEBwYXJhbSB7T2JqZWN0fSBvcHRpb25zXG4gKiBAcmV0dXJuIHtTdHJpbmd9XG4gKi9cbmZ1bmN0aW9uIG9uSWdub3JlVGFnKHRhZywgaHRtbCwgb3B0aW9ucykge1xuICAvLyBkbyBub3RoaW5nXG59XG5cbi8qKlxuICogZGVmYXVsdCBvblRhZ0F0dHIgZnVuY3Rpb25cbiAqXG4gKiBAcGFyYW0ge1N0cmluZ30gdGFnXG4gKiBAcGFyYW0ge1N0cmluZ30gbmFtZVxuICogQHBhcmFtIHtTdHJpbmd9IHZhbHVlXG4gKiBAcmV0dXJuIHtTdHJpbmd9XG4gKi9cbmZ1bmN0aW9uIG9uVGFnQXR0cih0YWcsIG5hbWUsIHZhbHVlKSB7XG4gIC8vIGRvIG5vdGhpbmdcbn1cblxuLyoqXG4gKiBkZWZhdWx0IG9uSWdub3JlVGFnQXR0ciBmdW5jdGlvblxuICpcbiAqIEBwYXJhbSB7U3RyaW5nfSB0YWdcbiAqIEBwYXJhbSB7U3RyaW5nfSBuYW1lXG4gKiBAcGFyYW0ge1N0cmluZ30gdmFsdWVcbiAqIEByZXR1cm4ge1N0cmluZ31cbiAqL1xuZnVuY3Rpb24gb25JZ25vcmVUYWdBdHRyKHRhZywgbmFtZSwgdmFsdWUpIHtcbiAgLy8gZG8gbm90aGluZ1xufVxuXG4vKipcbiAqIGRlZmF1bHQgZXNjYXBlSHRtbCBmdW5jdGlvblxuICpcbiAqIEBwYXJhbSB7U3RyaW5nfSBodG1sXG4gKi9cbmZ1bmN0aW9uIGVzY2FwZUh0bWwoaHRtbCkge1xuICByZXR1cm4gaHRtbC5yZXBsYWNlKFJFR0VYUF9MVCwgXCImbHQ7XCIpLnJlcGxhY2UoUkVHRVhQX0dULCBcIiZndDtcIik7XG59XG5cbi8qKlxuICogZGVmYXVsdCBzYWZlQXR0clZhbHVlIGZ1bmN0aW9uXG4gKlxuICogQHBhcmFtIHtTdHJpbmd9IHRhZ1xuICogQHBhcmFtIHtTdHJpbmd9IG5hbWVcbiAqIEBwYXJhbSB7U3RyaW5nfSB2YWx1ZVxuICogQHBhcmFtIHtPYmplY3R9IGNzc0ZpbHRlclxuICogQHJldHVybiB7U3RyaW5nfVxuICovXG5mdW5jdGlvbiBzYWZlQXR0clZhbHVlKHRhZywgbmFtZSwgdmFsdWUsIGNzc0ZpbHRlcikge1xuICAvLyB1bmVzY2FwZSBhdHRyaWJ1dGUgdmFsdWUgZmlyc3RseVxuICB2YWx1ZSA9IGZyaWVuZGx5QXR0clZhbHVlKHZhbHVlKTtcblxuICBpZiAobmFtZSA9PT0gXCJocmVmXCIgfHwgbmFtZSA9PT0gXCJzcmNcIikge1xuICAgIC8vIGZpbHRlciBgaHJlZmAgYW5kIGBzcmNgIGF0dHJpYnV0ZVxuICAgIC8vIG9ubHkgYWxsb3cgdGhlIHZhbHVlIHRoYXQgc3RhcnRzIHdpdGggYGh0dHA6Ly9gIHwgYGh0dHBzOi8vYCB8IGBtYWlsdG86YCB8IGAvYCB8IGAjYFxuICAgIHZhbHVlID0gXy50cmltKHZhbHVlKTtcbiAgICBpZiAodmFsdWUgPT09IFwiI1wiKSByZXR1cm4gXCIjXCI7XG4gICAgaWYgKFxuICAgICAgIShcbiAgICAgICAgdmFsdWUuc3Vic3RyKDAsIDcpID09PSBcImh0dHA6Ly9cIiB8fFxuICAgICAgICB2YWx1ZS5zdWJzdHIoMCwgOCkgPT09IFwiaHR0cHM6Ly9cIiB8fFxuICAgICAgICB2YWx1ZS5zdWJzdHIoMCwgNykgPT09IFwibWFpbHRvOlwiIHx8XG4gICAgICAgIHZhbHVlLnN1YnN0cigwLCA0KSA9PT0gXCJ0ZWw6XCIgfHxcbiAgICAgICAgdmFsdWUuc3Vic3RyKDAsIDExKSA9PT0gXCJkYXRhOmltYWdlL1wiIHx8XG4gICAgICAgIHZhbHVlLnN1YnN0cigwLCA2KSA9PT0gXCJmdHA6Ly9cIiB8fFxuICAgICAgICB2YWx1ZS5zdWJzdHIoMCwgMikgPT09IFwiLi9cIiB8fFxuICAgICAgICB2YWx1ZS5zdWJzdHIoMCwgMykgPT09IFwiLi4vXCIgfHxcbiAgICAgICAgdmFsdWVbMF0gPT09IFwiI1wiIHx8XG4gICAgICAgIHZhbHVlWzBdID09PSBcIi9cIlxuICAgICAgKVxuICAgICkge1xuICAgICAgcmV0dXJuIFwiXCI7XG4gICAgfVxuICB9IGVsc2UgaWYgKG5hbWUgPT09IFwiYmFja2dyb3VuZFwiKSB7XG4gICAgLy8gZmlsdGVyIGBiYWNrZ3JvdW5kYCBhdHRyaWJ1dGUgKG1heWJlIG5vIHVzZSlcbiAgICAvLyBgamF2YXNjcmlwdDpgXG4gICAgUkVHRVhQX0RFRkFVTFRfT05fVEFHX0FUVFJfNC5sYXN0SW5kZXggPSAwO1xuICAgIGlmIChSRUdFWFBfREVGQVVMVF9PTl9UQUdfQVRUUl80LnRlc3QodmFsdWUpKSB7XG4gICAgICByZXR1cm4gXCJcIjtcbiAgICB9XG4gIH0gZWxzZSBpZiAobmFtZSA9PT0gXCJzdHlsZVwiKSB7XG4gICAgLy8gYGV4cHJlc3Npb24oKWBcbiAgICBSRUdFWFBfREVGQVVMVF9PTl9UQUdfQVRUUl83Lmxhc3RJbmRleCA9IDA7XG4gICAgaWYgKFJFR0VYUF9ERUZBVUxUX09OX1RBR19BVFRSXzcudGVzdCh2YWx1ZSkpIHtcbiAgICAgIHJldHVybiBcIlwiO1xuICAgIH1cbiAgICAvLyBgdXJsKClgXG4gICAgUkVHRVhQX0RFRkFVTFRfT05fVEFHX0FUVFJfOC5sYXN0SW5kZXggPSAwO1xuICAgIGlmIChSRUdFWFBfREVGQVVMVF9PTl9UQUdfQVRUUl84LnRlc3QodmFsdWUpKSB7XG4gICAgICBSRUdFWFBfREVGQVVMVF9PTl9UQUdfQVRUUl80Lmxhc3RJbmRleCA9IDA7XG4gICAgICBpZiAoUkVHRVhQX0RFRkFVTFRfT05fVEFHX0FUVFJfNC50ZXN0KHZhbHVlKSkge1xuICAgICAgICByZXR1cm4gXCJcIjtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKGNzc0ZpbHRlciAhPT0gZmFsc2UpIHtcbiAgICAgIGNzc0ZpbHRlciA9IGNzc0ZpbHRlciB8fCBkZWZhdWx0Q1NTRmlsdGVyO1xuICAgICAgdmFsdWUgPSBjc3NGaWx0ZXIucHJvY2Vzcyh2YWx1ZSk7XG4gICAgfVxuICB9XG5cbiAgLy8gZXNjYXBlIGA8PlwiYCBiZWZvcmUgcmV0dXJuc1xuICB2YWx1ZSA9IGVzY2FwZUF0dHJWYWx1ZSh2YWx1ZSk7XG4gIHJldHVybiB2YWx1ZTtcbn1cblxuLy8gUmVnRXhwIGxpc3RcbnZhciBSRUdFWFBfTFQgPSAvPC9nO1xudmFyIFJFR0VYUF9HVCA9IC8+L2c7XG52YXIgUkVHRVhQX1FVT1RFID0gL1wiL2c7XG52YXIgUkVHRVhQX1FVT1RFXzIgPSAvJnF1b3Q7L2c7XG52YXIgUkVHRVhQX0FUVFJfVkFMVUVfMSA9IC8mIyhbYS16QS1aMC05XSopOz8vZ2ltO1xudmFyIFJFR0VYUF9BVFRSX1ZBTFVFX0NPTE9OID0gLyZjb2xvbjs/L2dpbTtcbnZhciBSRUdFWFBfQVRUUl9WQUxVRV9ORVdMSU5FID0gLyZuZXdsaW5lOz8vZ2ltO1xudmFyIFJFR0VYUF9ERUZBVUxUX09OX1RBR19BVFRSXzMgPSAvXFwvXFwqfFxcKlxcLy9nbTtcbnZhciBSRUdFWFBfREVGQVVMVF9PTl9UQUdfQVRUUl80ID1cbiAgLygoalxccyphXFxzKnZcXHMqYXx2XFxzKmJ8bFxccyppXFxzKnZcXHMqZSlcXHMqc1xccypjXFxzKnJcXHMqaVxccypwXFxzKnRcXHMqfG1cXHMqb1xccypjXFxzKmhcXHMqYSlcXDovZ2k7XG52YXIgUkVHRVhQX0RFRkFVTFRfT05fVEFHX0FUVFJfNSA9IC9eW1xcc1wiJ2BdKihkXFxzKmFcXHMqdFxccyphXFxzKilcXDovZ2k7XG52YXIgUkVHRVhQX0RFRkFVTFRfT05fVEFHX0FUVFJfNiA9IC9eW1xcc1wiJ2BdKihkXFxzKmFcXHMqdFxccyphXFxzKilcXDpcXHMqaW1hZ2VcXC8vZ2k7XG52YXIgUkVHRVhQX0RFRkFVTFRfT05fVEFHX0FUVFJfNyA9XG4gIC9lXFxzKnhcXHMqcFxccypyXFxzKmVcXHMqc1xccypzXFxzKmlcXHMqb1xccypuXFxzKlxcKC4qL2dpO1xudmFyIFJFR0VYUF9ERUZBVUxUX09OX1RBR19BVFRSXzggPSAvdVxccypyXFxzKmxcXHMqXFwoLiovZ2k7XG5cbi8qKlxuICogZXNjYXBlIGRvdWJsZSBxdW90ZVxuICpcbiAqIEBwYXJhbSB7U3RyaW5nfSBzdHJcbiAqIEByZXR1cm4ge1N0cmluZ30gc3RyXG4gKi9cbmZ1bmN0aW9uIGVzY2FwZVF1b3RlKHN0cikge1xuICByZXR1cm4gc3RyLnJlcGxhY2UoUkVHRVhQX1FVT1RFLCBcIiZxdW90O1wiKTtcbn1cblxuLyoqXG4gKiB1bmVzY2FwZSBkb3VibGUgcXVvdGVcbiAqXG4gKiBAcGFyYW0ge1N0cmluZ30gc3RyXG4gKiBAcmV0dXJuIHtTdHJpbmd9IHN0clxuICovXG5mdW5jdGlvbiB1bmVzY2FwZVF1b3RlKHN0cikge1xuICByZXR1cm4gc3RyLnJlcGxhY2UoUkVHRVhQX1FVT1RFXzIsICdcIicpO1xufVxuXG4vKipcbiAqIGVzY2FwZSBodG1sIGVudGl0aWVzXG4gKlxuICogQHBhcmFtIHtTdHJpbmd9IHN0clxuICogQHJldHVybiB7U3RyaW5nfVxuICovXG5mdW5jdGlvbiBlc2NhcGVIdG1sRW50aXRpZXMoc3RyKSB7XG4gIHJldHVybiBzdHIucmVwbGFjZShSRUdFWFBfQVRUUl9WQUxVRV8xLCBmdW5jdGlvbiByZXBsYWNlVW5pY29kZShzdHIsIGNvZGUpIHtcbiAgICByZXR1cm4gY29kZVswXSA9PT0gXCJ4XCIgfHwgY29kZVswXSA9PT0gXCJYXCJcbiAgICAgID8gU3RyaW5nLmZyb21DaGFyQ29kZShwYXJzZUludChjb2RlLnN1YnN0cigxKSwgMTYpKVxuICAgICAgOiBTdHJpbmcuZnJvbUNoYXJDb2RlKHBhcnNlSW50KGNvZGUsIDEwKSk7XG4gIH0pO1xufVxuXG4vKipcbiAqIGVzY2FwZSBodG1sNSBuZXcgZGFuZ2VyIGVudGl0aWVzXG4gKlxuICogQHBhcmFtIHtTdHJpbmd9IHN0clxuICogQHJldHVybiB7U3RyaW5nfVxuICovXG5mdW5jdGlvbiBlc2NhcGVEYW5nZXJIdG1sNUVudGl0aWVzKHN0cikge1xuICByZXR1cm4gc3RyXG4gICAgLnJlcGxhY2UoUkVHRVhQX0FUVFJfVkFMVUVfQ09MT04sIFwiOlwiKVxuICAgIC5yZXBsYWNlKFJFR0VYUF9BVFRSX1ZBTFVFX05FV0xJTkUsIFwiIFwiKTtcbn1cblxuLyoqXG4gKiBjbGVhciBub25wcmludGFibGUgY2hhcmFjdGVyc1xuICpcbiAqIEBwYXJhbSB7U3RyaW5nfSBzdHJcbiAqIEByZXR1cm4ge1N0cmluZ31cbiAqL1xuZnVuY3Rpb24gY2xlYXJOb25QcmludGFibGVDaGFyYWN0ZXIoc3RyKSB7XG4gIHZhciBzdHIyID0gXCJcIjtcbiAgZm9yICh2YXIgaSA9IDAsIGxlbiA9IHN0ci5sZW5ndGg7IGkgPCBsZW47IGkrKykge1xuICAgIHN0cjIgKz0gc3RyLmNoYXJDb2RlQXQoaSkgPCAzMiA/IFwiIFwiIDogc3RyLmNoYXJBdChpKTtcbiAgfVxuICByZXR1cm4gXy50cmltKHN0cjIpO1xufVxuXG4vKipcbiAqIGdldCBmcmllbmRseSBhdHRyaWJ1dGUgdmFsdWVcbiAqXG4gKiBAcGFyYW0ge1N0cmluZ30gc3RyXG4gKiBAcmV0dXJuIHtTdHJpbmd9XG4gKi9cbmZ1bmN0aW9uIGZyaWVuZGx5QXR0clZhbHVlKHN0cikge1xuICBzdHIgPSB1bmVzY2FwZVF1b3RlKHN0cik7XG4gIHN0ciA9IGVzY2FwZUh0bWxFbnRpdGllcyhzdHIpO1xuICBzdHIgPSBlc2NhcGVEYW5nZXJIdG1sNUVudGl0aWVzKHN0cik7XG4gIHN0ciA9IGNsZWFyTm9uUHJpbnRhYmxlQ2hhcmFjdGVyKHN0cik7XG4gIHJldHVybiBzdHI7XG59XG5cbi8qKlxuICogdW5lc2NhcGUgYXR0cmlidXRlIHZhbHVlXG4gKlxuICogQHBhcmFtIHtTdHJpbmd9IHN0clxuICogQHJldHVybiB7U3RyaW5nfVxuICovXG5mdW5jdGlvbiBlc2NhcGVBdHRyVmFsdWUoc3RyKSB7XG4gIHN0ciA9IGVzY2FwZVF1b3RlKHN0cik7XG4gIHN0ciA9IGVzY2FwZUh0bWwoc3RyKTtcbiAgcmV0dXJuIHN0cjtcbn1cblxuLyoqXG4gKiBgb25JZ25vcmVUYWdgIGZ1bmN0aW9uIGZvciByZW1vdmluZyBhbGwgdGhlIHRhZ3MgdGhhdCBhcmUgbm90IGluIHdoaXRlbGlzdFxuICovXG5mdW5jdGlvbiBvbklnbm9yZVRhZ1N0cmlwQWxsKCkge1xuICByZXR1cm4gXCJcIjtcbn1cblxuLyoqXG4gKiByZW1vdmUgdGFnIGJvZHlcbiAqIHNwZWNpZnkgYSBgdGFnc2AgbGlzdCwgaWYgdGhlIHRhZyBpcyBub3QgaW4gdGhlIGB0YWdzYCBsaXN0IHRoZW4gcHJvY2VzcyBieSB0aGUgc3BlY2lmeSBmdW5jdGlvbiAob3B0aW9uYWwpXG4gKlxuICogQHBhcmFtIHthcnJheX0gdGFnc1xuICogQHBhcmFtIHtmdW5jdGlvbn0gbmV4dFxuICovXG5mdW5jdGlvbiBTdHJpcFRhZ0JvZHkodGFncywgbmV4dCkge1xuICBpZiAodHlwZW9mIG5leHQgIT09IFwiZnVuY3Rpb25cIikge1xuICAgIG5leHQgPSBmdW5jdGlvbiAoKSB7fTtcbiAgfVxuXG4gIHZhciBpc1JlbW92ZUFsbFRhZyA9ICFBcnJheS5pc0FycmF5KHRhZ3MpO1xuICBmdW5jdGlvbiBpc1JlbW92ZVRhZyh0YWcpIHtcbiAgICBpZiAoaXNSZW1vdmVBbGxUYWcpIHJldHVybiB0cnVlO1xuICAgIHJldHVybiBfLmluZGV4T2YodGFncywgdGFnKSAhPT0gLTE7XG4gIH1cblxuICB2YXIgcmVtb3ZlTGlzdCA9IFtdO1xuICB2YXIgcG9zU3RhcnQgPSBmYWxzZTtcblxuICByZXR1cm4ge1xuICAgIG9uSWdub3JlVGFnOiBmdW5jdGlvbiAodGFnLCBodG1sLCBvcHRpb25zKSB7XG4gICAgICBpZiAoaXNSZW1vdmVUYWcodGFnKSkge1xuICAgICAgICBpZiAob3B0aW9ucy5pc0Nsb3NpbmcpIHtcbiAgICAgICAgICB2YXIgcmV0ID0gXCJbL3JlbW92ZWRdXCI7XG4gICAgICAgICAgdmFyIGVuZCA9IG9wdGlvbnMucG9zaXRpb24gKyByZXQubGVuZ3RoO1xuICAgICAgICAgIHJlbW92ZUxpc3QucHVzaChbXG4gICAgICAgICAgICBwb3NTdGFydCAhPT0gZmFsc2UgPyBwb3NTdGFydCA6IG9wdGlvbnMucG9zaXRpb24sXG4gICAgICAgICAgICBlbmQsXG4gICAgICAgICAgXSk7XG4gICAgICAgICAgcG9zU3RhcnQgPSBmYWxzZTtcbiAgICAgICAgICByZXR1cm4gcmV0O1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGlmICghcG9zU3RhcnQpIHtcbiAgICAgICAgICAgIHBvc1N0YXJ0ID0gb3B0aW9ucy5wb3NpdGlvbjtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIFwiW3JlbW92ZWRdXCI7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJldHVybiBuZXh0KHRhZywgaHRtbCwgb3B0aW9ucyk7XG4gICAgICB9XG4gICAgfSxcbiAgICByZW1vdmU6IGZ1bmN0aW9uIChodG1sKSB7XG4gICAgICB2YXIgcmV0aHRtbCA9IFwiXCI7XG4gICAgICB2YXIgbGFzdFBvcyA9IDA7XG4gICAgICBfLmZvckVhY2gocmVtb3ZlTGlzdCwgZnVuY3Rpb24gKHBvcykge1xuICAgICAgICByZXRodG1sICs9IGh0bWwuc2xpY2UobGFzdFBvcywgcG9zWzBdKTtcbiAgICAgICAgbGFzdFBvcyA9IHBvc1sxXTtcbiAgICAgIH0pO1xuICAgICAgcmV0aHRtbCArPSBodG1sLnNsaWNlKGxhc3RQb3MpO1xuICAgICAgcmV0dXJuIHJldGh0bWw7XG4gICAgfSxcbiAgfTtcbn1cblxuLyoqXG4gKiByZW1vdmUgaHRtbCBjb21tZW50c1xuICpcbiAqIEBwYXJhbSB7U3RyaW5nfSBodG1sXG4gKiBAcmV0dXJuIHtTdHJpbmd9XG4gKi9cbmZ1bmN0aW9uIHN0cmlwQ29tbWVudFRhZyhodG1sKSB7XG4gIHZhciByZXRIdG1sID0gXCJcIjtcbiAgdmFyIGxhc3RQb3MgPSAwO1xuICB3aGlsZSAobGFzdFBvcyA8IGh0bWwubGVuZ3RoKSB7XG4gICAgdmFyIGkgPSBodG1sLmluZGV4T2YoXCI8IS0tXCIsIGxhc3RQb3MpO1xuICAgIGlmIChpID09PSAtMSkge1xuICAgICAgcmV0SHRtbCArPSBodG1sLnNsaWNlKGxhc3RQb3MpO1xuICAgICAgYnJlYWs7XG4gICAgfVxuICAgIHJldEh0bWwgKz0gaHRtbC5zbGljZShsYXN0UG9zLCBpKTtcbiAgICB2YXIgaiA9IGh0bWwuaW5kZXhPZihcIi0tPlwiLCBpKTtcbiAgICBpZiAoaiA9PT0gLTEpIHtcbiAgICAgIGJyZWFrO1xuICAgIH1cbiAgICBsYXN0UG9zID0gaiArIDM7XG4gIH1cbiAgcmV0dXJuIHJldEh0bWw7XG59XG5cbi8qKlxuICogcmVtb3ZlIGludmlzaWJsZSBjaGFyYWN0ZXJzXG4gKlxuICogQHBhcmFtIHtTdHJpbmd9IGh0bWxcbiAqIEByZXR1cm4ge1N0cmluZ31cbiAqL1xuZnVuY3Rpb24gc3RyaXBCbGFua0NoYXIoaHRtbCkge1xuICB2YXIgY2hhcnMgPSBodG1sLnNwbGl0KFwiXCIpO1xuICBjaGFycyA9IGNoYXJzLmZpbHRlcihmdW5jdGlvbiAoY2hhcikge1xuICAgIHZhciBjID0gY2hhci5jaGFyQ29kZUF0KDApO1xuICAgIGlmIChjID09PSAxMjcpIHJldHVybiBmYWxzZTtcbiAgICBpZiAoYyA8PSAzMSkge1xuICAgICAgaWYgKGMgPT09IDEwIHx8IGMgPT09IDEzKSByZXR1cm4gdHJ1ZTtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgcmV0dXJuIHRydWU7XG4gIH0pO1xuICByZXR1cm4gY2hhcnMuam9pbihcIlwiKTtcbn1cblxuZXhwb3J0cy53aGl0ZUxpc3QgPSBnZXREZWZhdWx0V2hpdGVMaXN0KCk7XG5leHBvcnRzLmdldERlZmF1bHRXaGl0ZUxpc3QgPSBnZXREZWZhdWx0V2hpdGVMaXN0O1xuZXhwb3J0cy5vblRhZyA9IG9uVGFnO1xuZXhwb3J0cy5vbklnbm9yZVRhZyA9IG9uSWdub3JlVGFnO1xuZXhwb3J0cy5vblRhZ0F0dHIgPSBvblRhZ0F0dHI7XG5leHBvcnRzLm9uSWdub3JlVGFnQXR0ciA9IG9uSWdub3JlVGFnQXR0cjtcbmV4cG9ydHMuc2FmZUF0dHJWYWx1ZSA9IHNhZmVBdHRyVmFsdWU7XG5leHBvcnRzLmVzY2FwZUh0bWwgPSBlc2NhcGVIdG1sO1xuZXhwb3J0cy5lc2NhcGVRdW90ZSA9IGVzY2FwZVF1b3RlO1xuZXhwb3J0cy51bmVzY2FwZVF1b3RlID0gdW5lc2NhcGVRdW90ZTtcbmV4cG9ydHMuZXNjYXBlSHRtbEVudGl0aWVzID0gZXNjYXBlSHRtbEVudGl0aWVzO1xuZXhwb3J0cy5lc2NhcGVEYW5nZXJIdG1sNUVudGl0aWVzID0gZXNjYXBlRGFuZ2VySHRtbDVFbnRpdGllcztcbmV4cG9ydHMuY2xlYXJOb25QcmludGFibGVDaGFyYWN0ZXIgPSBjbGVhck5vblByaW50YWJsZUNoYXJhY3RlcjtcbmV4cG9ydHMuZnJpZW5kbHlBdHRyVmFsdWUgPSBmcmllbmRseUF0dHJWYWx1ZTtcbmV4cG9ydHMuZXNjYXBlQXR0clZhbHVlID0gZXNjYXBlQXR0clZhbHVlO1xuZXhwb3J0cy5vbklnbm9yZVRhZ1N0cmlwQWxsID0gb25JZ25vcmVUYWdTdHJpcEFsbDtcbmV4cG9ydHMuU3RyaXBUYWdCb2R5ID0gU3RyaXBUYWdCb2R5O1xuZXhwb3J0cy5zdHJpcENvbW1lbnRUYWcgPSBzdHJpcENvbW1lbnRUYWc7XG5leHBvcnRzLnN0cmlwQmxhbmtDaGFyID0gc3RyaXBCbGFua0NoYXI7XG5leHBvcnRzLmNzc0ZpbHRlciA9IGRlZmF1bHRDU1NGaWx0ZXI7XG5leHBvcnRzLmdldERlZmF1bHRDU1NXaGl0ZUxpc3QgPSBnZXREZWZhdWx0Q1NTV2hpdGVMaXN0O1xuIiwiLyoqXG4gKiB4c3NcbiAqXG4gKiBAYXV0aG9yIFpvbmdtaW4gTGVpPGxlaXpvbmdtaW5AZ21haWwuY29tPlxuICovXG5cbnZhciBERUZBVUxUID0gcmVxdWlyZShcIi4vZGVmYXVsdFwiKTtcbnZhciBwYXJzZXIgPSByZXF1aXJlKFwiLi9wYXJzZXJcIik7XG52YXIgRmlsdGVyWFNTID0gcmVxdWlyZShcIi4veHNzXCIpO1xuXG4vKipcbiAqIGZpbHRlciB4c3MgZnVuY3Rpb25cbiAqXG4gKiBAcGFyYW0ge1N0cmluZ30gaHRtbFxuICogQHBhcmFtIHtPYmplY3R9IG9wdGlvbnMgeyB3aGl0ZUxpc3QsIG9uVGFnLCBvblRhZ0F0dHIsIG9uSWdub3JlVGFnLCBvbklnbm9yZVRhZ0F0dHIsIHNhZmVBdHRyVmFsdWUsIGVzY2FwZUh0bWwgfVxuICogQHJldHVybiB7U3RyaW5nfVxuICovXG5mdW5jdGlvbiBmaWx0ZXJYU1MoaHRtbCwgb3B0aW9ucykge1xuICB2YXIgeHNzID0gbmV3IEZpbHRlclhTUyhvcHRpb25zKTtcbiAgcmV0dXJuIHhzcy5wcm9jZXNzKGh0bWwpO1xufVxuXG5leHBvcnRzID0gbW9kdWxlLmV4cG9ydHMgPSBmaWx0ZXJYU1M7XG5leHBvcnRzLmZpbHRlclhTUyA9IGZpbHRlclhTUztcbmV4cG9ydHMuRmlsdGVyWFNTID0gRmlsdGVyWFNTO1xuZm9yICh2YXIgaSBpbiBERUZBVUxUKSBleHBvcnRzW2ldID0gREVGQVVMVFtpXTtcbmZvciAodmFyIGkgaW4gcGFyc2VyKSBleHBvcnRzW2ldID0gcGFyc2VyW2ldO1xuXG4vLyB1c2luZyBgeHNzYCBvbiB0aGUgYnJvd3Nlciwgb3V0cHV0IGBmaWx0ZXJYU1NgIHRvIHRoZSBnbG9iYWxzXG5pZiAodHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIikge1xuICB3aW5kb3cuZmlsdGVyWFNTID0gbW9kdWxlLmV4cG9ydHM7XG59XG5cbi8vIHVzaW5nIGB4c3NgIG9uIHRoZSBXZWJXb3JrZXIsIG91dHB1dCBgZmlsdGVyWFNTYCB0byB0aGUgZ2xvYmFsc1xuZnVuY3Rpb24gaXNXb3JrZXJFbnYoKSB7XG4gIHJldHVybiAoXG4gICAgdHlwZW9mIHNlbGYgIT09IFwidW5kZWZpbmVkXCIgJiZcbiAgICB0eXBlb2YgRGVkaWNhdGVkV29ya2VyR2xvYmFsU2NvcGUgIT09IFwidW5kZWZpbmVkXCIgJiZcbiAgICBzZWxmIGluc3RhbmNlb2YgRGVkaWNhdGVkV29ya2VyR2xvYmFsU2NvcGVcbiAgKTtcbn1cbmlmIChpc1dvcmtlckVudigpKSB7XG4gIHNlbGYuZmlsdGVyWFNTID0gbW9kdWxlLmV4cG9ydHM7XG59XG4iLCIvKipcbiAqIFNpbXBsZSBIVE1MIFBhcnNlclxuICpcbiAqIEBhdXRob3IgWm9uZ21pbiBMZWk8bGVpem9uZ21pbkBnbWFpbC5jb20+XG4gKi9cblxudmFyIF8gPSByZXF1aXJlKFwiLi91dGlsXCIpO1xuXG4vKipcbiAqIGdldCB0YWcgbmFtZVxuICpcbiAqIEBwYXJhbSB7U3RyaW5nfSBodG1sIGUuZy4gJzxhIGhlZj1cIiNcIj4nXG4gKiBAcmV0dXJuIHtTdHJpbmd9XG4gKi9cbmZ1bmN0aW9uIGdldFRhZ05hbWUoaHRtbCkge1xuICB2YXIgaSA9IF8uc3BhY2VJbmRleChodG1sKTtcbiAgaWYgKGkgPT09IC0xKSB7XG4gICAgdmFyIHRhZ05hbWUgPSBodG1sLnNsaWNlKDEsIC0xKTtcbiAgfSBlbHNlIHtcbiAgICB2YXIgdGFnTmFtZSA9IGh0bWwuc2xpY2UoMSwgaSArIDEpO1xuICB9XG4gIHRhZ05hbWUgPSBfLnRyaW0odGFnTmFtZSkudG9Mb3dlckNhc2UoKTtcbiAgaWYgKHRhZ05hbWUuc2xpY2UoMCwgMSkgPT09IFwiL1wiKSB0YWdOYW1lID0gdGFnTmFtZS5zbGljZSgxKTtcbiAgaWYgKHRhZ05hbWUuc2xpY2UoLTEpID09PSBcIi9cIikgdGFnTmFtZSA9IHRhZ05hbWUuc2xpY2UoMCwgLTEpO1xuICByZXR1cm4gdGFnTmFtZTtcbn1cblxuLyoqXG4gKiBpcyBjbG9zZSB0YWc/XG4gKlxuICogQHBhcmFtIHtTdHJpbmd9IGh0bWwg5aaC77yaJzxhIGhlZj1cIiNcIj4nXG4gKiBAcmV0dXJuIHtCb29sZWFufVxuICovXG5mdW5jdGlvbiBpc0Nsb3NpbmcoaHRtbCkge1xuICByZXR1cm4gaHRtbC5zbGljZSgwLCAyKSA9PT0gXCI8L1wiO1xufVxuXG4vKipcbiAqIHBhcnNlIGlucHV0IGh0bWwgYW5kIHJldHVybnMgcHJvY2Vzc2VkIGh0bWxcbiAqXG4gKiBAcGFyYW0ge1N0cmluZ30gaHRtbFxuICogQHBhcmFtIHtGdW5jdGlvbn0gb25UYWcgZS5nLiBmdW5jdGlvbiAoc291cmNlUG9zaXRpb24sIHBvc2l0aW9uLCB0YWcsIGh0bWwsIGlzQ2xvc2luZylcbiAqIEBwYXJhbSB7RnVuY3Rpb259IGVzY2FwZUh0bWxcbiAqIEByZXR1cm4ge1N0cmluZ31cbiAqL1xuZnVuY3Rpb24gcGFyc2VUYWcoaHRtbCwgb25UYWcsIGVzY2FwZUh0bWwpIHtcbiAgXCJ1c2Ugc3RyaWN0XCI7XG5cbiAgdmFyIHJldGh0bWwgPSBcIlwiO1xuICB2YXIgbGFzdFBvcyA9IDA7XG4gIHZhciB0YWdTdGFydCA9IGZhbHNlO1xuICB2YXIgcXVvdGVTdGFydCA9IGZhbHNlO1xuICB2YXIgY3VycmVudFBvcyA9IDA7XG4gIHZhciBsZW4gPSBodG1sLmxlbmd0aDtcbiAgdmFyIGN1cnJlbnRUYWdOYW1lID0gXCJcIjtcbiAgdmFyIGN1cnJlbnRIdG1sID0gXCJcIjtcblxuICBjaGFyaXRlcmF0b3I6IGZvciAoY3VycmVudFBvcyA9IDA7IGN1cnJlbnRQb3MgPCBsZW47IGN1cnJlbnRQb3MrKykge1xuICAgIHZhciBjID0gaHRtbC5jaGFyQXQoY3VycmVudFBvcyk7XG4gICAgaWYgKHRhZ1N0YXJ0ID09PSBmYWxzZSkge1xuICAgICAgaWYgKGMgPT09IFwiPFwiKSB7XG4gICAgICAgIHRhZ1N0YXJ0ID0gY3VycmVudFBvcztcbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIGlmIChxdW90ZVN0YXJ0ID09PSBmYWxzZSkge1xuICAgICAgICBpZiAoYyA9PT0gXCI8XCIpIHtcbiAgICAgICAgICByZXRodG1sICs9IGVzY2FwZUh0bWwoaHRtbC5zbGljZShsYXN0UG9zLCBjdXJyZW50UG9zKSk7XG4gICAgICAgICAgdGFnU3RhcnQgPSBjdXJyZW50UG9zO1xuICAgICAgICAgIGxhc3RQb3MgPSBjdXJyZW50UG9zO1xuICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIGlmIChjID09PSBcIj5cIikge1xuICAgICAgICAgIHJldGh0bWwgKz0gZXNjYXBlSHRtbChodG1sLnNsaWNlKGxhc3RQb3MsIHRhZ1N0YXJ0KSk7XG4gICAgICAgICAgY3VycmVudEh0bWwgPSBodG1sLnNsaWNlKHRhZ1N0YXJ0LCBjdXJyZW50UG9zICsgMSk7XG4gICAgICAgICAgY3VycmVudFRhZ05hbWUgPSBnZXRUYWdOYW1lKGN1cnJlbnRIdG1sKTtcbiAgICAgICAgICByZXRodG1sICs9IG9uVGFnKFxuICAgICAgICAgICAgdGFnU3RhcnQsXG4gICAgICAgICAgICByZXRodG1sLmxlbmd0aCxcbiAgICAgICAgICAgIGN1cnJlbnRUYWdOYW1lLFxuICAgICAgICAgICAgY3VycmVudEh0bWwsXG4gICAgICAgICAgICBpc0Nsb3NpbmcoY3VycmVudEh0bWwpXG4gICAgICAgICAgKTtcbiAgICAgICAgICBsYXN0UG9zID0gY3VycmVudFBvcyArIDE7XG4gICAgICAgICAgdGFnU3RhcnQgPSBmYWxzZTtcbiAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoYyA9PT0gJ1wiJyB8fCBjID09PSBcIidcIikge1xuICAgICAgICAgIHZhciBpID0gMTtcbiAgICAgICAgICB2YXIgaWMgPSBodG1sLmNoYXJBdChjdXJyZW50UG9zIC0gaSk7XG5cbiAgICAgICAgICB3aGlsZSAoaWMudHJpbSgpID09PSBcIlwiIHx8IGljID09PSBcIj1cIikge1xuICAgICAgICAgICAgaWYgKGljID09PSBcIj1cIikge1xuICAgICAgICAgICAgICBxdW90ZVN0YXJ0ID0gYztcbiAgICAgICAgICAgICAgY29udGludWUgY2hhcml0ZXJhdG9yO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWMgPSBodG1sLmNoYXJBdChjdXJyZW50UG9zIC0gKytpKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGlmIChjID09PSBxdW90ZVN0YXJ0KSB7XG4gICAgICAgICAgcXVvdGVTdGFydCA9IGZhbHNlO1xuICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG4gIGlmIChsYXN0UG9zIDwgaHRtbC5sZW5ndGgpIHtcbiAgICByZXRodG1sICs9IGVzY2FwZUh0bWwoaHRtbC5zdWJzdHIobGFzdFBvcykpO1xuICB9XG5cbiAgcmV0dXJuIHJldGh0bWw7XG59XG5cbnZhciBSRUdFWFBfSUxMRUdBTF9BVFRSX05BTUUgPSAvW15hLXpBLVowLTlfOlxcLlxcLV0vZ2ltO1xuXG4vKipcbiAqIHBhcnNlIGlucHV0IGF0dHJpYnV0ZXMgYW5kIHJldHVybnMgcHJvY2Vzc2VkIGF0dHJpYnV0ZXNcbiAqXG4gKiBAcGFyYW0ge1N0cmluZ30gaHRtbCBlLmcuIGBocmVmPVwiI1wiIHRhcmdldD1cIl9ibGFua1wiYFxuICogQHBhcmFtIHtGdW5jdGlvbn0gb25BdHRyIGUuZy4gYGZ1bmN0aW9uIChuYW1lLCB2YWx1ZSlgXG4gKiBAcmV0dXJuIHtTdHJpbmd9XG4gKi9cbmZ1bmN0aW9uIHBhcnNlQXR0cihodG1sLCBvbkF0dHIpIHtcbiAgXCJ1c2Ugc3RyaWN0XCI7XG5cbiAgdmFyIGxhc3RQb3MgPSAwO1xuICB2YXIgcmV0QXR0cnMgPSBbXTtcbiAgdmFyIHRtcE5hbWUgPSBmYWxzZTtcbiAgdmFyIGxlbiA9IGh0bWwubGVuZ3RoO1xuXG4gIGZ1bmN0aW9uIGFkZEF0dHIobmFtZSwgdmFsdWUpIHtcbiAgICBuYW1lID0gXy50cmltKG5hbWUpO1xuICAgIG5hbWUgPSBuYW1lLnJlcGxhY2UoUkVHRVhQX0lMTEVHQUxfQVRUUl9OQU1FLCBcIlwiKS50b0xvd2VyQ2FzZSgpO1xuICAgIGlmIChuYW1lLmxlbmd0aCA8IDEpIHJldHVybjtcbiAgICB2YXIgcmV0ID0gb25BdHRyKG5hbWUsIHZhbHVlIHx8IFwiXCIpO1xuICAgIGlmIChyZXQpIHJldEF0dHJzLnB1c2gocmV0KTtcbiAgfVxuXG4gIC8vIOmAkOS4quWIhuaekOWtl+esplxuICBmb3IgKHZhciBpID0gMDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgdmFyIGMgPSBodG1sLmNoYXJBdChpKTtcbiAgICB2YXIgdiwgajtcbiAgICBpZiAodG1wTmFtZSA9PT0gZmFsc2UgJiYgYyA9PT0gXCI9XCIpIHtcbiAgICAgIHRtcE5hbWUgPSBodG1sLnNsaWNlKGxhc3RQb3MsIGkpO1xuICAgICAgbGFzdFBvcyA9IGkgKyAxO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGlmICh0bXBOYW1lICE9PSBmYWxzZSkge1xuICAgICAgaWYgKFxuICAgICAgICBpID09PSBsYXN0UG9zICYmXG4gICAgICAgIChjID09PSAnXCInIHx8IGMgPT09IFwiJ1wiKSAmJlxuICAgICAgICBodG1sLmNoYXJBdChpIC0gMSkgPT09IFwiPVwiXG4gICAgICApIHtcbiAgICAgICAgaiA9IGh0bWwuaW5kZXhPZihjLCBpICsgMSk7XG4gICAgICAgIGlmIChqID09PSAtMSkge1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHYgPSBfLnRyaW0oaHRtbC5zbGljZShsYXN0UG9zICsgMSwgaikpO1xuICAgICAgICAgIGFkZEF0dHIodG1wTmFtZSwgdik7XG4gICAgICAgICAgdG1wTmFtZSA9IGZhbHNlO1xuICAgICAgICAgIGkgPSBqO1xuICAgICAgICAgIGxhc3RQb3MgPSBpICsgMTtcbiAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICBpZiAoL1xcc3xcXG58XFx0Ly50ZXN0KGMpKSB7XG4gICAgICBodG1sID0gaHRtbC5yZXBsYWNlKC9cXHN8XFxufFxcdC9nLCBcIiBcIik7XG4gICAgICBpZiAodG1wTmFtZSA9PT0gZmFsc2UpIHtcbiAgICAgICAgaiA9IGZpbmROZXh0RXF1YWwoaHRtbCwgaSk7XG4gICAgICAgIGlmIChqID09PSAtMSkge1xuICAgICAgICAgIHYgPSBfLnRyaW0oaHRtbC5zbGljZShsYXN0UG9zLCBpKSk7XG4gICAgICAgICAgYWRkQXR0cih2KTtcbiAgICAgICAgICB0bXBOYW1lID0gZmFsc2U7XG4gICAgICAgICAgbGFzdFBvcyA9IGkgKyAxO1xuICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGkgPSBqIC0gMTtcbiAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgaiA9IGZpbmRCZWZvcmVFcXVhbChodG1sLCBpIC0gMSk7XG4gICAgICAgIGlmIChqID09PSAtMSkge1xuICAgICAgICAgIHYgPSBfLnRyaW0oaHRtbC5zbGljZShsYXN0UG9zLCBpKSk7XG4gICAgICAgICAgdiA9IHN0cmlwUXVvdGVXcmFwKHYpO1xuICAgICAgICAgIGFkZEF0dHIodG1wTmFtZSwgdik7XG4gICAgICAgICAgdG1wTmFtZSA9IGZhbHNlO1xuICAgICAgICAgIGxhc3RQb3MgPSBpICsgMTtcbiAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIGlmIChsYXN0UG9zIDwgaHRtbC5sZW5ndGgpIHtcbiAgICBpZiAodG1wTmFtZSA9PT0gZmFsc2UpIHtcbiAgICAgIGFkZEF0dHIoaHRtbC5zbGljZShsYXN0UG9zKSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGFkZEF0dHIodG1wTmFtZSwgc3RyaXBRdW90ZVdyYXAoXy50cmltKGh0bWwuc2xpY2UobGFzdFBvcykpKSk7XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIF8udHJpbShyZXRBdHRycy5qb2luKFwiIFwiKSk7XG59XG5cbmZ1bmN0aW9uIGZpbmROZXh0RXF1YWwoc3RyLCBpKSB7XG4gIGZvciAoOyBpIDwgc3RyLmxlbmd0aDsgaSsrKSB7XG4gICAgdmFyIGMgPSBzdHJbaV07XG4gICAgaWYgKGMgPT09IFwiIFwiKSBjb250aW51ZTtcbiAgICBpZiAoYyA9PT0gXCI9XCIpIHJldHVybiBpO1xuICAgIHJldHVybiAtMTtcbiAgfVxufVxuXG5mdW5jdGlvbiBmaW5kQmVmb3JlRXF1YWwoc3RyLCBpKSB7XG4gIGZvciAoOyBpID4gMDsgaS0tKSB7XG4gICAgdmFyIGMgPSBzdHJbaV07XG4gICAgaWYgKGMgPT09IFwiIFwiKSBjb250aW51ZTtcbiAgICBpZiAoYyA9PT0gXCI9XCIpIHJldHVybiBpO1xuICAgIHJldHVybiAtMTtcbiAgfVxufVxuXG5mdW5jdGlvbiBpc1F1b3RlV3JhcFN0cmluZyh0ZXh0KSB7XG4gIGlmIChcbiAgICAodGV4dFswXSA9PT0gJ1wiJyAmJiB0ZXh0W3RleHQubGVuZ3RoIC0gMV0gPT09ICdcIicpIHx8XG4gICAgKHRleHRbMF0gPT09IFwiJ1wiICYmIHRleHRbdGV4dC5sZW5ndGggLSAxXSA9PT0gXCInXCIpXG4gICkge1xuICAgIHJldHVybiB0cnVlO1xuICB9IGVsc2Uge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxufVxuXG5mdW5jdGlvbiBzdHJpcFF1b3RlV3JhcCh0ZXh0KSB7XG4gIGlmIChpc1F1b3RlV3JhcFN0cmluZyh0ZXh0KSkge1xuICAgIHJldHVybiB0ZXh0LnN1YnN0cigxLCB0ZXh0Lmxlbmd0aCAtIDIpO1xuICB9IGVsc2Uge1xuICAgIHJldHVybiB0ZXh0O1xuICB9XG59XG5cbmV4cG9ydHMucGFyc2VUYWcgPSBwYXJzZVRhZztcbmV4cG9ydHMucGFyc2VBdHRyID0gcGFyc2VBdHRyO1xuIiwibW9kdWxlLmV4cG9ydHMgPSB7XG4gIGluZGV4T2Y6IGZ1bmN0aW9uIChhcnIsIGl0ZW0pIHtcbiAgICB2YXIgaSwgajtcbiAgICBpZiAoQXJyYXkucHJvdG90eXBlLmluZGV4T2YpIHtcbiAgICAgIHJldHVybiBhcnIuaW5kZXhPZihpdGVtKTtcbiAgICB9XG4gICAgZm9yIChpID0gMCwgaiA9IGFyci5sZW5ndGg7IGkgPCBqOyBpKyspIHtcbiAgICAgIGlmIChhcnJbaV0gPT09IGl0ZW0pIHtcbiAgICAgICAgcmV0dXJuIGk7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiAtMTtcbiAgfSxcbiAgZm9yRWFjaDogZnVuY3Rpb24gKGFyciwgZm4sIHNjb3BlKSB7XG4gICAgdmFyIGksIGo7XG4gICAgaWYgKEFycmF5LnByb3RvdHlwZS5mb3JFYWNoKSB7XG4gICAgICByZXR1cm4gYXJyLmZvckVhY2goZm4sIHNjb3BlKTtcbiAgICB9XG4gICAgZm9yIChpID0gMCwgaiA9IGFyci5sZW5ndGg7IGkgPCBqOyBpKyspIHtcbiAgICAgIGZuLmNhbGwoc2NvcGUsIGFycltpXSwgaSwgYXJyKTtcbiAgICB9XG4gIH0sXG4gIHRyaW06IGZ1bmN0aW9uIChzdHIpIHtcbiAgICBpZiAoU3RyaW5nLnByb3RvdHlwZS50cmltKSB7XG4gICAgICByZXR1cm4gc3RyLnRyaW0oKTtcbiAgICB9XG4gICAgcmV0dXJuIHN0ci5yZXBsYWNlKC8oXlxccyopfChcXHMqJCkvZywgXCJcIik7XG4gIH0sXG4gIHNwYWNlSW5kZXg6IGZ1bmN0aW9uIChzdHIpIHtcbiAgICB2YXIgcmVnID0gL1xcc3xcXG58XFx0LztcbiAgICB2YXIgbWF0Y2ggPSByZWcuZXhlYyhzdHIpO1xuICAgIHJldHVybiBtYXRjaCA/IG1hdGNoLmluZGV4IDogLTE7XG4gIH0sXG59O1xuIiwiLyoqXG4gKiBmaWx0ZXIgeHNzXG4gKlxuICogQGF1dGhvciBab25nbWluIExlaTxsZWl6b25nbWluQGdtYWlsLmNvbT5cbiAqL1xuXG52YXIgRmlsdGVyQ1NTID0gcmVxdWlyZShcImNzc2ZpbHRlclwiKS5GaWx0ZXJDU1M7XG52YXIgREVGQVVMVCA9IHJlcXVpcmUoXCIuL2RlZmF1bHRcIik7XG52YXIgcGFyc2VyID0gcmVxdWlyZShcIi4vcGFyc2VyXCIpO1xudmFyIHBhcnNlVGFnID0gcGFyc2VyLnBhcnNlVGFnO1xudmFyIHBhcnNlQXR0ciA9IHBhcnNlci5wYXJzZUF0dHI7XG52YXIgXyA9IHJlcXVpcmUoXCIuL3V0aWxcIik7XG5cbi8qKlxuICogcmV0dXJucyBgdHJ1ZWAgaWYgdGhlIGlucHV0IHZhbHVlIGlzIGB1bmRlZmluZWRgIG9yIGBudWxsYFxuICpcbiAqIEBwYXJhbSB7T2JqZWN0fSBvYmpcbiAqIEByZXR1cm4ge0Jvb2xlYW59XG4gKi9cbmZ1bmN0aW9uIGlzTnVsbChvYmopIHtcbiAgcmV0dXJuIG9iaiA9PT0gdW5kZWZpbmVkIHx8IG9iaiA9PT0gbnVsbDtcbn1cblxuLyoqXG4gKiBnZXQgYXR0cmlidXRlcyBmb3IgYSB0YWdcbiAqXG4gKiBAcGFyYW0ge1N0cmluZ30gaHRtbFxuICogQHJldHVybiB7T2JqZWN0fVxuICogICAtIHtTdHJpbmd9IGh0bWxcbiAqICAgLSB7Qm9vbGVhbn0gY2xvc2luZ1xuICovXG5mdW5jdGlvbiBnZXRBdHRycyhodG1sKSB7XG4gIHZhciBpID0gXy5zcGFjZUluZGV4KGh0bWwpO1xuICBpZiAoaSA9PT0gLTEpIHtcbiAgICByZXR1cm4ge1xuICAgICAgaHRtbDogXCJcIixcbiAgICAgIGNsb3Npbmc6IGh0bWxbaHRtbC5sZW5ndGggLSAyXSA9PT0gXCIvXCIsXG4gICAgfTtcbiAgfVxuICBodG1sID0gXy50cmltKGh0bWwuc2xpY2UoaSArIDEsIC0xKSk7XG4gIHZhciBpc0Nsb3NpbmcgPSBodG1sW2h0bWwubGVuZ3RoIC0gMV0gPT09IFwiL1wiO1xuICBpZiAoaXNDbG9zaW5nKSBodG1sID0gXy50cmltKGh0bWwuc2xpY2UoMCwgLTEpKTtcbiAgcmV0dXJuIHtcbiAgICBodG1sOiBodG1sLFxuICAgIGNsb3Npbmc6IGlzQ2xvc2luZyxcbiAgfTtcbn1cblxuLyoqXG4gKiBzaGFsbG93IGNvcHlcbiAqXG4gKiBAcGFyYW0ge09iamVjdH0gb2JqXG4gKiBAcmV0dXJuIHtPYmplY3R9XG4gKi9cbmZ1bmN0aW9uIHNoYWxsb3dDb3B5T2JqZWN0KG9iaikge1xuICB2YXIgcmV0ID0ge307XG4gIGZvciAodmFyIGkgaW4gb2JqKSB7XG4gICAgcmV0W2ldID0gb2JqW2ldO1xuICB9XG4gIHJldHVybiByZXQ7XG59XG5cbi8qKlxuICogRmlsdGVyWFNTIGNsYXNzXG4gKlxuICogQHBhcmFtIHtPYmplY3R9IG9wdGlvbnNcbiAqICAgICAgICB3aGl0ZUxpc3QsIG9uVGFnLCBvblRhZ0F0dHIsIG9uSWdub3JlVGFnLFxuICogICAgICAgIG9uSWdub3JlVGFnQXR0ciwgc2FmZUF0dHJWYWx1ZSwgZXNjYXBlSHRtbFxuICogICAgICAgIHN0cmlwSWdub3JlVGFnQm9keSwgYWxsb3dDb21tZW50VGFnLCBzdHJpcEJsYW5rQ2hhclxuICogICAgICAgIGNzc3t3aGl0ZUxpc3QsIG9uQXR0ciwgb25JZ25vcmVBdHRyfSBgY3NzPWZhbHNlYCBtZWFucyBkb24ndCB1c2UgYGNzc2ZpbHRlcmBcbiAqL1xuZnVuY3Rpb24gRmlsdGVyWFNTKG9wdGlvbnMpIHtcbiAgb3B0aW9ucyA9IHNoYWxsb3dDb3B5T2JqZWN0KG9wdGlvbnMgfHwge30pO1xuXG4gIGlmIChvcHRpb25zLnN0cmlwSWdub3JlVGFnKSB7XG4gICAgaWYgKG9wdGlvbnMub25JZ25vcmVUYWcpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICAgICdOb3RlczogY2Fubm90IHVzZSB0aGVzZSB0d28gb3B0aW9ucyBcInN0cmlwSWdub3JlVGFnXCIgYW5kIFwib25JZ25vcmVUYWdcIiBhdCB0aGUgc2FtZSB0aW1lJ1xuICAgICAgKTtcbiAgICB9XG4gICAgb3B0aW9ucy5vbklnbm9yZVRhZyA9IERFRkFVTFQub25JZ25vcmVUYWdTdHJpcEFsbDtcbiAgfVxuXG4gIG9wdGlvbnMud2hpdGVMaXN0ID0gb3B0aW9ucy53aGl0ZUxpc3QgfHwgREVGQVVMVC53aGl0ZUxpc3Q7XG4gIG9wdGlvbnMub25UYWcgPSBvcHRpb25zLm9uVGFnIHx8IERFRkFVTFQub25UYWc7XG4gIG9wdGlvbnMub25UYWdBdHRyID0gb3B0aW9ucy5vblRhZ0F0dHIgfHwgREVGQVVMVC5vblRhZ0F0dHI7XG4gIG9wdGlvbnMub25JZ25vcmVUYWcgPSBvcHRpb25zLm9uSWdub3JlVGFnIHx8IERFRkFVTFQub25JZ25vcmVUYWc7XG4gIG9wdGlvbnMub25JZ25vcmVUYWdBdHRyID0gb3B0aW9ucy5vbklnbm9yZVRhZ0F0dHIgfHwgREVGQVVMVC5vbklnbm9yZVRhZ0F0dHI7XG4gIG9wdGlvbnMuc2FmZUF0dHJWYWx1ZSA9IG9wdGlvbnMuc2FmZUF0dHJWYWx1ZSB8fCBERUZBVUxULnNhZmVBdHRyVmFsdWU7XG4gIG9wdGlvbnMuZXNjYXBlSHRtbCA9IG9wdGlvbnMuZXNjYXBlSHRtbCB8fCBERUZBVUxULmVzY2FwZUh0bWw7XG4gIHRoaXMub3B0aW9ucyA9IG9wdGlvbnM7XG5cbiAgaWYgKG9wdGlvbnMuY3NzID09PSBmYWxzZSkge1xuICAgIHRoaXMuY3NzRmlsdGVyID0gZmFsc2U7XG4gIH0gZWxzZSB7XG4gICAgb3B0aW9ucy5jc3MgPSBvcHRpb25zLmNzcyB8fCB7fTtcbiAgICB0aGlzLmNzc0ZpbHRlciA9IG5ldyBGaWx0ZXJDU1Mob3B0aW9ucy5jc3MpO1xuICB9XG59XG5cbi8qKlxuICogc3RhcnQgcHJvY2VzcyBhbmQgcmV0dXJucyByZXN1bHRcbiAqXG4gKiBAcGFyYW0ge1N0cmluZ30gaHRtbFxuICogQHJldHVybiB7U3RyaW5nfVxuICovXG5GaWx0ZXJYU1MucHJvdG90eXBlLnByb2Nlc3MgPSBmdW5jdGlvbiAoaHRtbCkge1xuICAvLyBjb21wYXRpYmxlIHdpdGggdGhlIGlucHV0XG4gIGh0bWwgPSBodG1sIHx8IFwiXCI7XG4gIGh0bWwgPSBodG1sLnRvU3RyaW5nKCk7XG4gIGlmICghaHRtbCkgcmV0dXJuIFwiXCI7XG5cbiAgdmFyIG1lID0gdGhpcztcbiAgdmFyIG9wdGlvbnMgPSBtZS5vcHRpb25zO1xuICB2YXIgd2hpdGVMaXN0ID0gb3B0aW9ucy53aGl0ZUxpc3Q7XG4gIHZhciBvblRhZyA9IG9wdGlvbnMub25UYWc7XG4gIHZhciBvbklnbm9yZVRhZyA9IG9wdGlvbnMub25JZ25vcmVUYWc7XG4gIHZhciBvblRhZ0F0dHIgPSBvcHRpb25zLm9uVGFnQXR0cjtcbiAgdmFyIG9uSWdub3JlVGFnQXR0ciA9IG9wdGlvbnMub25JZ25vcmVUYWdBdHRyO1xuICB2YXIgc2FmZUF0dHJWYWx1ZSA9IG9wdGlvbnMuc2FmZUF0dHJWYWx1ZTtcbiAgdmFyIGVzY2FwZUh0bWwgPSBvcHRpb25zLmVzY2FwZUh0bWw7XG4gIHZhciBjc3NGaWx0ZXIgPSBtZS5jc3NGaWx0ZXI7XG5cbiAgLy8gcmVtb3ZlIGludmlzaWJsZSBjaGFyYWN0ZXJzXG4gIGlmIChvcHRpb25zLnN0cmlwQmxhbmtDaGFyKSB7XG4gICAgaHRtbCA9IERFRkFVTFQuc3RyaXBCbGFua0NoYXIoaHRtbCk7XG4gIH1cblxuICAvLyByZW1vdmUgaHRtbCBjb21tZW50c1xuICBpZiAoIW9wdGlvbnMuYWxsb3dDb21tZW50VGFnKSB7XG4gICAgaHRtbCA9IERFRkFVTFQuc3RyaXBDb21tZW50VGFnKGh0bWwpO1xuICB9XG5cbiAgLy8gaWYgZW5hYmxlIHN0cmlwSWdub3JlVGFnQm9keVxuICB2YXIgc3RyaXBJZ25vcmVUYWdCb2R5ID0gZmFsc2U7XG4gIGlmIChvcHRpb25zLnN0cmlwSWdub3JlVGFnQm9keSkge1xuICAgIHZhciBzdHJpcElnbm9yZVRhZ0JvZHkgPSBERUZBVUxULlN0cmlwVGFnQm9keShcbiAgICAgIG9wdGlvbnMuc3RyaXBJZ25vcmVUYWdCb2R5LFxuICAgICAgb25JZ25vcmVUYWdcbiAgICApO1xuICAgIG9uSWdub3JlVGFnID0gc3RyaXBJZ25vcmVUYWdCb2R5Lm9uSWdub3JlVGFnO1xuICB9XG5cbiAgdmFyIHJldEh0bWwgPSBwYXJzZVRhZyhcbiAgICBodG1sLFxuICAgIGZ1bmN0aW9uIChzb3VyY2VQb3NpdGlvbiwgcG9zaXRpb24sIHRhZywgaHRtbCwgaXNDbG9zaW5nKSB7XG4gICAgICB2YXIgaW5mbyA9IHtcbiAgICAgICAgc291cmNlUG9zaXRpb246IHNvdXJjZVBvc2l0aW9uLFxuICAgICAgICBwb3NpdGlvbjogcG9zaXRpb24sXG4gICAgICAgIGlzQ2xvc2luZzogaXNDbG9zaW5nLFxuICAgICAgICBpc1doaXRlOiB3aGl0ZUxpc3QuaGFzT3duUHJvcGVydHkodGFnKSxcbiAgICAgIH07XG5cbiAgICAgIC8vIGNhbGwgYG9uVGFnKClgXG4gICAgICB2YXIgcmV0ID0gb25UYWcodGFnLCBodG1sLCBpbmZvKTtcbiAgICAgIGlmICghaXNOdWxsKHJldCkpIHJldHVybiByZXQ7XG5cbiAgICAgIGlmIChpbmZvLmlzV2hpdGUpIHtcbiAgICAgICAgaWYgKGluZm8uaXNDbG9zaW5nKSB7XG4gICAgICAgICAgcmV0dXJuIFwiPC9cIiArIHRhZyArIFwiPlwiO1xuICAgICAgICB9XG5cbiAgICAgICAgdmFyIGF0dHJzID0gZ2V0QXR0cnMoaHRtbCk7XG4gICAgICAgIHZhciB3aGl0ZUF0dHJMaXN0ID0gd2hpdGVMaXN0W3RhZ107XG4gICAgICAgIHZhciBhdHRyc0h0bWwgPSBwYXJzZUF0dHIoYXR0cnMuaHRtbCwgZnVuY3Rpb24gKG5hbWUsIHZhbHVlKSB7XG4gICAgICAgICAgLy8gY2FsbCBgb25UYWdBdHRyKClgXG4gICAgICAgICAgdmFyIGlzV2hpdGVBdHRyID0gXy5pbmRleE9mKHdoaXRlQXR0ckxpc3QsIG5hbWUpICE9PSAtMTtcbiAgICAgICAgICB2YXIgcmV0ID0gb25UYWdBdHRyKHRhZywgbmFtZSwgdmFsdWUsIGlzV2hpdGVBdHRyKTtcbiAgICAgICAgICBpZiAoIWlzTnVsbChyZXQpKSByZXR1cm4gcmV0O1xuXG4gICAgICAgICAgaWYgKGlzV2hpdGVBdHRyKSB7XG4gICAgICAgICAgICAvLyBjYWxsIGBzYWZlQXR0clZhbHVlKClgXG4gICAgICAgICAgICB2YWx1ZSA9IHNhZmVBdHRyVmFsdWUodGFnLCBuYW1lLCB2YWx1ZSwgY3NzRmlsdGVyKTtcbiAgICAgICAgICAgIGlmICh2YWx1ZSkge1xuICAgICAgICAgICAgICByZXR1cm4gbmFtZSArICc9XCInICsgdmFsdWUgKyAnXCInO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgcmV0dXJuIG5hbWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIC8vIGNhbGwgYG9uSWdub3JlVGFnQXR0cigpYFxuICAgICAgICAgICAgdmFyIHJldCA9IG9uSWdub3JlVGFnQXR0cih0YWcsIG5hbWUsIHZhbHVlLCBpc1doaXRlQXR0cik7XG4gICAgICAgICAgICBpZiAoIWlzTnVsbChyZXQpKSByZXR1cm4gcmV0O1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG5cbiAgICAgICAgLy8gYnVpbGQgbmV3IHRhZyBodG1sXG4gICAgICAgIHZhciBodG1sID0gXCI8XCIgKyB0YWc7XG4gICAgICAgIGlmIChhdHRyc0h0bWwpIGh0bWwgKz0gXCIgXCIgKyBhdHRyc0h0bWw7XG4gICAgICAgIGlmIChhdHRycy5jbG9zaW5nKSBodG1sICs9IFwiIC9cIjtcbiAgICAgICAgaHRtbCArPSBcIj5cIjtcbiAgICAgICAgcmV0dXJuIGh0bWw7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyBjYWxsIGBvbklnbm9yZVRhZygpYFxuICAgICAgICB2YXIgcmV0ID0gb25JZ25vcmVUYWcodGFnLCBodG1sLCBpbmZvKTtcbiAgICAgICAgaWYgKCFpc051bGwocmV0KSkgcmV0dXJuIHJldDtcbiAgICAgICAgcmV0dXJuIGVzY2FwZUh0bWwoaHRtbCk7XG4gICAgICB9XG4gICAgfSxcbiAgICBlc2NhcGVIdG1sXG4gICk7XG5cbiAgLy8gaWYgZW5hYmxlIHN0cmlwSWdub3JlVGFnQm9keVxuICBpZiAoc3RyaXBJZ25vcmVUYWdCb2R5KSB7XG4gICAgcmV0SHRtbCA9IHN0cmlwSWdub3JlVGFnQm9keS5yZW1vdmUocmV0SHRtbCk7XG4gIH1cblxuICByZXR1cm4gcmV0SHRtbDtcbn07XG5cbm1vZHVsZS5leHBvcnRzID0gRmlsdGVyWFNTO1xuIiwiY29uc3QgYnVzID0gbmV3IFZ1ZSgpXG53aW5kb3cuYnVzID0gYnVzO1xubW9kdWxlLmV4cG9ydHMgPSBidXM7XG4iLCJjb25zdCB7bWVtb3J5fSA9IHJlcXVpcmUoXCJqc2ItdXRpbFwiKTtcblxuY29uc3QgYmFpZHUgPSByZXF1aXJlKFwiL3NyYy9hc3NldHMvYmFpZHUuc3ZnXCIpO1xuY29uc3QgZ29vZ2xlID0gcmVxdWlyZShcIi9zcmMvYXNzZXRzL2dvb2dsZS5zdmdcIik7XG5jb25zdCBzb3Vnb3UgPSByZXF1aXJlKFwiL3NyYy9hc3NldHMvc291Z291LnN2Z1wiKTtcbmNvbnN0IHMzNjAgPSByZXF1aXJlKFwiL3NyYy9hc3NldHMvMzYwLnN2Z1wiKVxuY29uc3QgYmluZyA9IHJlcXVpcmUoXCIvc3JjL2Fzc2V0cy9iaW5nLnN2Z1wiKVxuXG5jb25zdCBzb3UgPSBbXG4gICAge1xuICAgICAgICBuYW1lOiAn55m+5bqmJyxcbiAgICAgICAgaHJlZjogXCJodHRwczovL3d3dy5iYWlkdS5jb20vcz8maWU9dXRmLTgmd29yZD0ka2V5XCIsXG4gICAgICAgIGljb246IGJhaWR1XG4gICAgfSxcbiAgICB7XG4gICAgICAgIG5hbWU6ICfosLfmrYwnLFxuICAgICAgICBocmVmOiAnaHR0cHM6Ly93d3cuZ29vZ2xlLmNvbS9zZWFyY2g/cT0ka2V5JyxcbiAgICAgICAgaWNvbjogZ29vZ2xlXG4gICAgfSxcbiAgICB7XG4gICAgICAgIG5hbWU6ICfmkJzni5cnLFxuICAgICAgICBocmVmOiBcImh0dHBzOi8vd3d3LnNvZ291LmNvbS93ZWI/cXVlcnk9JGtleVwiLFxuICAgICAgICBpY29uOiBzb3Vnb3VcbiAgICB9LFxuICAgIHtcbiAgICAgICAgbmFtZTogJzM2MCcsXG4gICAgICAgIGhyZWY6ICdodHRwczovL3d3dy5zby5jb20vcz9pZT11dGYtOCZxPSRrZXknLFxuICAgICAgICBpY29uOiBzMzYwXG4gICAgfSxcbiAgICB7XG4gICAgICAgIG5hbWU6ICflv4XlupQnLFxuICAgICAgICBocmVmOiAnaHR0cHM6Ly9jbi5iaW5nLmNvbS9zZWFyY2g/cT0ka2V5JyxcbiAgICAgICAgaWNvbjogYmluZ1xuICAgIH1cbl1cbmxldCBkZWZhdWx0X3NvdSA9IG1lbW9yeS5nZXQoXCJzb3VcIikgfHwgc291WzBdO1xuc2V0X3NvdShkZWZhdWx0X3NvdSlcblxuZnVuY3Rpb24gc291c2VhcmNoKHRleHQpIHtcbiAgICBsb2NhdGlvbi5ocmVmID0gZGVmYXVsdF9zb3UuaHJlZi5yZXBsYWNlKC9cXCRrZXkvLCB0ZXh0KVxufVxuXG4vKipcbiAqIOiuvue9ruaQnOe0ouW8leaTjlxuICogQHBhcmFtIGl0ZW1cbiAqL1xuZnVuY3Rpb24gc2V0X3NvdShpdGVtKSB7XG4gICAgZGVmYXVsdF9zb3UgPSBpdGVtO1xuICAgIG1lbW9yeS5zZXQoXCJzb3VcIiwgaXRlbSlcbn1cblxuZXhwb3J0cy5zb3VzZWFyY2ggPSBzb3VzZWFyY2g7XG5leHBvcnRzLnNldF9zb3UgPSBzZXRfc291XG5leHBvcnRzLmRlZmF1bHRfc291ID0gZGVmYXVsdF9zb3U7XG5leHBvcnRzLnNvdSA9IHNvdTtcbiIsIi8vIFRoZSBtb2R1bGUgY2FjaGVcbnZhciBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX18gPSB7fTtcblxuLy8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbmZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG5cdHZhciBjYWNoZWRNb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdO1xuXHRpZiAoY2FjaGVkTW9kdWxlICE9PSB1bmRlZmluZWQpIHtcblx0XHRyZXR1cm4gY2FjaGVkTW9kdWxlLmV4cG9ydHM7XG5cdH1cblx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcblx0dmFyIG1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF0gPSB7XG5cdFx0Ly8gbm8gbW9kdWxlLmlkIG5lZWRlZFxuXHRcdC8vIG5vIG1vZHVsZS5sb2FkZWQgbmVlZGVkXG5cdFx0ZXhwb3J0czoge31cblx0fTtcblxuXHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cblx0X193ZWJwYWNrX21vZHVsZXNfX1ttb2R1bGVJZF0obW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG5cblx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcblx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xufVxuXG4iLCIvLyBnZXREZWZhdWx0RXhwb3J0IGZ1bmN0aW9uIGZvciBjb21wYXRpYmlsaXR5IHdpdGggbm9uLWhhcm1vbnkgbW9kdWxlc1xuX193ZWJwYWNrX3JlcXVpcmVfXy5uID0gKG1vZHVsZSkgPT4ge1xuXHR2YXIgZ2V0dGVyID0gbW9kdWxlICYmIG1vZHVsZS5fX2VzTW9kdWxlID9cblx0XHQoKSA9PiAobW9kdWxlWydkZWZhdWx0J10pIDpcblx0XHQoKSA9PiAobW9kdWxlKTtcblx0X193ZWJwYWNrX3JlcXVpcmVfXy5kKGdldHRlciwgeyBhOiBnZXR0ZXIgfSk7XG5cdHJldHVybiBnZXR0ZXI7XG59OyIsIi8vIGRlZmluZSBnZXR0ZXIgZnVuY3Rpb25zIGZvciBoYXJtb255IGV4cG9ydHNcbl9fd2VicGFja19yZXF1aXJlX18uZCA9IChleHBvcnRzLCBkZWZpbml0aW9uKSA9PiB7XG5cdGZvcih2YXIga2V5IGluIGRlZmluaXRpb24pIHtcblx0XHRpZihfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZGVmaW5pdGlvbiwga2V5KSAmJiAhX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIGtleSkpIHtcblx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBrZXksIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBkZWZpbml0aW9uW2tleV0gfSk7XG5cdFx0fVxuXHR9XG59OyIsIl9fd2VicGFja19yZXF1aXJlX18ubyA9IChvYmosIHByb3ApID0+IChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqLCBwcm9wKSkiLCIvLyBkZWZpbmUgX19lc01vZHVsZSBvbiBleHBvcnRzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLnIgPSAoZXhwb3J0cykgPT4ge1xuXHRpZih0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2wudG9TdHJpbmdUYWcpIHtcblx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgU3ltYm9sLnRvU3RyaW5nVGFnLCB7IHZhbHVlOiAnTW9kdWxlJyB9KTtcblx0fVxuXHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xufTsiLCJpbXBvcnQgXCIuL2Nzcy9pbmRleC5zY3NzXCI7XG5pbXBvcnQge2RlZmF1bHRfc291LCBzZXRfc291LCBzb3UsIHNvdXNlYXJjaH0gZnJvbSBcIi4vanMvc291c3VvXCJcbmltcG9ydCB7bWVtb3J5LCB0aHJvdHRsZX0gZnJvbSBcImpzYi11dGlsXCI7XG5pbXBvcnQge2luc3RhbGx9IGZyb20gXCIuL2pzL21lbnUuanN4XCI7XG5pbXBvcnQgYnVzIGZyb20gXCIvc3JjL2pzL2J1c1wiXG5pbXBvcnQgYXhpb3MgZnJvbSBcImF4aW9zXCI7XG5cbmxldCB0b2tlbiA9IGZhbHNlO1xuYXhpb3MuZGVmYXVsdHMuYmFzZVVSTCA9IFwiXCI7XG5pZiAobG9jYXRpb24uaG9zdG5hbWUgPT09IFwibG9jYWxob3N0XCIpIHtcbiAgICBheGlvcy5kZWZhdWx0cy5iYXNlVVJMID0gXCJodHRwczovL3dlYi5wbmcuaW5rXCJcbiAgICB0b2tlbiA9IFwiYTYzZDIxZTE5NDZjZjA3NDYwNTZjNzU1NTBhNzg3YzZcIiAvL+W8gOWPkeeOr+Wig+eahHRva2VuXG59XG53aW5kb3cuc2Nyb2xsbG9jayA9IGZhbHNlO1xuYXhpb3MuaW50ZXJjZXB0b3JzLnJlcXVlc3QudXNlKChjb25maWcpID0+IHtcbiAgICBjb25maWcuaGVhZGVyc1snQ29udGVudC1UeXBlJ10gPSBcImFwcGxpY2F0aW9uL3gtd3d3LWZvcm0tdXJsZW5jb2RlZDsgY2hhcnNldD1VVEYtOFwiO1xuICAgIGlmIChjb25maWcubWV0aG9kID09PSBcInBvc3RcIilcbiAgICAgICAgaWYgKHRva2VuKVxuICAgICAgICAgICAgaWYgKHR5cGVvZiBjb25maWcuZGF0YSA9PSBcIm9iamVjdFwiKVxuICAgICAgICAgICAgICAgIGNvbmZpZy5kYXRhWyd0b2tlbiddID0gdG9rZW5cbiAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgICBjb25maWcuZGF0YSA9IHt0b2tlbjogdG9rZW59XG4gICAgY29uZmlnLnRyYW5zZm9ybVJlcXVlc3QgPSBbXG4gICAgICAgIGZ1bmN0aW9uIChkYXRhKSB7XG4gICAgICAgICAgICBsZXQgcmV0ID0gJyc7XG4gICAgICAgICAgICBmb3IgKGxldCBpdCBpbiBkYXRhKSB7XG4gICAgICAgICAgICAgICAgLy8g5Lit5paH57yW56CBXG4gICAgICAgICAgICAgICAgaWYgKGRhdGFbaXRdICE9ICcnIHx8IGRhdGFbaXRdID09IDApIHtcbiAgICAgICAgICAgICAgICAgICAgLy/lgLzkuLrnqbrnmoTlhajpg6jliZTpmaRcbiAgICAgICAgICAgICAgICAgICAgcmV0ICs9IGVuY29kZVVSSUNvbXBvbmVudChpdCkgKyAnPScgKyBlbmNvZGVVUklDb21wb25lbnQoZGF0YVtpdF0pICsgJyYnO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiByZXQ7XG4gICAgICAgIH0sXG4gICAgXTtcbiAgICByZXR1cm4gY29uZmlnXG59KVxuaW5zdGFsbChWdWUpO1xuY29uc3Qgdm0gPSBuZXcgVnVlKHtcbiAgICBlbDogJyNyb290JyxcbiAgICBkYXRhKCkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgc2VhcmNoUHJldmlldzogZmFsc2UsXG4gICAgICAgICAgICBzZWFyY2hMaXN0OiBbXSxcbiAgICAgICAgICAgIGhpc3Rvcnk6IG1lbW9yeS5nZXQoXCJoaXN0b3J5XCIpIHx8IFtdLFxuICAgICAgICAgICAgc2VhcmNoOiAnJyxcbiAgICAgICAgICAgIGRyYXdlcjogZmFsc2UsXG4gICAgICAgICAgICBzb3VTdGF0dXM6IGZhbHNlLFxuICAgICAgICAgICAgc291OiBzb3UsXG4gICAgICAgICAgICBkZWZhdWx0X3NvdSxcbiAgICAgICAgICAgIHRvdWNoOiB7XG4gICAgICAgICAgICAgICAgeTogMCxcbiAgICAgICAgICAgICAgICB0aW1lOiAwXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgbGlzdDogbWVtb3J5LmdldChcImxpc3RcIikgfHwgW10sXG4gICAgICAgICAgICBsaXN0czogW10sXG4gICAgICAgICAgICBtb3VzZVJpZ2h0OiB7XG4gICAgICAgICAgICAgICAgeDogMCxcbiAgICAgICAgICAgICAgICB5OiAwLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHRhYmJhcjogW11cbiAgICAgICAgfVxuICAgIH0sXG4gICAgbWV0aG9kczoge1xuICAgICAgICBzZWFyY2hfZ28oKSB7XG4gICAgICAgICAgICBpZiAodGhpcy5DSEVDS19VUkwodGhpcy5zZWFyY2gpKSB7XG4gICAgICAgICAgICAgICAgaWYgKC9eaHR0cC8udGVzdCh0aGlzLnNlYXJjaCkpIHtcbiAgICAgICAgICAgICAgICAgICAgbG9jYXRpb24uaHJlZiA9IHRoaXMuc2VhcmNoO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGxvY2F0aW9uLmhyZWYgPSBcIi8vXCIgKyB0aGlzLnNlYXJjaDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgc291c2VhcmNoKHRoaXMuc2VhcmNoKVxuICAgICAgICB9LFxuICAgICAgICAvKipcbiAgICAgICAgICog5q2j5YiZ6KGo6L6+5byP5Yik5a6aVXJsXG4gICAgICAgICAqIEBwYXJhbSB1cmxcbiAgICAgICAgICogQHJldHVybnMge0Jvb2xlYW59XG4gICAgICAgICAqL1xuICAgICAgICBDSEVDS19VUkwodXJsKSB7XG4gICAgICAgICAgICAvL3VybD0g5Y2P6K6uOi8vKGZ0cOeahOeZu+W9leS/oeaBrylbSVB85Z+f5ZCNXSg656uv5Y+j5Y+3KSgv5oiWP+ivt+axguWPguaVsClcbiAgICAgICAgICAgIHZhciBzdHJSZWdleCA9ICdeKChodHRwc3xodHRwfGZ0cCk6Ly8pPycvLyhodHRwc+aIlmh0dHDmiJZmdHApOi8vIOWPr+acieWPr+aXoFxuICAgICAgICAgICAgICAgICsgJygoW1xcXFx3XyF+KlxcJygpXFxcXC4mPSskJS1dKzogKT9bXFxcXHdfIX4qXFwnKClcXFxcLiY9KyQlLV0rQCk/JyAvL2Z0cOeahHVzZXJAICDlj6/mnInlj6/ml6BcbiAgICAgICAgICAgICAgICArICcoKFswLTldezEsM31cXFxcLil7M31bMC05XXsxLDN9JyAvLyBJUOW9ouW8j+eahFVSTC0gM+S9jeaVsOWtly4z5L2N5pWw5a2XLjPkvY3mlbDlrZcuM+S9jeaVsOWtl1xuICAgICAgICAgICAgICAgICsgJ3wnIC8vIOWFgeiuuElQ5ZKMRE9NQUlO77yI5Z+f5ZCN77yJXG4gICAgICAgICAgICAgICAgKyAnKGxvY2FsaG9zdCl8J1x0Ly/ljLnphY1sb2NhbGhvc3RcbiAgICAgICAgICAgICAgICArICcoW1xcXFx3XyF+KlxcJygpLV0rXFxcXC4pKicgLy8g5Z+f5ZCNLSDoh7PlsJHkuIDkuKpb6Iux5paH5oiW5pWw5a2XXyF+KlxcJygpLV3liqDkuIouXG4gICAgICAgICAgICAgICAgKyAnXFxcXHcrXFxcXC4nIC8vIOS4gOe6p+Wfn+WQjSAt6Iux5paH5oiW5pWw5a2XICDliqDkuIouXG4gICAgICAgICAgICAgICAgKyAnW2EtekEtWl17MSw2fSknIC8vIOmhtue6p+Wfn+WQjS0gMS025L2N6Iux5paHXG4gICAgICAgICAgICAgICAgKyAnKDpbMC05XXsxLDV9KT8nIC8vIOerr+WPoy0gOjgwICwxLTXkvY3mlbDlrZdcbiAgICAgICAgICAgICAgICArICcoKC8/KXwnIC8vIHVybOaXoOWPguaVsOe7k+WwviAtIOaWnOadhuaIlui/meayoeaciVxuICAgICAgICAgICAgICAgICsgJygvW1xcXFx3XyF+KlxcJygpXFxcXC47PzpAJj0rJCwlIy1dKykrLz8pJCc7Ly/or7fmsYLlj4LmlbDnu5PlsL4tIOiLseaWh+aIluaVsOWtl+WSjFtd5YaF55qE5ZCE56eN5a2X56ymXG5cbiAgICAgICAgICAgIHZhciBzdHJSZWdleDEgPSAnXig/PV4uezMsMjU1fSQpKChodHRwfGh0dHBzfGZ0cCk/OlxcL1xcLyk/KHd3d1xcLik/W2EtekEtWjAtOV1bLWEtekEtWjAtOV17MCw2Mn0oXFwuW2EtekEtWjAtOV1bLWEtekEtWjAtOV17MCw2Mn0pKyg6XFxkKykqKFxcLyk/KD86XFwvKC4rKVxcLz8kKT8oXFwvXFx3K1xcLlxcdyspKihbXFw/Jl1cXHcrPVxcdyp8W1xcdTRlMDAtXFx1OWZhNV0rKSokJztcbiAgICAgICAgICAgIHZhciByZSA9IG5ldyBSZWdFeHAoc3RyUmVnZXgsICdpJyk7Ly9p5LiN5Yy65YiG5aSn5bCP5YaZXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhyZSk7XG4gICAgICAgICAgICAvL+WwhnVybOWBmnVyaei9rOeggeWQjuWGjeWMuemFje+8jOino+mZpOivt+axguWPguaVsOS4reeahOS4reaWh+WSjOepuuWtl+espuW9seWTjVxuICAgICAgICAgICAgaWYgKHJlLnRlc3QoZW5jb2RlVVJJKHVybCkpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuICh0cnVlKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIChmYWxzZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIHRvKHt1cmx9KSB7XG4gICAgICAgICAgICBjb25zdCBpbmRleCA9IHRoaXMubGlzdHMuZmluZEluZGV4KGVsID0+IGVsLnVybCA9PT0gdXJsKS8v5p+l5om+5pys5Zyw55qE5L+h5oGvXG4gICAgICAgICAgICBjb25zdCBpbmZvID0gdGhpcy5saXN0c1tpbmRleF07XG4gICAgICAgICAgICBjb25zdCBpbmRleDEgPSB0aGlzLmhpc3RvcnkuZmluZEluZGV4KGl0ID0+IGl0LnVybCA9PT0gdXJsKTtcbiAgICAgICAgICAgIGlmIChpbmRleDEgPiAtMSkgey8v5aaC5p6c5Y6G5Y+y6K6w5b2V5a2Y5Zyo77yM5YiZ5Yig6ZmkXG4gICAgICAgICAgICAgICAgdGhpcy5oaXN0b3J5LnNwbGljZShpbmRleDEsIDEpXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoaW5kZXggPiAtMSkge1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLmhpc3RvcnkubGVuZ3RoID09PSA4KSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuaGlzdG9yeS5wb3AoKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgdGhpcy5oaXN0b3J5LnVuc2hpZnQoe1xuICAgICAgICAgICAgICAgICAgICB1cmw6IHVybCxcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU6IGluZm8udGl0bGUsXG4gICAgICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBpbmZvLmRlc2NyaXB0aW9uXG4gICAgICAgICAgICAgICAgfSkvL+WIoOmZpOWQjuWQkeaVsOe7hOacgOW8gOWni+aPkuWFpeaVsOaNrlxuXG4gICAgICAgICAgICAgICAgbWVtb3J5LnNldChcImhpc3RvcnlcIiwgdGhpcy5oaXN0b3J5LnNsaWNlKDAsIDgpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IHRlbXB3aW5kb3cgPSB3aW5kb3cub3BlbigpO1xuICAgICAgICAgICAgdGVtcHdpbmRvdy5sb2NhdGlvbiA9IHVybDtcbiAgICAgICAgfVxuICAgICAgICAsXG4gICAgICAgIGdldEljb24oaXRlbSkge1xuICAgICAgICAgICAgaWYgKGl0ZW0udXJsKSB7XG4gICAgICAgICAgICAgICAgbGV0IHN0ciA9IFwiXCJcbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICBzdHIgPSBcImh0dHBzOi8vZmF2aWNvbi5yc3MuaW5rL3YxL1wiICsgYnRvYShlbmNvZGVVUkkoaXRlbS51cmwpKTtcbiAgICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhpdGVtKVxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhpdGVtLnVybClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIHN0clxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgICxcbiAgICAgICAgbG9naW4oKSB7XG4gICAgICAgICAgICBsb2NhdGlvbi5ocmVmID0gJy9pbmRleC5waHA/Yz1sb2dpbidcbiAgICAgICAgfSxcbiAgICAgICAgbW91c2VNZW51KGV2ZW50KSB7XG4gICAgICAgICAgICBjb25zdCB7Y2xpZW50WCwgY2xpZW50WX0gPSBldmVudDtcbiAgICAgICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KClcbiAgICAgICAgfVxuICAgICAgICAsXG4gICAgICAgIHNldHNvdShpdGVtKSB7XG4gICAgICAgICAgICBzZXRfc291KGl0ZW0pO1xuICAgICAgICAgICAgdGhpcy5kZWZhdWx0X3NvdSA9IGl0ZW07XG4gICAgICAgICAgICB0aGlzLnNvdVN0YXR1cyA9IGZhbHNlXG4gICAgICAgIH1cbiAgICAgICAgLFxuICAgICAgICBhc3luYyBmZXRjaERhdGEoKSB7XG4gICAgICAgICAgICBsZXQgZGF0YSA9IChhd2FpdCBheGlvcy5nZXQoXCIvaW5kZXgucGhwP2M9YXBpJm1ldGhvZD1jYXRlZ29yeV9saXN0JmxpbWl0PTk5OTk5OVwiKSkuZGF0YVxuICAgICAgICAgICAgbGV0IGxpc3QgPSAoYXdhaXQgYXhpb3MucG9zdCgnL2luZGV4LnBocD9jPWFwaSZtZXRob2Q9bGlua19saXN0JmxpbWl0PTk5OTk5OScpKS5kYXRhXG4gICAgICAgICAgICB2bS5saXN0cyA9IGxpc3QuZGF0YVxuICAgICAgICAgICAgbWVtb3J5LnNldChcImxpc3RzXCIsIGxpc3QuZGF0YSlcbiAgICAgICAgICAgIC8v5LiL6Z2i5piv5bCG55uu5b2V5ZKM5YiX6KGo5ZCI5bm244CC5bCG5YiX6KGo5Yqg5YWl55uu5b2VY2hpbGRyZW7ph4xcbiAgICAgICAgICAgIGxldCBtZW51ID0gZGF0YS5kYXRhO1xuICAgICAgICAgICAgbGlzdC5kYXRhLmZvckVhY2goKGl0ZW0pID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCB7Y2F0ZWdvcnlfbmFtZTogbmFtZX0gPSBpdGVtO1xuICAgICAgICAgICAgICAgIGNvbnN0IGluZGV4ID0gbWVudS5maW5kSW5kZXgoZWwgPT4gZWwubmFtZSA9PT0gbmFtZSk7XG4gICAgICAgICAgICAgICAgaWYgKCFtZW51W2luZGV4XS5jaGlsZHJlbikge1xuICAgICAgICAgICAgICAgICAgICBtZW51W2luZGV4XS5jaGlsZHJlbiA9IFtdO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBtZW51W2luZGV4XS5jaGlsZHJlbi5wdXNoKGl0ZW0pXG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgdm0ubGlzdCA9IG1lbnVcbiAgICAgICAgICAgIG1lbW9yeS5zZXQoXCJsaXN0XCIsIG1lbnUpXG4gICAgICAgICAgICBhd2FpdCB0aGlzLiRuZXh0VGljayhfID0+IHtcbiAgICAgICAgICAgICAgICBzdW1pY29uKClcbiAgICAgICAgICAgIH0pXG4gICAgICAgIH1cbiAgICAgICAgLFxuICAgICAgICBzZWFyY2hQcmV2aWV3UmVuZGVyKCkge1xuICAgICAgICAgICAgY29uc3QgdmFsID0gdGhpcy5zZWFyY2hcbiAgICAgICAgICAgIC8vIHRoaXMuc2VhcmNoUHJldmlldyA9IHZhbC5zcGxpdChcIlwiKS5sZW5ndGggPiAwO1xuICAgICAgICAgICAgY29uc3QgbGlzdCA9IG1lbW9yeS5nZXQoXCJsaXN0c1wiKSB8fCBbXVxuICAgICAgICAgICAgbGV0IHRtcCA9IFtdO1xuICAgICAgICAgICAgbGlzdC5mb3JFYWNoKGVsID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoZWwudGl0bGUudG9Mb3dlckNhc2UoKS5pbmRleE9mKHRoaXMuc2VhcmNoLnRvTG93ZXJDYXNlKCkpICE9PSAtMSkge1xuICAgICAgICAgICAgICAgICAgICB0bXAucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogZWwudGl0bGUucmVwbGFjZShSZWdFeHAodGhpcy5zZWFyY2gsIFwiaWdcIiksIGA8Yj4ke3RoaXMuc2VhcmNofTwvYj5gKSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHVybDogZWwudXJsLFxuICAgICAgICAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IGVsLmRlc2NyaXB0aW9uXG4gICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIHRoaXMuc2VhcmNoUHJldmlldyA9IEJvb2xlYW4odG1wLmxlbmd0aCA+IDApXG4gICAgICAgICAgICAvLyBpZiAoIXRoaXMuc2VhcmNoUHJldmlldykge1xuICAgICAgICAgICAgLy8gICAgICQuYWpheCh7XG4gICAgICAgICAgICAvLyAgICAgICAgIHVybDogJ2h0dHBzOi8vd3d3LmJhaWR1LmNvbS9zdWdyZWM/cHJlPTEmcD0zJmllPXV0Zi04Jmpzb249MSZwcm9kPXBjJyxcbiAgICAgICAgICAgIC8vICAgICAgICAgZGF0YVR5cGU6ICdqc29ucCcsXG4gICAgICAgICAgICAvLyAgICAgICAgIGpzb25wOiAnY2InLFxuICAgICAgICAgICAgLy8gICAgICAgICBkYXRhOiB7d2Q6IHRoaXMuc2VhcmNofSxcbiAgICAgICAgICAgIC8vICAgICAgICAgc3VjY2VzczogZnVuY3Rpb24gKG1zZykge1xuICAgICAgICAgICAgLy8gICAgICAgICAgICAgY29uc29sZS5sb2cobXNnLmcpXG4gICAgICAgICAgICAvLyAgICAgICAgIH1cbiAgICAgICAgICAgIC8vICAgICB9KVxuICAgICAgICAgICAgLy8gfVxuICAgICAgICAgICAgdGhpcy5zZWFyY2hMaXN0ID0gdG1wLnNsaWNlKDAsIDEwKVxuICAgICAgICAgICAgaWYgKHRoaXMuZHJhd2VyKVxuICAgICAgICAgICAgICAgIHRoaXMuZHJhd2VyID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgLFxuICAgICAgICBjbG9zZVByZXZpZXcoKSB7XG4gICAgICAgICAgICBzZXRUaW1lb3V0KF8gPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuc2VhcmNoUHJldmlldyA9IGZhbHNlXG4gICAgICAgICAgICB9LCAxMDApXG4gICAgICAgIH1cbiAgICB9LFxuICAgIGFzeW5jIG1vdW50ZWQoKSB7XG4gICAgICAgIGF3YWl0IHRoaXMuZmV0Y2hEYXRhKClcbiAgICAgICAgYnVzLiRvbihcImRlbGhpc3RvcnlcIiwgKGUpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGluZGV4ID0gdGhpcy5oaXN0b3J5LmZpbmRJbmRleChpdCA9PiBpdC51cmwgPT09IGUpO1xuICAgICAgICAgICAgdGhpcy5oaXN0b3J5LnNwbGljZShpbmRleCwgMSlcbiAgICAgICAgICAgIG1lbW9yeS5zZXQoXCJoaXN0b3J5XCIsIHRoaXMuaGlzdG9yeSlcbiAgICAgICAgfSlcbiAgICB9XG4gICAgLFxuICAgIHdhdGNoOiB7XG4gICAgICAgIHNlYXJjaCh2YWwpIHtcbiAgICAgICAgICAgIHRoaXMuc2VhcmNoUHJldmlld1JlbmRlcigpXG4gICAgICAgIH1cbiAgICAgICAgLFxuICAgICAgICBkcmF3ZXIodmFsKSB7XG4gICAgICAgICAgICBpZiAodmFsKVxuICAgICAgICAgICAgICAgIHZtLnNlYXJjaFByZXZpZXcgPSBmYWxzZVxuICAgICAgICB9XG4gICAgfVxufSlcbi8v55uR5ZCs6byg5qCH5rua5YqoXG53aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcIndoZWVsXCIsIChldmVudCkgPT4ge1xuICAgIGlmICh3aW5kb3cuc2Nyb2xsbG9jaykgcmV0dXJuO1xuICAgIGxldCBmYW5neGlhbmcgPSBCb29sZWFuKGV2ZW50LmRlbHRhWSA+IDApO1xuICAgIGNvbnN0IGRyYXdlciA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIuZHJhd2VyLW1haW5cIik7XG4gICAgaWYgKGZhbmd4aWFuZykge1xuICAgICAgICBpZiAoIXZtLmRyYXdlcilcbiAgICAgICAgICAgIHNldFRpbWVvdXQoXyA9PiB7XG4gICAgICAgICAgICAgICAgZHJhd2VyLnN0eWxlLm92ZXJmbG93WSA9IFwic2Nyb2xsXCJcbiAgICAgICAgICAgIH0sIDIwMClcbiAgICAgICAgdm0uZHJhd2VyID0gdHJ1ZTtcbiAgICB9IGVsc2Uge1xuICAgICAgICBpZiAoZHJhd2VyLnNjcm9sbFRvcCAhPT0gMCkgcmV0dXJuO1xuICAgICAgICB2bS5kcmF3ZXIgPSBmYWxzZTtcbiAgICAgICAgZHJhd2VyLnN0eWxlLm92ZXJmbG93WSA9IFwiaGlkZGVuXCJcbiAgICB9XG59KVxuZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIi5kcmF3ZXItbWFpblwiKS5hZGRFdmVudExpc3RlbmVyKCd0b3VjaG1vdmUnLCBmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcbn0sIHtwYXNzaXZlOiBmYWxzZX0pXG5cbi8v55uR5ZCs6Z2i6Kem5pG45ruR5Yqo5LqL5Lu2XG5kb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI3Jvb3RcIikuYWRkRXZlbnRMaXN0ZW5lcihcInRvdWNoc3RhcnRcIiwgZnVuY3Rpb24gKGV2ZW50KSB7XG4gICAgaWYgKHNjcm9sbGxvY2spIHJldHVyblxuICAgIGxldCB5ID0gZXZlbnQudG91Y2hlc1swXS5jbGllbnRZO1xuICAgIHZtLnRvdWNoID0ge1xuICAgICAgICB5OiB5LFxuICAgICAgICB0aW1lOiBuZXcgRGF0ZSgpLmdldFRpbWUoKVxuICAgIH1cbn0pXG4vL+mhtemdoua7keWKqOe7k+adn+S6i+S7tlxuZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiNyb290XCIpLmFkZEV2ZW50TGlzdGVuZXIoXCJ0b3VjaGVuZFwiLCBmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICBpZiAoc2Nyb2xsbG9jaykgcmV0dXJuXG4gICAgbGV0IHkgPSBldmVudC5jaGFuZ2VkVG91Y2hlc1swXS5jbGllbnRZO1xuICAgIGxldCB0ID0gbmV3IERhdGUoKS5nZXRUaW1lKCk7XG4gICAgaWYgKHkgPT09IHZtLnRvdWNoLnkpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBpZiAodCAtIDMwMCA8IHZtLnRvdWNoLnRpbWUpIHtcbiAgICAgICAgaWYgKHkgKyAxMDAgPCB2bS50b3VjaC55KSB7XG4gICAgICAgICAgICB2bS5kcmF3ZXIgPSB0cnVlO1xuICAgICAgICB9IGVsc2UgaWYgKHkgLSAxMDAgPiB2bS50b3VjaC55KSB7XG4gICAgICAgICAgICBpZiAoZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIi5kcmF3ZXItbWFpblwiKS5zY3JvbGxUb3AgIT09IDApIHJldHVybjtcbiAgICAgICAgICAgIHZtLmRyYXdlciA9IGZhbHNlO1xuICAgICAgICB9XG4gICAgfVxufSlcbi8v6Zi75q2i5YaS5rOhXG5kb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI3Jvb3RcIikuYWRkRXZlbnRMaXN0ZW5lcihcInRvdWNobW92ZVwiLCBmdW5jdGlvbiAoZSkge1xuICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXG59LCB7cGFzc2l2ZTogZmFsc2V9KVxuXG5mdW5jdGlvbiBzdW1pY29uKCkge1xuICAgIGxldCB3ID0gb3V0ZXJXaWR0aCAtIDYwO1xuICAgIGxldCBhdXRvID0gTWF0aC5mbG9vcih3IC8gMTAwKTtcbiAgICBsZXQgbCA9IHcgLyBhdXRvXG4gICAgaWYgKG91dGVyV2lkdGggPiA1MDEpIHtcbiAgICAgICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChcIi5kcmVhZXItbGlzdFwiKS5mb3JFYWNoKGVsID0+IHtcbiAgICAgICAgICAgIGVsLnN0eWxlLndpZHRoID0gbCArICdweCc7XG4gICAgICAgIH0pXG4gICAgfSBlbHNlIHtcbiAgICAgICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChcIi5kcmVhZXItbGlzdFwiKS5mb3JFYWNoKGVsID0+IHtcbiAgICAgICAgICAgIGVsLnN0eWxlLndpZHRoID0gXCJcIjtcbiAgICAgICAgfSlcbiAgICB9XG59XG5cbnN1bWljb24oKTtcbndpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwicmVzaXplXCIsIHRocm90dGxlKHN1bWljb24sIDIwMCkpXG5cbmJ1cy4kb24oXCJjY1wiLCBmdW5jdGlvbiAoKSB7XG4gICAgLy/miZPlvIDmir3lsYlcbiAgICB2bS5kcmF3ZXIgPSB0cnVlXG59KVxuXG53aW5kb3cuYmFzZTY0VG9CbG9iID0gKHVybERhdGEsIHR5cGUpID0+IHtcbiAgICBsZXQgYXJyID0gdXJsRGF0YS5zcGxpdCgnLCcpO1xuICAgIGxldCBtaW1lID0gYXJyWzBdLm1hdGNoKC86KC4qPyk7LylbMV0gfHwgdHlwZTtcbiAgICBsZXQgYnl0ZXMgPSB3aW5kb3cuYXRvYihhcnJbMV0pO1xuICAgIGxldCBhYiA9IG5ldyBBcnJheUJ1ZmZlcihieXRlcy5sZW5ndGgpO1xuICAgIGxldCBpYSA9IG5ldyBVaW50OEFycmF5KGFiKTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGJ5dGVzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGlhW2ldID0gYnl0ZXMuY2hhckNvZGVBdChpKTtcbiAgICB9XG4gICAgcmV0dXJuIG5ldyBCbG9iKFthYl0sIHtcbiAgICAgICAgdHlwZTogbWltZVxuICAgIH0pO1xufVxubGV0IGJhc2UgPSBtZW1vcnkuZ2V0KFwiYmdcIik7XG5pZiAoYmFzZSkge1xuICAgIGlmIChiYXNlLmxlbmd0aCA8IDEwMCkge1xuICAgICAgICBtZW1vcnkuZGVsKCdiZycpXG4gICAgfSBlbHNlIHtcbiAgICAgICAgYmFzZTY0VG9CbG9iKGJhc2UpXG4gICAgICAgIGNvbnN0IGJ6ID0gVVJMLmNyZWF0ZU9iamVjdFVSTChiYXNlNjRUb0Jsb2IoYmFzZSkpXG4gICAgICAgIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjcm9vdFwiKS5zdHlsZS5iYWNrZ3JvdW5kID0gYHVybCgke2J6fSkgbm8tcmVwZWF0IGNlbnRlci9jb3ZlcmBcbiAgICB9XG59XG4iXSwibmFtZXMiOlsiYnVzIiwicmVxdWlyZSIsImF4aW9zIiwibWVtb3J5IiwiZXhwb3J0cyIsImluc3RhbGwiLCJWdWUiLCJjb21wb25lbnQiLCJ0ZW1wbGF0ZSIsIm1ldGhvZHMiLCJzdWJtaXQiLCJ0eXBlIiwiYWRkSW5mbyIsInVybCIsIiRtZXNzYWdlIiwiZXJyb3IiLCJ0aXRsZSIsImRhdGEiLCJpc2VkaXQiLCJwcm9wZXJ0eSIsInBvc3QiLCJ0aGVuIiwiZSIsImNvZGUiLCJzdWNjZXNzIiwic2V0VGltZW91dCIsIl8iLCJsb2NhdGlvbiIsInJlbG9hZCIsImRpYWxvZ1Zpc2libGUiLCJzdW13aWR0aCIsIm91dGVyV2lkdGgiLCJvcHRpb24iLCJ0bXAiLCJ3ZWlnaHQiLCJmaWQiLCJ1cmxfc3RhbmRieSIsImRlc2NyaXB0aW9uIiwid2F0Y2giLCJ3aW5kb3ciLCJzY3JvbGxsb2NrIiwiSlNPTiIsInBhcnNlIiwic3RyaW5naWZ5IiwibW91bnRlZCIsIiRvbiIsImdldCIsIiRuZXh0VGljayIsIm1vdXNlUmlnaHQiLCJ4IiwieSIsInNob3ciLCJpbmZvIiwiY3R5cGUiLCJlbGVtZW50IiwicHJvcHMiLCJhZGRtZW51IiwiJGVtaXQiLCJkb3duYmciLCJiYXNlNjRUb0Jsb2IiLCJhIiwiZG9jdW1lbnQiLCJjcmVhdGVFbGVtZW50IiwiaHJlZiIsIlVSTCIsImNyZWF0ZU9iamVjdFVSTCIsImRvd25sb2FkIiwiY2xpY2siLCJ1cGRhdGVtZW51IiwibGlzdCIsImluZGV4IiwiZmluZEluZGV4IiwiaWQiLCJhZGRsaW5rIiwiZGVsaGlzdG9yeSIsInN3aXB0QmciLCJGaWxlUmVhZGVyIiwib25sb2FkIiwiZXIiLCJiYXNlIiwicmVzdWx0IiwibGVuZ3RoIiwiJG5vdGlmeSIsIm1lc3NhZ2UiLCJzZXQiLCJmZXRjaCIsImRlZmF1bHRzIiwiYmFzZVVSTCIsImVsbCIsImJsb2IiLCJjYyIsInJlYWRBc0RhdGFVUkwiLCJhYyIsInF1ZXJ5U2VsZWN0b3IiLCJzdHlsZSIsImJhY2tncm91bmQiLCJkZWxtZW51IiwiJGNvbmZpcm0iLCJlbCIsInBhcmVudE5vZGUiLCJyZW1vdmUiLCJkZWxsaW5rIiwibGlzdHMiLCJzZXR0aW5nIiwidXBkYXRlbGluayIsImNhbnNob3ciLCJCb29sZWFuIiwiaW5kZXhPZiIsImFkZEV2ZW50TGlzdGVuZXIiLCJldmVudCIsInN0b3BQcm9wYWdhdGlvbiIsInByZXZlbnREZWZhdWx0IiwidG91Y2giLCJpc2Rvd24iLCJ0aW1lIiwiRGF0ZSIsImdldFRpbWUiLCJjaGFuZ2VkVG91Y2hlcyIsImNsaWVudFgiLCJjbGllbnRZIiwidCIsInRhcmdldCIsImF0dHJpYnV0ZXMiLCJ2YWx1ZSIsImNkYXRhIiwiY2xlYXJUaW1lb3V0IiwiYnV0dG9uIiwidG9FbGVtZW50IiwibmFtZSIsImZvbnRfaWNvbiIsImFyciIsImZvckVhY2giLCJwdXNoIiwiaXRlbSJdLCJzb3VyY2VSb290IjoiIn0=