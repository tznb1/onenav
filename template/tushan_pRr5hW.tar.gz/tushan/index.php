<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta content="<?php echo $site['keywords']; ?>" name="keywords">
    <meta content="<?php echo $site['description']; ?>" name="description">
    <meta content="IE=edge" http-equiv="X-UA-Compatible">
    <meta content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no" name="viewport">
    <meta content="width=device-width,initial-scale=1" name="viewport">
    <link href="<?php echo $Theme?>/favicon.ico" rel="icon">
    <title><?php echo $site['Title']; ?></title>
    <script> var user = '<?php echo $u?>',ICP = '<?php echo $ICP?>',templates = '<?php echo $Theme?>';  </script>
    <script defer="defer" src="<?php echo $Theme?>/js/chunk-vendors.04831ac6.js"></script>
    <script defer="defer" src="<?php echo $Theme?>/js/app.a4ca89e2.js"></script>
    <link href="<?php echo $Theme?>/css/chunk-vendors.37bab8c1.css" rel="stylesheet">
    <link href="<?php echo $Theme?>/css/app.95df5ac9.css" rel="stylesheet">
</head>

<body>
    <div id="app"></div>
</body>

</html>