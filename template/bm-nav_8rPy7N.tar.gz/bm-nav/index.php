<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <meta name="keywords" content="<?php echo $site['keywords']?>"/>
    <meta name="description" content="<?php echo $site['description']?>"/>
    <title><?php echo $site['Title'];?></title>
    
<?php require ('const.php');?>
    <link rel="stylesheet" href="<?php echo $libs?>/Font-awesome/4.7.0/css/font-awesome.css">
    <link rel="stylesheet" href="<?php echo $libs?>/Layui/v2.6.8/css/layui-icon.css">
    <script type="module" crossorigin src="<?php echo $Theme?>/assets/index.js?v=3.4.0.221018"></script>
    <link rel="stylesheet" href="<?php echo $Theme?>/assets/index.css?v=3.4.0.221018">
    <?php echo $site['custom_header']; ?>
</head>
<body>
<div id="app"></div>
</body>
<footer>
<?php echo $site['custom_footer']; ?>
<br />Powered by
<a target="_blank" href="https://gitee.com/tznb/OneNav" title="OneNav Extend" rel="nofollow">OneNav Extend</a>
<?php if($ICP != ''){echo '<a href="https://beian.miit.gov.cn" target="_blank">'.$ICP.'</a>';} ?>
<?php echo $Ofooter; ?>
</footer>
<?php echo $style; //隐藏登录入口?>
</html>
<!--主题来源:故时旅人(robin901118),适配者:落幕(lm21)-->
