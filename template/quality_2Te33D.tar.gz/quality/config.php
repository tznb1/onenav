<?php
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    Writeconfig($config.'hitokoto',intval($_POST['hitokoto']));
    Writeconfig($config.'hefeng',intval($_POST['hefeng']));
    Writeconfig($config.'search',intval($_POST['search']));
    Writeconfig($config.'title',$_POST['title']);
    Writeconfig($config.'fad',$_POST['fad']);//滚动的文字广告
    Writeconfig($config.'txtad',$_POST['txtad']);//文字广告
    Writeconfig($config.'ads_w',$_POST['ads_w']);//图片广告
    Writeconfig($config.'ad_slider',$_POST['ad_slider']);//幻灯片广告 nav-link
    Writeconfig($config.'nav-link',$_POST['nav-link']);//顶部链接
    Writeconfig($config.'backgroundURL',$_POST['backgroundURL']);//背景图
    Writeconfig($config.'icon',$_POST['icon']);//图标位置
    Writeconfig($config.'links-lists',$_POST['links-lists']);//链接列表显示样式
    Writeconfig($config.'nav-bar',$_POST['nav-bar']);//导航条开关
    Writeconfig($config.'dblclick',$_POST['dblclick']);//双击事件
    
    msg(0,"修改成功");
}

?>
 
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <title>主题DIY</title>
  <link rel='stylesheet' href='<?php echo $libs?>/Layui/v2.6.8/css/layui.css'>
  <style>    
    .layui-form-item {
        margin-bottom: 10px;
        height: 38px;
    }
  </style>
</head>
<body>
<div>
<!-- 内容主体区域 -->
<div class="layui-row" style = "margin-top:18px;">
	<div class="layui-container">
    <div class="layui-col-lg6 layui-col-md-offset3">
    <form class="layui-form">
  <div class="layui-form-item">
    <input id="hitokoto-input" type="hidden" value="<?php echo getconfig($config.'hitokoto','1');?>">
    <label class="layui-form-label">一言</label>
    <div class="layui-input-inline">
      <select lay-verify="required"  id="hitokoto" name="hitokoto" lay-search>
        <option value="0">不显示</option>
        <option value="1">显示</option>
      </select>
    </div>
    <div class="layui-form-mid layui-word-aux">一言在线API</div>
  </div>
  <div class="layui-form-item">
    <input id="hefeng-input" type="hidden" value="<?php echo getconfig($config.'hefeng','1');?>">
    <label class="layui-form-label">天气</label>
    <div class="layui-input-inline">
      <select lay-verify="required"  id="hefeng" name="hefeng" lay-search>
        <option value="0">不显示</option>
        <option value="1">显示</option>
      </select>
    </div>
    <div class="layui-form-mid layui-word-aux">和风天气在线API</div>
  </div>
  <div class="layui-form-item">
    <input id="search-input" type="hidden" value="<?php echo getconfig($config.'search','1');?>">
    <label class="layui-form-label">本地搜索</label>
    <div class="layui-input-inline">
      <select lay-verify="required"  id="search" name="search" lay-search>
        <option value="0">关闭</option>
        <option value="1">开启</option>
      </select>
    </div>
    <div class="layui-form-mid layui-word-aux">输入时搜索本地书签</div>
  </div>
  <div class="layui-form-item">
    <input id="nav-bar-input" type="hidden" value="<?php echo getconfig($config.'nav-bar','1');?>">
    <label class="layui-form-label">导航条</label>
    <div class="layui-input-inline">
      <select lay-verify="required"  id="nav-bar" name="nav-bar" lay-search>
        <option value="0">关闭</option>
        <option value="1">开启</option>
      </select>
    </div>
    <div class="layui-form-mid layui-word-aux">导航条开关</div>
  </div>
  
  <div class="layui-form-item">
    <input id="dblclick-input" type="hidden" value="<?php echo getconfig($config.'dblclick','top');?>">
    <label class="layui-form-label">双击事件</label>
    <div class="layui-input-inline">
      <select lay-verify="required"  id="dblclick" name="dblclick" lay-search>
        <option value="0">无</option>
        <option value="top">到顶部</option>
        <option value="search">到搜索框</option>
      </select>
    </div>
    <div class="layui-form-mid layui-word-aux">双击空白处时响应的动作</div>
  </div>
  
  <div class="layui-form-item">
    <input id="icon-input" type="hidden" value="<?php echo getconfig($config.'icon','right_up');?>">
    <label class="layui-form-label">抽屉位置</label>
    <div class="layui-input-inline">
      <select lay-verify="required"  id="icon" name="icon" lay-search>
        <option value="left_up">左上角</option>
        <option value="right_up">右上角</option>
        <option value="right_down">右下角</option>
      </select>
    </div>
    <div class="layui-form-mid layui-word-aux">PC端分类抽屉图标的位置</div>
  </div>
  <div class="layui-form-item">
    <input id="links-lists-input" type="hidden" value="<?php echo getconfig($config.'links-lists','all');?>">
    <label class="layui-form-label">链接列表</label>
    <div class="layui-input-inline">
      <select lay-verify="required"  id="links-lists" name="links-lists" lay-search>
        <option value="all">全部</option>
        <option value="fix-2">固定2排</option>
        <option value="fix-3">固定3排</option>
        <option value="fix-4">固定4排</option>
        <option value="fix-5">固定5排</option>
        <option value="fix-6">固定6排</option>
        <option value="max-2">最多2排</option>
        <option value="max-3">最多3排</option>
        <option value="max-4">最多4排</option>
        <option value="max-5">最多5排</option>
        <option value="max-6">最多6排</option>
      </select>
    </div>
    <div class="layui-form-mid layui-word-aux">链接列表显示样式</div>
  </div>
  
  
  <div class="layui-form-item">
    <label class="layui-form-label">标题</label>
    <div class="layui-input-inline" style="width: 50%;">
    <input  id = "title" name="title" value = "<?php echo getconfig($config.'title','上网，从这里开始！');?>" placeholder="" autocomplete="off" class="layui-input" >
    </div>
    <div class="layui-form-mid layui-word-aux">搜索框上面的标题</div>
  </div>
  <div class="layui-form-item">
    <label class="layui-form-label">滚动广告</label>
    <div class="layui-input-inline" style="width: 50%;">
    <input  id = "fad" name="fad" value = "<?php echo getconfig($config.'fad');?>" placeholder="" autocomplete="off" class="layui-input" >
    </div>
    <div class="layui-form-mid layui-word-aux">滚动的文字广告</div>
  </div> 
  
  <div class="layui-form-item" >
    <label class="layui-form-label"><a href="https://gitee.com/tznb/OneNav/wikis/%E4%B8%BB%E9%A2%98%E8%AF%B4%E6%98%8E/quality%20%E4%B8%BB%E9%A2%98%E8%AF%B4%E6%98%8E" target="_blank" rel="nofollow" >文字广告</a></label>
    <div class="layui-input-inline" style="width:73%;">
        <textarea name="txtad" id="txtad" placeholder="← 点击它查看使用说明" class="layui-textarea"><?php echo getconfig($config.'txtad');?></textarea>
    </div>
  </div>
  <div class="layui-form-item" style=" padding-top: 10px; ">
    <label class="layui-form-label"><a href="https://gitee.com/tznb/OneNav/wikis/%E4%B8%BB%E9%A2%98%E8%AF%B4%E6%98%8E/quality%20%E4%B8%BB%E9%A2%98%E8%AF%B4%E6%98%8E" target="_blank" rel="nofollow" >图片广告</a></label>
    <div class="layui-input-inline" style="width:73%;">
        <textarea name="ads_w" id="ads_w" placeholder="← 点击它查看使用说明" class="layui-textarea"><?php echo getconfig($config.'ads_w','<a target="_blank" href="https://www.hbd0.cn/archives/957.html"><img src="./templates/quality/img/20221107035428687.jpg" alt="广告位招租" width="100%"><i class="gg-icon"></i></a>');?></textarea>
    </div>
  </div>
  
  <div class="layui-form-item" style=" padding-top: 10px; ">
    <label class="layui-form-label"><a href="https://gitee.com/tznb/OneNav/wikis/%E4%B8%BB%E9%A2%98%E8%AF%B4%E6%98%8E/quality%20%E4%B8%BB%E9%A2%98%E8%AF%B4%E6%98%8E" target="_blank" rel="nofollow" >轮播图片</a></label>
    <div class="layui-input-inline" style="width:73%;">
        <textarea name="ad_slider" id="ad_slider" placeholder="← 点击它查看使用说明" class="layui-textarea"><?php echo getconfig($config.'ad_slider','<div class="slide"><div class="slideCopy"><p style="margin-bottom: 5px;">热门广告位招租</p></div><a href="https://bing.img.run/rand_1366x768.php" target="_blank"><img src="https://bing.img.run/rand_1366x768.php"></a></div>');?></textarea>
    </div>
  </div>

  <div class="layui-form-item" style=" padding-top: 10px; ">
    <label class="layui-form-label"><a href="https://gitee.com/tznb/OneNav/wikis/%E4%B8%BB%E9%A2%98%E8%AF%B4%E6%98%8E/quality%20%E4%B8%BB%E9%A2%98%E8%AF%B4%E6%98%8E" target="_blank" rel="nofollow" >导航链接</a></label>
    <div class="layui-input-inline" style="width:73%;">
        <textarea name="nav-link" id="nav-link" placeholder="← 点击它查看使用说明" class="layui-textarea"><?php echo getconfig($config.'nav-link');?></textarea>
    </div>
  </div>
  
  <div class="layui-form-item" style="padding-top: 10px;">
    <label class="layui-form-label">背景图URL</label>
    <div class="layui-input-inline" style="width: 73%;">
    <input type="url" id = "backgroundURL" name="backgroundURL" value = "<?php echo getconfig($config.'backgroundURL','./templates/quality/img/background.jpg');?>" placeholder="请输入图片URL" autocomplete="off" class="layui-input">
    </div>
  </div>
    
 <div class="layui-form-item" style="padding-top: 10px;">
    <div class="layui-input-block">
      <button class="layui-btn" lay-submit lay-filter="edit_homepage">保存</button>
    </div>
  </div>
</form>

    </div>
<!-- 内容主题区域END -->
</div>
<script src = '<?php echo $libs?>/jquery/jquery-3.6.0.min.js'></script>
<script src = '<?php echo $libs?>/Layui/v2.6.8/layui.js'></script>

<script>
var u = '<?php echo $u?>';
var t = '<?php echo $theme;?>';
var s = '<?php echo $_GET['source'];?>';

$('#hitokoto').val(document.getElementById('hitokoto-input').value); 
$('#hefeng').val(document.getElementById('hefeng-input').value); 
$('#search').val(document.getElementById('search-input').value); 
$('#icon').val(document.getElementById('icon-input').value); 
$('#links-lists').val(document.getElementById('links-lists-input').value); 
$('#nav-bar').val(document.getElementById('nav-bar-input').value);
$('#dblclick').val(document.getElementById('dblclick-input').value);


layui.use(['form','dropdown'], function(){
    var form = layui.form;
    var dropdown = layui.dropdown;
    
dropdown.render({
    elem: '#backgroundURL'
    ,data: [{
      title: '默认背景图'
      ,url: './templates/quality/img/background.jpg'
      ,author:'https://gitee.com/tznb/OneNav'
    },{
      title: '博天(自适应/动漫)'
      ,url: 'https://api.btstu.cn/sjbz/api.php?lx=dongman&method=zsy'
      ,author:'https://api.btstu.cn/doc/sjbz.php'
    },{
      title: '博天(自适应/妹子)'
      ,url: 'https://api.btstu.cn/sjbz/api.php?lx=meizi&method=zsy'
      ,author:'https://api.btstu.cn/doc/sjbz.php'
    },{
      title: '博天(自适应/风景)'
      ,url: 'https://api.btstu.cn/sjbz/api.php?lx=fengjing&method=zsy'
      ,author:'https://api.btstu.cn/doc/sjbz.php'
    },{
      title: '博天(自适应/随机)'
      ,url: 'https://api.btstu.cn/sjbz/api.php?lx=suiji&method=zsy'
      ,author:'https://api.btstu.cn/doc/sjbz.php'
    },{ 
      title: '姬长信(PC/每日必应)'
      ,url: 'https://api.isoyu.com/bing_images.php'
      ,author:'https://api.isoyu.com'
      ,n:'姬长信'
    },{
      title: '樱花(PC/动漫)'
      ,url: 'https://www.dmoe.cc/random.php'
      ,author:'https://www.dmoe.cc'
    },{
      title: '梁炯灿(PC/动漫)'
      ,url: 'https://tuapi.eees.cc/api.php?category=dongman&type=302'
      ,author:'https://tuapi.eees.cc'
    },{
      title: '梁炯灿(PC/风景)'
      ,url: 'https://tuapi.eees.cc/api.php?category=fengjing&type=302'
      ,author:'https://tuapi.eees.cc'
    },{
      title: '梁炯灿(PC/必应)'
      ,url: 'https://tuapi.eees.cc/api.php?category=biying&type=302'
      ,author:'https://tuapi.eees.cc'
    },{
      title: '梁炯灿(PC/美女)'
      ,url: 'https://tuapi.eees.cc/api.php?category=meinv&type=302'
      ,author:'https://tuapi.eees.cc'
    },{
      title: '苏晓晴(PC/动漫)'
      ,url: 'https://acg.toubiec.cn/random.php'
      ,author:'https://acg.toubiec.cn'
    },{
      title: '墨天逸(PC/动漫)'
      ,url: 'https://api.mtyqx.cn/api/random.php'
      ,author:'https://api.mtyqx.cn/'
    },{
      title: '小歪(PC/动漫)'
      ,url: 'https://api.ixiaowai.cn/api/api.php'
      ,author:'https://api.ixiaowai.cn'
    },{
      title: '小歪(PC/MC酱)'
      ,url: 'https://api.ixiaowai.cn/mcapi/mcapi.php'
      ,author:'https://api.ixiaowai.cn'
    },{
      title: '小歪(PC/风景)'
      ,url: 'https://api.ixiaowai.cn/gqapi/gqapi.php'
      ,author:'https://api.ixiaowai.cn' 
    },{
      title: '保罗(PC/动漫)'
      ,url: 'https://api.paugram.com/wallpaper/?source=sina'
      ,author:'https://api.paugram.com/help/wallpaper'
      ,n:'保罗'
    },{
      title: '樱道(PC/动漫)'
      ,url: 'https://api.r10086.com/img-api.php?type=动漫综合1'
      ,author:'https://img.r10086.com/'
      ,n:'樱道'
    }]
    ,click: function(obj){
        if (obj.n == '樱道'){
            layeropen('官方还有很多分类哦<br />感兴趣的自己去看<br />访问速度比较慢<br />友链有个镜像接口比较快','https://img.r10086.com/');
        }else if (obj.n == '保罗'){
            layeropen('官方还有其他接口<br />感兴趣的自己去看<br />有缓存','https://api.paugram.com/help/wallpaper');
        }else if (obj.n == '姬长信'){
            layeropen('官方还有其他接口<br />感兴趣的自己去看<br />慢且不稳','https://api.isoyu.com/#/壁纸模块');
        }
      this.elem.val(obj.url);
    }
    ,style: 'width: 235px;'
  });


//保存设置
form.on('submit(edit_homepage)', function(data){
    $.post('./index.php?c=admin&page=config&u='+u+'&Theme='+t,data.field,function(data,status){
      //如果添加成功
      if(data.code == 0) {
        if (s == 'admin'){
            layer.msg(data.msg, {icon: 1});
            return false;
        }else{
            parent.location.reload(); //刷新页面
        }
      }
      else{
        layer.msg(data.msg, {icon: 5});
      }
    });
    console.log(data.field);
    return false; 
});
});
</script>
</body>
</html>