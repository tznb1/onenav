<?php if(basename($_SERVER['PHP_SELF']) == basename(__FILE__)) header("Location:/"); ?>
<!--<script src="https://lf6-cdn-tos.bytecdntp.com/cdn/expire-1-M/bootstrap/4.5.3/js/bootstrap.min.js" type="application/javascript"></script>-->
<script>

//如果URL锚点为空则默认搜索获取输入焦点方便快速搜索
if(window.location.hash == ''){
    document.getElementById('search-text').focus();
}
//导航条点击事件
function point(key){
    $('html, body').animate({scrollTop: $('#group_' + key ).offset().top}, 300);
}


<?php if(getconfig($config.'dblclick','top') != '0') { ?>
//双击事件
var timeoutID = null;
var dblclick = "<?php echo getconfig($config.'dblclick','top'); ?>";
$('body').on('dblclick',function(e){
    clearTimeout(timeoutID);  
    //排除部分标签
    if( !/INPUT|H2|SPAN/.test(e.target.nodeName)){
        if(dblclick == 'top'){
            //scrollTo(0,0);
            $("html,body").animate({scrollTop:0},100);
        }else if(dblclick == 'search'){
            document.getElementById('search-text').focus();
        }
    }
    //console.log(e.target.nodeName);
});
<?php } ?>

</script>
<script src="<?php echo $Theme;?>/js/bootstrap.min.js" type="application/javascript"></script>
<script src="<?php echo $Theme;?>/js/script.js?v=20221225"></script>
<script src="<?php echo $Theme;?>/js/typed.js"></script>
<script src="<?php echo $Theme;?>/js/svg.js"></script>
<div style="display:none;" class="back-to" id="toolBackTop"> 
<a title="返回顶部" onclick="window.scrollTo(0,0);return false;" href="#top" class="back-top"></a> 
</div> 
<div class="mt-5 mb-3 footer text-muted text-center"> 
    <!--备案信息-->
    Copyright © <?php echo date('Y');?> All Rights Reserved <a target="_blank" href="" title="<?php echo $site['title'];?>"><?php echo $site['title'];?></a> &nbsp;&nbsp;<?php if($ICP != ''){echo '<img src="'.$Theme.'/img/icp.png" width="16px" height="16px" /><a href="https://beian.miit.gov.cn" target="_blank">'.$ICP.'</a>';} ?>
    <!--版权信息-->
    <p>Powered by&nbsp;&nbsp;<a target="_blank" href="https://github.com/helloxz/onenav" title="简约导航/书签管理器" target="_blank" rel="nofollow">落幕</a>&nbsp;&nbsp;The theme by&nbsp;&nbsp;<a href="https://www.hbd0.cn/archives/2245.html" target="_blank" rel="nofollow">七夏</a></p>
    <?php echo $site['custom_footer']; ?>
    <?php echo $Ofooter; ?>
  </div>  
</html>
<?php if(getconfig($config.'search','1') == '1'){ ?>
<script type='text/javascript' src="<?php echo $libs?>/Other/holmes.js"></script>
<script>
var h = holmes({
    input: '#search-text',
    find: '.url-card',
	hiddenAttr: true
});
</script>
<?php } ?>