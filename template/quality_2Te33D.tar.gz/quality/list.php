<?php if(getconfig($config.'nav-bar','1') == '1'){ ?>
     <div class="sites-tabs-container d-flex align-items-end"> 
      <div class="d-flex flex-fill container-lg overflow-hidden text-nowrap" style=" margin-left: 10px; margin-right: 10px; max-width: calc(100% - 55px);"> 
       <div class="d-flex sites-tabs-btn"> 
        <?php foreach ($categorys as $category) {
    echo '<a class="sites-tab-btn" href="javascript:void(0);" onclick = "point('.$category["id"].');">'. $category["name"] . '</a>';
        } ?>
       </div> 
      </div> 
     </div> 
<?php }?>
<?php
    foreach ( $categorys as $category ) {
        $fid = $category['id'];
        $links = get_links($fid);
        //如果分类是私有的
        if( $category['property'] == 1 ) {
            $property = '<i class="fa fa-lock" style = "color:#5FB878"></i>';
        }
        else {
            $property = '';
        }
?>

<ul class="mylist row link-space">
    <li id="group_<?php echo geticon($category['id']) ?>" class="title"><span><?php echo geticon($category['Icon']).'&nbsp;'.$category['name'].'&nbsp;'.$property;?></span><span class="description"><?php echo $category['description'] ?></span></li><div class="links-lists">
    
                <?php
foreach ($links as $link) {
    //遍历链接
    $link['description'] = empty($link['description']) ? '作者很懒，没有填写描述。' : $link['description'];
    //判断是否是私有
    if( $link['property'] == 1 ) {
        $privacy_class = 'property';
    }
    else {
        $privacy_class = '';
    }
?>
        <li class="col-3 col-sm-3 col-md-3 col-lg-1 url-card">
            <?php if($link['property'] == 1 ) { echo '<div class="angle"></div>';}?>
            <a rel="nofollow" href="<?php echo geturl($link); ?>" title="<?php echo $link['description']; ?>" target="_blank">
        <img src="<?php echo geticourl($IconAPI,$link); ?>" alt="<?php echo $link['title']; ?>" />
        <span><?php echo $link['title']; ?></span>
    </a>
</li>
<?php } ?>
    </ul>
<?php } ?>