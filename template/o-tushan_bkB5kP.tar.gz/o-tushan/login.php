<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="<?php echo $dir ?>/css/Login.css">
  <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no" />
  <title>OneNav Extend 登录</title>
  <script>
    window.onload = function () {
      document.querySelector(".login").style.opacity = 1;
    }
  </script>
</head>

<body class="login">
  <div class="root">
    <section class="left">
      <img class="cover" src="<?php echo $dir ?>/image/backgroundLogin.png" />
    </section>
    <section class="right">
      <!-- PC版的样式 -->
      <h2>OneNav Extend 后台管理系统</h2>
      <div class="login_frame">
        <div class="login_box">
          <h4>管理登录</h4>
          <h6>亲爱的管理员欢迎回来！</h6>
          <form >
            <div class="inp">
              <span class="label">用户名</span>
              <input type="text" name="user" id ="user1" placeholder="请输入账号" value="<?php echo Get('u'); ?>"/>
            </div>
            <div class="inp">
              <span class="label">用户密码</span>
              <input type="password" name="pass"  id ="pass1" placeholder="请输入密码" />
            </div>
            <div class="submit">
              <input type="button" class="submit" value="登录" onclick="login(1)">
            </div>
          </form>
        </div>
      </div>
    </section>
  </div>
  <div class="mobile">
    <!-- 手机版的样式 -->
    <h1>OneNav Extend</h1>
    <form >
      <div class="inp">
        <span class="label">用户名</span>
        <input type="text" name="user" id ="user2" placeholder="请输入账号" />
      </div>
      <div class="inp">
        <span class="label">用户密码</span>
        <input type="password" name="pass" id ="pass2" placeholder="请输入密码" />
      </div>
      <div class="submit">
        <input type="submit" class="submit" value="登录" onclick="login(2)">
      </div>
    </form>
  </div>
  <footer><img src='<?php echo $dir ?>/image/copyright-fill.png' />2022 Powered by 落幕</footer>
</body>
<script src = '<?php echo $libs?>/jquery/jquery-3.6.0.min.js'></script>
<script src = '<?php echo $libs?>/jquery/jquery.md5.js'></script>
<script>
//回车事件
$("#user1").keydown(function(e) {
    if (e.keyCode == 13) {
        login(1);
    }
});
$("#pass1").keydown(function(e) {
    if (e.keyCode == 13) {
        login(1);
    }
});


$("#user2").keydown(function(e) {
    if (e.keyCode == 13) {
        login(2);
    }
});
$("#pass2").keydown(function(e) {
    if (e.keyCode == 13) {
        login(2);
    }
});
  //登录事件
  function login($i) {
      var user = $('#user'+ $i).val();
      var pass = $('#pass'+ $i).val();
      if(user.length == 0 || pass.length == 0 ){
          alt('账号密码不能为空');
          return;
      }
      var pass = $.md5(pass);
      $.post('./index.php?c=<?php echo $c; ?>&u=' + user,{'user':user,'pass':pass},function(re,status){
            if(re.code == 0) {
                window.location.href = './index.php?c=admin&u='+ re.u;
            }else{
                alt(re.msg);
            }
      });
      console.log(user +pass);
  }
  //自己封装的弹出框
  function alt(text) {
    const t = document.createElement("div")
    t.innerText = text;
    Object.assign(t.style, {
      position: 'fixed',
      maxWidth: '300px',
      top: '48%',
      left: '0px',
      right: '0px',
      margin: '0 auto',
      color: '#000',
      background: '#d3cbcb',
      boxShadow: '0px 3px 4px rgba(197, 197, 197, 0.115)',
      padding: '15px 20px',
      borderRadius: '8px',
      transition: 'all .5s',
      opacity: 0,
      transform: 'translateY(-10px)'
    })
    document.body.append(t)
    setTimeout(_ => {
      t.style.transform = 'translateY(10px)'
      t.style.opacity = 1;
    }, 100)
    setTimeout(_ => {
      t.style.transform = 'translateY(-10px)'
      t.style.opacity = 0;
    }, 3000)
  }
</script>

</html>