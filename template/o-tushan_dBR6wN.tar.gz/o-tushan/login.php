<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="<?php echo $dir ?>/css/Login.css">
  <link rel="stylesheet" href="<?php echo $libs?>/Layui/v2.6.8/css/layui.css">
  <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no" />
  <title>OneNav Extend 登录</title>
  <script>
    window.onload = function () {
      document.querySelector(".login").style.opacity = 1;
    }
  </script>
</head>

<body class="login">
  <div class="root">
    <section class="left">
      <img class="cover" src="<?php echo $dir ?>/image/backgroundLogin.png" />
    </section>
    <section class="right">
      <!-- PC版的样式 -->
      <h2>OneNav Extend 后台管理系统</h2>
      <div class="login_frame">
        <div class="login_box">
          <h4>管理登录</h4>
          <h6>亲爱的管理员欢迎回来！</h6>
          <form class="layui-form login-bottom">
            <input name="type" value="pc" style = "display:none;"/>
            <div class="inp">
              <span class="label">用户名</span>
              <input type="text" name="user" placeholder="请输入账号" value="<?php echo Get('u'); ?>"/>
            </div>
            <div class="inp">
              <span class="label">用户密码</span>
              <input type="password" name="pass" placeholder="请输入密码" />
            </div>
            <div class="submit">
              <input type="submit" lay-submit lay-filter="login" class="submit" value="登录">
            </div>
          </form>
        </div>
      </div>
    </section>
  </div>
  <div class="mobile">
    <!-- 手机版的样式 -->
    <h1>OneNav Extend</h1>
    <form class="layui-form login-bottom">
      <input name="type" value="mobile" style = "display:none;"/>
      <div class="inp">
        <span class="label">用户名</span>
        <input type="text" name="user" placeholder="请输入账号" />
      </div>
      <div class="inp">
        <span class="label">用户密码</span>
        <input type="password" name="pass" placeholder="请输入密码" />
      </div>
      <div class="submit">
        <input type="submit" lay-submit lay-filter="login" class="submit" value="登录">
      </div>
    </form>
  </div>
  <footer><img src='<?php echo $dir ?>/image/copyright-fill.png' />2022 Powered by 落幕</footer>
</body>
<script src = '<?php echo $libs?>/Layui/v2.6.8/layui.js'></script>
<script src = '<?php echo $libs?>/jquery/jquery-3.6.0.min.js'></script>
<script src = '<?php echo $libs?>/jquery/jquery.md5.js'></script>

<script>
 layui.use(['form','jquery'], function () {
        var $ = layui.jquery,
            form = layui.form,
            layer = layui.layer;
        
        // 进行登录操作
        form.on('submit(login)', function (data) {
            console.log(data.field) 
            data = data.field;
            if (data.user == '') {
                layer.msg('用户名不能为空',{icon: 5});
                return false;
            }
            if (data.pass == '') {
                layer.msg('密码不能为空',{icon: 5});
                return false;
            }
            data.pass = $.md5(data.pass);
            $.post('./index.php?c=<?php echo $c; ?>&u='+data.user,data,function(re,status){
                if(re.code == 0) {
                    if(data.type == 'pc'){
                        window.location.href = './index.php?c=admin&u='+ re.u;
                    }else{
                        window.location.href = './';
                    }
                }else{
                    layer.msg(re.msg, {icon: 5});
                }
            });
            return false;
        });
    });
</script>
</html>