<!DOCTYPE html>
<html lang="zh-ch" xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta charset="utf-8" />
	<title><?php echo $site['Title'];?></title>
	<?php if($site['keywords'] !=''){echo '<meta name="keywords" content="'.$site['keywords'].'"/>'."\n";}?>
	<?php if($site['description'] !=''){echo '<meta name="description" content="'.$site['description'].'"/>'."\n";}?>
	<meta name="generator" content="EverEdit" />
	<meta name="author" content="xiaoz<www.xiaoz.me>" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel='stylesheet' href='<?php echo $libs?>/MDUI/v1.0.1/css/mdui.min.css'>
	<link rel='stylesheet' href='<?php echo $libs?>/ContextMenu/2.9.2/jquery.contextMenu.min.css'>
	<link rel="stylesheet" href="<?php echo $libs?>/Font-awesome/4.7.0/css/font-awesome.css">
	<link rel="stylesheet" href="<?php echo $libs?>/Layui/v2.6.8/css/layui-icon.css">
	<link rel="stylesheet" href="<?php echo $Theme?>/static/style.css?v=<?php echo $version; ?>">
	<script src = '<?php echo $libs?>/MDUI/v1.0.1/js/mdui.min.js'></script>
	<?php echo $site['custom_header']; ?>
</head>
<body class = "mdui-drawer-body-left mdui-appbar-with-toolbar mdui-theme-primary-light-green mdui-theme-accent-pink mdui-loaded mdui-text-color-black">
	<!--背景图片修改-->
<body background=<?php echo $Theme?>/bg/bg.jpg style=" background-repeat:no-repeat ; background-size:100% 100%;background-attachment: fixed;">
	<!--导航工具-->
	<header class = "mdui-appbar mdui-appbar-fixed">
		<div class="mdui-toolbar mdui-color-theme">
		<span class="mdui-btn mdui-btn-icon mdui-ripple mdui-ripple-white" mdui-drawer="{target: '#drawer', swipe: true}"><i class="mdui-icon material-icons">menu</i></span>
		  <a href="" class = "mdui-typo-headline"><span class="mdui-typo-title"><?php echo $site['logo'];?></span></a>
		  <div class="mdui-toolbar-spacer"></div>
		  <!-- 新版搜索框 -->
		  	<div class="mdui-col-md-4 mdui-col-xs-6">
				<div class="mdui-textfield mdui-textfield-floating-label">
					<input class="mdui-textfield-input search" id="bdcsMain" style = "color:#FFFFFF;" placeholder="输入书签关键词进行搜索" type="text" />
				</div>
			</div>
			<!-- 新版搜索框END -->
			<!--自定义搜索开始-->
		<p>
	<center>
	<button class="mdui-btn mdui-btn-dense mdui-color-theme-accent mdui-ripple" type="submit" onclick="window.open('https://www.baidu.com/s?wd='+document.getElementById('bdcsMain').value)">百度一下</button>
	<!--<button class="mdui-btn mdui-btn-dense mdui-color-theme-accent mdui-ripple" type="submit" onclick="window.open('https://www.google.com/search?q='+document.getElementById('bdcsMain').value)">谷歌</button>-->
	</center>
			<!-- 天气设置开始-->
	<div id="he-plugin-simple"></div>
<script>
WIDGET = {
  "CONFIG": {
    "modules": "01234",
    "background": "5",
    "tmpColor": "FFFFFF",
    "tmpSize": "16",
    "cityColor": "FFFFFF",
    "citySize": "16",
    "aqiColor": "FFFFFF",
    "aqiSize": "16",
    "weatherIconSize": "24",
    "alertIconSize": "18",
    "padding": "10px 10px 10px 10px",
    "shadow": "0",
    "language": "auto",
    "fixed": "false",
    "vertical": "center",
    "horizontal": "left",
    "key": "96a270c80ba94483bbd55f0c8b7569b0"
  }
}
</script>
<script src="https://widget.qweather.net/simple/static/js/he-simple-common.js?v=2.0"></script>			
			<!-- 天气设置结束-->			
		  <a class = "mdui-hidden-xs" href="https://gitee.com/tznb/OneNav" rel = "nofollow" target="_blank" class="mdui-btn mdui-btn-icon mdui-ripple mdui-ripple-white" mdui-tooltip="{content: '查看 Github'}">
      <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 36 36" enable-background="new 0 0 36 36" xml:space="preserve" class="mdui-icon" style="width: 24px;height:24px;">
        <path fill-rule="evenodd" clip-rule="evenodd" fill="#ffffff" d="M18,1.4C9,1.4,1.7,8.7,1.7,17.7c0,7.2,4.7,13.3,11.1,15.5
	c0.8,0.1,1.1-0.4,1.1-0.8c0-0.4,0-1.4,0-2.8c-4.5,1-5.5-2.2-5.5-2.2c-0.7-1.9-1.8-2.4-1.8-2.4c-1.5-1,0.1-1,0.1-1
	c1.6,0.1,2.5,1.7,2.5,1.7c1.5,2.5,3.8,1.8,4.7,1.4c0.1-1.1,0.6-1.8,1-2.2c-3.6-0.4-7.4-1.8-7.4-8.1c0-1.8,0.6-3.2,1.7-4.4
	c-0.2-0.4-0.7-2.1,0.2-4.3c0,0,1.4-0.4,4.5,1.7c1.3-0.4,2.7-0.5,4.1-0.5c1.4,0,2.8,0.2,4.1,0.5c3.1-2.1,4.5-1.7,4.5-1.7
	c0.9,2.2,0.3,3.9,0.2,4.3c1,1.1,1.7,2.6,1.7,4.4c0,6.3-3.8,7.6-7.4,8c0.6,0.5,1.1,1.5,1.1,3c0,2.2,0,3.9,0,4.5
	c0,0.4,0.3,0.9,1.1,0.8c6.5-2.2,11.1-8.3,11.1-15.5C34.3,8.7,27,1.4,18,1.4z"></path>
	  </svg>	  
	  <?php
		if( $is_login ) {
	  ?>	
	  <a class = "mdui-hidden-xs" href="./index.php?c=admin&u=<?php echo $u?>" title = "后台管理" target="_blank" class="mdui-btn mdui-btn-icon"><i class="mdui-icon material-icons">account_circle</i></a>
	  <?php }elseif ($site['GoAdmin']) {  ?>
		<a class = "mdui-hidden-xs" href="./index.php?c=<?php if($login =='login'){echo $login;}else{echo $Elogin;}?>&u=<?php echo $u?>" title = "登录后台" target="_blank" class="mdui-btn mdui-btn-icon"><i class="mdui-icon material-icons">account_circle</i></a>
	  <?php } ?>
    </a>
		</div>
	</header>
	<!--导航工具END-->
	<!-- 添加按钮 -->
	<?php
		if( $is_login && $site['quickAdd'] ) {
	?>	
	<div class="right-button mdui-hidden-xs" style="position: fixed;right:10px;bottom:80px;z-index:99;">
		<div>
		<button title = "快速添加链接" id = "add" class="mdui-fab mdui-color-theme-accent mdui-ripple mdui-fab-mini"><i class="mdui-icon material-icons">add</i></button>
		</div>
	</div>
	<?php } ?>
	<!-- 添加按钮END -->
	<?php if($site['gotop'] ) {?>
	<!-- 返回顶部按钮 -->
	<div id="top"></div>
	<div class="top mdui-shadow-10">
	<a href="javascript:;" title="返回顶部" onclick="gotop()"><i class="mdui-icon material-icons">arrow_drop_up</i>
	</div>
	<!-- 返回顶部END -->
	<?php } ?>
		<!--左侧抽屉导航-->
	<!-- 默认抽屉栏在左侧 -->
	<div class="mdui-drawer" id="drawer">
	  <ul class="mdui-list">
	  	<?php
			//遍历分类目录并显示
			foreach ($categorys as $category) {
			//var_dump($category);
		?>
		<a href="#category-<?php echo $category['id']; ?>">
			<li class="mdui-list-item mdui-ripple">
				<div class="mdui-list-item-content category-name"><?php echo geticon($category['Icon']); ?><?php echo htmlspecialchars_decode($category['name']); ?></div>
			</li>
		</a>
	    
		<?php } ?>
		<a href="https://www.xiaoz.me/" target="_blank" title="小z博客">
			<li class="mdui-list-item mdui-ripple">
			<div class="mdui-list-item-content category-name"><i class="fa fa-user-circle"></i> About</div>
			</li>
		</a>
		
		<?php
		if( $is_login ) {
		?>	
		<a href="./index.php?c=admin&u=<?php echo $u?>" title="后台管理" class="mdui-hidden-sm-up">
		<li class="mdui-list-item mdui-ripple">
		<div class="mdui-list-item-content category-name"><i class="fa fa-dashboard"></i> 后台管理</div>
		</li>
		</a>
	  <?php }elseif ($site['GoAdmin']) {  ?>
		<a href="./index.php?c=<?php if($login =='login'){echo $login;}else{echo $Elogin;}?>&u=<?php echo $u?>" title="手机登录" class="mdui-hidden-sm-up">
			<li class="mdui-list-item mdui-ripple">
			<div class="mdui-list-item-content category-name"><i class="fa fa-dashboard"></i> 登录</div>
			</li>
		</a>
	  <?php } ?>
	  </ul>
	</div>
	<!--左侧抽屉导航END-->

	<!--正文内容部分-->
	<div class="mdui-container">
		<!-- 搜索框END -->
		<div class="mdui-row">
			<!-- 遍历分类目录 -->
            <?php foreach ( $categorys as $category ) {
                $fid = $category['id'];
                $links = get_links($fid);
                //如果分类是私有的(锁的颜色在这里改)
                if( $category['property'] == 1 ) {
                    $property = '<i class="fa fa-expeditedssl" style = "color:#ff4081"></i>';
                }
                else {
                    $property = '';
                }
            ?>
			<div id = "category-<?php echo $category['id']; ?>" class = "mdui-col-xs-12 mdui-typo-title cat-title">
				<?php echo geticon($category['Icon']).htmlspecialchars_decode($category['name']); ?> <?php echo $property; ?>
				<span class = "mdui-typo-caption"><?php echo $category['description']; ?></span>
			</div>
			<!-- 遍历链接 -->
			<?php
				foreach ($links as $link) {
					//默认描述
					$link['description'] = empty($link['description']) ? '作者很懒，没有填写描述。' : $link['description'];
			?>
			<div class="mdui-col-lg-2 mdui-col-md-3 mdui-col-sm-4 mdui-col-xs-6 link-space" id = "id_<?php echo $link['id']; ?>" link-title = "<?php echo $link['title']; ?>" link-url = "<?php echo $link['url']; ?>">
				<!--定义一个卡片-->
				<div class="mdui-card link-line mdui-hoverable">
						<!-- 如果是私有链接，则显示角标 -->
						<?php if($link['property'] == 1 ) { ?>
						<div class="angle">
							<span> </span>
						</div>
						<?php } ?>
						<!-- 角标END---padding-top:6px文字距离框的高度-->
						<?php 
						if ($site['urlz']  == 'on'  ){
						    ?><a href="<?php echo $link['url']; ?>" target="_blank" title = "<?php echo $link['description']; ?>"><?php
						}else{
						    ?><a href="./index.php?c=click&id=<?php echo $link['id'].'&u='.$u; ?>" target="_blank" title = "<?php echo $link['description']; ?>"><?php
						};
						?>
							<div class="mdui-card-primary" style = "padding-top:6px;">
									<div class="mdui-card-primary-title link-title">
										<img src="<?php echo geticourl($IconAPI,$link); ?>" alt="HUAN" width="16" height="16">
										<span class="link_title"><?php echo $link['title']; ?></span> 
									</div>

							</div>
						</a>
						
					
					<!-- 卡片的内容end -->
					<div class="mdui-card-content mdui-text-color-black-disabled" style="padding-top:0px;"><span class="link-content"><?php echo $link['description']; ?></span></div>
				</div>
				<!--卡片END-->
			</div>
			<?php } ?>
			<!-- 遍历链接END -->
			<?php } ?>
		</div>
		<!-- row end -->

		
	</div>
	<div class="mdui-divider" style = "margin-top:2em;"></div>
	<!--正文内容部分END-->
	<!-- footer部分 -->
	<!-- 未经作者授权，请勿去掉版权，否则可能影响作者更新代码的积极性或直接放弃维护此项目。 -->
	<footer>
		© 2022 Powered by <a target = "_blank" href="https://gitee.com/tznb/OneNav" title = "简约导航/书签管理器" rel = "nofollow">OneNav</a>.The author is <a href="https://www.xiaoz.me/" target="_blank" title = "小z博客">xiaoz.me</a>
	<?php if($ICP != ''){echo '<a href="https://beian.miit.gov.cn" target="_blank">'.$ICP.'</a>';} ?>
    <?php echo $site['custom_footer']; ?>
    <?php echo $Ofooter; ?>
	</footer>
	<!-- footerend -->
</body>
<script src = "<?php echo $libs?>/jquery/jquery-3.6.0.min.js"></script>
<script src = "<?php echo $libs?>/Layer/v3.3.0/layer.js"></script> 
<script src = "<?php echo $libs?>/ContextMenu/2.9.2/jquery.contextMenu.min.js"></script>
<script src = "<?php echo $libs?>/Other/ClipBoard.min.js"></script>
<script src = "<?php echo $libs?>/Other/holmes.js"></script>
<script src = "<?php echo $Theme?>/static/embed.js?v=<?php echo $version; ?>"></script>
<script>
var u = '<?php echo $u?>';
<?php echo $onenav['right_menu']; ?>
</script>
<?php echo $onenav['extend']; ?>
</html>
