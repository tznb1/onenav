<?php

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    Writeconfig($config.'default_category_id',intval($_POST['default_category_id']));
    Writeconfig($config.'default_search',$_POST['default_search']);
    msg(0,"修改成功");
}

?>
 
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <title>主题DIY</title>
  <link rel='stylesheet' href='<?php echo $libs?>/Layui/v2.6.8/css/layui.css'>
  <style>    
    .layui-form-item {
        margin-bottom: 10px;
        height: 38px;
    }
  </style>
</head>
<body>
<div>
<!-- 内容主体区域 -->
<div class="layui-row" style = "margin-top:18px;">
	<div class="layui-container">
    <div class="layui-col-lg6 layui-col-md-offset3">
    <form class="layui-form">

  <div class="layui-form-item">
    <input id="default_category_id-input" type="hidden" value="<?php echo getconfig($config.'default_category_id');?>">
    <label class="layui-form-label">默认分类</label>
    <div class="layui-input-inline">
      <select lay-verify="required"  id="default_category_id" name="default_category_id" lay-search>
        <?php $categorys = $db->select('on_categorys','*',["ORDER" =>  ["weight" => "DESC"]]); foreach ($categorys as $category) {    ?>
        <option value="<?php echo $category['id'] ?>"><?php echo $category['name']; ?></option>
        <?php } ?>
      </select>
    </div>
    <div class="layui-form-mid layui-word-aux">默认展示该分类下的链接</div>
  </div>
  <div class="layui-form-item">
    <input id="default_search-input" type="hidden" value="<?php echo getconfig($config.'default_search','baidu');?>">
    <label class="layui-form-label">搜索引擎</label>
    <div class="layui-input-inline">
      <select lay-verify="required"  id="default_search" name="default_search" lay-search>
        <option value="baidu">百度</option>
        <option value="google">Google</option>
        <option value="bing">必应</option>
        <option value="sogou">搜狗</option>
        <option value="360">360搜索</option>
        <option value="zhihu">知乎</option>
        <option value="weibo">微博</option>
      </select>
    </div>
    <div class="layui-form-mid layui-word-aux">默认的搜索引擎</div>
  </div>
  <div class="layui-form-item">
    <div class="layui-input-block">
      <button class="layui-btn" lay-submit lay-filter="edit_homepage">保存</button>
    </div>
  </div>
</form>

    </div>
<!-- 内容主题区域END -->
</div>
<script src = '<?php echo $libs?>/jquery/jquery-3.6.0.min.js'></script>
<script src = '<?php echo $libs?>/Layui/v2.6.8/layui.js'></script>

<script>
var u = '<?php echo $u?>';
var t = '<?php echo $theme;?>';
var s = '<?php echo $_GET['source'];?>';
$('#default_category_id').val(document.getElementById('default_category_id-input').value); 
$('#default_search').val(document.getElementById('default_search-input').value); 


layui.use(['form'], function(){
    var form = layui.form;


//保存设置
form.on('submit(edit_homepage)', function(data){
    $.post('./index.php?c=admin&page=config&u='+u+'&Theme='+t,data.field,function(data,status){
      //如果添加成功
      if(data.code == 0) {
        if (s == 'admin'){
            layer.msg(data.msg, {icon: 1});
            return false;
        }else{
            parent.location.reload(); //刷新页面
        }
      }
      else{
        layer.msg(data.msg, {icon: 5});
      }
    });
    console.log(data.field);
    return false; 
});
});
</script>
</body>
</html>